<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>{{ config('app.name', 'Laravel') }}</title>
        <!-- Styles -->
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="{{ asset('css/shop-app.css') }}">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.css">
        
        <!-- Scripts -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <style>
          #country-list{float:left;list-style:none;margin-top:-3px;padding:0;width:190px;position: absolute;}
          #country-list li{padding: 10px; background: #f0f0f0; border-bottom: #bbb9b9 1px solid;}
          #country-list li:hover{background:#ece3d2;cursor: pointer;}
          #search-box{padding: 10px;border: #a8d4b1 1px solid;border-radius:4px;}
        </style>
    </head>
    <body>
        
        <x-corporateHeaderComponent />
        {{ $header }}
        <main class="main-content">
            {{ $slot }}
        </main>
        <x-corporateFooterComponent />
        @livewireScripts
        <script src="{{ asset('js/shop-app.js') }}"></script>
        <script type="text/javascript" defer>
            var input = document.getElementById("searchProducts");
            input.addEventListener("keyup", function(event) {
                if (event.keyCode === 13) {
                    return;
                }
            });


            $(document).ready(function(){
            $("#searchProducts").keyup(function(){
              $("#suggesstion-box").empty();
              $.ajax({
                type: "POST",
                url: "{{ route('autocomplete') }}",
                data: {"_token": "{{ csrf_token() }}",'keyword' : $(this).val() },
                success: function(data){
                  $("#suggesstion-box").show();
                  $("#suggesstion-box").html(data);
                  }
                });
              });
            });
          
          function selectProduct(val) {
            $("#searchProducts").val(val);
            $("#suggesstion-box").hide();
            $("#searchForm").submit();

          }
          
          
        </script>
        
        <script type="text/javascript" defer>
            var input = document.getElementById("searchProductsMobile");
            input.addEventListener("keyup", function(event) {
                if (event.keyCode === 13) {
                    return;
                }
            });


            $(document).ready(function(){
            $("#searchProductsMobile").keyup(function(){
              $("#suggesstion-box-mobile").empty();
              $.ajax({
                type: "POST",
                url: "{{ route('autocomplete') }}",
                data: {"_token": "{{ csrf_token() }}",'keyword' : $(this).val() },
                success: function(data){
                  $("#suggesstion-box-mobile").show();
                  $("#suggesstion-box-mobile").html(data);
                  }
                });
              });
            });
          
        </script>
        
        <!--to remove # in url on click of anchor href-->
        <script>
            $('a[href="#"]').click(function(event){
                event.preventDefault();
            });
        </script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.js"></script>
        
    </body>
</html>