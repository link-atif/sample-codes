@if(!empty($products))
	<ul id="country-list">
	@foreach($products as $p)
		<li onClick="selectProduct('{{ $p->title }}');">{{ $p->title }}</li>
	@endforeach
</ul>
@endif