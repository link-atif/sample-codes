
<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
    <main class="main-content">
        <div class="page-title-infoBar bg-grey">
            <div class="container">
                <nav class="breadcrumbs-wrapper">
                    <ul class="h-list breadcrumb-list">
                        <li><a href="{{ route('corporate') }}">Home</a></li>
                        <li><span>{{ $brand->name }}</span></li>
                    </ul>
                </nav>
                <div class="row">
                    <div class="col-sm-12 col-md-8">
                        <div class="title-head pt-15 pb-45">
                            <h2 class="mb-20">{{ $brand->name }}</h2>
                            <p>{{ nl2br($brand->short_description) }}</p>
                            @if($brand->website != null || $brand->email != null)
                            <ul class="h-list mb-20">
                                @if($brand->website != null)
                                <li><strong>Website: </strong> <a href="{{ $brand->website }}" target="_blank">{{ $brand->website }}</a>
                                </li>
                                @endif
                                @if($brand->website != null && $brand->email != null)
                                <li class="vl">|</li>
                                @endif
                                @if($brand->email != null)
                                <li><strong>Email: </strong> <a href="mailto:{{ $brand->email }}">{{ $brand->email }}</a>
                                </li>
                                @endif
                            </ul>
                            @endif
                            <a href="{{ route('brands-products', $brand->id) }}" class="btn btn-primary">View Products</a>
                        </div>
                    </div>
                    @if($brand->image != null )
                    <div class="col-sm-12 col-md-4">
                        <img class="bos-logo" src="{{ asset('images/brand/'.$brand->image) }}" alt="Baden Haus Logo" />
                    </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="container">
            <div class="brands-info-section">
                <div class="content-holder">
                    <p>{{ $brand->description }}</p>
                </div>
            </div>
        </div>
    </main>
</x-corporate-layout>