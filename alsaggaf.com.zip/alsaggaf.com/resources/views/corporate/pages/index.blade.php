<x-corporate-layout>
    <x-slot name="header">
        <x-sliderComponent :id="10" />
    </x-slot>
    <x-corporateCategoryListingComponent />
    <div class="about-us-section">
             <x-headingTextWithRightImageComponent :id="11" />
            <x-corporateHeadingTextWithLeftImageComponent :id="41" />
            <x-corporateHeadingTextButtonWithImageComponent :id="42" />   
    </div>
    <x-corporateFeaturedSectionComponent :id="12" />
    
    @foreach($features as $item)
            <x-featuredProductsComponent  :id="$item->id" :name="$item->name"  />
     @endforeach
    <x-corporateMediaTeaserComponent/>
</x-corporate-layout>