<x-corporate-layout>
    <x-slot name="header">
    </x-slot>

    <main class="main-content">
        <div class="page-title-infoBar">
            <div class="container">
            <nav class="breadcrumbs-wrapper">
                    <ul class="h-list breadcrumb-list">
                        <li><a href="{{ route('corporate') }}">Home</a></li>
                        <li><a href="{{ route('careers') }}">Careers</a></li>
                        <li><a href="{{ route('careers-listing') }}">Jobs Opening</a></li>
                        <li><span>{{ $job->position }}</span></li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="container">
            <div class="corporate-careers-page">
                <div class="row">
                    <div class="col-sm-4 order-sm-2">
                        <div class="clear"></div>
                        @if(Session::has('message'))
                        <div class="alert alert-success alert-block">
                          <button type="button" class="close" data-dismiss="alert">×</button> 
                              <strong>{!! session('message') !!}</strong>
                        </div>
                        @endif
                        @if($errors->any())
                            <div class="alert alert-danger">
                              @foreach($errors->all() as $error)
                                {{ $error }} <br>
                              @endforeach
                            </div>
                        @endif
                        <form action="{{ route('submit.application') }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="job_id" value="{{ $job->id }}">
                            <div class="content-card">
                                 <header class="v-list header">
                                    <h5>Apply</h5>
                                </header>
                                <div class="form-group">
                                    <input type="text" class="form-control" value="{{ old('full_name') }}" name="full_name" placeholder="Full name *" />
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" value="{{ old('phone_number') }}" name="phone_number" placeholder="Phone number *" />
                                </div>

                                <div class="form-group">
                                    <input type="text" class="form-control" value="{{ old('city') }}" name="city" placeholder="City *" />
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" value="{{ old('country') }}" name="country" placeholder="Country *" />
                                </div>

                                <!-- <div class="select-item form-group">
                                    <select class="form-control">
                                        <option>City</option>
                                        <option>Lahore</option>
                                        <option>Karachi</option>
                                        <option>Peshawar</option>
                                        <option>Multan</option>
                                    </select>
                                </div>
                                <div class="select-item form-group">
                                    <select class="form-control">
                                        <option>Country</option>
                                        <option>Japan</option>
                                        <option>Pakistan</option>
                                        <option>Iran</option>
                                        <option>India</option>
                                    </select>
                                </div> -->
                                <div class="form-group">
                                    <input type="email" name="email" value="{{ old('email') }}" class="form-control" placeholder="Email" />
                                </div>
                                <div class="upload-holder form-group">
                                    <input type="text" readonly class="form-control" placeholder="Upload CV, experience doc" />
                                    <div class="upload-control">Upload <input type="file" name="document" /></div>
                                </div>
                                <div class="form-group">
                                    <textarea type="text" name="cover_letter" class="form-control" placeholder="Coverletter">{{ old('cover_letter') }}</textarea>
                                </div>

                                <button class="btn btn-primary" type="submit">Proceed</button>
                            </div>
                        </form>
                    </div>
                    <div class="col-sm-7">
                        <div class="title-head pt-15 pb-30">
                            <h2 class="mb-0">{{ $job->position }}</h2>
                        </div>
                        <div class="content-holder order-sm-1">
                            <p>{{ $job->short_description }}</p>
                            <p><strong>Responsibilities</strong></p>
                            <div class="text-block">
                                <p> {!! nl2br($job->responsibilities) !!} </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</x-corporate-layout>