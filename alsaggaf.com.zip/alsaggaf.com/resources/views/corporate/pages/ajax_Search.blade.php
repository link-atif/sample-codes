   <div class="product-wrapper row justify-content-start">
                @foreach($products as $product)
                    <div class="product-list-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <a href="{{ route('corporate-product', $product->id) }}">
                        <div class="product-card">
                            <div class="product-image">
                                <img src="{{ asset('images') }}/catalog/products/{{ $product->product_image }}" alt="Produt Image" class="img-fluid"/>
                            </div>
                            <div class="product-title">
                                 {{ $product->title }} 
                            </div>
                        </div>
                         </a>
                    </div>
                @endforeach
            </div>

 @if($countSearch > 20)
 <div class="load-more-btn text-center mb-50" id='remove-btn'>
     <a href="javascript:;" id="load-more-data" class="btn btn-transparent">Load More...</a>
 </div>
 @endif