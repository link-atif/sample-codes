<x-corporate-layout>
    <div class="contact-page">
        <x-slot name="header">
        </x-slot>
        <main class="main-content">
            <div class="page-title-infoBar">
                <div class="container">
                    <div class="title-head pt-30 pb-10">
                        <h2 class="mb-20">Contact</h2>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="two-col-layout">
                    <div class="content-wrapper contact-page-wrapper">
                        <x-corporateContactAddressComponent :id="22" />
                        <x-corporateContactFormComponent :id="23" />
                    </div>
                    <x-corporateContactMapBoxComponent :id="24" />
                </div>
            </div>
        </main>
    </div>
</x-corporate-layout>