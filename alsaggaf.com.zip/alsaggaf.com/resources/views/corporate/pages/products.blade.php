<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
    <main class="main-content">
        <div class="page-title-infoBar bg-grey">
            <div class="container">
                <nav class="breadcrumbs-wrapper">
                    <ul class="h-list breadcrumb-list">
                        <li><a href="{{ route('corporate') }}">Home</a></li>
                        <li><span>Products</span></li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="container">
            <div class="two-col-layout category-page-section">
                <div class="content-wrapper">
                    <aside class="left-sidebar">
                        <nav class="left-sidebar-nav">
                            <h5>Categories</h5>
                            <ul class="v-list nav-list-item boxscroll">
                                @foreach($categories as $category)
                                    @if($category->sub_categories->isNotEmpty())
                                        <li class="nav-item">
                                            <a href="{{ route('corporate-category', $category->id) }}" class="custom-toggle-display-inline">
                                                <span>{{ $category->name }}</span>
                                            </a>
                                            <a href="javascript: void(0);" class="dropdown-toggle custom-toggle">
                                                <span> &nbsp; </span>
                                            </a>
                                    @else
                                        <li>
                                            <a href="{{ route('corporate-category', $category->id) }}">
                                                <span>{{ $category->name }}</span>
                                            </a>
                                    @endif
                                        @if($category->sub_categories->isNotEmpty())
                                        <ul class="dropdown-menu first-level">
                                            @foreach($category->sub_categories as $sub_category)
                                                <li class="nav-item">
                                                    <a href="{{ route('corporate-category', $sub_category->id) }}">
                                                        <span>{{ $sub_category->name }}</span>
                                                    </a>
                                                </li>
                                            @endforeach
                                        </ul>
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                        </nav>
                    </aside>
                    <div class="right-content-area">
                        <div class="product-wrapper justify-content-start">
                            @foreach($products as $product)
                                <div class="product-list-item">
                                    <div class="product-card">
                                        <div class="product-image">
                                            <img src="{{ asset('images/catalog/products') }}/{{ $product->product_image }}" alt="{{ $product->title }}" class="img-fluid">
                                        </div>
                                        <div class="product-title">
                                            <a href="{{ route('corporate-product', $product->id) }}"> {{ $product->title }} </a>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        @if ($products->hasPages())
                            <div class="text-center mt-30">
                                <button class="btn btn-transparent">Load More</button>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </main>
</x-corporate-layout>