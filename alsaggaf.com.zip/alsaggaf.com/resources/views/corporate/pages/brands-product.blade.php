<x-corporate-layout>
    <x-slot name="header">
        <nav class="breadcrumbs-wrapper bg-color-grey">
            <div class="container">
                <ul class="h-list breadcrumb-list">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li><a href="{{ route('brands-products', $brand->id) }}">Brands</a></li>
                    <li><span>{{ $brand->name }}</span></li>
                </ul>
            </div>
        </nav>
    </x-slot>
    <div>
        <div class="product-category pt-0 pb-40">
            <div class="container">
                <div class="title-head pt-0 pb-30">
                    @if($products->isNotEmpty())
                        <h2>{{ $products[0]->brand->name }}</h2>
                    @endif
                </div>
            </div>
        </div>
        @if($products->isNotEmpty())
            <div class="filtered-products">
                <div class="container">
                    <div class="two-col-layout category-page-section">
                        <div class="content-wrapper">
                            <aside class="left-sidebar">
                                <nav class="left-sidebar-nav">
                                    <h5>Brands</h5>
                                    <ul class="v-list nav-list-item boxscroll">
                                        @foreach($brands as $b)
                                        <li>
                                            <a href="{{ route('brands-products', $b->id) }}">
                                                <span>{{ $b->name }}</span>
                                            </a>
                                        </li>
                                        @endforeach
                                    </ul>
                                </nav>
                            </aside>
                            <div class="right-content-area">
                                <div class="d-flex justify-content-between sort-by"><span class="title">{{ count($products) }} results found for {{ $brand->name }}</span></div>
                                <div class="product-wrapper justify-content-start">
                                    @foreach($products as $product)
                                        <div class="product-list-item">
                                            <div class="product-card">
                                                <a href="{{ route('corporate-product', $product->id) }}">
                                                <div class="product-image">
                                                    <img src="{{ asset('images/catalog/products') }}/{{ $product->product_image }}" alt="{{ $product->title }}" class="img-fluid">
                                                </div>
                                                </a>
                                                <div class="product-title">
                                                    <a href="{{ route('corporate-product', $product->id) }}"> {{ $product->title }} </a>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="load-more-btn text-center mb-50">
                                @if($products->hasPages())
                                    @if($products->hasMorePages())
                                        <a href="{{ $products->nextPageUrl() }}" class="btn btn-transparent">Load More...</a>
                                    @else
                                        <a href="{{ route('brands-products', $brand->id) }}" class="btn btn-transparent">First Page</a>
                                    @endif
                                @endif
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    </div>
</x-corporate-layout>