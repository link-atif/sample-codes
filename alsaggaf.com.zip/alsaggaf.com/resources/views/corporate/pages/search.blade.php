<x-corporate-layout>
    <x-slot name="header">
        <nav class="breadcrumbs-wrapper bg-color-grey">
            <div class="container">
                <ul class="h-list breadcrumb-list">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li><span> Search</span></li>
                </ul>
            </div>
        </nav>
    </x-slot>
    <div class="filtered-products">
        <div class="container">
            <div class="title-head pt-0 pb-25">
                <h5 class="mb-0">{{ $countSearch }} search results found for '{{ $products->corporateSearch }}'</h5>
            </div>
            <div class="product-wrapper row justify-content-start">
                @foreach($products as $product)
                    <div class="product-list-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <a href="{{ route('corporate-product', $product->id) }}">
                        <div class="product-card">
                            <div class="product-image">
                                <img src="{{ asset('images') }}/catalog/products/{{ $product->product_image }}" alt="Produt Image" class="img-fluid"/>
                            </div>
                            <div class="product-title">
                                 {{ $product->title }} 
                            </div>
                        </div>
                         </a>
                    </div>
                @endforeach
            </div>
            <div id="data_fatch"></div>
                <input type="hidden" name="page" value="2" id="page_number">
                @if($countSearch >20)
                <div class="load-more-btn text-center mb-50" id='remove-btn'>
                    <a href="javascript:;" id="load-more-data" class="btn btn-transparent">Load More...</a>
                </div>
                @endif
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $(document).on('click', '#load-more-data', function() {
                var page = $("#page_number").val();
                var search = $("#searchProducts").val();
                $.ajax({
                    type: "POST",
                    url: "{{ route('ajaxSearch') }}",
                    data: {
                        ' _token': "{{csrf_token() }}",
                        'page': page ,
                        'search':search
                    },
                    success: function(data) {
                        if (data.length > 0) {
                            $('#remove-btn').remove();
                        }
                        $("#page_number").val(parseInt(page) + 1);
                        $("#data_fatch").append(data);
                    }
                });
            });

        });
    </script>
</x-corporate-layout>