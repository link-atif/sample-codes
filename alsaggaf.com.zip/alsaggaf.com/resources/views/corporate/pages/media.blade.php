<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
    <main class="main-content">
        <div class="container">
            <nav class="breadcrumbs-wrapper">
                <ul class="h-list breadcrumb-list">
                    <li><a href="{{ route('corporate') }}">Home</a></li>
                    <li><span>Media</span></li>
                </ul>
            </nav>
        </div>
        <div class="latest-media-section media-section">
            <div class="container">
                <div class="title-head pt-15 pb-30">
                    <h2>{{ $content->headline_1 }}</h2>
                </div>
                <div class="row latest-media-wrapper">
                    @foreach($medias as $media)

                    <div class="col-sm-4">
                        <a href="{{ route('media.show', $media->id) }}">
                            <div class="latest-media-item">
                                <div class="image-holder">
                                    <img src="{{ asset('images/media') }}/{{ $media->image }}" class="img-fluid" />
                                </div>
                                <div class="content-holder">
                                    <h4>{{ $media->title }}</h4>
                                </div>
                            </div>
                        </a>
                    </div>
                    @endforeach
                </div>

                <div id="data_fatch"></div>
                <input type="hidden" name="page" value="2" id="page_number">
                @if($countMedias >6)
                <div class="load-more-btn text-center mb-50" id='remove-btn'>
                    <a href="javascript:;" id="load-more-data" class="btn btn-transparent">Load More...</a>
                </div>
                @endif
            </div>
        </div>
        {{-- <x-corporateMediaOverviewComponent :id="21" /> --}}
    </main>

    <script>
        $(document).ready(function() {
            $(document).on('click', '#load-more-data', function() {
                var page = $("#page_number").val();
                $.ajax({
                    type: "POST",
                    url: "{{ route('ajaxMedia') }}",
                    data: {
                        ' _token': "{{csrf_token() }}",
                        'page': page
                    },
                    success: function(data) {
                        if (data.length > 0) {
                            $('#remove-btn').remove();
                        }
                        $("#page_number").val(parseInt(page) + 1);
                        $("#data_fatch").append(data);
                    }
                });
            });

        });
    </script>
</x-corporate-layout>