 <div class="row latest-media-wrapper">
     @foreach($medias as $media)
     <div class="col-sm-4">
         <a href="{{ route('media.show', $media->id) }}">
             <div class="latest-media-item">
                 <div class="image-holder">
                     <img src="{{ asset('images/media') }}/{{ $media->image }}" class="img-fluid" />
                 </div>
                 <div class="content-holder">
                     <h4>{{ $media->title }}</h4>
                 </div>
             </div>
         </a>
     </div>
     @endforeach
 </div>
 @if($countMedias > 6)
 <div class="load-more-btn text-center mb-50" id='remove-btn'>
     <a href="javascript:;" id="load-more-data" class="btn btn-transparent">Load More...</a>
 </div>
 @endif