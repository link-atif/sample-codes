<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
    <main class="main-content">
        <div class="page-title-infoBar bg-grey">
            <div class="container">
                <nav class="breadcrumbs-wrapper">
                    <ul class="h-list breadcrumb-list">
                        <li><a href="{{ route('corporate') }}">Home</a></li>
                        <li><span>About</span></li>
                    </ul>
                </nav>
                <x-corporateHeaderHeadingAndTextComponent :id="16" />
            </div>
        </div>

        <div class="about-us-section">
            <x-corporateHeadingTextButtonWithImageComponent :id="17" />
            <x-corporateHeadingTextWithLeftImageComponent :id="18" />
            <x-corporateHeadingTextButtonWithImageComponent :id="19" />
            <x-corporateChallengesOverviewComponent :id="20" />
            <x-corporateTimelineComponent :id="40" />
            
        </div>
    </main>
</x-corporate-layout>