<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
    <main class="main-content">
        <div class="page-title-infoBar bg-grey">
            <div class="container">
                <nav class="breadcrumbs-wrapper">
                    <ul class="h-list breadcrumb-list">
                        <li><a href="{{ route('corporate') }}">Home</a></li>
                        <li><a href="{{ route('corporate-category', app('request')->segment(2)) }}">Category</a></li>
                        <li><span>{{ $category->name }}</span></li>
                    </ul>
                </nav>
                @php 
                    $cat_name = $category->name;
                    $url = route('corporate-category', app('request')->segment(2));
                @endphp
                <div class="title-head pt-15 pb-45">
                    <h2 class="mb-20">{{ $category->name }}</h2>
                    <p>{{ $category->description }}</p>
                   {{-- <button class="btn btn-primary" onClick="downloadCatalog('{{ $category->catalog }}')";>
                        <span class="mr-10">Download Catalog</span>
                        <img class="icon" src="{{ asset('images/icon') }}/download-icon.svg" alt="dropdown-icon" />
                    </button> --}}
                </div>
            </div>
        </div>
        <div class="container">
            <div class="two-col-layout category-page-section">
                <div class="content-wrapper">
                    <aside class="left-sidebar">
                        <nav class="left-sidebar-nav">
                            <h5>Categories</h5>
                            <ul class="v-list nav-list-item boxscroll">
                                @foreach($categories as $category)
                                    @if($category->sub_categories->isNotEmpty())
                                        <li class="nav-item">
                                            <a href="{{ route('corporate-category', $category->id) }}" class="custom-toggle-display-inline">
                                                <span>{{ $category->name }}</span>
                                            </a>
                                            <a href="javascript: void(0);" class="dropdown-toggle custom-toggle">
                                                <span> &nbsp; </span>
                                            </a>
                                    @else
                                        <li>
                                            <a href="{{ route('corporate-category', $category->id) }}">
                                                <span>{{ $category->name }}</span>
                                            </a>
                                    @endif
                                        @if($category->sub_categories->isNotEmpty())
                                        <ul class="dropdown-menu first-level">
                                            @foreach($category->sub_categories as $sub_category)
                                                <li class="nav-item">
                                                    <a href="{{ route('corporate-category', $sub_category->id) }}">
                                                        <span>{{ $sub_category->name }}</span>
                                                    </a>
                                                </li>
                                            @endforeach
                                        </ul>
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                        </nav>
                    </aside>
                    <div class="right-content-area">
                        <div class="d-flex justify-content-between sort-by"><span class="title">{{ count($products) }} results found for {{ $cat_name }}</span>
                            <span class="option">Sort by <select id="sort_by_brands"><option value="">Brands</option>
                        @foreach($brands as $b)
                            <option value="{{ $b['id'] }}" @if($brand_id !="" && $brand_id == $b['id']) selected="selected"  @endif>{{ $b['name'] }}</option>
                        @endforeach
                        </select></span></div>
                        <div class="product-wrapper justify-content-start">
                            @foreach($products as $product)
                                <div class="product-list-item">
                                    <div class="product-card">
                                        <a href="{{ route('corporate-product', $product->id) }}">
                                        <div class="product-image">
                                            <img src="@if($product->product_image !=""){{ asset('images/catalog/products') }}/{{ $product->product_image }}@else {{ asset('images/no-image.png') }} @endif" alt="{{ $product->title }}" class="img-fluid">
                                        </div>
                                        <div class="product-title">{{ $product->title }}</div>
                                        </a>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        <div class="load-more-btn text-center mb-50">
                        @if($products->hasPages())
                            @if($products->hasMorePages())
                                <a href="{{ $products->nextPageUrl() }}" class="btn btn-transparent">Load More...</a>
                            @else
                                <a href="{{ route('corporate-category', app('request')->segment(2)) }}" class="btn btn-transparent">First Page</a>
                            @endif
                        @endif
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">

        function downloadCatalog(file){
            if(file !=""){
                var url = "{{ asset('assets/') }}" +"/"+file;
                window.open(url, '_blank');
            }
        }
        
        $(document).ready(function() {
            $(document).on('change','#sort_by_brands', function(){
                var brand_id = $("#sort_by_brands").val();
                var url = '{{ $url }}';
                if(brand_id != ""){
                    window.location.href = url+"/"+brand_id;    
                }else{
                    window.location.href = url;
                }
            });
        });
        </script>
    </main>
</x-corporate-layout>
