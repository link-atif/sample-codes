<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
    <main class="main-content">
        <div class="page-title-infoBar bg-grey">
            <div class="container">
                <nav class="breadcrumbs-wrapper">
                    <ul class="h-list breadcrumb-list">
                        <li><a href="{{ route('corporate') }}">Home</a></li>
                        <li><a href="{{ route('careers') }}">Careers</a></li>
                        <li><span>Jobs Openings</span></li>
                    </ul>
                </nav>
                <x-corporateHeaderHeadingAndTextComponent :id="29" />
            </div>
        </div>
        <div class="container">
                <x-corporateCareerJobsLisingComponent :id="30" />
        </div>
    </main>
</x-corporate-layout>