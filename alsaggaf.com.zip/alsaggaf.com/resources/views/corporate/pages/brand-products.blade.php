<x-corporate-layout>

    <x-slot name="header">

    </x-slot>

    <main class="main-content">

        <div class="page-title-infoBar bg-grey">

            <div class="container">

                <nav class="breadcrumbs-wrapper">

                    <ul class="h-list breadcrumb-list">

                        <li><a href="{{ route('corporate') }}">Home</a></li>

                        <li><a href="{{ route('corporate-brand
', app('request')->segment(3)) }}">Brand
</a></li>

                        <li><span>{{ $brand
->name }}</span></li>

                    </ul>

                </nav>

                @php 

                    $cat_name = $brand
->name;

                    $url = route('corporate-brand
', app('request')->segment(3));

                @endphp

                <div class="title-head pt-15 pb-45">

                    <h2 class="mb-20">{{ $brand
->name }}</h2>

                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed erat felis, cursus vitae feugiat iaculis, sollicitudin at massa.</p>

                    <button class="btn btn-primary" onClick="downloadCatalog('{{ $brand
->catalog }}')";>

                        <span class="mr-10">Download Catalog</span>

                        <img class="icon" src="{{ asset('images/icon') }}/download-icon.svg" alt="dropdown-icon" />

                    </button>

                </div>

            </div>

        </div>

        <div class="container">

            <div class="two-col-layout brand
-page-section">

                <div class="content-wrapper">

                    <aside class="left-sidebar">

                        <nav class="left-sidebar-nav">

                            <h5>Brands</h5>

                            <ul class="v-list nav-list-item boxscroll">

                                @foreach($brands as $brand
)

                                    @if($brand
->sub_brands->isNotEmpty())

                                        <li class="nav-item">

                                            <a href="{{ route('corporate-brand
', $brand
->id) }}" class="custom-toggle-display-inline">

                                                <span>{{ $brand
->name }}</span>

                                            </a>

                                            <a href="javascript: void(0);" class="dropdown-toggle custom-toggle">

                                                <span> &nbsp; </span>

                                            </a>

                                    @else

                                        <li>

                                            <a href="{{ route('corporate-brand
', $brand
->id) }}">

                                                <span>{{ $brand
->name }}</span>

                                            </a>

                                    @endif

                                        @if($brand
->sub_brands->isNotEmpty())

                                        <ul class="dropdown-menu first-level">

                                            @foreach($brand
->sub_brands as $sub_brand
)

                                                <li class="nav-item">

                                                    <a href="{{ route('corporate-brand
', $sub_brand
->id) }}">

                                                        <span>{{ $sub_brand
->name }}</span>

                                                    </a>

                                                </li>

                                            @endforeach

                                        </ul>

                                        @endif

                                    </li>

                                @endforeach

                            </ul>

                        </nav>

                    </aside>

                    <div class="right-content-area">

                        <div class="d-flex justify-content-between sort-by"><span class="title">{{ count($products) }} results found for {{ $cat_name }}</span>

                            <span class="option">Sort by <select id="sort_by_brands"><option value="">Brands</option>

                        @foreach($brands as $b)

                            <option value="{{ $b->id }}" @if($brand_id !="" && $brand_id == $b->id) selected="selected"  @endif>{{ $b->name }}</option>

                        @endforeach

                        </select></span></div>

                        <div class="product-wrapper justify-content-start">

                            @foreach($products as $product)

                                <div class="product-list-item">

                                    <div class="product-card">

                                        <div class="product-image">

                                            <img src="{{ asset('images/catalog/products') }}/{{ $product->product_image }}" alt="{{ $product->title }}" class="img-fluid">

                                        </div>

                                        <div class="product-title">

                                            <a href="{{ route('corporate-product', $product->id) }}"> {{ $product->title }} </a>

                                        </div>

                                    </div>

                                </div>

                            @endforeach

                        </div>

                        @if ($products->hasPages())

                            <div class="text-center mt-30">

                                <button class="btn btn-transparent">Load More</button>

                            </div>

                        @endif

                        

                    </div>

                </div>

            </div>

        </div>

        <script type="text/javascript">



            function downloadCatalog(file){

                if(file !=""){

                    var url = "{{ asset('assets/') }}" +"/"+file;

                    window.open(url, '_blank');

                }

            }

        $(document).ready(function() {

            $(document).on('change','#sort_by_brands', function(){

                var brand_id = $("#sort_by_brands").val();

                var url = '{{ $url }}';

                if(brand_id != ""){

                    window.location.href = url+"/"+brand_id;    

                }else{

                    window.location.href = url;

                }

            });

        });

        </script>

    </main>

</x-corporate-layout>

