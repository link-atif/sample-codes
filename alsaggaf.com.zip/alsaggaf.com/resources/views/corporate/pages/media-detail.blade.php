<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
    <main class="main-content">
        <div class="page-title-infoBar">
            <div class="container">
                <nav class="breadcrumbs-wrapper">
                    <ul class="h-list breadcrumb-list">
                        <li><a href="{{ route('corporate') }}">Home</a></li>
                        <li><a href="{{ route('media') }}">Media</a></li>
                        <li><span>{{ $media->title }}</span></li>
                    </ul>
                </nav>
                <div class="title-head pt-15 pb-10">
                    <h2 class="mb-20">{{ $media->title }}</h2>
                    <p class="mb-0"><span>Posted on: </span><strong>{{ \Carbon\Carbon::parse($media->created_at)->format('d, F Y')}}</strong></p>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="article-post-wrapper">
                <div class="row">
                    <div class="col-sm-6 order-sm-2">
                        <div class="image-holder">
                            <img src="{{ asset('images/media') }}/{{ $media->image }}" alt="{{ $media->title }}" />
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="content-holder order-sm-1">
                            <p>{!! nl2br($media->article) !!}</p>
                        </div>
                    </div>
                </div>
            </div>
            {{--2nd show--}}
            @if($media->title_1 != null)
            <div class="article-post-wrappers grey-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="image-holder">
                                <img src="{{ asset('images/media') }}/{{  $media->image_1  }}" alt="$media->title_1" class="img-fluid" />
                            </div>
                        </div>
                        <div class="col-sm-9">
                            <div class="content-holder">

                                <p>{!! nl2br($media->article_1) !!}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endif
            {{--3nd show--}}
            {{-- <span>{{ $media->title_2 }}</span> --}}
            <div class="article-post-wrapper">
                <div class="row">
                    <div class="col-sm-6 order-sm-2">
                        <div class="image_2-holder">
                            <img src="{{ asset('images/media') }}/{{ $media->image_2 }}" alt="{{ $media->title_2 }}" />
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="content-holder order-sm-1">
                            <p>{!! nl2br($media->article_2) !!}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</x-corporate-layout>