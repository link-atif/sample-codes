<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
    <main class="main-content">
        <div class="page-title-infoBar bg-grey">
            <div class="container">
                <nav class="breadcrumbs-wrapper">
                    <ul class="h-list breadcrumb-list">
                        <li><a href="{{ route('corporate') }}">Home</a></li>
                        <li><span>Careers</span></li>
                    </ul>
                </nav>
                <x-corporateCareersHeaderComponent :id="25" />
            </div>
        </div>
        <x-corporateCareerFeaturedSectionComponent :id="26" />
        <x-corporateCareersOurTeamComponent :id="27" />
        <x-corporateOurServicesComponent :id="28" />
    </main>
</x-corporate-layout>