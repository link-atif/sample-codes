<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
   
   <script type="text/javascript" src="{{ asset('js/Nzoom.min.js') }}" defer></script>
    <main class="main-content">
        <div class="container">
            <nav class="breadcrumbs-wrapper">
                <ul class="h-list breadcrumb-list">
                    <li><a href="#">Home</a></li>
                    @if(isset($product->category->name)) <li><a href="{{ route('corporate-category', $product->category_id) }}">{{ $product->category->name }}</a></li> @endif
                    <li><span>{{ $product->title }}</span></li>
                </ul>
            </nav>
        </div>
        <div class="container">
            <div class="pdp-content-wrapper corporate-pdp-wrapper">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="pdp-slider-section">
                            <!--product large slider-->
                            <div class="pdp-slider-holder">
                                <div class="row">
                                    @if (count($product->images) === 1)
                                    <div class="col-md-12 order-md-2">
                                        <div class="pdp-gallery-slider">
                                            @foreach($product->images as $key => $image)
                                                <div class="slide-item">
                                                    <div class="image-holder zoomArea">
                                                        <img src="{{ asset('images/catalog/products') }}/{{ $image->product_image }}"  class="img-fluid zoomImg NZoomImg" id="NZoomImg-{{ $key }}" data-NZoomscale="2" alt="{{ $product->title }}"/>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>

                                    @elseif (count($product->images) > 1)
                                    <div class="col-md-9 order-md-2">
                                        <div class="pdp-gallery-slider">
                                            
                                            @foreach($product->images as $key => $image)
                                                <div class="slide-item">
                                                    <div class="image-holder zoomArea">
                                                        <img src="{{ asset('images/catalog/products') }}/{{ $image->product_image }}"  class="img-fluid zoomImg fullImage NZoomImg" id="NZoomImg-{{ $key }}" data-NZoomscale="2" alt="{{ $product->title }}"/>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                    <div class="col-md-3 order-md-1">
                                         
                                        <div class="pdp-thumb-slider">
                                           
                                            @foreach($product->images as $image)
                                                <!--product feature -->
                                                <div class="featured-item">
                                                    <div class="image-holder">
                                                        <img src="{{ asset('images/catalog/products') }}/{{ $image->product_image }}" class="img-fluid" alt="{{ $product->title }}"/>
                                                    </div>
                                                </div>
                                            @endforeach
                                        
                                        </div>
                                    </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <!--product Info Details-->
                        <div class="pdp-info-detail">
                            <h4 class="product-title">{{ $product->title }}</h4>
                          <!--  <a href="{{ route('product-detail-page', $product->id) }}" class="btn btn-primary mb-30">Buy</a>-->
                            <!--Product Detail Tabs-->
                            <div class="pdp-detail-tabs">
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active"  data-toggle="tab" data-target="#pd-description" type="button"  aria-selected="true">Product Description</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" data-toggle="tab" data-target="#pd-specification" type="button" role="tab" aria-selected="false">Product specifications</button>
                                   {{-- </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" data-toggle="tab" data-target="#pd-exchange" type="button" role="tab" aria-selected="false">Exchange & Return</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" data-toggle="tab" data-target="#pd-shipping" type="button" role="tab" aria-selected="false">Shipping</button>
                                    </li>--}}
                                    
                                </ul>
                                @php
                                   if (strlen($product->description) > 200) {
                                       $d_substr = substr($product->description, 0, 200);
                                       $d_endPoint = strrpos($d_substr, ' ');
                                       $product_description = $d_endPoint? substr($d_substr, 0, $d_endPoint):substr($d_substr, 0);
                                   }

                                   if (strlen($product->returns_and_exchange) > 200) {
                                       $re_substr = substr($product->returns_and_exchange, 0, 200);
                                       $re_endPoint = strrpos($re_substr, ' ');
                                       $re_description = $re_endPoint ? substr($re_substr, 0, $re_endPoint):substr($re_substr, 0);
                                   }

                                @endphp
                                <div class="tab-content">
                                    <div class="tab-pane fade show active" id="pd-description" role="tabpanel" aria-labelledby="pd-description">
                                        <div class="content-holder">
                                            @if (strlen($product->description) > 200)
                                                <p id="d_less">{!! $product_description !!}</p>
                                                <p style="display: none;" id="d_more">{!! $product->description !!}</p>
                                                <a href="javascript:;" class="item-link" onClick="showMore('d')" id="d_btn">Read More</a>
                                            @else
                                                <p>{!! $product->description !!}</p>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="pd-specification">
                                    <div class="pdp-spec-wrapper">
                                            <div class="row">
                                                <div class="col-sm-12 mb-15">
                                                    <ul class="v-list">
                                                        @foreach($product->product_specifications_attributes as $attribute)
                                                            <li class="content-list-item ">
                                                                <strong>{{ $attribute->product_attribute_set->attribute_name }}:</strong>
                                                                <span>{{ $attribute->value }}</span>
                                                            </li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade show" id="pd-exchange" role="tabpanel" aria-labelledby="pd-exchange">
                                        <div class="content-holder">
                                            @if (strlen($product->returns_and_exchange) > 200)
                                                <p id="re_less">{{ $re_description }}</p>
                                                <p style="display: none;" id="re_more">{{ $product->returns_and_exchange }}</p>
                                                <a href="javascript:;" class="item-link" onClick="showMore('re')" id="re_btn">Read More</a>
                                            @else
                                                <p>{{ $product->returns_and_exchange }}</p>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="tab-pane fade show" id="pd-shipping" role="tabpanel" aria-labelledby="pd-shipping">
                                        <div class="content-holder">
                                            <p>{{ $product->shipment_information }}</p>
                                           
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
    // function zoomImage(x){
    //     document.getElement
    //     x.setAttribute("id", "NZoomImg");
    //     //alert("here");
    // }
    
    function showMore(id) {
  var less = document.getElementById(id+"_less");
  var moreText = document.getElementById(id+"_more");
  var btnText = document.getElementById(id+"_btn");

  if (moreText.style.display === "none") {
    less.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "block";
  } else {
    less.style.display = "block";
    btnText.innerHTML = "Read More"; 
    moreText.style.display = "none";
  }
}
</script>
</x-corporate-layout>