<x-corporate-layout>
    <x-slot name="header">
    </x-slot>
    <main class="main-content">
        <div class="page-title-infoBar bg-grey">
            <div class="container">
                <nav class="breadcrumbs-wrapper">
                    <ul class="h-list breadcrumb-list">
                        <li><a href="{{ route('corporate') }}">Home</a></li>
                        <li><span>Projects</span></li>
                    </ul>
                </nav>
                <x-corporateProjectsHeader :id="14" />
            </div>
        </div>

        <div class="container">
            <div class="project-list-section">
                <div class="row project-card-wrapper">
                    <x-corporateProjectsOverviewComponent :id="15" />
                </div>
            </div>
        </div>
    </main>
</x-corporate-layout>