<x-shop-layout>
    <x-slot name="header">
        <nav class="breadcrumbs-wrapper">
            <div class="container">
                <ul class="h-list breadcrumb-list">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li><span>Shoping Cart</span></li>
                </ul>
            </div>
        </nav>
    </x-slot>
    @if(session()->has('message'))
        <div class="container">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    <div class="product-category pt-0 pb-40">
        <div class="container">
            <div class="title-head pt-0 pb-30">
                <h2>Shopping Cart</h2>
            </div>
            <div class="row cart-contents">
                <div class="col-md-8 mb-20">
                    <div class="content-card cart-items">
                        @if($flag)
                            @foreach($order->cart_details as $item)
                                <div class="cart-item item">
                                    <div class="image-holder">
                                        <img src="{{ asset('images/catalog/products') }}/{{ $item->product_detail->images[0]->product_image }}" alt="{{ $item->product_detail->title }}" >
                                    </div>
                                    <div class="right v-list">
                                        <a href="{{ route('product-detail-page', $item->product_detail->id) }}" class="title">{{ $item->product_detail->title }}</a>
                                        <div class="info-list">
                                            <div class="info-row">
                                                <div class="lbl">Total</div>
                                                <div>{{ $item->product_qty * $item->product_price }} SAR</div>
                                            </div>
                                            <div class="info-row">
                                                <div class="lbl">Qty</div>
                                                <div>
                                                    {!! Form::open(['method' => 'post', 'route' => ['update-cart', $item->id], 'class' => 'form-horizontal', 'id' => 'update-product-qty-cart-form']) !!}
                                                        <div class="qty-selector">
                                                            {!! Form::text('qty', $item->product_qty , ['placeholder' => '20', 'class' => 'form-control', 'onchange' => 'updateCartProductQty()']) !!}
                                                        </div>
                                                    {!! Form::close() !!}
                                                </div>
                                            </div>
                                        </div>
                                        <!-- <a href="#" class="move-to-wishlist">Move to wishlist</a> -->
                                    </div>
                                </div>
                            @endforeach
                        @else
                            <h2> No items in the cart </h2>
                        @endif
                    </div>
                </div>
                @if($flag)
                    <div class="col-md-4">
                        <div class="order-summary">
                            <header class="header">Order Summary</header>
                            <div class="card-body">
                                <div class="item">
                                    <span>Sub Total</span>
                                    <span class="price" data-unit="sar">{{ $order->cart_sub_total }}</span>
                                </div>
                                <div class="item">
                                    <span>Shipping</span>
                                    <span class="price" data-unit="sar">{{ $order->shippment_charges }}</span>
                                </div>
                                <div class="item">
                                    <span>Vat</span>
                                    <span class="price" data-unit="sar">{{ $order->vat_charges }}</span>
                                </div>
                            </div>
                            <div class="item total">
                                <span>Order Total</span>
                                <span class="price" data-unit="sar">{{ $order->cart_total }}</span>
                            </div>
                            <a href="{{ route('shipping-and-contact-info') }}" class="btn btn-primary btn-block">Shipping Info</a>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
    <script>
        function updateCartProductQty() {
            document.getElementById('update-product-qty-cart-form').submit();
        }
    </script>
</x-shop-layout>