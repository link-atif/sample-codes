<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <div class="distributor-registration">
            <div class="inner">
                <header class="v-list header">
                    <h5>Distributor Registration</h5>
                    <div>Please fillup the form for proceeding with the quote</div>
                </header>
                {!! Form::open(['method' => 'post', 'route' => ['distributor-registration.save', 2], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                    <div class="content-card">
                        <div>
                            {!! Form::text('contact_name', null , ['placeholder' => 'Contact Name *', 'class' => 'form-control']) !!}
                            @if($errors->first('contact_name'))
                                <div class=""><span class="text-danger">{{ $errors->first('contact_name') }}</span></div>
                            @endif
                        </div>
                        <div>
                            {!! Form::text('company_name', null , ['placeholder' => 'Company Name *', 'class' => 'form-control']) !!}
                            @if($errors->first('company_name'))
                                <div class=""><span class="text-danger">{{ $errors->first('company_name') }}</span></div>
                            @endif
                        </div>
                        <div>
                            {!! Form::text('contact_number', null , ['placeholder' => 'Contact Number *', 'class' => 'form-control']) !!}
                            @if($errors->first('contact_number'))
                                <div class=""><span class="text-danger">{{ $errors->first('contact_number') }}</span></div>
                            @endif
                        </div>
                        <div class="select-item">
                            {!! Form::select('city', ['1' => 'Dubai'], null , ['placeholder' => 'City *', 'class' => 'form-control']) !!}
                            @if($errors->first('city'))
                                <div class=""><span class="text-danger">{{ $errors->first('city') }}</span></div>
                            @endif
                        </div>

                        <div class="upload-holder">
                            <!-- <input type="text" readonly class="form-control" placeholder="Document 1" />
                            <div class="upload-control">Upload <input type="file" /></div> -->
                            {!! Form::file('document',['placeholder' => 'Doucment', 'class' => 'form-control', 'id' => 'inputDocument']) !!}
                        </div>
                        <div>
                            {!! Form::text('cr_number', null , ['placeholder' => 'CR Number *', 'class' => 'form-control']) !!}
                            @if($errors->first('cr_number'))
                                <div class=""><span class="text-danger">{{ $errors->first('cr_number') }}</span></div>
                            @endif
                        </div>
                        <div class="form-group">
                            {!! Form::text('email', null , ['placeholder' => 'E-Mail Address', 'class' => 'form-control']) !!}
                            @if($errors->first('email'))
                                <div class=""><span class="text-danger">{{ $errors->first('email') }}</span></div>
                            @endif
                        </div>
                        <div class="form-group">
                            {!! Form::text('password', null , ['placeholder' => 'Password', 'class' => 'form-control']) !!}
                            @if($errors->first('password'))
                                <div class=""><span class="text-danger">{{ $errors->first('password') }}</span></div>
                            @endif
                        </div>
                        <button type="submit" class="btn btn-primary">Proceed</button>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</x-shop-layout>