<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <div class="thankyou-section">
            <h5>Transaction Failed</h5>
            <div class="order-detail-block">
                <div class="row">
                    <div class="col-md-8">
                        <div class="content-card">
                            <p>Order# <strong>{{ $order->id }}</strong></p>
                            <p> <strong>{{ $user->email }} </strong></p>
                            @if(empty($user->password))
                                <p><a href="{{ route('registration', $user->id) }}"> Create an Account </a></p>
                            @endif
                            <p> Something went wrong, Please try again...</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="content-card shipment-details-card">
                            <div class="mb-30">
                                <p class="mb-0"> Delivery Options </p>
                                <strong> Standard Delivery </strong>
                            </div>
                            <div class="mb-30">
                                <p class="mb-0"> Delivery Address </p>
                                <strong>{{ $user->shipping_address->address }} </strong>
                            </div>
                            <div class="mb-30">
                                <p class="mb-0"> Contact Number </p>
                                <strong> {{ $user->contact_number }} </strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>