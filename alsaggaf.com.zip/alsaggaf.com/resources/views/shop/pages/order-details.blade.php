<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <nav class="breadcrumbs-wrapper">
            <ul class="h-list breadcrumb-list">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="{{ route('myaccount') }}">My Account</a></li>
                <li><a href="{{ route('myaccount.orders') }}">My Orders</a></li>
                <li><span>My Orders</span></li>
            </ul>
        </nav>
        <div class="title-head pt-0 pb-30">
            <h2>Order# {{ str_pad($order->id, 8, '0', STR_PAD_LEFT) }}</h2>
        </div>
        <div class="two-col-layout">
            <div class="content-wrapper">
                <x-myB2CAccountSideBarComponent />
                <div class="right-content-area">
                    <div class="content-card mb-30">
                        <div class="mb-15">Status: <span class="text-warning">
                            @if($order->status == 1)
                                Pending
                            @elseif($order->status == 2) 
                                Order under Prep
                            @elseif($order->status == 3) 
                                Ready to Dispatch
                            @elseif($order->status == 4) 
                                Order Dispatched
                            @elseif($order->status == 5)
                                Delivered
                            @endif
                        </span></div>
                        <div>Placed on: <span class="text-primary">{{ \Carbon\Carbon::parse($order->created_at)->format('d, F Y') }}</span></div>
                    </div>
                    <div class="row">
                        @foreach($order->cart_details as $item)
                            <div class="col-md-6">
                                <div class="content-card">
                                    <div class="cart-item item">
                                        <div class="image-holder">
                                            <img src="{{ asset('images/catalog/products') }}/{{ $item->product_detail->images[0]->product_image }}" alt="{{ $item->product_detail->title }}" >
                                        </div>
                                        <div class="right v-list">
                                            <a href="{{ route('product-detail-page', $item->product_detail->id) }}" class="title">{{ $item->product_detail->title }}</a>
                                            <div class="info-list">
                                                <div class="info-row">
                                                    <div class="lbl">Total</div>
                                                    <div>{{ $item->product_price * $item->product_qty }} SAR</div>
                                                </div>
                                                <div class="info-row">
                                                    <div class="lbl">Qty</div>
                                                    <div>{{ $item->product_qty }}</div>
                                                </div>
                                            </div>
                                            <div><a href="{{ route('myaccount.orders.product.return', [$order->id, $item->product_detail->id]) }}">Return on each product</a></div>
                                            <div class="h-list justify-content-between pt-10">
                                                <a href="{{ route('product-detail-page', $item->product_detail->id) }}">Review this Item</a>
                                                <a href="{{ route('myaccount.returns') }}">Go to Returns</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>