<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <nav class="breadcrumbs-wrapper bg-color-grey">
        <div class="container">
            <ul class="h-list breadcrumb-list">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="{{ route('shopping-cart') }}">Shoping Cart</a></li>
                <li><span>Shipping & Contact Info</span></li>
            </ul>
        </div>
    </nav>
    @if(session()->has('message'))
        <div class="container">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    <div class="product-category pt-0 pb-40">
        <div class="container">
            <div class="title-head pt-0 pb-30">
                <h2>Shipping & Contact Info</h2>
            </div>
            <div class="row cart-contents shoping-info">
                <div class="col-md-8 mb-20">
                    <div class="v-list sections-holder">
                        {!! Form::open(['method' => 'post', 'route' => 'myaccount.checkout.login', 'class' => 'form-horizontal']) !!}
                            <div class="content-card">
                                <div class="row">
                                    <div class="col-md-6 mb-25">
                                        {!! Form::text('email', null , ['placeholder' => 'E-Mail Address *', 'class' => 'form-control']) !!}
                                        <div class="mt-10"><span class="text-danger">{{ $errors->first('email') }}</span></div>
                                    </div>
                                    <div class="col-md-6 mb-25">
                                        <input name="password" type="password" class="form-control" placeholder="Password">
                                        <div class="mt-10"><span class="text-danger">{{ $errors->first('password') }}</span></div>
                                    </div>
                                </div>
                                <div class="mb-25">You already have an account with us. Sign in or continue as guest.</div>
                                <div class="h-list justify-content-end">
                                    <span>Forgot your password? <a href="#">Rest now</a></span>
                                    <button href="#" class="btn btn-transparent btn-login" type="submit">Login</button>
                                </div>
                            </div>
                        {!! Form::close() !!}

                        {!! Form::open(['method' => 'post', 'route' => 'checkout-step-1', 'class' => 'form-horizontal', 'id' => 'checkout-form']) !!}
                            <div class="content-card">
                                {!! Form::text('email', null , ['placeholder' => 'E-Mail Address *', 'class' => 'form-control mb-25']) !!}
                                <div>You can create an account after checkout</div>
                                <div class="mt-10"><span class="text-danger">{{ $errors->first('email') }}</span></div>
                            </div>

                            <div class="content-card contact-info-card">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="row bs-gap-20">
                                            <div class="col-md-6 mb-35">
                                                <div class="select-item">
                                                    {!! Form::select('delivery_option', [ '0' => 'Normal Delivery', '1' => 'Urgent Deliver'], null , ['placeholder' => 'Delivery Options', 'class' => 'form-control']) !!}
                                                </div>
                                            </div>
                                            <div class="col-md-6 mb-35">
                                                <div class="select-item">
                                                    {!! Form::select('delivery_date', [ '0' => '10 / 12 / 2020', '1' => '11 / 12 / 2020'], null , ['placeholder' => 'Delivery Date', 'class' => 'form-control']) !!}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-35">
                                        <div class="select-item">
                                            {!! Form::select('delivery_time', [ '0' => '10:00 AM - 11:00 PM', '1' => '11:00 PM - 10:00 AM'], null , ['placeholder' => 'Delivery Time', 'class' => 'form-control']) !!}
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-35">
                                        {!! Form::text('name', null , ['placeholder' => 'Full Name *', 'class' => 'form-control']) !!}
                                        <div class="mt-10"><span class="text-danger">{{ $errors->first('name') }}</span></div>
                                    </div>
                                    <div class="col-md-6 mb-35">
                                        {!! Form::text('contact_number', null , ['placeholder' => 'Phone Number *', 'class' => 'form-control']) !!}
                                        <div class="mt-10"><span class="text-danger">{{ $errors->first('contact_number') }}</span></div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6 mb-35">
                                        <div class="select-item">
                                            {!! Form::select('city', $cities, null, ['placeholder' => 'City *', 'class' => 'form-control']) !!}
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('city') }}</span></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 mb-35">
                                        {!! Form::text('region', null , ['placeholder' => 'Region *', 'class' => 'form-control']) !!}
                                        <div class="mt-10"><span class="text-danger">{{ $errors->first('region') }}</span></div>
                                    </div>
                                </div>
                                <div>
                                    {!! Form::textarea('address', null , ['placeholder' => 'Building #, Street Name, District *', 'class' => 'form-control']) !!}
                                    <div class="mt-10"><span class="text-danger">{{ $errors->first('address') }}</span></div>
                                </div>
                            </div>
                        {!! Form::close() !!}
                    </div>
                </div>
                @if($flag)
                    <div class="col-md-4">
                        <div class="order-summary">
                            <header class="header">Order Summary</header>
                            <div class="card-body">
                                <div class="item">
                                    <span>Sub Total</span>
                                    <span class="price" data-unit="sar">{{ $order->cart_sub_total }}</span>
                                </div>
                                <div class="item">
                                    <span>Shipping</span>
                                    <span class="price" data-unit="sar">{{ $order->shippment_charges }}</span>
                                </div>
                                <div class="item">
                                    <span>Vat</span>
                                    <span class="price" data-unit="sar">{{ $order->vat_charges }}</span>
                                </div>
                            </div>
                            <div class="item total">
                                <span>Order Total</span>
                                <span class="price" data-unit="sar">{{ $order->cart_total }}</span>
                            </div>
                            <a class="btn btn-primary btn-block" onclick="checkout()">Shipping Info</a>
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
    <script> 
        function checkout() {
            document.getElementById('checkout-form').submit();
        }
    </script>
</x-shop-layout>