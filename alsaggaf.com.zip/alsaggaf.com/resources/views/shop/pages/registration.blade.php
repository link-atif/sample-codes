<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <!--Registration Tabs-->
        <div class="registration-section">
            <div class="content-card">
                <div class="registration-tabs">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a class="nav-link"  href="{{ route('signin') }}">Sign In</a>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" data-toggle="tab" data-target="#signUp">Sign Up</button>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="signIn">
                            @if(session()->has('message'))
                                <div class="alert alert-primary alert-dismissible fade show mb-35" role="alert">
                                    <strong>{{ session()->get('status') }}!</strong><br> {{ session()->get('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            @endif
                        </div>
                        @if($registered)
                            <div class="tab-pane fade show active" id="signUp">
                                <div class="registration-wrapper">
                                    {!! Form::open(['method' => 'post', 'route' => ['signup', $user->id], 'class' => 'form-content']) !!}
                                        {!! Form::hidden('id', $user->id , ['class' => 'form-control']) !!}
                                        <div class="form-group">
                                            {!! Form::text('first_name', null , ['placeholder' => 'First Name', 'class' => 'form-control']) !!}
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('first_name') }}</span></div>
                                        </div>
                                        <div class="form-group">
                                            {!! Form::text('last_name', null , ['placeholder' => 'Last Name', 'class' => 'form-control']) !!}
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('last_name') }}</span></div>
                                        </div>
                                        <div class="form-group">
                                            {!! Form::text('email', $user->email , ['placeholder' => 'E-Mail Address', 'class' => 'form-control']) !!}
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('email') }}</span></div>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="password" class="form-control" placeholder="Password" />
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('password') }}</span></div>
                                        </div>
                                        <div class="form-group info-text">
                                            <label class="custom-input-item">
                                                <input name="is_agree" value="1" type="checkbox" class="checkbox-item" />
                                                <span>I have read and agree to the <a href="#">Privacy Policy</a></span>
                                            </label>
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('is_agree') }}</span></div>
                                        </div>
                                        <button class="btn btn-primary btn-block" type="submit">Create an Account</button>
                                    {!! Form::close() !!}
                                </div>
                            </div>
                        @else
                            <div class="tab-pane fade show active" id="signUp">
                                <div class="registration-wrapper">
                                    {!! Form::open(['method' => 'post', 'route' => 'signup', 'class' => 'form-content']) !!}
                                        <div class="form-group">
                                            {!! Form::text('first_name', null , ['placeholder' => 'First Name', 'class' => 'form-control']) !!}
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('first_name') }}</span></div>
                                        </div>
                                        <div class="form-group">
                                            {!! Form::text('last_name', null , ['placeholder' => 'Last Name', 'class' => 'form-control']) !!}
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('last_name') }}</span></div>
                                        </div>
                                        <div class="form-group">
                                            {!! Form::text('email', null , ['placeholder' => 'E-Mail Address', 'class' => 'form-control']) !!}
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('email') }}</span></div>
                                        </div>
                                        <div class="form-group">
                                            {!! Form::text('password', null , ['placeholder' => 'Password', 'class' => 'form-control']) !!}
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('password') }}</span></div>
                                        </div>
                                        <div class="form-group info-text">
                                            <label class="custom-input-item">
                                                <input type="checkbox" name="is_agree" value="1" class="checkbox-item" />
                                                <span>I have read and agree to the <a href="#">Privacy Policy</a></span>
                                            </label>
                                            <div class="mt-10"><span class="text-danger">{{ $errors->first('is_agree') }}</span></div>
                                        </div>
                                        <button class="btn btn-primary btn-block">Get Started</button>
                                    {!! Form::close() !!}
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>