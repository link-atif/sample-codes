<x-shop-layout>
    <x-slot name="header">
        <nav class="breadcrumbs-wrapper">
            <div class="container">
                <ul class="h-list breadcrumb-list">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li><a href="{{ route('all-category') }}">All Categories</a></li>
                    @if($tt_contents->categories->count() > 1)
                        <li><a href="{{ route('category-detail-page', $tt_contents->categories[0]->id) }}">{{ $tt_contents->categories[0]->name }}</a></li>
                        <li><span>{{ $tt_contents->categories[1]->name }}</span></li>
                    @else
                        @if($tt_contents->categories[0])
                            <li><span>{{ $tt_contents->categories[0]->name }}</span></li>
                        @endif
                    @endif
                </ul>
            </div>
        </nav>
    </x-slot>
    @if(session()->has('message'))
        <div class="container pb-20">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    @if($errors->first('qty'))
        <div class="container pb-20">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <strong>Error !</strong> The Quantity Field is required ...!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    @if($errors->first('size'))
        <div class="container pb-20">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <strong>Error !</strong> The Size Field is required ...!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    @if($errors->first('color'))
        <div class="container pb-20">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <strong>Error !</strong> The Color Field is required ...!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    <section class="pdp-layout-top shop--pdp-wrapper">
        <div class="container">
            <div class="pdp-content-wrapper">
                <div class="row">
                    <div class="col-sm-8">
                        <div class="pdp-slider-section">
                            <!--product large slider-->
                            <div class="pdp-slider-holder">
                                <div class="pdp-gallery-slider">
                                    @foreach($tt_contents->product->images as $image)
                                        <div class="slide-item">
                                            <div class="image-holder">
                                                <img src="{{ asset('images') }}/catalog/products/{{ $image->product_image }}"  class="img-fluid" alt="Slide Image"/>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <!-- <nav class="slider-actions-btn">
                                    <ul class="h-list justify-content-center align-items-center">
                                        <li>
                                            <a href="">
                                                <i class="far fa-heart"></i>
                                                <span>Add to Wishlist</span>
                                            </a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#"class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fa fa-share-alt"></i>
                                                <span>Share</span>
                                            </a>
                                            <div class="dropdown-menu">
                                                <ul class="h-list">
                                                    <li class="dd-menu-item"> 
                                                        <a href=""><img src="{{ asset('images') }}/socail/wahtsapp.png" alt="WhatsApp" /></a>
                                                    </li>
                                                    <li class="dd-menu-item"> 
                                                        <a href=""><img src="{{ asset('images') }}/socail/snapchat.png" alt="WhatsApp" /></a>
                                                    </li>
                                                    <li class="dd-menu-item"> 
                                                        <a href=""><img src="{{ asset('images') }}/socail/facebook.png" alt="WhatsApp" /></a>
                                                    </li>
                                                    <li class="dd-menu-item"> 
                                                        <a href=""><img src="{{ asset('images') }}/socail/instagram.png" alt="WhatsApp" /></a>
                                                    </li>
                                                    <li class="dd-menu-item"> 
                                                        <a href=""><img src="{{ asset('images') }}/socail/linkedin.png" alt="WhatsApp" /></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li> 
                                        <li>
                                            <a href="">
                                                <i class="fa fa-envelope"></i>
                                                <span>Email</span>
                                            </a>
                                        </li>
                                    </ul>
                                </nav> -->
                            </div>
                        </div>
                        <span style="font-weight: 500;"> Visually Similar </span>
                        <!--product feature -->
                        <div class="pdp-feature-product mt-10">
                            <div class="row">
                                @foreach($tt_contents->similar_products as $item)
                                    <div class="col-sm-3">
                                        <div class="featured-item">
                                            <div class="image-holder">
                                                <!-- <div class="action-btn">
                                                    <a href="#"><i class="far fa-heart"></i></a>
                                                </div> -->
                                                <a href="{{ route('product-detail-page', $item->id) }}">
                                                    <img src="{{ asset('images/catalog/products') }}/{{ $item->images[0]->product_image }}" class="img-fluid" alt="{{ $item->title }}"/>
                                                </a>
                                                <div class="price-tag">{{ $item->price }} <span>SAR</span></div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        {!! Form::open(['method' => 'post', 'route' => ['admin.product.cart.add', $tt_contents->product->id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                            <!--product Info Details-->
                            <div class="pdp-info-detail">
                                <h4 class="product-title">{{ $tt_contents->product->title }}</h4>
                                <!-- <div class="rating-wrapper h-list">
                                    <div class="stars">
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="fa fa-star checked"></span>
                                        <span class="far fa-star"></span>
                                        <span class="far fa-star"></span>
                                    </div>
                                    <span class="review-no">(14)</span>
                                </div> -->
                                <div class="product-price">
                                    <div class="price">{{ $tt_contents->product->price }} <span>SAR</span></div>
                                    <div class="product-discount">
                                        <div class="discount-item"><span>Sale Starts</span> <strong>Nov 15, 11:00 AM</strong> </div>
                                    </div>
                                </div>
                                <div class="shipping-info-text">{{ $tt_contents->product->shipment_information }}</div>
                                <div class="product-attributes">
                                    @if($tt_contents->product->product_type == 'Simple Product')
                                        <div class="product-quantity">
                                            <div class="product-qty-wrapper">
                                                <label class="info-label">Quantity</label>
                                                {!! Form::text('qty', null , ['placeholder' => '20', 'class' => 'form-control']) !!}
                                                @if($tt_contents->product->qty > 0)
                                                    <div class="info-text text-success">In stock</div>
                                                @else
                                                    <div class="info-text text-danger">Not in stock</div>
                                                @endif
                                            </div>
                                            @if($errors->first('qty'))
                                                <span class="text-danger">{{ $errors->first('qty') }}</span>
                                            @endif
                                        </div>
                                    @endif
                                    @if($tt_contents->product->product_type == 'Configurable Product')
                                        <div class="product-quantity">
                                            <div class="product-qty-wrapper">
                                                <label class="info-label">Quantity</label>
                                                {!! Form::text('qty', null , ['placeholder' => '20', 'class' => 'form-control']) !!}
                                            </div>
                                            @if($errors->first('qty'))
                                                <span class="text-danger">{{ $errors->first('qty') }}</span>
                                            @endif
                                        </div>
                                        @if($tt_contents->product->size->isNotEmpty())
                                            <div class="product-size">
                                                <div class="sizes-wrapper">
                                                    <label class="info-label">Size</label>
                                                    <div class="select-item">
                                                        <select name="size" class="form-control">
                                                            <option value=""> Size </option>
                                                            @foreach($tt_contents->product->size as $size)
                                                                <option value="{{ $size->id }}"> {{ $size->size }} </option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    @if(session()->has('is_available'))
                                                        <div class="info-text text-danger">Not in stock</div>
                                                    @endif
                                                </div>
                                                @if($errors->first('size'))
                                                    <span class="text-danger">{{ $errors->first('size') }}</span>
                                                @endif
                                            </div>
                                        @endif
                                        @if($tt_contents->product->color->isNotEmpty())
                                            <div class="product-color">
                                                <div class="color-wrapper">
                                                    <label class="info-label">colors</label>
                                                    <div class="color-swatches h-list">
                                                        @foreach($tt_contents->product->color as $color)
                                                            <div class="custom-input-wrapper">
                                                                <input type="radio" class="custom-input" data-toggle="tooltip" title="{{ $color->color}}" value="{{ $color->id }}" name="color" />
                                                                <span class="color"></span>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                                @if($errors->first('color'))
                                                    <span class="text-danger">{{ $errors->first('color') }}</span>
                                                @endif
                                            </div>
                                        @endif
                                    @endif
                                </div>

                                <div class="product-action-btns">
                                    <div class="btn-item">
                                        @if(session()->has('is_available'))
                                            <a data-toggle="modal" data-target="#notify-me" role="button" class="add-to-cart btn btn-primary">
                                                Notify me
                                            </a>
                                        @else
                                            <button class="add-to-cart btn btn-primary" type="submit">Add to Cart</button>
                                        @endif
                                    </div>
                                    <!-- <div class="btn-item">
                                        <button class="like btn btn-transparent" type="button">Add to Quote</button>
                                        <div class="info-text">Are you a Distributor?</div>
                                    </div> -->
                                </div>
                            </div>
                        {!! Form::close() !!}
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-8">
                        <!--Product Detail Tabs-->
                        <div class="pdp-detail-tabs">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active"  data-toggle="tab" data-target="#pd-description" type="button"  aria-selected="true">Product Description</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" data-toggle="tab" data-target="#pd-specification" type="button" role="tab" aria-selected="false">Product specifications</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" data-toggle="tab" data-target="#pd-return" type="button" role="tab"  aria-selected="false">Returns & Exchange</button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link"  data-toggle="tab" data-target="#pd-warrenty" type="button" role="tab"  aria-selected="false">Warranty</button>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="pd-description" role="tabpanel" aria-labelledby="pd-description">
                                    <div class="content-holder">
                                        <p>{!! nl2br($tt_contents->product->description) !!}</p>
                                        <!-- <a href="#" class="item-link">Read More</a> -->
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pd-specification">
                                    <div class="pdp-spec-wrapper">
                                        <div class="row">
                                            <div>
                                                <ul class="v-list flex-row flex-wrap">
                                                    @foreach($tt_contents->product->product_specifications_attributes as $attribute)
                                                        <li class="content-list-item col-12 col-md-6">
                                                            <strong>{{ $attribute->product_attribute_set->attribute_name }}:</strong>
                                                            <span>{{ $attribute->value }}</span>
                                                        </li>
                                                    @endforeach
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pd-return" >{!! nl2br($tt_contents->product->returns_and_exchange) !!}</div>
                                <div class="tab-pane fade" id="pd-warrenty">{!! nl2br($tt_contents->product->warranty) !!}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Notify Me Dialog Box -->
    <div class="modal fade modal-xxl quick-view-modal" id="notify-me">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button class="close-btn" data-dismiss="modal">
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                        </svg>
                    </button>
                </div>
                {!! Form::open(['method' => 'post', 'route' => ['product.qty.notify',$tt_contents->product->id], 'class' => 'form-horizontal']) !!}
                    <div class="modal-body">
                        <div class="pdp-content-wrapper">
                            <div class="form-group row">
                                {!! Form::label('inputEmail', 'Email', ['class' => 'col-sm-3 col-form-label']) !!}
                                <div class="col-sm-9">
                                    {!! Form::text('email', null , ['placeholder' => 'Email', 'class' => 'form-control', 'id' => 'inputEmail']) !!}
                                    <span class="text-danger">{{ $errors->first('email') }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <div class="action-link">
                            <button type="submit" class="btn btn-primary">Notify Me</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</x-shop-layout>