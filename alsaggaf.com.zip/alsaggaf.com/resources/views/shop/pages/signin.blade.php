<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <!--Registration Tabs-->
        <div class="registration-section">
            <div class="content-card">
                <div class="registration-tabs">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active"  data-toggle="tab" data-target="#signIn">Sign In</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link" href="{{ route('registration') }}">Sign Up</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="signIn">
                            @if(session()->has('message'))
                                <div class="alert alert-primary alert-dismissible fade show mb-35" role="alert">
                                    <strong>{{ session()->get('status') }}!</strong><br> {{ session()->get('message') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            @endif
                            <div class="registration-wrapper">
                                {!! Form::open(['method' => 'post', 'route' => 'fe_user_sign_in', 'class' => 'form-content']) !!}
                                    <div class="form-group">
                                        {!! Form::text('email', null , ['placeholder' => 'E-Mail Address', 'class' => 'form-control']) !!}
                                        <div class="mt-10"><span class="text-danger">{{ $errors->first('email') }}</span></div>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="password" class="form-control" placeholder="Password" />
                                        <div class="mt-10"><span class="text-danger">{{ $errors->first('password') }}</span></div>
                                    </div>
                                    <div class="form-group info-block">
                                        <div class="h-list">
                                            <label class="custom-input-item">
                                                <input type="checkbox" class="checkbox-item" />
                                                <span>Remember Me</span>
                                            </label>
                                            <a href="#">Forgot Password?</a>
                                        </div>
                                    </div>
                                    <button class="btn btn-primary btn-block">Login</button>
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>