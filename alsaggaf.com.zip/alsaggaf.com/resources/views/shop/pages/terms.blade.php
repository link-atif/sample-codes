<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <nav class="breadcrumbs-wrapper">
            <ul class="h-list breadcrumb-list">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><span>{{ $tt_contents[0]->headline_1 }}</span></li>
            </ul>
        </nav>
        <div class="full-container-wrapper">
            <div class="text-block-wrapper">
                <div class="title-head pt-0 pb-30">
                    <h2>{{ $tt_contents[0]->headline_1 }}</h2>
                </div>
                <p> {!! nl2br($tt_contents[0]->text_1) !!}</p>
            </div>
        </div>
    </div>
</x-shop-layout>