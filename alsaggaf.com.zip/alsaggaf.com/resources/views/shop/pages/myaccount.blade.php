<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <nav class="breadcrumbs-wrapper">
            <ul class="h-list breadcrumb-list">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><span>My Account</span></li>
            </ul>
        </nav>
        <div class="title-head pt-0 pb-30">
            <h2>My Account</h2>
        </div>
        <div class="two-col-layout">
            <div class="content-wrapper">
                <x-myB2CAccountSideBarComponent />
                <div class="right-content-area personal-details">
                    <div class="h-list user">
                        <figure class="icon-rounded image-holder">
                            <img src="{{ asset('images/users') }}/{{ $user->profile_picture }}" class="base-image" alt="Icon">
                            <span class="icon-rounded edit-icon"><img src="{{ asset('images') }}/icon/edit-icon.svg" alt="Edit"></span>
                        </figure>
                        <span>{{ $user->name }}</span>
                    </div>
                    <div class="content-card mb-30">
                        <h4 class="main-title">Account Information</h4>
                        <div class="row mb-10">
                            <div class="col-md-6 mb-20">
                                <h5 class="inner-title">Contact Information</h5>
                                <div class="info-list">
                                    <div class="info-row">
                                        <div class="lbl">Contact Name</div>
                                        <div>
                                            <div class="h-list contact-data">
                                                <span>{{ $user->name }}</span>
                                                <img class="cursor-pointer" src="{{ asset('images') }}/icon/edit-icon.svg" alt="Edit">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="info-row">
                                        <div class="lbl">Contact Number</div>
                                        <div>
                                            <div class="h-list contact-data">
                                                <span>{{ $user->contact_number }}</span>
                                                <img class="cursor-pointer" src="{{ asset('images') }}/icon/edit-icon.svg" alt="Edit">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="info-row">
                                        <div class="lbl">Contact Email</div>
                                        <div>
                                            <div class="h-list contact-data">
                                                <span>{{ $user->email }}</span>
                                                <img class="cursor-pointer" src="{{ asset('images') }}/icon/edit-icon.svg" alt="Edit">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="info-row">
                                        <div class="lbl">Password</div>
                                        <div>
                                            <div class="h-list contact-data">
                                                <span>***********</span>
                                                <img class="cursor-pointer" src="{{ asset('images') }}/icon/edit-icon.svg" alt="Edit">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 mb-20 last-margin-0">
                                <h5 class="inner-title">Newsletters</h5>
                                @if($user->newsletter_subscription)
                                    <p>You have subscribe to our newsletter</p>
                                @else
                                    <p>You don't subscribe to our newsletter</p>
                                @endif
                            </div>
                        </div>
                        <h4 class="main-title">Address Book</h4>
                        <div class="row">
                            <div class="col-sm-4 last-margin-0">
                                <div class="h-list justify-content-between inner-title">
                                    <h5>Default Billing Address</h5>
                                    <img class="cursor-pointer" src="{{ asset('images') }}/icon/edit-icon.svg" alt="Edit">
                                </div>
                                @if($user->billing_address->address)
                                    <p>{{ $user->billing_address->address }}</p>
                                    <p>{{ $user->billing_address->city }}, {{ $user->billing_address->region }}</p>
                                @else
                                    <p>You have not set a default billing address.</p>
                                @endif
                            </div>
                            <div class="col-sm-4 last-margin-0">
                                <div class="h-list justify-content-between inner-title">
                                    <h5>Default Shipping Address</h5>
                                    <img class="cursor-pointer" src="{{ asset('images') }}/icon/edit-icon.svg" alt="Edit">
                                </div>
                                @if($user->shipping_address->address)
                                    <p>{{ $user->shipping_address->address }}</p>
                                    <p>{{ $user->shipping_address->city }}, {{ $user->shipping_address->region }}</p>
                                @else
                                    <p>You have not set a default billing address.</p>
                                @endif
                            </div>
                        </div>
                    </div>
                    <!-- <button class="btn btn-primary">Save</button> -->
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>