<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>{{ config('app.name', 'Laravel') }}</title>
        <!-- Styles -->
        <link rel="stylesheet" href="{{ asset('css/shop-app.css') }}">
        <!-- Scripts -->
        
    </head>
    <body>
        <div class="interest-modal">
            <div class="interest-modal-wrapper">
                <div class="card-info">
                    <div class="card-header">
                        <h5>What are you interested in ?</h5>
                        <p>Follow 3 or more topics to see more of what you're interested in</p>
                        <div class="search-holder">
                            <div class="h-list">
                                <input type="text" placeholder="Search Topic" class="form-control"/>
                                <button class="btn btn-primary">Search</button>
                            </div>
                        </div>
                    </div>
                    {!! Form::open(['method' => 'post', 'route' => ['preferences.save', $user->id, $user->user_type], 'class' => 'form-horizontal']) !!}
                        <div class="card-wrapper boxscroll">
                            @foreach($categories as $category)
                                <div class="card-item">
                                    <div class="card-desc">
                                        <div class="customCheckBox">
                                            <input type="checkbox" name="preferences[]" value="{{ $category->id }}" {{ (in_array($category->id, explode(',', rtrim($user->preferences, ',')))) ? "checked='checked'" : ''}}  class="" id="customCheck-{{ $category->id }}" />
                                        </div>
                                        <label for="customCheck-{{ $category->id }}">
                                            <div class="card-image">
                                                <img src="{{ asset('images/catalog/category') }}/{{ $category->thumbnail }}" alt="{{ $category->name }}" class="img-fluid"/>
                                            </div>
                                            <div class="card-title">{{ $category->name }}</div>
                                        </label>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        <div class="text-center">
                            <button class="btn btn-primary" type="submit">Save Preference</button>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
        @livewireScripts
        <script src="{{ asset('js/shop-app.js') }}" defer></script>
    </body>
</html>