<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <nav class="breadcrumbs-wrapper">
            <ul class="h-list breadcrumb-list">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="{{ route('myaccount') }}">My Account</a></li>
                <li><a href="{{ route('myaccount.orders') }}">My Orders</a></li>
                <li><span>Apply for Returns</span></li>
            </ul>
        </nav>
        <div class="title-head pt-0 pb-30">
            <h2>Order# {{ str_pad($order->id, 8, '0', STR_PAD_LEFT) }}</h2>
        </div>
        <div class="two-col-layout">
            <div class="content-wrapper">
                <x-myB2CAccountSideBarComponent />
                <div class="right-content-area">
                    {!! Form::open(['method' => 'post', 'route' => ['myaccount.orders.product.return.apply', $order->id, $product->id], 'enctype' => 'multipart/form-data']) !!}
                        <imput type="hidden" name="order_id" value="{{ $order->id }}" >
                        <imput type="hidden" name="product_id" value="{{ $product->id }}" >
                        @foreach($order->cart_details as $item)
                            @if($item->product_id == $product->id)
                                <div class="row">
                                    <div class="col-md-8">
                                        <h4 class="mb-25">Items</h4>
                                        <div class="content-card mb-30">
                                            <div class="cart-item item">
                                                <div class="image-holder">
                                                    <img src="{{ asset('images/catalog/products') }}/{{ $product->images[0]->product_image }}" alt="{{ $product->title }}" >
                                                </div>
                                                <div class="right v-list">
                                                    <div class="last-margin-0">
                                                        <p>{{ $product->title }}</p>
                                                    </div>
                                                    <div class="info-list">
                                                        <div class="info-row">
                                                            <div class="lbl">Total</div>
                                                            <div>{{ $item->product_qty * $item->product_price }} SAR</div>
                                                        </div>
                                                        <div class="info-row">
                                                            <div class="lbl">Qty</div>
                                                            <div>{{ $item->product_qty }}</div>
                                                        </div>
                                                    </div>
                                                    <div class="h-list pt-10">
                                                        <div class="select-item">
                                                            <select name="reason" class="form-control">
                                                                <option value="">Reason</option>
                                                                <option value="reason-1">Reason 1</option>
                                                                <option value="reason-2">Reason 2</option>
                                                            </select>
                                                            <div><span class="text-danger">{{ $errors->first('reason') }}</span></div>
                                                        </div>
                                                        <div>
                                                            <a href="#" class="btn upload-button">
                                                                Upload Photo
                                                                <input type="file" name="product_img" />
                                                                <img class="icon" src="{{ asset('images/icon') }}/upload-icon.svg" alt="" />
                                                            </a>
                                                            <div><span class="text-danger">{{ $errors->first('product_img') }}</span></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div> 
                                        </div>
                                        <div class="mb-30">
                                            <a href="#" class="btn upload-button">
                                                Invoice Attachment <span class="star">*</span>
                                                <input type="file" name="invoice" />
                                                <img class="icon" src="{{ asset('images/icon') }}/upload-icon.svg" alt="" />
                                            </a>
                                            <div><span class="text-danger">{{ $errors->first('invoice') }}</span></div>
                                        </div>
                                        
                                        <button class="btn btn-primary">Submit Request</button>
                                    </div>
                                </div>
                            @endif
                        @endforeach
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>