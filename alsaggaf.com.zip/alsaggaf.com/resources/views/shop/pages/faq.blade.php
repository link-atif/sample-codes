<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <nav class="breadcrumbs-wrapper">
            <ul class="h-list breadcrumb-list">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><span>FAQ</span></li>
            </ul>
        </nav>
        <div class="full-container-wrapper">
            <div class="faq-wrapper">
                <div class="title-head pt-0 pb-30">
                    <h2>{{ $tt_contents[0]->headline_1 }}</h2>
                    <p>{{ $tt_contents[0]->text_1 }}</p>
                </div>
                <div id="faq-accordion" class="accordion-wrapper">
                    @foreach($faqs as $faq)
                        @if($loop->iteration == 1)
                            <div class="card-collapse-item show-content">
                                <div class="card-header">
                                    <a class="card-link text-black" data-toggle="collapse" href="#collapse-{{ $faq->id }}" aria-expanded="true">
                                        <h5>{{ $faq->title }}</h5>
                                        <span class="icon-btn"><i class="fa fa-angle-down"></i></span>
                                    </a>
                                </div>
                                <div id="collapse-{{ $faq->id }}" class="collapse show" data-parent="#faq-accordion">
                                    <div class="card-body">
                                        <div class="content-holder">
                                            <p>{!! nl2br($faq->text) !!}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @else
                            <div class="card-collapse-item">
                                <div class="card-header">
                                    <a class="collapsed card-link text-black" data-toggle="collapse" href="#collapse-{{ $faq->id }}">
                                        <h5>{{ $faq->title }}</h5>
                                        <span class="icon-btn"><i class="fa fa-angle-down"></i></span>
                                    </a>
                                </div>
                                <div id="collapse-{{ $faq->id }}" class="collapse" data-parent="#faq-accordion">
                                    <div class="card-body">
                                        <div class="content-holder">
                                            <p>{!! nl2br($faq->text) !!}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>