<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <nav class="breadcrumbs-wrapper bg-color-grey">
        <div class="container">
            <ul class="h-list breadcrumb-list">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="{{ route('shopping-cart') }}">Shoping Cart</a></li>
                <li><span>Shipping & Contact Info</span></li>
            </ul>
        </div>
    </nav>
    {!! Form::open(['method' => 'post', 'route' => ['checkout-step-2', $user->id], 'class' => 'form-horizontal']) !!}
        <div class="product-category pt-0 pb-40">
            <div class="container">
                <div class="title-head pt-0 pb-30">
                    <h2>Review & Payments</h2>
                </div>
                <div class="row cart-contents">
                    <div class="col-md-8 mb-20">
                        <div class="content-card payment-methods">
                            <div class="inner-head">
                                <h2>Choose a payment option below</h2>
                            </div>
                            <div class="payment-method-wrapper">
                                <div class="content-holder">
                                    <div class="form-check-inline">
                                        <label class="custom-input-item" for="inputCreditCard">
                                            <input class="custom-input" type="radio" name="transaction_type" id="inputCreditCard" value="1" checked>
                                            <div class="checkmark"><span>Credit Card</span></div>
                                        </label>
                                    </div>
                                    <div class="form-check-inline">
                                        <label class="custom-input-item" for="inputDebitCard">
                                            <input class="custom-input" type="radio" name="transaction_type" id="inputDebitCard" value="2">
                                            <div class="checkmark"><span>Debit Card</span></div>
                                        </label>
                                    </div>
                                    <div class="form-check-inline">
                                        <label class="custom-input-item" for="inputCashOnDelivery">
                                            <input class="custom-input" type="radio" name="transaction_type" id="inputCashOnDelivery" value="3">
                                            <div class="checkmark"><span>Cash on Delivery</span></div>
                                        </label>
                                    </div>
                                </div>
                                <div class="billing-wrapper">
                                    <div class="billing-address">
                                        <label class="custom-input-item">
                                            <input type="radio" class="custom-input" name="is_billing_address_and_shipping_address_same" value="1" checked/>
                                            <div class="checkmark">
                                                <span>My Billing and shipping address are the same</span>
                                            </div>
                                        </label>
                                        <div class="address-info mb-20">
                                            {!! nl2br($user->billing_address->address) !!} <br>
                                            Email: {{ $user->email }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    @if($flag)
                        <div class="col-md-4">
                            <div class="order-summary">
                                <header class="header">Order Summary</header>
                                <div class="card-body">
                                    <div class="item">
                                        <span>Sub Total</span>
                                        <span class="price" data-unit="sar">{{ $order->cart_sub_total }}</span>
                                    </div>
                                    <div class="item">
                                        <span>Shipping</span>
                                        <span class="price" data-unit="sar">{{ $order->shippment_charges }}</span>
                                    </div>
                                    <div class="item">
                                        <span>Vat</span>
                                        <span class="price" data-unit="sar">{{ $order->vat_charges }}</span>
                                    </div>
                                </div>
                                <div class="item total">
                                    <span>Order Total</span>
                                    <span class="price" data-unit="sar">{{ $order->cart_total }}</span>
                                </div>
                                <button class="btn btn-primary btn-block" type="submit">Checkout</button>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    {!! Form::close() !!}
</x-shop-layout>