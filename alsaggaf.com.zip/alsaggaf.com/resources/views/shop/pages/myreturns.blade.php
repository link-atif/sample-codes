<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <nav class="breadcrumbs-wrapper">
            <ul class="h-list breadcrumb-list">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="{{ route('myaccount') }}">My Account</a></li>
                <li><span>My Returns</span></li>
            </ul>
        </nav>
        <div class="title-head pt-0 pb-30">
            <h2>My Account</h2>
        </div>
        <div class="two-col-layout">
            <div class="content-wrapper">
                <x-myB2CAccountSideBarComponent />
                <div class="right-content-area">
                    <div class="content-card mb-30">
                        <div class="table-wrapper bg-table">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col"></th>
                                            <th scope="col">Id</th>
                                            <th scope="col">Date and time</th>
                                            <th scope="col">Order Id</th>
                                            <th scope="col">Product Name</th>
                                            <th scope="col">Total</th>
                                            <th scope="col">Refund Amount</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($returns as $return)
                                            <tr>
                                                <td>
                                                    <div class="image-holder">
                                                        <img src="{{ asset('images/catalog/products') }}/{{ $return->product->images[0]->product_image }}" alt="{{ $return->product->title }}" >
                                                    </div>
                                                </td>
                                                <td>{{ str_pad($return->id, 8, '0', STR_PAD_LEFT) }}</td>
                                                <td>{{ \Carbon\Carbon::parse($return->created_at)->format('d, F Y g i A') }}</td>
                                                <td>{{ str_pad($return->order_id, 8, '0', STR_PAD_LEFT) }}</td>
                                                <td>{{ \Illuminate\Support\Str::limit($return->product->title, 30, $end='...') }}</td>
                                                <td>{{ $return->cart_detail->product_qty * $return->cart_detail->product_price }}</td>
                                                <td>{{ $return->refund_amount }}</td>
                                                <td>
                                                    @if($return->status == 0)
                                                        Under Process
                                                    @elseif($return->status == 1)
                                                        Required to return product
                                                    @elseif($return->status == 2)
                                                        Refund under process
                                                    @elseif($return->status == 3)
                                                        Refund Processed
                                                    @elseif($return->status == 4)
                                                        Request rejected due to exceeding 15 days
                                                    @elseif($return->status == 5)
                                                        Request rejected due to product failing quality check
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>