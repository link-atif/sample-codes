<x-shop-layout>
    <x-slot name="header">
        <nav class="breadcrumbs-wrapper">
            <div class="container">
                <ul class="h-list breadcrumb-list">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li><a href="{{ route('all-category') }}">All Categories</a></li>
                    <li><span>Sale</span></li>
                </ul>
            </div>
        </nav>
    </x-slot>
    <div class="container">
        <div class="two-col-layout">
            <div class="content-wrapper">
                <x-asidebarCategoriesComponent />
                <div class="right-content-area">
                    <x-salesBannerComponent :id="8" />
                    <x-salesOffersOverviewComponent :id="9" />
                </div>
            </div>
        </div>
    </div>
    <x-bestSellerComponent />
</x-shop-layout>