<x-shop-layout>
    <x-slot name="header">
        <nav class="breadcrumbs-wrapper bg-color-grey">
            <div class="container">
                <ul class="h-list breadcrumb-list">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li><a href="{{ route('all-category') }}">All Categories</a></li>
                    <li><span>Best Seller</span></li>
                </ul>
            </div>
        </nav>
    </x-slot>
    <div>
    <div class="product-category pt-0 pb-40">
        <div class="container">
            <div class="title-head pt-0 pb-30">
                <h2>Best Seller</h2>
            </div>
        </div>
    </div>
    <div class="filter-section">
        <div class="container">
            {!! Form::open(['method' => 'post', 'route' => 'best-seller-page.filter', 'class' => 'form-horizontal', 'id' => 'filter-products']) !!}
                <div class="filter-wrapper justify-content-start">
                    <div class="filter-item">
                        <button class="btn btn-transparent" type="submit">All Filters</button>
                    </div>
                    <div class="filter-item">
                        <button class="btn btn-default dropdown-toggle" id="dropdown" data-toggle="dropdown"> Brands </button>
                        <ul class="dropdown-menu boxSlimScroll">
                            @foreach($products->brands as $brand)
                                <li class="dropdown-item">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="brand_id[]" value="{{ $brand->id }}" {{ in_array($brand->id, $products->brand_id ) ? "checked='checked'" : ''}}  class="" />
                                        <span>{{ $brand->name }}</span>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="filter-item">
                        <button class="btn btn-default dropdown-toggle" id="dropdown" data-toggle="dropdown"> Sub Brands </button>
                        <ul class="dropdown-menu boxSlimScroll">
                            @foreach($products->sub_brands as $sub_brand)
                                <li class="dropdown-item">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="sub_brand_id[]" value="{{ $sub_brand->id }}" {{ (in_array($sub_brand->id, $products->sub_brand_id )) ? "checked='checked'" : ''}} class="" />
                                        <span>{{ $sub_brand->name }}</span>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="filter-item">
                        <button class="btn btn-default dropdown-toggle" id="dropdown" data-toggle="dropdown"> Size </button>
                        <ul class="dropdown-menu boxSlimScroll">
                            @foreach($products->sizes as $size)
                                <li class="dropdown-item">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="size[]" value="{{ $size->size }}" {{ (in_array($size->size, $products->size )) ? "checked='checked'" : ''}} class="" />
                                        <span>{{ $size->size }}</span>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="filter-item">
                        <button class="btn btn-default dropdown-toggle" id="dropdown" data-toggle="dropdown"> Colors </button>
                        <ul class="dropdown-menu boxSlimScroll">
                            @foreach($products->colors as $color)
                                <li class="dropdown-item">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="color[]" value="{{ $color->color }}" {{ (in_array($color->color, $products->color )) ? "checked='checked'" : ''}} class="" />
                                        <span>{{ $color->color }}</span>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="filter-item">
                        <button class="btn btn-default dropdown-toggle" id="dropdown" data-toggle="dropdown"> Origin </button>
                        <ul class="dropdown-menu boxSlimScroll">
                            @foreach($products->origins as $origin)
                                <li class="dropdown-item">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="origin[]" value="{{ $origin->origin }}" {{ (in_array($origin->origin, $products->origin )) ? "checked='checked'" : ''}} class="" />
                                        <span>{{ $origin->origin }}</span>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="filter-item">
                        <button class="btn btn-default dropdown-toggle" id="dropdown" data-toggle="dropdown"> Materials </button>
                        <ul class="dropdown-menu boxSlimScroll">
                            @foreach($products->materials as $material)
                                <li class="dropdown-item">
                                    <div class="custom-checkbox">
                                        <input type="checkbox" name="material[]" value="{{ $material->material }}" {{ (in_array($material->material, $products->material )) ? "checked='checked'" : ''}} class="" />
                                        <span>{{ $material->material }}</span>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
    @if($filter_applies)
        <div class="filtered-products">
            <div class="container">
                <div class="title-head pt-0 pb-25">
                <h5 class="mb-0">{{ $products->count() }} results</h5>
                    <div class="filter-list">
                        {{ $products->links('vendor.pagination.custom-products-pagination') }}
                    </div>
                </div>

                <div class="product-wrapper row justify-content-start">
                    @foreach($products as $product)
                        <div class="product-list-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                            <div class="product-card">
                                <div class="product-image">
                                    <a href="{{ route('product-detail-page', $product->id) }}">
                                        <img src="{{ asset('images') }}/catalog/products/{{ $product->images[0]->product_image }}" loading="lazy" alt="{{ $product->title }}" class="img-fluid"/>
                                    </a>
                                </div>
                                <div class="product-title">
                                    <a href="{{ route('product-detail-page', $product->id) }}">{{ $product->title }} </a>
                                </div>
                                <div class="product-price">
                                    <div class="price"><strong>{{ $product->price }} </strong> <span>SAR</span> </div>
                                    <div class="strike-price"><span>{{ $product->cost }} SAR</span></div>
                                </div>
                                <div class="btn-group">
                                    <a href="javascript:void(0);" class="btn-item" data-toggle="tooltip" data-placement="left" title="Add to whishlist"><i class="fa fa-heart"></i></a>
                                </div>
                                <div class="quick-view">
                                    <button class="btn btn-transparent" data-toggle="modal" data-target="#quick-view-modal-{{ $product->id }}"><i class="fa fa-search mr-10"></i> <strong>Quick View</strong></button>
                                </div>
                            </div>
                        </div>
                        <!-- Modal Quick View-->
                        <div class="modal fade modal-xxl quick-view-modal" id="quick-view-modal-{{ $product->id }}">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button class="close-btn" data-dismiss="modal">
                                            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                                            </svg>
                                        </button>
                                    </div>
                                    {!! Form::open(['method' => 'post', 'route' => ['admin.product.cart.add', $product->id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                                        <div class="modal-body">
                                            <div class="pdp-content-wrapper">
                                                <div class="row">
                                                    <div class="col-sm-7">
                                                        <div class="pdp-slider-section">
                                                            <!--product large slider-->
                                                            <div class="pdp-slider-holder">
                                                                <div class="pdp-gallery-slider">
                                                                    @foreach($product->images as $image)
                                                                        <div class="slide-item">
                                                                            <div class="image-holder">
                                                                                <img src="{{ asset('images') }}/catalog/products/{{ $image->product_image }}" loading="lazy" class="img-fluid" alt="Slide Image"/>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                </div>
                                                                <!-- <nav class="slider-actions-btn">
                                                                    <ul class="h-list justify-content-center align-items-center">
                                                                        <li>
                                                                            <a href="">
                                                                                <i class="far fa-heart"></i>
                                                                                <span>Add to Wishlist</span>
                                                                            </a>
                                                                        </li>
                                                                        <li class="dropdown">
                                                                            <a href="#"class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                                <i class="fa fa-share-alt"></i>
                                                                                <span>Share</span>
                                                                            </a>
                                                                            <div class="dropdown-menu">
                                                                                <ul class="h-list">
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/wahtsapp.png" alt="WhatsApp" /></a>
                                                                                    </li>
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/snapchat.png" alt="Snapchat" /></a>
                                                                                    </li>
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/facebook.png" alt="Facebook" /></a>
                                                                                    </li>
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/instagram.png" alt="Instagram" /></a>
                                                                                    </li>
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/linkedin.png" alt="Linkedin" /></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <a href="">
                                                                                <i class="fa fa-envelope"></i>
                                                                                <span>Email</span>
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </nav> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-5">
                                                        <!--product Info Details-->
                                                        <div class="pdp-info-detail">
                                                            <h4 class="product-title">{{ $product->title }}</h4>
                                                            <!-- <div class="rating-wrapper h-list">
                                                                <div class="stars">
                                                                    <span class="fa fa-star checked"></span>
                                                                    <span class="fa fa-star checked"></span>
                                                                    <span class="fa fa-star checked"></span>
                                                                    <span class="far fa-star"></span>
                                                                    <span class="far fa-star"></span>
                                                                </div>
                                                                <span class="review-no">(14)</span>
                                                            </div> -->

                                                            <div class="product-price">
                                                                <div class="price">{{ $product->price}} <span>SAR</span></div>
                                                                <!-- <div class="product-discount">
                                                                    <div class="discount-item"><span>Sale Starts</span> <strong>Nov 15, 11:00 AM</strong> </div>
                                                                </div> -->
                                                            </div>

                                                            <div class="shipping-info-text">{{ $product->shipment_information }}</div>
                                                            <div class="product-attributes">
                                                                <div class="product-quantity">
                                                                    <div class="product-qty-wrapper">
                                                                        <label class="info-label">Quantity</label>
                                                                        {!! Form::text('qty', null , ['placeholder' => '20', 'class' => 'form-control']) !!}
                                                                        @if($product->qty > 0)
                                                                            <div class="info-text text-success">In stock</div>
                                                                        @else
                                                                            <div class="info-text text-success">Out of stock</div>
                                                                        @endif
                                                                    </div>
                                                                    @if($errors->first('qty'))
                                                                        <span class="text-danger">{{ $errors->first('qty') }}</span>
                                                                    @endif
                                                                    @if(session()->has('is_available'))
                                                                        <div class="info-text text-danger">Not in stock</div>
                                                                    @endif
                                                                </div>
                                                                @if($product->product_type == 1)
                                                                    <div class="product-size">
                                                                        <div class="sizes-wrapper">
                                                                            <label class="info-label">Size</label>
                                                                            <div class="select-item">
                                                                                <select name="size" class="form-control">
                                                                                    <option value=""> Size </option>
                                                                                    @foreach($product->size as $size)
                                                                                        <option value="{{ $size->id }}"> {{ $size->size }} </option>
                                                                                    @endforeach
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        @if($errors->first('size'))
                                                                            <span class="text-danger">{{ $errors->first('size') }}</span>
                                                                        @endif
                                                                    </div>
                                                                    <div class="product-color">
                                                                        <div class="color-wrapper">
                                                                            <label class="info-label">colors</label>
                                                                            <div class="color-swatches h-list">
                                                                                @foreach($product->color as $color)
                                                                                    <div class="custom-input-wrapper">
                                                                                        <input type="radio" class="custom-input" data-toggle="tooltip" title="{{ $color->color}}" value="{{ $color->id }}" name="color" />
                                                                                        <span class="color"></span>
                                                                                    </div>
                                                                                @endforeach
                                                                            </div>
                                                                        </div>
                                                                        @if($errors->first('color'))
                                                                            <span class="text-danger">{{ $errors->first('color') }}</span>
                                                                        @endif
                                                                    </div>
                                                                @endif
                                                            </div>

                                                            <div class="product-action-btns">
                                                                <div class="btn-item">
                                                                    @if(session()->has('is_available'))
                                                                        <a data-toggle="modal" data-target="#notify-me" role="button" class="add-to-cart btn btn-primary">
                                                                            Notify me
                                                                        </a>
                                                                    @else
                                                                        <button class="add-to-cart btn btn-primary" type="submit">Add to Cart</button>
                                                                    @endif
                                                                </div>
                                                                <!-- <div class="btn-item">
                                                                    <button class="like btn btn-transparent" type="button">Add to Quote</button>
                                                                    <div class="info-text">Are you a Distributor?</div>
                                                                </div> -->
                                                            </div>

                                                            <div id="accordion" class="accordion-wrapper">
                                                                <div class="card-collapse-item">
                                                                    <div class="card-header">
                                                                        <a class="card-link text-black" data-toggle="collapse" href="#collapseOne">
                                                                            <h5>Product Description</h5>
                                                                            <span class="icon-btn"><i class="fa fa-plus"></i></span>
                                                                        </a>
                                                                    </div>
                                                                    <div id="collapseOne" class="collapse show" data-parent="#accordion">
                                                                        <div class="card-body">
                                                                            <div class="content-holder">
                                                                                <p>{{ \Illuminate\Support\Str::limit($product->description, 150, $end='...') }}</p>
                                                                                <a href="{{ route('product-detail-page', $product->id) }}" class="item-link">Read More</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="card-collapse-item">
                                                                    <div class="card-header">
                                                                        <a class="collapsed card-link text-black" data-toggle="collapse" href="#collapseTwo">
                                                                            <h5>Product Specification</h5>
                                                                            <span class="icon-btn"><i class="fa fa-plus"></i></span>
                                                                        </a>
                                                                    </div>
                                                                    <div id="collapseTwo" class="collapse" data-parent="#accordion">
                                                                        <div class="card-body">
                                                                            <ul class="v-list">
                                                                                @foreach($product->product_specifications_attributes as $attribute)
                                                                                <li class="content-list-item">
                                                                                    <strong>{{ $attribute->product_attribute_set->attribute_name }}:</strong>
                                                                                    <span>{{ $attribute->value }}</span>
                                                                                </li>
                                                                                @endforeach
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="card-collapse-item">
                                                                    <div class="card-header">
                                                                        <a class="collapsed card-link text-black" data-toggle="collapse" href="#collapseThree">
                                                                            <h5>Returns & Exchange Policy</h5>
                                                                            <span class="icon-btn"><i class="fa fa-plus"></i></span>
                                                                        </a>
                                                                    </div>
                                                                    <div id="collapseThree" class="collapse" data-parent="#accordion">
                                                                        <div class="card-body">
                                                                            <div class="content-holder">
                                                                                <p>{{ \Illuminate\Support\Str::limit($product->returns_and_exchange, 150, $end='...') }}</p>
                                                                                <a href="{{ route('product-detail-page', $product->id) }}" class="item-link">Read More</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    {!! Form::close() !!}
                                    <div class="modal-footer justify-content-center">
                                        <div class="action-link">
                                            <a href="{{ route('product-detail-page', $product->id) }}" class="link-item">View Full Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    @else
        <div class="filtered-products">
            <div class="container">
                <div class="title-head pt-0 pb-25">
                <h5 class="mb-0">{{ $products->count() }} results</h5>
                    <div class="filter-list">
                        {{ $products->links('vendor.pagination.custom-products-pagination') }}
                    </div>
                </div>

                <div class="product-wrapper row justify-content-start">
                    @foreach($products as $product)
                        <div class="product-list-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                            <div class="product-card">
                                <div class="product-image">
                                    <a href="{{ route('product-detail-page', $product->id) }}">
                                        <img src="{{ asset('images') }}/catalog/products/{{ $product->images[0]->product_image }}" loading="lazy" alt="{{ $product->title }}" class="img-fluid"/>
                                    </a>
                                </div>
                                <div class="product-title">
                                    <a href="{{ route('product-detail-page', $product->id) }}">{{ $product->title }} </a>
                                </div>
                                <div class="product-price">
                                    <div class="price"><strong>{{ $product->price }} </strong> <span>SAR</span> </div>
                                    <div class="strike-price"><span>{{ $product->cost }} SAR</span></div>
                                </div>
                                <div class="btn-group">
                                    <a href="javascript:void(0);" class="btn-item" data-toggle="tooltip" data-placement="left" title="Add to whishlist"><i class="fa fa-heart"></i></a>
                                </div>
                                <div class="quick-view">
                                    <button class="btn btn-transparent" data-toggle="modal" data-target="#quick-view-modal-{{ $product->id }}"><i class="fa fa-search mr-10"></i> <strong>Quick View</strong></button>
                                </div>
                            </div>
                        </div>
                        <!-- Modal Quick View-->
                        <div class="modal fade modal-xxl quick-view-modal" id="quick-view-modal-{{ $product->id }}">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button class="close-btn" data-dismiss="modal">
                                            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                                            </svg>
                                        </button>
                                    </div>
                                    {!! Form::open(['method' => 'post', 'route' => ['admin.product.cart.add', $product->id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                                        <div class="modal-body">
                                            <div class="pdp-content-wrapper">
                                                <div class="row">
                                                    <div class="col-sm-7">
                                                        <div class="pdp-slider-section">
                                                            <!--product large slider-->
                                                            <div class="pdp-slider-holder">
                                                                <div class="pdp-gallery-slider">
                                                                    @foreach($product->images as $image)
                                                                        <div class="slide-item">
                                                                            <div class="image-holder">
                                                                                <img src="{{ asset('images') }}/catalog/products/{{ $image->product_image }}" loading="lazy" class="img-fluid" alt="Slide Image"/>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                </div>
                                                                <!-- <nav class="slider-actions-btn">
                                                                    <ul class="h-list justify-content-center align-items-center">
                                                                        <li>
                                                                            <a href="">
                                                                                <i class="far fa-heart"></i>
                                                                                <span>Add to Wishlist</span>
                                                                            </a>
                                                                        </li>
                                                                        <li class="dropdown">
                                                                            <a href="#"class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                                <i class="fa fa-share-alt"></i>
                                                                                <span>Share</span>
                                                                            </a>
                                                                            <div class="dropdown-menu">
                                                                                <ul class="h-list">
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/wahtsapp.png" alt="WhatsApp" /></a>
                                                                                    </li>
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/snapchat.png" alt="Snapchat" /></a>
                                                                                    </li>
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/facebook.png" alt="Facebook" /></a>
                                                                                    </li>
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/instagram.png" alt="Instagram" /></a>
                                                                                    </li>
                                                                                    <li class="dd-menu-item">
                                                                                        <a href=""><img src="{{ asset('images/social') }}/linkedin.png" alt="Linkedin" /></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <a href="">
                                                                                <i class="fa fa-envelope"></i>
                                                                                <span>Email</span>
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </nav> -->
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-5">
                                                        <!--product Info Details-->
                                                        <div class="pdp-info-detail">
                                                            <h4 class="product-title">{{ $product->title }}</h4>
                                                            <!-- <div class="rating-wrapper h-list">
                                                                <div class="stars">
                                                                    <span class="fa fa-star checked"></span>
                                                                    <span class="fa fa-star checked"></span>
                                                                    <span class="fa fa-star checked"></span>
                                                                    <span class="far fa-star"></span>
                                                                    <span class="far fa-star"></span>
                                                                </div>
                                                                <span class="review-no">(14)</span>
                                                            </div> -->

                                                            <div class="product-price">
                                                                <div class="price">{{ $product->price}} <span>SAR</span></div>
                                                                <!-- <div class="product-discount">
                                                                    <div class="discount-item"><span>Sale Starts</span> <strong>Nov 15, 11:00 AM</strong> </div>
                                                                </div> -->
                                                            </div>

                                                            <div class="shipping-info-text">{{ $product->shipment_information }}</div>
                                                            <div class="product-attributes">
                                                                <div class="product-quantity">
                                                                    <div class="product-qty-wrapper">
                                                                        <label class="info-label">Quantity</label>
                                                                        {!! Form::text('qty', null , ['placeholder' => '20', 'class' => 'form-control']) !!}
                                                                        @if($product->qty > 0)
                                                                            <div class="info-text text-success">In stock</div>
                                                                        @else
                                                                            <div class="info-text text-success">Out of stock</div>
                                                                        @endif
                                                                    </div>
                                                                    @if($errors->first('qty'))
                                                                        <span class="text-danger">{{ $errors->first('qty') }}</span>
                                                                    @endif
                                                                    @if(session()->has('is_available'))
                                                                        <div class="info-text text-danger">Not in stock</div>
                                                                    @endif
                                                                </div>
                                                                @if($product->product_type == 'Configurable Product')
                                                                    <div class="product-size">
                                                                        <div class="sizes-wrapper">
                                                                            <label class="info-label">Size</label>
                                                                            <div class="select-item">
                                                                                <select name="size" class="form-control">
                                                                                    <option value=""> Size </option>
                                                                                    @foreach($product->size as $size)
                                                                                        <option value="{{ $size->id }}"> {{ $size->size }} </option>
                                                                                    @endforeach
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        @if($errors->first('size'))
                                                                            <span class="text-danger">{{ $errors->first('size') }}</span>
                                                                        @endif
                                                                    </div>
                                                                    <div class="product-color">
                                                                        <div class="color-wrapper">
                                                                            <label class="info-label">colors</label>
                                                                            <div class="color-swatches h-list">
                                                                                @foreach($product->color as $color)
                                                                                    <div class="custom-input-wrapper">
                                                                                        <input type="radio" class="custom-input" data-toggle="tooltip" title="{{ $color->color}}" value="{{ $color->id }}" name="color" />
                                                                                        <span class="color"></span>
                                                                                    </div>
                                                                                @endforeach
                                                                            </div>
                                                                        </div>
                                                                        @if($errors->first('color'))
                                                                            <span class="text-danger">{{ $errors->first('color') }}</span>
                                                                        @endif
                                                                    </div>
                                                                @endif
                                                            </div>

                                                            <div class="product-action-btns">
                                                                <div class="btn-item">
                                                                    @if(session()->has('is_available'))
                                                                        <a data-toggle="modal" data-target="#notify-me" role="button" class="add-to-cart btn btn-primary">
                                                                            Notify me
                                                                        </a>
                                                                    @else
                                                                        <button class="add-to-cart btn btn-primary" type="submit">Add to Cart</button>
                                                                    @endif
                                                                </div>
                                                                <!-- <div class="btn-item">
                                                                    <button class="like btn btn-transparent" type="button">Add to Quote</button>
                                                                    <div class="info-text">Are you a Distributor?</div>
                                                                </div> -->
                                                            </div>

                                                            <div id="accordion" class="accordion-wrapper">
                                                                <div class="card-collapse-item">
                                                                    <div class="card-header">
                                                                        <a class="card-link text-black" data-toggle="collapse" href="#collapseOne">
                                                                            <h5>Product Description</h5>
                                                                            <span class="icon-btn"><i class="fa fa-plus"></i></span>
                                                                        </a>
                                                                    </div>
                                                                    <div id="collapseOne" class="collapse show" data-parent="#accordion">
                                                                        <div class="card-body">
                                                                            <div class="content-holder">
                                                                                <p>{{ \Illuminate\Support\Str::limit($product->description, 150, $end='...') }}</p>
                                                                                <a href="{{ route('product-detail-page', $product->id) }}" class="item-link">Read More</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="card-collapse-item">
                                                                    <div class="card-header">
                                                                        <a class="collapsed card-link text-black" data-toggle="collapse" href="#collapseTwo">
                                                                            <h5>Product Specification</h5>
                                                                            <span class="icon-btn"><i class="fa fa-plus"></i></span>
                                                                        </a>
                                                                    </div>
                                                                    <div id="collapseTwo" class="collapse" data-parent="#accordion">
                                                                        <div class="card-body">
                                                                            <ul class="v-list">
                                                                                @foreach($product->product_specifications_attributes as $attribute)
                                                                                <li class="content-list-item">
                                                                                    <strong>{{ $attribute->product_attribute_set->attribute_name }}:</strong>
                                                                                    <span>{{ $attribute->value }}</span>
                                                                                </li>
                                                                                @endforeach
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="card-collapse-item">
                                                                    <div class="card-header">
                                                                        <a class="collapsed card-link text-black" data-toggle="collapse" href="#collapseThree">
                                                                            <h5>Returns & Exchange Policy</h5>
                                                                            <span class="icon-btn"><i class="fa fa-plus"></i></span>
                                                                        </a>
                                                                    </div>
                                                                    <div id="collapseThree" class="collapse" data-parent="#accordion">
                                                                        <div class="card-body">
                                                                            <div class="content-holder">
                                                                                <p>{{ \Illuminate\Support\Str::limit($product->returns_and_exchange, 150, $end='...') }}</p>
                                                                                <a href="{{ route('product-detail-page', $product->id) }}" class="item-link">Read More</a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    {!! Form::close() !!}
                                    <div class="modal-footer justify-content-center">
                                        <div class="action-link">
                                            <a href="{{ route('product-detail-page', $product->id) }}" class="link-item">View Full Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    @endif
    </div>
</x-shop-layout>