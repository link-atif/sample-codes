<x-shop-layout>

    <x-slot name="header">
        <x-sliderComponent :id="1" />
    </x-slot>
    @if($errors->first('qty'))
        <div class="container mt-10 py-10">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <strong>Error !</strong> The Quantity Field is required ...!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    @if($errors->first('size'))
        <div class="container mt-10 py-10">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <strong>Error !</strong> The Size Field is required ...!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    @if($errors->first('color'))
        <div class="container mt-10 py-10">
            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                <strong>Error !</strong> The Color Field is required ...!
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif
    <x-bestSellerComponent />
    <x-featuredSectionComponent :id="4" />
    <x-categoryProductSectionComponent :id="38" />
    <x-discountProductBannerSectionComponent :id="6" />
    <x-brandsCarousalComponent :id="7" />
    <x-newsLetterComponent />
</x-shop-layout>