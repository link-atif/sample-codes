<x-shop-layout>
    <x-slot name="header">
        <nav class="breadcrumbs-wrapper">
            <div class="container">
                <ul class="h-list breadcrumb-list">
                    <li><a href="{{ url('/') }}">Home</a></li>
                    <li><span>All Categories</span></li>
                </ul>
            </div>
        </nav>
    </x-slot>
    <div class="container">
        <div class="two-col-layout">
            <div class="content-wrapper">
                <x-asidebarCategoriesComponent />
                <div class="right-content-area">
                    <x-allCategoryPageBannerComponent :id="5" />
                </div>
            </div>
        </div>
        <div class="category-list-section">
            <div class="row category-wrapper">
                <x-mainCategoryAndSubCategoriesComponent />
            </div>
        </div>
    </div>

    <x-bestSellerComponent />
    <x-recommendedProductsComponent />
</x-shop-layout>