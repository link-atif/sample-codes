<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <div class="thankyou-section-signup">
            <div class="image-holder mb-30">
                <svg viewBox="0 0 84 84" xmlns="http://www.w3.org/2000/svg">
                    <path d="m42 0c-23.196 0-42 18.804-42 42s18.804 42 42 42 42-18.804 42-42c-0.0246-23.186-18.814-41.975-42-42zm0 78c-19.882 0-36-16.118-36-36 0-19.882 16.118-36 36-36 19.882 0 36 16.118 36 36-0.0215 19.874-16.126 35.978-36 36z" fill="#0A2568"/>
                    <path d="m65.047 24.879c-1.1626-1.1229-3.0056-1.1229-4.1681 0l-27.879 27.879-9.8791-9.8791c-1.151-1.1918-3.0504-1.2246-4.242-0.0736-1.1918 1.151-1.2246 3.0503-0.0736 4.2419 0.0241 0.025 0.0487 0.0496 0.0736 0.0737l12 12c1.1714 1.1713 3.0705 1.1713 4.2419 0l30-30c1.151-1.1916 1.1179-3.0908-0.0739-4.2418z" fill="#219653"/>
                </svg>
            </div>
            <h5>Thanks for signing up !</h5>
            <div class="order-detail-block">
                <div class="content-card">
                    <p>We have sent you an email confirmation.</p>
                    <p>Check your inbox and confirm your email...</p>
                    <p><a href="#"><strong>Resend email confirmation</strong> </a></p>
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>