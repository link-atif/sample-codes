@foreach($products as $product) 
    <li>
        <div class="cart-item-wrapper">
            <div class="item-left">
                <div class="image-holder">
                    <img src="{{ asset('images/catalog/products') }}/{{ $product->images[0]->product_image }}" alt="{{ $product->title }}" class="img-fluid" />
                </div>
                <div class="item-info">
                    <div class="item-name">{{ $product->title }}</div>
                    <div class="item-price">{{ $product->price }} SAR</div>
                </div>
            </div>
        </div>
    </li>
@endforeach
<li class="view-cart-button"><button class="text-center btn btn-transparent btn-block">Search Results</button></li>