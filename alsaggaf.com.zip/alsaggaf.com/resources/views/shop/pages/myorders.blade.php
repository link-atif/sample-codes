<x-shop-layout>
    <x-slot name="header">
    </x-slot>
    <div class="container">
        <nav class="breadcrumbs-wrapper">
            <ul class="h-list breadcrumb-list">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="{{ route('myaccount') }}">My Account</a></li>
                <li><span>My Orders</span></li>
            </ul>
        </nav>
        <div class="title-head pt-0 pb-30">
            <h2>My Account</h2>
        </div>
        <div class="two-col-layout">
            <div class="content-wrapper">
                <x-myB2CAccountSideBarComponent />
                <div class="right-content-area">
                    <div class="content-card mb-30">
                        <div class="table-wrapper bg-table">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Id</th>
                                            <th scope="col">Date and time</th>
                                            <th scope="col">Sub Total</th>
                                            <th scope="col">Shipment Charges</th>
                                            <th scope="col">Vat Charges</th>
                                            <th scope="col">Total</th>
                                            <th scope="col">Status</th>
                                            <th scope="col" class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($orders as $order)
                                            <tr>
                                                <td>{{ str_pad($order->id, 8, '0', STR_PAD_LEFT) }}</td>
                                                <td>{{ \Carbon\Carbon::parse($order->created_at)->format('d, F Y g i A') }}</td>
                                                <td>{{ $order->cart_sub_total }}</td>
                                                <td>{{ $order->shippment_charges }}</td>
                                                <td>{{ $order->vat_charges }}</td>
                                                <td>{{ $order->cart_total }}</td>
                                                <td><span class="text-warning">
                                                    @if($order->status == 1)
                                                        Pending
                                                    @elseif($order->status == 2) 
                                                        Order under Prep
                                                    @elseif($order->status == 3) 
                                                        Ready to Dispatch
                                                    @elseif($order->status == 4) 
                                                        Order Dispatched
                                                    @elseif($order->status == 5)
                                                        Delivered
                                                    @elseif($order->status == 6)
                                                        On Hold
                                                    @endif
                                                    @if($order->refund)
                                                        @if($order->refund->status == 0)
                                                            <br>Under Process
                                                        @elseif($order->refund->status == 1)
                                                            <br>Required to return product
                                                        @elseif($order->refund->status == 2)
                                                            <br>Refund under process
                                                        @elseif($order->refund->status == 3)
                                                            <br>Refund Processed
                                                        @elseif($order->refund->status == 4)
                                                            <br>Request rejected due to exceeding 15 days
                                                        @elseif($order->refund->status == 5)
                                                            <br>Request rejected due to product failing quality check
                                                        @endif
                                                    @endif
                                                </span></td>
                                                <td  class="text-center"><a href="{{ route('myaccount.orders.detail', $order->id) }}" class="btn btn-transparent">View Details</a></td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-shop-layout>