<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>{{ config('app.name', 'Laravel') }}</title>
        <!-- Styles -->
        <link rel="stylesheet" href="{{ asset('css/shop-app.css') }}">
        <!-- Scripts -->
        
    </head>
    <body>
        <x-shopHeaderComponent></x-shopHeaderComponent>
        {{ $header }}
        <main class="main-content">
            {{ $slot }}
        </main>
        <x-shopFooterComponent></x-shopFooterComponent>

        <!-- Modal -->
        @if(Cookie::get('user_type') == null)
            <div id="openModal" class="modal fade show" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" role="dialog" style="display:block">
                <div class="login-options">
                    <div class="login-wrapper">
                        <div class="card-info">
                            <div class="card-header">
                                <h5>Which describes you best ?</h5>
                                <a href="{{ route('save-user-type', 3) }}" class="close" >
                                    <span aria-hidden="true">&times;</span>
                                </a>
                            </div>
                            <div class="card-wrapper">
                                <div class="card-item-option primary">
                                    <a href="{{ route('save-user-type', 1) }}">
                                        <div class="image-holder">
                                            <svg fill="none" viewBox="0 0 89 89" xmlns="http://www.w3.org/2000/svg">
                                            <circle cx="44.5" cy="44.5" r="44" stroke="currentColor"/>
                                            <g fill="currentColor" opacity=".9">
                                            <path d="m50.606 29.343c-5.417-0.6933-9.1222 1.5818-9.6855 5.9371-0.4984 3.8785 1.43 6.5003 6.8687 9.3822 7.2804 3.5969 10.466 8.0388 9.7506 13.542-0.2384 1.7984-0.8451 3.4235-1.7985 4.8319 5.3304-2.7518 8.9273-7.8871 9.7073-13.824 0.4767-3.7486-0.195-7.4755-1.9501-10.791-1.7118-3.2502-4.3336-5.872-7.5621-7.5838-1.7335-0.7584-3.5102-1.2567-5.3304-1.4951z"/>
                                            <path d="m48.505 24.165c-5.0487-0.7151-11.202 0.91-16.078 4.6802-4.1819 3.2502-7.4321 8.0605-8.2338 14.301-0.91 7.0854 1.5384 12.437 4.3336 16.056 2.3401 3.0335 4.9403 4.8753 6.002 5.547l0.1734-0.26c-1.9285-1.4735-3.7269-3.1419-5.222-5.0704-2.9685-3.8569-4.7453-8.7321-4.0086-15.081 0.6717-6.0887 3.9869-10.942 8.1688-14.171 4.2036-3.2285 9.2306-4.8103 13.304-4.3986h0.065l0.065-0.0433 1.5384-1.3001 0.26-0.2167-0.3683-0.0433z"/>
                                            <path d="m52.492 58.422c0.5201-3.9652-1.4517-6.6087-6.9121-9.4906-6.652-3.2935-10.466-7.4971-9.7072-13.434 0.26-1.9501 0.9534-3.7052 2.0585-5.1786-5.3737 2.6001-9.3823 7.7788-10.184 14.128-0.9967 7.7571 3.0335 15.038 9.5773 18.483 1.6251 0.7151 3.4235 1.2568 5.3519 1.5168 5.612 0.7367 9.2523-1.7334 9.8156-6.0237z"/>
                                            </g>
                                            </svg>
                                        </div>
                                    </a>
                                    <div class="card-title">Home Owner</div>
                                    <div class="card-desc">Some text goes here</div>
                                </div>
                                <div class="card-item-option">
                                    <a href="{{ route('save-user-type', 2) }}">
                                        <div class="image-holder">
                                            <svg fill="none" viewBox="0 0 89 89" xmlns="http://www.w3.org/2000/svg">
                                            <circle cx="44.5" cy="44.5" r="44" stroke="currentColor"/>
                                            <g fill="currentColor" opacity=".9">
                                            <path d="m50.606 29.343c-5.417-0.6933-9.1222 1.5818-9.6855 5.9371-0.4984 3.8785 1.43 6.5003 6.8687 9.3822 7.2804 3.5969 10.466 8.0388 9.7506 13.542-0.2384 1.7984-0.8451 3.4235-1.7985 4.8319 5.3304-2.7518 8.9273-7.8871 9.7073-13.824 0.4767-3.7486-0.195-7.4755-1.9501-10.791-1.7118-3.2502-4.3336-5.872-7.5621-7.5838-1.7335-0.7584-3.5102-1.2567-5.3304-1.4951z"/>
                                            <path d="m48.505 24.165c-5.0487-0.7151-11.202 0.91-16.078 4.6802-4.1819 3.2502-7.4321 8.0605-8.2338 14.301-0.91 7.0854 1.5384 12.437 4.3336 16.056 2.3401 3.0335 4.9403 4.8753 6.002 5.547l0.1734-0.26c-1.9285-1.4735-3.7269-3.1419-5.222-5.0704-2.9685-3.8569-4.7453-8.7321-4.0086-15.081 0.6717-6.0887 3.9869-10.942 8.1688-14.171 4.2036-3.2285 9.2306-4.8103 13.304-4.3986h0.065l0.065-0.0433 1.5384-1.3001 0.26-0.2167-0.3683-0.0433z"/>
                                            <path d="m52.492 58.422c0.5201-3.9652-1.4517-6.6087-6.9121-9.4906-6.652-3.2935-10.466-7.4971-9.7072-13.434 0.26-1.9501 0.9534-3.7052 2.0585-5.1786-5.3737 2.6001-9.3823 7.7788-10.184 14.128-0.9967 7.7571 3.0335 15.038 9.5773 18.483 1.6251 0.7151 3.4235 1.2568 5.3519 1.5168 5.612 0.7367 9.2523-1.7334 9.8156-6.0237z"/>
                                            </g>
                                            </svg>
                                        </div>
                                    </a>
                                    <div class="card-title">Distributor</div>
                                    <div class="card-desc">Some text goes here</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endif
        @if(Cookie::get('user_type') == 3 && Cookie::get('user_preferences') == null)
            <div class="modal fade show" id="preferencesModel" tabindex="-1" aria-labelledby="preferencesModelLabel" aria-hidden="true" role="dialog" style="display:block">
                <div class="interest-modal">w
                    <div class="interest-modal-wrapper">
                        <div class="card-info">
                            <div class="card-header">
                                <h5>What are you interested in ?</h5>
                                <p>Follow 3 or more topics to see more of what you're interested in</p>
                                <div class="search-holder">
                                    <div class="h-list">
                                        <input type="text" placeholder="Search Topic" class="form-control"/>
                                        <button class="btn btn-primary">Search</button>
                                    </div>
                                </div>
                            </div>
                            {!! Form::open(['method' => 'post', 'route' => 'save-user-preferences', 'class' => 'form-horizontal']) !!}
                                <div class="card-wrapper boxscroll">
                                    @foreach($categories as $category)
                                        <div class="card-item">
                                            <div class="card-desc">
                                                <div class="customCheckBox">
                                                    <input type="checkbox" name="preferences[]" value="{{ $category->id }}" id="customCheck-{{ $category->id }}" />
                                                </div>
                                                <label for="customCheck-{{ $category->id }}">
                                                    <div class="card-image">
                                                        <img src="{{ asset('images/catalog/category') }}/{{ $category->thumbnail }}" alt="{{ $category->name }}" class="img-fluid"/>
                                                    </div>
                                                    <div class="card-title">{{ $category->name }}</div>
                                                </label>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="text-center">
                                    <button class="btn btn-primary" type="submit">Save Preference</button>
                                </div>
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        @else
            <div class="modal fade" id="preferencesModel" tabindex="-1" aria-labelledby="preferencesModelLabel" aria-hidden="true" role="dialog">
                <div class="interest-modal">w
                    <div class="interest-modal-wrapper">
                        <div class="card-info">
                            <div class="card-header">
                                <h5>What are you interested in ?</h5>
                                <p>Follow 3 or more topics to see more of what you're interested in</p>
                                <div class="search-holder">
                                    <div class="h-list">
                                        <input type="text" placeholder="Search Topic" class="form-control"/>
                                        <button class="btn btn-primary">Search</button>
                                    </div>
                                </div>
                            </div>
                            {!! Form::open(['method' => 'post', 'route' => 'save-user-preferences', 'class' => 'form-horizontal']) !!}
                                <div class="card-wrapper boxscroll">
                                    @foreach($categories as $category)
                                        <div class="card-item">
                                            <div class="card-desc">
                                                <div class="customCheckBox">
                                                    <input type="checkbox" name="preferences[]" value="{{ $category->id }}" id="customCheck-{{ $category->id }}" />
                                                </div>
                                                <label for="customCheck-{{ $category->id }}">
                                                    <div class="card-image">
                                                        <img src="{{ asset('images/catalog/category') }}/{{ $category->thumbnail }}" alt="{{ $category->name }}" class="img-fluid"/>
                                                    </div>
                                                    <div class="card-title">{{ $category->name }}</div>
                                                </label>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="text-center">
                                    <button class="btn btn-primary" type="submit">Save Preference</button>
                                </div>
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        @endif
        @livewireScripts
        <script src="{{ asset('js/shop-app.js') }}" defer></script>
        <script>
            // function searchProducts() {
            //     $query = document.getElementById('inputSearch').value;
            //     if($query.length >= 2) {
            //         console.log('done');
            //     }
            // }
        </script>
    </body>
</html>