<p> Hello... </p>
<span> <strong>Message:</strong> </span>
<span> Thanks for your order.</span>
<a href="{{ $tracking_link }}"> Track Your Order </a>
<p> Kind Regards... </p>
<span> <strong>Name:</strong> ALSAGGAF TEAM </span></br>
<span> <strong>Email:</strong> info@alsaggaf.com.sa </span>