<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::model($location, ['method' => 'put', 'route' => ['admin.location.update', $tt_content_id, $location->id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                <div class="title-head">
                    <h2>Edit Location</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item"><a href="{{ route('admin.location.index', $tt_content_id) }}" class="btn btn-primary"> Back </a></li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>

                <div class="card-form-wrapper">
                    <div class="card-item">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputBranch_name', 'Branch Name', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('branch_name', null , ['placeholder' => 'Branch', 'class' => 'form-control', 'id' => 'inputBranch_name']) !!}
                                            <span class="text-danger">{{ $errors->first('branch_name') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputAddress', 'Address', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('address', null , ['placeholder' => 'Address', 'class' => 'form-control', 'id' => 'inputAddress']) !!}
                                            <span class="text-danger">{{ $errors->first('address') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputPhone_number', 'Phone No', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('phone_number', null , ['placeholder' => 'Phone Number', 'class' => 'form-control', 'id' => 'inputPhone_number']) !!}
                                            <span class="text-danger">{{ $errors->first('phone_number') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputWhatsapp_number', 'Whatsapp No', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('whatsapp_number', null , ['placeholder' => 'WhatsApp Number', 'class' => 'form-control', 'id' => 'inputWhatsapp_number']) !!}
                                            <span class="text-danger">{{ $errors->first('whatsapp_number') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputLatitude', 'Latitude', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('latitude', null , ['placeholder' => 'Latitude', 'class' => 'form-control', 'id' => 'inputLatitude']) !!}
                                            <span class="text-danger">{{ $errors->first('latitude') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputLongitude', 'Longitude', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('longitude', null , ['placeholder' => 'Longitude', 'class' => 'form-control', 'id' => 'inputLongitude']) !!}
                                            <span class="text-danger">{{ $errors->first('longitude') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputStatus', 'Status', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                             {!! Form::select('status', [0 => 'In Active', '1' => 'Active'] , null, ['placeholder' => 'Status', 'class' => 'form-control', 'id' => 'inputStatus']) !!}
                                            <span class="text-danger">{{ $errors->first('status') }}</span>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>