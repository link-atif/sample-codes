<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>CMS Page: "{{ $tt_contents->page->title }}"</h2>
            </div>
            @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
            @foreach($tt_contents as $content)
                <div class="card-form-wrapper">
                    <div class="card-item">
                        <div class="card-holder">
                            <div class="row">
                            <div class="title-head">
                                <h2>{{ $content->component->title }}</h2>
                            </div>
                            </div>
                            <div class="row align-items-center">
                                <div class="col-md-8 order-md-2">
                                    <div class="section-inner-txt order-md-2">
                                        <h3>
                                        {{ $content->component->title }}
                                        </h3>
                                        {{ $content->component->description }}
                                    </div>
                                </div>
                                <div class="col-md-4 order-md-1">
                                    <div class="section-inner-img">
                                        <img src="{{ asset('images')}}/{{ $content->component->thumbnail }}">
                                    </div>
                                </div>
                            </div>
                            @if(
                                $content->component->id != 1 
                                && $content->component->id != 2 
                                && $content->component->id != 3 
                                && $content->component->id != 9 
                                && $content->component->id != 14 
                                && $content->component->id != 22
                                && $content->component->id != 26
                                && $content->component->id != 27
                                && $content->component->id != 30
                                && $content->component->id != 33
                            )
                                <a href="{{ url('admin/component') }}/{{ $content->id }}/edit" class="btn btn-primary mt-20"> Edit {{ $content->component->title }} </a>
                            @endif
                            @if($content->component->id == 1)
                                <a href="/admin/{{ $content->id }}/slider" class="btn btn-primary mt-20"> Slider Slides </a>
                            @endif
                            @if($content->component->id == 7)
                                <a href="/admin/{{ $content->id }}/brands-carousal" class="btn btn-primary mt-20"> Brands Carousal Slider Slides </a>
                            @endif
                            @if($content->component->id == 14)
                                <a href="/admin/{{ $content->id }}/project" class="btn btn-primary mt-20"> Projects </a>
                            @endif
                            @if($content->component->id == 33)
                                <a href="/admin/{{ $content->id }}/timeline" class="btn btn-primary mt-20"> Timeline </a>
                            @endif
                           <!-- @if($content->component->id == 19)
                                <a href="/admin/{{ $content->id }}/media" class="btn btn-primary mt-20"> Media </a>
                            @endif-->
                            @if($content->component->id == 22)
                                <a href="/admin/{{ $content->id }}/location" class="btn btn-primary mt-20"> Locations </a>
                            @endif
                            @if($content->component->id == 25)
                                <a href="/admin/{{ $content->id }}/team" class="btn btn-primary mt-20"> Our Team </a>
                            @endif
                            @if($content->component->id == 26)
                                <a href="/admin/{{ $content->id }}/division" class="btn btn-primary mt-20"> Our Divisions </a>
                            @endif
                            @if($content->component->id == 27)
                                <a href="/admin/{{ $content->id }}/jobs" class="btn btn-primary mt-20"> Jobs Listings </a>
                            @endif
                            @if($content->component->id == 30)
                                <a href="/admin/{{ $content->id }}/faq" class="btn btn-primary mt-20"> FAQ Accordions </a>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</x-master-layout>