<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>All Product Attributes</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><a href="{{ route('admin.attribute-set.create') }}" class="btn btn-primary"> Add Product Attribute</a></li>
                </ul>
            </div>

            <div class="filter-wrapper">
                <div class="search-holder">
                    
                </div>
                <div class="filter-section">
                    {{ $product_attribute_sets->links('vendor.pagination.custom-pagination') }}
                </div>
            </div>

            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Attribute Name</th>
                                    <th scope="col">Attribute Type</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($product_attribute_sets as $product_attribute_set)
                                    <tr>
                                        <td> {{ $loop->iteration }} </td>
                                        <td>{{ $product_attribute_set->attribute_name }}</td>
                                        @if($product_attribute_set->configureable == 0)
                                            <td> Product Specification Attribute </td>
                                        @elseif($product_attribute_set->configureable == 1)
                                            <td> Product Configureable Attribute </td>
                                        @endif
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.attribute-set.edit', ['attribute_set' => $product_attribute_set->id]) }}">Edit</a> 
                                                <a data-toggle="modal" data-target="#deleteModal_{{$product_attribute_set->id}}" role="button">Delete</a>
                                                <!-- Modal -->
                                                <div class="modal fade" id="deleteModal_{{$product_attribute_set->id}}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel_{{$product_attribute_set->id}}" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel_{{$product_attribute_set->id}}">Delete Product Attribute</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure, you wants to delete ...
                                                            </div>
                                                            <div class="modal-footer">
                                                                {!! Form::open(['method' => 'delete', 'route' => ['admin.attribute-set.destroy', $product_attribute_set->id], 'class' => 'form-horizontal']) !!}
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                                {!! Form::close() !!}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    {{ $product_attribute_sets->links() }}
                </div>
            </div>
        </div>
    </div>
</x-master-layout>