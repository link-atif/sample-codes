<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::model($product_attribute_set, ['method' => 'put', 'route' => ['admin.attribute-set.update', $product_attribute_set->id], 'class' => 'form-horizontal']) !!}
                <div class="title-head">
                    <h2>Create Product Attribute</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>

                <div class="card-form-wrapper">
                    <div class="card-item">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputAttributeSetName', 'Attribute Name', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('attribute_name', null , ['placeholder' => 'Attribute Name', 'class' => 'form-control', 'id' => 'inputAttributeSetName']) !!}
                                            <span class="text-danger">{{ $errors->first('attribute_name') }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>