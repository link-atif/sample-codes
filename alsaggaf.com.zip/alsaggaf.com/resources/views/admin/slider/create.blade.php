<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::open(['method' => 'post', 'route' => ['admin.slider.store', $tt_content_id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                <div class="title-head">
                    <h2>Create Slide</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>

                <div class="card-form-wrapper">
                    <div class="card-item">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('headline', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                            <span class="text-danger">{{ $errors->first('headline') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputButtonLabel', 'Button Label', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('button_label', null , ['placeholder' => 'Button Label', 'class' => 'form-control', 'id' => 'inputButtonLabel']) !!}
                                            <span class="text-danger">{{ $errors->first('button_label') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputButtonLink', 'Button Link', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('button_link', null , ['placeholder' => 'Button Link', 'class' => 'form-control', 'id' => 'inputButtonLink']) !!}
                                            <span class="text-danger">{{ $errors->first('button_link') }}</span>
                                        </div>
                                    </div>
                                     <div class="form-group row">
                                        {!! Form::label('inputSortOrder', 'Sort Order', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::number('sort_order', null , ['placeholder' => 'Sort Order', 'class' => 'form-control', 'id' => 'inputSortOrder', 'min' => '0']) !!}
                                            <span class="text-danger">{{ $errors->first('sort_order') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group files">
                                        {!! Form::file('image',['class' => 'form-control', 'id' => 'inputImage', 'onChange' => 'encodeImageFileAsURL("inputImage", "image_preview", "");']) !!}
                                        <div class="content">Drag or Drop Slider Image <span class="required">*</span></div>
                                        <span class="text-danger">{{ $errors->first('image') }}</span>
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                
                                    <div class="form-group files">
                                        {!! Form::file('mobile_image',['class' => 'form-control', 'id' => 'inputImage1', 'onChange' => 'encodeImageFileAsURL("inputImage1", "image_preview_new", "");']) !!}
                                        <div class="content">Drag or Drop Slider Image for Mobile <span class="required">*</span></div>
                                        <span class="text-danger">{{ $errors->first('mobile_image') }}</span>
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview_new"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>