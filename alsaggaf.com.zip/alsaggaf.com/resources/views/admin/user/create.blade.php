<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::open(['method' => 'post', 'route' => ['admin.user.store'], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                <div class="title-head">
                    <h2>Create User</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item"><a href="{{ route('admin.user.index') }}" class="btn btn-primary"> Back </a></li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>

                <div class="card-form-wrapper">
                    <div class="card-item">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputName', 'Name', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('name', null , ['placeholder' => 'Name', 'class' => 'form-control', 'id' => 'inputName']) !!}
                                        <span class="text-danger">{{ $errors->first('name') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputEmail', 'E-Mail', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('email', null , ['placeholder' => 'E-Mail', 'class' => 'form-control', 'id' => 'inputEmail']) !!}
                                        <span class="text-danger">{{ $errors->first('email') }}</span>
                                    </div>
                                    </div>
                                    <div class="form-group row">
                                    {!! Form::label('inputPassword', 'Enter Password', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::password('password', ['placeholder' => 'Enter Password', 'class' => 'form-control', 'id' => 'inputPassword']) !!}
                                        <span class="text-danger">{{ $errors->first('password') }}</span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputConfirmPassword', 'Password Confirmation', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::password('password_confirmation', ['placeholder' => 'Password Confirmation', 'class' => 'form-control', 'id' => 'inputConfirmPassword']) !!}
                                        <span class="text-danger">{{ $errors->first('password_confirmation') }}</span>
                                    </div>
                                </div>
                                   
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>