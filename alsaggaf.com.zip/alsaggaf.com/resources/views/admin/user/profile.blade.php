<x-master-layout>

    <div class="main-wrapper">

        <div class="dashboard-wrapper">

            <div class="title-head">

                <h2>User</h2>

                <ul class="btn-group h-list">

                    <li class="btn-item"><a href="{{ url('/admin/user') }}" class="btn btn-primary"> Back </a></li>

                </ul>

            </div>

            @if(session()->has('message'))

                <div class="alert alert-primary alert-dismissible fade show" role="alert">

                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                        <span aria-hidden="true">&times;</span>

                    </button>

                </div>

            @endif

            <div class="all-product-table">

                <div class="table-wrapper mb-30">

                    <div class="table-responsive">

                        <table class="table">

                            <tbody>

                                <tr>
                                    <th scope="col" style="border:none;">Name</th>
                                    <td style="border:none;">{{ $user->name }}</td>
                                </tr>
                                <tr>
                                    <th scope="col">Email</th>
                                    <td>{{ $user->email }}</td>
                                </tr>

                                

                            </tbody>

                            

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </div>

</x-master-layout>