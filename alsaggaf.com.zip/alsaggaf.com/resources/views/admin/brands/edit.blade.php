<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::model($brand, ['method' => 'put', 'route' => ['admin.brand.update', $brand->id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                <div class="title-head">
                    <h2>Edit Brand</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            <a href="{{ route('admin.brand.index') }}" class="btn btn-primary"> Back </a>
                        </li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>
                @if(session()->has('message'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                @if($errors->first('name'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>Error!</strong> Something went wrong, Please Try again Later. 
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="card-form-wrapper">
                    <div class="card-item basic-detail">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputName', 'Name', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('name', null , ['placeholder' => 'Name', 'class' => 'form-control', 'id' => 'inputName']) !!}
                                            <span class="text-danger">{{ $errors->first('name') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputWebsiteLink', 'Website Link', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('website', null , ['placeholder' => 'Website Link', 'class' => 'form-control', 'id' => 'inputWebsiteLink']) !!}
                                            <span class="text-danger">{{ $errors->first('website') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputEmail', 'Email', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('email', null , ['placeholder' => 'Email', 'class' => 'form-control', 'id' => 'inputEmail']) !!}
                                            <span class="text-danger">{{ $errors->first('email') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputShortDescription', 'Short Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('short_description', null , ['placeholder' => 'Short Description', 'class' => 'form-control', 'id' => 'inputShortDescription']) !!}
                                            <span class="text-danger">{{ $errors->first('short_description') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputDescription', 'Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('description', null , ['placeholder' => 'Description', 'class' => 'form-control', 'id' => 'inputDescription']) !!}
                                            <span class="text-danger">{{ $errors->first('description') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group files">
                                        {!! Form::file('image',['class' => 'form-control', 'id' => 'inputImage',  'onChange' => 'encodeImageFileAsURL("inputImage", "image_preview", "old_image");']) !!}
                                        <div class="content">Drag or Drop Brand Image <span class="required">*</span></div>
                                        <span class="text-danger">{{ $errors->first('image') }}</span>
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($brand->image !="")
                                            <img width="125px" height="125px" src="{{ asset('images/brand/'.$brand->image) }}">
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
    <!-- Product Sub Brand Edit Model -->
    @if($brand->sub_brands)
        @foreach($brand->sub_brands as $sub_brand)
            <div class="modal fade modal-xxl quick-view-modal" id="sub-brand-edit-model-{{ $sub_brand->id }}">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button class="close-btn" data-dismiss="modal">
                                <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                                </svg>
                            </button>
                        </div>
                        {!! Form::model($sub_brand, ['method' => 'put', 'route' => ['admin.sub-brand.update', $sub_brand->id], 'class' => 'form-horizontal']) !!}
                            <div class="modal-body">
                                <div class="pdp-content-wrapper">
                                    <div class="form-group row">
                                        {!! Form::label('inputSubBrandName', 'Sub Brand Name', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('name', null , ['placeholder' => 'Sub Brand Name', 'class' => 'form-control', 'id' => 'inputSubBrandName']) !!}
                                            <span class="text-danger">{{ $errors->first('name') }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer justify-content-center">
                                <div class="action-link">
                                    <button type="submit" class="btn btn-primary">Update Sub Brand</button>
                                </div>
                            </div>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        @endforeach
    @endif
    <!-- Sub Brand Add Model -->
    <div class="modal fade modal-xxl quick-view-modal" id="sub_brand_model" style="z-index: 1051;">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button class="close-btn" data-dismiss="modal">
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                        </svg>
                    </button>
                </div>
                {!! Form::open(['method' => 'post', 'route' => ['admin.sub_brand.add', $brand->id], 'class' => 'form-horizontal']) !!}
                    <div class="modal-body">
                        <div class="pdp-content-wrapper">
                            <div class="form-group row">
                                {!! Form::label('inputSubBrandTitle', 'Sub Brand Name', ['class' => 'col-sm-3 col-form-label']) !!}
                                <div class="col-sm-9">
                                    {!! Form::text('name', null , ['placeholder' => 'Sub Brand Name', 'class' => 'form-control', 'id' => 'inputSubBrandTitle']) !!}
                                    <span class="text-danger">{{ $errors->first('name') }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <div class="action-link">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
    <!-- Sub Brand Delete Modal -->
    @foreach($brand->sub_brands as $sub_brand)
        <div class="modal fade modal-xxl quick-view-modal" id="sub-brand-delete-model-{{ $sub_brand->id }}">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button class="close-btn" data-dismiss="modal">
                            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                            </svg>
                        </button>
                    </div>
                    <div class="modal-body">
                        Are you sure, you wants to delete Sub Brand ({{ $sub_brand->name }})
                    </div>
                    <div class="modal-footer">
                        {!! Form::open(['method' => 'delete', 'route' => ['admin.sub-brand.delete',$sub_brand->id], 'class' => 'form-horizontal']) !!}
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Delete</button>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
</x-master-layout>