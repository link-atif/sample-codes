<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::open(['method' => 'post', 'route' => 'admin.brand.store', 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                <div class="title-head">
                    <h2>Add Brand</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            <a href="{{ route('admin.brand.index') }}" class="btn btn-primary"> Back </a>
                        </li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>
                @if(session()->has('message'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="card-form-wrapper">
                    <div class="card-item basic-detail">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputName', 'Name', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('name', null , ['placeholder' => 'Name', 'class' => 'form-control', 'id' => 'inputName']) !!}
                                            <span class="text-danger">{{ $errors->first('name') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputWebsiteLink', 'Website Link', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('website', null , ['placeholder' => 'Website Link', 'class' => 'form-control', 'id' => 'inputWebsiteLink']) !!}
                                            <span class="text-danger">{{ $errors->first('website') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputEmail', 'Email', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('email', null , ['placeholder' => 'Email', 'class' => 'form-control', 'id' => 'inputEmail']) !!}
                                            <span class="text-danger">{{ $errors->first('email') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputShortDescription', 'Short Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('short_description', null , ['placeholder' => 'Short Description', 'class' => 'form-control', 'id' => 'inputShortDescription']) !!}
                                            <span class="text-danger">{{ $errors->first('short_description') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputDescription', 'Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('description', null , ['placeholder' => 'Description', 'class' => 'form-control', 'id' => 'inputDescription']) !!}
                                            <span class="text-danger">{{ $errors->first('description') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group files">
                                        {!! Form::file('image',['class' => 'form-control', 'id' => 'inputImage', 'onChange' => 'encodeImageFileAsURL("inputImage", "image_preview", "");']) !!}
                                        <div class="content">Drag or Drop Brand Image <span class="required">*</span></div>
                                        <span class="text-danger">{{ $errors->first('image') }}</span>
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>