<x-master-layout>
    <div class="main-wrapper">
    
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>Orders</h2>
            </div>
            <div class="filter-wrapper">
                <div class="search-holder">
                    
                </div>
                <div class="filter-section">
                    {{ $orders->links('vendor.pagination.custom-pagination') }}
                </div>
            </div>
            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Id</th>
                                    <th scope="col">Order ID</th>
                                    <th scope="col">Cancellation Creation</th>
                                    <th scope="col">Customer</th>
                                    <th scope="col">Reason</th>
                                    <th scope="col">Total Amount</th>
                                    <th scope="col">Refund Amount</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($orders as $order)
                                    <tr>
                                        <td>{{ str_pad($order->id, 8, '0', STR_PAD_LEFT) }}</td>
                                        <td>{{ str_pad($order->order_id, 8, '0', STR_PAD_LEFT) }}</td>
                                        <td>{{ \Carbon\Carbon::parse($order->created_at)->format('d, F Y') }}</td>
                                        <td>{{ $order->fe_user->name }}</td>
                                        <td>{{ $order->reason }}</td>
                                        <td>{{ $order->order->cart_total }}</td>
                                        <td>{{ $order->refund_amount }}</td>
                                        <td>
                                            @if($order->status == 0)
                                                Pending
                                            @elseif($order->status == 1) 
                                                Order under Prep
                                            @elseif($order->status == 2) 
                                                Ready to Dispatch
                                            @elseif($order->status == 3) 
                                                Order Dispatched
                                            @elseif($order->status == 4)
                                                Delivered
                                            @elseif($order->status == 5)
                                                On Hold
                                            @endif
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.cancellation.show', $order->id) }}">View</a> 
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>