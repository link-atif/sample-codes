<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
                <div class="title-head title-buttons">
                    <h2>Cancellation: {{ str_pad($cancel->id, 8, '0', STR_PAD_LEFT) }}</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item"><button class="btn btn-primary" type="button" onclick="updateCancellationProcess()"> Save </button></li>
                    </ul>
                </div>

            <div class="card-form-wrapper">
                <div class="card-item tab-area">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="generalInfo" data-toggle="tab" href="#general-info" role="tab" aria-selected="true">General Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="refundTab" data-toggle="tab" href="#refund-tab" role="tab" aria-selected="false">Refunds</a>
                        </li>
                    </ul>
                    <div class="card-holder">
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="general-info" role="tabpanel">
                                {!! Form::model($cancel, ['method' => 'put', 'route' => ['admin.cancellation.update', $cancel->id], 'class' => 'form-horizontal', 'id' => 'cancellation-status-form']) !!}
                                    <div class="order-info-wrapper">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12 order-md-2 order-lg-0">
                                                <nav class="order-info-item">
                                                    <h5>Refund Information</h5>
                                                    <ul class="v-list">
                                                        <li>
                                                            <span class="text-primary">Order Date </span>
                                                            <span class="info-text">{{ \Carbon\Carbon::parse($cancel->created_at)->format('d, F Y g i A') }}</span>
                                                        </li>
                                                        <li>
                                                            <span class="text-primary">Order Status </span>
                                                            <span class="select-item">
                                                                {!! Form::select('status', ['0' => 'On Hold', '1' => 'Refund under Process',  '2' => 'Refund Processed', '3' => 'Order continues as planned to Dispatch', '4' => 'Cancellation Rejected'], null , ['placeholder' => 'Status', 'class' => 'form-control font-size-14 height-30 select-box-line-height']) !!}
                                                            </span>
                                                        </li>
                                                        <li>
                                                            <span class="text-primary">Type </span>
                                                            <span class="info-text">
                                                                @if($cancel->order->transaction->transaction_type == 1)
                                                                    Online Transaction
                                                                @elseif($cancel->order->transaction->transaction_type == 2) 
                                                                    Online Transaction
                                                                @else
                                                                    Cash
                                                                @endif
                                                            </span>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12">
                                                <nav class="order-info-item">
                                                    <h5>Billing Address</h5>
                                                    <div class="content-holder">
                                                        <p>{{ $cancel->fe_user->billing_address->address }} </p>
                                                    </div>
                                                </nav>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12">
                                                <nav class="order-info-item">
                                                    <h5>Shipping Address</h5>
                                                    <div class="content-holder">
                                                        <p>{{ $cancel->fe_user->shipping_address->address }} </p>
                                                    </div>
                                                </nav>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12 order-md-3 order-lg-3">
                                                <nav class="order-info-item">
                                                    <h5>Account Information</h5>
                                                    <ul class="v-list">
                                                        <li>
                                                            <span class="text-primary">Customer Name</span>
                                                            <span class="info-text">{{ $cancel->fe_user->name }}</span>
                                                        </li>
                                                        <li>
                                                            <span class="text-primary">Email  </span>
                                                            <span class="info-text">{{ $cancel->fe_user->email }}</span>
                                                        </li>
                                                        <li>
                                                            <span class="text-primary">Customer type </span>
                                                            @if($cancel->fe_user->user_type == 0)
                                                                <span class="info-text">Guest</span>
                                                            @elseif($cancel->fe_user->user_type == 1)
                                                                <span class="info-text">General</span>
                                                            @else
                                                                <span class="info-text">Distributor</span>
                                                            @endif
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12 order-md-4 order-lg-4">
                                                <nav class="order-info-item">
                                                    <h5>Payment info</h5>
                                                    <ul class="v-list">
                                                        <li>
                                                            <span class="text-primary">Payment Method</span>
                                                            <span class="info-text">
                                                                @if($cancel->order->transaction->transaction_type == 1)
                                                                    Credit
                                                                @elseif($cancel->order->transaction->transaction_type == 2) 
                                                                    Debit
                                                                @else
                                                                    Cash on Delivery
                                                                @endif
                                                            </span>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        </div>
                                    </div>
                                {!! Form::close() !!}
                            </div>
                            <div class="tab-pane fade" id="refund-tab" role="tabpanel">
                                {!! Form::model($cancel, ['method' => 'put', 'route' => ['admin.cancellation.update', $cancel->id], 'class' => 'form-horizontal']) !!}
                                    <h5 class="mb-30">Refund Detail</h5>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group row">
                                                <div class="form-item col-lg-6 col-md-6 mb-15">
                                                    <div class="row">
                                                        <label for="refund_amount" class="col-sm-3 col-form-label">Refund Amount</label>
                                                        <div class="col-sm-9">
                                                            <input type="text" name="refund_amount" value="{{ $cancel->refund_amount }}" class="form-control" id="refund_amount" placeholder="Refund Amount"/>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-item col-lg-4 col-md-6 mb-15">
                                                    <div class="row">
                                                        <div class="col-sm-9 offset-sm-3 offset-lg-2">
                                                            <button class="btn btn-block btn-transparent btn-payment" type="submit">Process Refund</button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="item-history-table">
                    <div class="table-wrapper bg-table mb-20">
                        <h5 class="mb-25">Products Ordered</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style="width: 8%;"></th>
                                        <th scope="col" style="width: 8%;">Id</th>
                                        <th scope="col" style="width: 50%;">Title</th>
                                        <th scope="col">Qty</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($cancel->order->cart_details as $product)
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                                    <label class="custom-control-label" for="customCheck1">
                                                    <span><img src="{{ asset('images/catalog/products/') }}/{{ $product->product_detail->images[0]->product_image }}" alt="label image" /></span>
                                                    </label>
                                                </div>
                                            </td>
                                            <td>{{ $product->id }}</td>
                                            <td><a href="javascript: void();">{{ $product->product_detail->title }} </a></td>
                                            <td>{{ $product->product_qty }}</td>
                                            <td>{{ $product->product_qty * $product->product_price }}</td>
                                            <td><span class="text-success">
                                                @if($cancel->status == 0)
                                                    On Hold
                                                @elseif($cancel->status == 1)
                                                    Refund under Process
                                                @elseif($cancel->status == 2)
                                                    Refund Processed
                                                @elseif($cancel->status == 3)
                                                    Order continues as planned to Dispatch
                                                @elseif($cancel->status == 4)
                                                    Cancellation Rejected
                                                @endif
                                            </span></td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div class="order-desc-total">
                        <div class="order-total-card">
                            <ul class="v-list">
                                <li>
                                    <span class="text-primary">Subtotal</span>
                                    <span class="info-text">{{ number_format($cancel->order->cart_sub_total, 2, '.', ',') }} SAR</span>
                                </li>
                                <li>
                                    <span class="text-primary">Shipping & Handling</span>
                                    <span class="info-text">{{ number_format($cancel->order->shippment_charges, 2, '.', ',') }} SAR</span>
                                </li>
                                <li>
                                    <span class="text-primary">Tax</span>
                                    <span class="info-text">{{ number_format($cancel->order->vat_charges, 2, '.', ',') }} SAR</span>
                                </li>
                                <li>
                                    <span class="text-primary">Grand Total</span>
                                    <span class="info-text">{{ number_format($cancel->order->cart_total, 2, '.', ',') }} SAR</span>
                                </li>
                                <li>
                                    <span class="text-primary">Total Paid</span>
                                    <span class="info-text">{{ number_format($cancel->order->cart_total, 2, '.', ',') }} SAR</span>
                                </li>
                                <li>
                                    <span class="text-primary">Total Refunded</span>
                                    <span class="info-text">{{ number_format($cancel->refund_amount, 2, '.', ',') }} SAR</span>
                                </li>
                                <li>
                                    <span class="text-primary">Total Due</span>
                                    <span class="info-text">0.00 SAR</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script> 
        function updateCancellationProcess() {
            document.getElementById('cancellation-status-form').submit();
        }
    </script>
</x-master-layout>