<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>Dashboard</h2>
                <div class="filter-section">
                    <div class="filter-item">
                        <span class="labelItem">Filter by Date:</span>
                        <div class="dropdown show">
                            <a class="dropdown-toggle" href="#" id="dropdownMenuLink1" data-toggle="dropdown">
                                <span class="ml-5">From</span>
                            </a>
                            <ul class="dropdown-menu v-list dropdown-menu-right">
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Action</a></li>
                            </ul>
                        </div>
                        <div class="dropdown show">
                            <a class="dropdown-toggle" href="#" id="dropdownMenuLink2" data-toggle="dropdown">
                                <span class="ml-5">To</span>
                            </a>
                            <ul class="dropdown-menu v-list dropdown-menu-right">
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Action</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard-stats">
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="dashboard-stats-item">
                            <h5>Total Customers</h5>
                            <div class="stat-count">2334</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="dashboard-stats-item">
                            <h5>Total Orders</h5>
                            <div class="stat-count">2334</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="dashboard-stats-item">
                            <h5>Total Sales</h5>
                            <div class="stat-count">2334</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="dashboard-stats-item">
                            <h5>Refunds</h5>
                            <div class="stat-count">2334</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="dashboard-stats-item">
                            <h5>Cancellation</h5>
                            <div class="stat-count">2334</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="dashboard-stats-item">
                            <h5>Total Sales</h5>
                            <div class="stat-count">2334</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="recent-orders-table">
                <div class="table-wrapper mb-30">
                    <h5>Recent Orders</h5>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col" style="width: 6%;"></th>
                                    <th scope="col" style="width: 8%;">Order Id</th>
                                    <th scope="col">Req. Date</th>
                                    <th scope="col">Customer</th>
                                    <th scope="col">Value</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                            <label class="custom-control-label" for="customCheck1">
                                                <span><img src="images/table-image.jpg" alt="label image" /></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>23323</td>
                                    <td>2020-04-07</td>
                                    <td>Mohammed Al Jaber</td>
                                    <td>130000</td>
                                    <td><span class="text-success">Approved</span></td>
                                    <td><div class="btn-group"><a href="#">View</a></div></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                            <label class="custom-control-label" for="customCheck1">
                                                <span><img src="images/table-image.jpg" alt="label image" /></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>23323</td>
                                    <td>2020-04-07</td>
                                    <td>Mohammed Al Jaber</td>
                                    <td>130000</td>
                                    <td><span class="text-warning">Open</span></td>
                                    <td><div class="btn-group"><a href="#">View</a></div></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                            <label class="custom-control-label" for="customCheck1">
                                                <span><img src="images/table-image.jpg" alt="label image" /></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>23323</td>
                                    <td>2020-04-07</td>
                                    <td>Mohammed Al Jaber</td>
                                    <td>130000</td>
                                    <td><span class="text-warning">Open</span></td>
                                    <td><div class="btn-group"><a href="#">View</a></div></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                            <label class="custom-control-label" for="customCheck1">
                                                <span><img src="images/table-image.jpg" alt="label image" /></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>23323</td>
                                    <td>2020-04-07</td>
                                    <td>Mohammed Al Jaber</td>
                                    <td>130000</td>
                                    <td><span class="text-danger">Credit Limit Exceeded</span></td>
                                    <td><div class="btn-group"><a href="#">View</a></div></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                            <label class="custom-control-label" for="customCheck1">
                                                <span><img src="images/table-image.jpg" alt="label image" /></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>23323</td>
                                    <td>2020-04-07</td>
                                    <td>Mohammed Al Jaber</td>
                                    <td>130000</td>
                                    <td><span class="text-success">Approved</span></td>
                                    <td><div class="btn-group"><a href="#">View</a></div></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                            <label class="custom-control-label" for="customCheck1">
                                                <span><img src="images/table-image.jpg" alt="label image" /></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>23323</td>
                                    <td>2020-04-07</td>
                                    <td>Mohammed Al Jaber</td>
                                    <td>130000</td>
                                    <td><span class="text-warning">Open</span></td>
                                    <td><div class="btn-group"><a href="#">View</a></div></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                            <label class="custom-control-label" for="customCheck1">
                                                <span><img src="images/table-image.jpg" alt="label image" /></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>23323</td>
                                    <td>2020-04-07</td>
                                    <td>Mohammed Al Jaber</td>
                                    <td>130000</td>
                                    <td><span class="text-warning">Open</span></td>
                                    <td><div class="btn-group"><a href="#">View</a></div></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                            <label class="custom-control-label" for="customCheck1">
                                                <span><img src="images/table-image.jpg" alt="label image" /></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>23323</td>
                                    <td>2020-04-07</td>
                                    <td>Mohammed Al Jaber</td>
                                    <td>130000</td>
                                    <td><span class="text-warning">Open</span></td>
                                    <td><div class="btn-group"><a href="#">View</a></div></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                            <label class="custom-control-label" for="customCheck1">
                                                <span><img src="images/table-image.jpg" alt="label image" /></span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>23323</td>
                                    <td>2020-04-07</td>
                                    <td>Mohammed Al Jaber</td>
                                    <td>130000</td>
                                    <td><span class="text-warning">Open</span></td>
                                    <td><div class="btn-group"><a href="#">View</a></div></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>