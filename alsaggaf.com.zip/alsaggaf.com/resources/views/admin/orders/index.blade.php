<x-master-layout>
    <div class="main-wrapper">
        
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>Orders</h2>
            </div>
            <div class="filter-wrapper">
                <div class="search-holder">
                    
                </div>
                <div class="filter-section">
                    {{ $orders->links('vendor.pagination.custom-pagination') }}
                </div>
            </div>
            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Id</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Order Creation</th>
                                    <th scope="col">Delivery Date</th>
                                    <th scope="col">Customer</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($orders as $order)
                                    <tr>
                                        <td>{{ str_pad($order->id, 8, '0', STR_PAD_LEFT) }}</td>
                                        <td>{{ $order->cart_total }}</td>
                                        <td>{{ \Carbon\Carbon::parse($order->created_at)->format('d, F Y') }}</td>
                                        <td>{{ $order->delivery_date }} {{ $order->delivery_time }}</td>
                                        <td>{{ $order->fe_user->name }}</td>
                                        <td>
                                            @if($order->transaction->transaction_type == 'MASTER')
                                                MASTER CARD
                                            @elseif($order->transaction->transaction_type == 'VISA') 
                                                vISA CARD
                                            @else
                                                Cash on Delivery
                                            @endif
                                        </td>
                                        <td>
                                            @if($order->cancel)
                                                @if($order->cancel->status == 1 || $order->cancel->status == 2)
                                                    Cancelled
                                                @else
                                                    @if($order->status == 1)
                                                        Pending
                                                    @elseif($order->status == 2) 
                                                        Order under Prep
                                                    @elseif($order->status == 3) 
                                                        Ready to Dispatch
                                                    @elseif($order->status == 4) 
                                                        Order Dispatched
                                                    @elseif($order->status == 5)
                                                        Delivered
                                                    @elseif($order->status == 6)
                                                        On Hold
                                                    @endif
                                                @endif
                                            @else
                                                @if($order->status == 1)
                                                    Pending
                                                @elseif($order->status == 2) 
                                                    Order under Prep
                                                @elseif($order->status == 3) 
                                                    Ready to Dispatch
                                                @elseif($order->status == 4) 
                                                    Order Dispatched
                                                @elseif($order->status == 5)
                                                    Delivered
                                                @elseif($order->status == 6)
                                                    On Hold
                                                @endif
                                            @endif
                                            @if($order->refund)
                                                @if($order->refund->status == 0)
                                                    <br>Under Process
                                                @elseif($order->refund->status == 1)
                                                    <br>Required to return product
                                                @elseif($order->refund->status == 2)
                                                    <br>Refund under process
                                                @elseif($order->refund->status == 3)
                                                    <br>Refund Processed
                                                @elseif($order->refund->status == 4)
                                                    <br>Request rejected due to exceeding 15 days
                                                @elseif($order->refund->status == 5)
                                                    <br>Request rejected due to product failing quality check
                                                @endif
                                            @endif
                                            @if($order->cancel)
                                                @if($order->cancel->status == 0)
                                                    <br>On Hold
                                                @elseif($order->cancel->status == 1)
                                                    <br>Refund under Process
                                                @elseif($order->cancel->status == 2)
                                                    <br>Refund Processed
                                                @elseif($order->cancel->status == 3)
                                                    <br>Order continues as planned to Dispatch
                                                @elseif($order->cancel->status == 4)
                                                    <br>Cancellation Rejected
                                                @endif
                                            @endif
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.orders.show', $order->id) }}">View</a> 
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>