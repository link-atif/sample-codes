<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">   
            <div class="title-head title-buttons">
                <h2>Order: {{ str_pad($order->id, 8, '0', STR_PAD_LEFT) }}</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><button class="btn btn-primary" type="button" onclick="updateOrderProcess()"> Save </button></li>
                </ul>
            </div>

            <div class="card-form-wrapper">
                <div class="card-item tab-area">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="generalInfo" data-toggle="tab" href="#general-info" role="tab" aria-selected="true">General Info</a>
                        </li>
                        <!-- <li class="nav-item">
                            <a class="nav-link" id="invoiceTab" data-toggle="tab" href="#invoice-tab" role="tab"  aria-selected="false">Invoice</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="refundTab" data-toggle="tab" href="#refund-tab" role="tab" aria-selected="false">Refunds</a>
                        </li> -->
                        <li class="nav-item">
                            <a class="nav-link" id="cancelOrder" data-toggle="tab" href="#cancel-order" role="tab" aria-selected="false">Cancellation</a>
                        </li>
                    </ul>
                    <div class="card-holder">
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="general-info" role="tabpanel">
                                {!! Form::model($order, ['method' => 'put', 'route' => ['admin.update-order-status', $order->id], 'class' => 'form-horizontal', 'id' => 'order-status-form']) !!}
                                    <div class="order-info-wrapper">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12 order-md-2 order-lg-0">
                                                <nav class="order-info-item">
                                                    <h5>Order Information</h5>
                                                    <ul class="v-list">
                                                        <li>
                                                            <span class="text-primary">Order Date </span>
                                                            <span class="info-text">{{ \Carbon\Carbon::parse($order->created_at)->format('d, F Y g i A') }}</span>
                                                        </li>
                                                        <li class="align-items-center">
                                                            <span class="text-primary">Order Status </span>
                                                            <span class="info-text">
                                                                <span class="select-item">
                                                                    {!! Form::select('status', ['1' => 'Pending', '2' => 'Order under Prep', '3' => 'Ready to Dispatch', '4' => 'Order Dispatched', '5' => 'Delivered', '6' => 'On Hold'], null , ['placeholder' => 'Status', 'class' => 'form-control font-size-14 height-30 select-box-line-height']) !!}
                                                                </span>
                                                            </span>
                                                        </li>
                                                        <li>
                                                            <span class="text-primary">Type </span>
                                                            <span class="info-text">
                                                                @if($order->transaction->transaction_type == 1)
                                                                    Online Transaction
                                                                @elseif($order->transaction->transaction_type == 2) 
                                                                    Online Transaction
                                                                @else
                                                                    Cash
                                                                @endif
                                                            </span>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12">
                                                <nav class="order-info-item">
                                                    <h5>Billing Address</h5>
                                                    <div class="content-holder">
                                                        <p>{{ $order->fe_user->billing_address->address }} </p>
                                                    </div>
                                                </nav>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12">
                                                <nav class="order-info-item">
                                                    <h5>Shipping Address</h5>
                                                    <div class="content-holder">
                                                        <p>{{ $order->fe_user->shipping_address->address }} </p>
                                                    </div>
                                                </nav>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12 order-md-3 order-lg-3">
                                                <nav class="order-info-item">
                                                    <h5>Account Information</h5>
                                                    <ul class="v-list">
                                                        <li>
                                                            <span class="text-primary">Customer Name</span>
                                                            <span class="info-text">{{ $order->fe_user->name }}</span>
                                                        </li>
                                                        <li>
                                                            <span class="text-primary">Email  </span>
                                                            <span class="info-text">{{ $order->fe_user->email }}</span>
                                                        </li>
                                                        <li>
                                                            <span class="text-primary">Customer type </span>
                                                            @if($order->fe_user->user_type == 0)
                                                                <span class="info-text">Guest</span>
                                                            @elseif($order->fe_user->user_type == 1)
                                                                <span class="info-text">General</span>
                                                            @else
                                                                <span class="info-text">Distributor</span>
                                                            @endif
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>

                                            <div class="col-lg-4 col-md-6 col-sm-4 col-xs-12 order-md-4 order-lg-4">
                                                <nav class="order-info-item">
                                                    <h5>Payment info</h5>
                                                    <ul class="v-list">
                                                        <li>
                                                            <span class="text-primary">Payment Method</span>
                                                            <span class="info-text">
                                                                @if($order->transaction->transaction_type == 1)
                                                                    Credit
                                                                @elseif($order->transaction->transaction_type == 2) 
                                                                    Debit
                                                                @else
                                                                    Cash on Delivery
                                                                @endif
                                                            </span>
                                                        </li>
                                                    </ul>
                                                </nav>
                                            </div>
                                        </div>
                                    </div>
                                {!! Form::close() !!}
                            </div>
                            <div class="tab-pane fade" id="cancel-order" role="tabpanel">
                                <h5 class="mb-30">Cancelled Order</h5>
                                {!! Form::open(['method' => 'post', 'route' => 'admin.cancellation.store', 'class' => 'form-horizontal', 'id' => 'order-status-form']) !!}
                                    <input type="hidden" name="order_id" value="{{ $order->id }}">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group row">
                                                <div class="form-item col-lg-6 col-md-6 mb-15">
                                                    <div class="row">
                                                        <label for="cancellationReason" class="col-sm-3 col-form-label">Cancellation Reason</label>
                                                        <div class="col-sm-9">
                                                            {!! Form::textarea('cancellation_reason', null , ['placeholder' => 'Cancellation Reason', 'class' => 'form-control', 'id' => 'cancellationReason']) !!}
                                                            <span class="text-danger">{{ $errors->first('cancellation_reason') }}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-item col-lg-4 col-md-6 mb-15">
                                                    <div class="row">
                                                        <div class="col-sm-9 offset-sm-3 offset-lg-2"><button class="btn btn-block btn-transparent btn-payment" type="submit">Cancel Order</button></div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>

                <div class="item-history-table">
                    <div class="table-wrapper bg-table mb-20">
                        <h5 class="mb-25">Products Ordered</h5>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col" style="width: 8%;"></th>
                                        <th scope="col" style="width: 8%;">Id</th>
                                        <th scope="col" style="width: 50%;">Title</th>
                                        <th scope="col">Qty</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($order->cart_details as $item)
                                        <tr>
                                            <td>
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="customCheck1" />
                                                    <label class="custom-control-label" for="customCheck1">
                                                    <span><img src="{{ asset('images/catalog/products/') }}/{{ $item->product_detail->images[0]->product_image }}" alt="label image" /></span>
                                                    </label>
                                                </div>
                                            </td>
                                            <td>{{ $item->id }}</td>
                                            <td><a href="javascript: void();">{{ $item->product_detail->title }} </a></td>
                                            <td>{{ $item->product_qty }}</td>
                                            <td>{{ $item->product_qty * $item->product_price }}</td>
                                            <td><span class="text-success">
                                                @if($order->status == 1)
                                                    Pending
                                                @elseif($order->status == 2) 
                                                    Order under Prep
                                                @elseif($order->status == 3) 
                                                    Ready to Dispatch
                                                @elseif($order->status == 4) 
                                                    Order Dispatched
                                                @elseif($order->status == 5)
                                                    Delivered
                                                @elseif($order->status == 6)
                                                    On Hold
                                                @endif
                                            </span></td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="order-desc-total">
                        <div class="order-total-card">
                            <ul class="v-list">
                                <li>
                                    <span class="text-primary">Subtotal</span>
                                    <span class="info-text">{{ number_format($order->cart_sub_total, 2, '.', ',') }}</span>
                                </li>
                                <li>
                                    <span class="text-primary">Shipping & Handling</span>
                                    <span class="info-text">{{ number_format($order->shippment_charges, 2, '.', ',') }}</span>
                                </li>
                                <li>
                                    <span class="text-primary">Tax</span>
                                    <span class="info-text">{{ number_format($order->vat_charges, 2, '.', ',') }}</span>
                                </li>
                                <li>
                                    <span class="text-primary">Grand Total</span>
                                    <span class="info-text">{{ number_format($order->cart_total, 2, '.', ',') }}</span>
                                </li>
                                <li>
                                    <span class="text-primary">Total Paid</span>
                                    <span class="info-text">{{ number_format($order->cart_total, 2, '.', ',') }}</span>
                                </li>
                                <li>
                                    <span class="text-primary">Total Refunded</span>
                                    <span class="info-text">0.00</span>
                                </li>
                                <li>
                                    <span class="text-primary">Total Due</span>
                                    <span class="info-text">0.00</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script> 
        function updateOrderProcess() {
            document.getElementById('order-status-form').submit();
        }
    </script>
</x-master-layout>