<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::model($category, ['method' => 'put', 'route' => ['admin.category.update', $category->id ], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                <div class="title-head">
                    <h2>Create Category</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>

                <div class="card-form-wrapper">
                    <div class="card-item">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputCategoryName', 'Category Name', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('name', null , ['placeholder' => 'Category Name', 'class' => 'form-control', 'id' => 'inputCategoryName']) !!}
                                            <span class="text-danger">{{ $errors->first('name') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputOrder', 'Category Order', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('order', null , ['placeholder' => 'Category Order', 'class' => 'form-control', 'id' => 'inputOrder']) !!}
                                            <span class="text-danger">{{ $errors->first('order') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputParentCategory', 'Parent Category', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            <div class="select-item">
                                                {!! Form::select('parent_id', $category->product_categories, $category->parent_id , ['placeholder' => 'Choose Parent Category', 'class' => 'form-control', 'id' => 'inputParentCategory']) !!}
                                                <span class="text-danger">{{ $errors->first('parent_id') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputfeature', 'Featured', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            <div class="select-item">
                                                {!! Form::select('featured', ['0' => 'No', '1' => 'Yes'], null , ['placeholder' => 'Choose featured', 'class' => 'form-control', 'id' => 'inputfeature']) !!}
                                                <span class="text-danger">{{ $errors->first('featured') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="form-group row">
                                        {!! Form::label('inputDescription', 'Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('description', null , ['placeholder' => 'Description', 'class' => 'form-control', 'id' => 'inputDescription']) !!}
                                            <span class="text-danger">{{ $errors->first('description') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group files">
                                        {!! Form::file('thumbnail',['class' => 'form-control', 'id' => 'inputCategoryThumbnail',  'onChange' => 'encodeImageFileAsURL("inputCategoryThumbnail", "image_preview", "old_image");']) !!}
                                        <div class="content">Drag or Drop Category thumbnail <span class="required">*</span></div>
                                        <span class="text-danger">{{ $errors->first('thumbnail') }}</span>
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($category->thumbnail !="")
                                            <img width="125px" height="125px" src="{{ asset('images/catalog/category/'.$category->thumbnail) }}">
                                        @endif
                                    </div>
                                    
                                    <div class="form-group files">
                                        {!! Form::file('catalog',['class' => 'form-control', 'id' => 'inputCategoryCatalog']) !!}
                                        <div class="content">Drag or Drop Category Catalog</div>
                                        <span class="text-danger">{{ $errors->first('catalog') }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>