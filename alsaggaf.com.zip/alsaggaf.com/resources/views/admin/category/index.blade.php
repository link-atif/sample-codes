<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>All Categories</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><a href="{{ route('admin.products.index') }}" class="btn btn-primary"> Back </a></li>
                    <li class="btn-item"><a href="{{ route('admin.category.create') }}" class="btn btn-primary"> Add Category</a></li>
                </ul>
            </div>

             <!-- Search -->
            <div class="filter-wrapper row px-4">
                <div class="col-lg-12">
                    <form action="{{route('admin.category.search')}}" method="POST" role="search">
                    <div class="row">
                        {{csrf_field()}}
                        <input type="text" class="col-lg-4 mr-10" value="@if(isset($name)){{$name}}@endif" name="name" placeholder="Search By Name">
                        <button type="submit" class="btn btn-search btn-primary col-lg-1">Search</button>
                         <div class="col-lg-2">
                            <a href="{{ route('admin.category.index') }}" class="btn btn-primary btn-search">Reset</a>
                        </div>
                    </div>
                    </form> 
                </div>
               

            </div>
            <!-- Search Ends-->

            @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif

            <div class="filter-wrapper">
                <div class="search-holder">
                    
                </div>
                <div class="filter-section">
                    {{-- $categories->links('vendor.pagination.custom-pagination') --}}
                </div>
            </div>

            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                         @if(isset($categories))
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Category ID</th>
                                    <th scope="col">Category Name</th>
                                    <th scope="col">Parent</th>
                                    <th scope="col">Sort Order</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="myTable">
                                @foreach($categories as $category)
                                    <tr>
                                        <td> {{ $category->id }} </td>
                                        <td>{{ $category->name }}</td>
                                        <td>{{ $category->parent }}</td>
                                        <td>{{ $category->order }}</td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.category.edit', ['category' => $category->id]) }}">Edit</a> 
                                                <a data-toggle="modal" data-target="#deleteModal_{{$category->id}}">Delete</a>
                                                <!-- Modal -->
                                                <div class="modal fade" id="deleteModal_{{$category->id}}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel_{{$category->id}}" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel_{{$category->id}}">Delete Category</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure, you wants to delete ...
                                                            </div>
                                                            <div class="modal-footer">
                                                                {!! Form::open(['method' => 'delete', 'route' => ['admin.category.destroy', $category->id], 'class' => 'form-horizontal']) !!}
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                                {!! Form::close() !!}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        @endif
                    </div>
                    {{ $categories->links() }}
                </div>
            </div>
        </div>
    </div>
</x-master-layout>