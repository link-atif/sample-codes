<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::open(['method' => 'post', 'route' => 'admin.sale.store', 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                <div class="title-head">
                    <h2>Add Sale Offer</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            <a href="{{ route('admin.sale.index') }}" class="btn btn-primary"> Back </a>
                        </li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>
                @if(session()->has('message'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="card-form-wrapper">
                    <div class="card-item basic-detail">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputSaleTitle', 'Sale Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('title', null , ['placeholder' => 'Sale Title', 'class' => 'form-control', 'id' => 'inputSaleTitle']) !!}
                                            <span class="text-danger">{{ $errors->first('title') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputDiscountPercentage', 'Discount Percentage', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('percentage', null , ['placeholder' => 'Discount Percentage', 'class' => 'form-control', 'id' => 'inputDiscountPercentage']) !!}
                                            <span class="text-danger">{{ $errors->first('percentage') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputCategory', 'Category', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            <div class="select-item">
                                                {!! Form::select('category_id', $categories, null , ['placeholder' => 'Choose Category', 'class' => 'form-control', 'id' => 'inputCategory']) !!}
                                                <span class="text-danger">{{ $errors->first('category_id') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputStatus', 'Status', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            <div class="select-item">
                                                {!! Form::select('status', ['0' => 'In Active', '1' => 'Active'], null , ['placeholder' => 'Choose Status', 'class' => 'form-control', 'id' => 'inputStatus']) !!}
                                                <span class="text-danger">{{ $errors->first('status') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group files">
                                        {!! Form::file('image',['class' => 'form-control', 'id' => 'inputImage', 'onChange' => 'encodeImageFileAsURL("inputImage", "image_preview", "");']) !!}
                                        <div class="content">Drag or Drop Sale Background Image <span class="required">*</span></div>
                                        <span class="text-danger">{{ $errors->first('image') }}</span>
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>