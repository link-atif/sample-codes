<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>Brands Carousal Slider Slides</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><a href="{{ route('admin.brands-carousal.create', $carousals->tt_content_id) }}" class="btn btn-primary"> Add Slide</a></li>
                </ul>
            </div>
            @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Brand Name</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($carousals as $slide)
                                    <tr>
                                        <td> {{ $loop->iteration }}
                                        <td>
                                            <div class="custom-image-list">
                                                <label class="">
                                                    <span><img src="{{ asset('images') }}/brands-carousal/{{ $slide->image }}" alt="Brand image" /></span>
                                                </label>
                                            </div>
                                        </td>
                                        <td> {!! nl2br($slide->name) !!}</td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.brands-carousal.edit', [$carousals->tt_content_id, $slide->id]) }}">Edit</a>
                                                <a data-toggle="modal" data-target="#deleteModal_{{ $slide->id }}" role="button">
                                                    Delete
                                                </a>
                                                <!-- Delete Modal -->
                                                <div class="modal fade" id="deleteModal_{{ $slide->id }}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel_{{ $slide->id }}" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel_{{ $slide->id }}">Delete Brands Carousal Slider Slide</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure, you wants to delete ...
                                                            </div>
                                                            <div class="modal-footer">
                                                                {!! Form::open(['method' => 'delete', 'route' => ['admin.brands-carousal.destroy',$carousals->tt_content_id, $slide->id], 'class' => 'form-horizontal']) !!}
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                                {!! Form::close() !!}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>