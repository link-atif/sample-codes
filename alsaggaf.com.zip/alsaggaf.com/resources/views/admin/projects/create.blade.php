<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::open(['method' => 'post', 'route' => ['admin.project.store', $tt_content_id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                <div class="title-head">
                    <h2>Add Project</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            <a href="{{ route('admin.project.index', $tt_content_id) }}" class="btn btn-primary"> Back </a>
                        </li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>
                @if(session()->has('message'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="card-form-wrapper">
                    <div class="card-item basic-detail">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputProjectName', 'Project Name', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('name', null , ['placeholder' => 'Project Name', 'class' => 'form-control', 'id' => 'inputProjectName']) !!}
                                            <span class="text-danger">{{ $errors->first('name') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputDescription', 'Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('description', null , ['placeholder' => 'Description', 'class' => 'form-control', 'id' => 'inputDescription']) !!}
                                            <span class="text-danger">{{ $errors->first('description') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group files">
                                        {!! Form::file('image',['class' => 'form-control', 'id' => 'inputImage', 'onChange' => 'encodeImageFileAsURL("inputImage", "image_preview", "");']) !!}
                                        <div class="content">Drag or Drop Project Image <span class="required">*</span></div>
                                        <span class="text-danger">{{ $errors->first('image') }}</span>
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputSupervisingEntity', 'Supervising Entity', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('supervising_entity', null , ['placeholder' => 'Supervising Entity', 'class' => 'form-control', 'id' => 'inputSupervisingEntity']) !!}
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputImplementing', 'Implementing', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('implementing', null , ['placeholder' => 'Implementing', 'class' => 'form-control', 'id' => 'inputImplementing']) !!}
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputYearOfExecution', 'Year of Execution', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('year_of_execution', null , ['placeholder' => 'Year of Execution', 'class' => 'form-control', 'id' => 'inputYearOfExecution']) !!}
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputContractor', 'Contractor', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('contractor', null , ['placeholder' => 'Contractor', 'class' => 'form-control', 'id' => 'inputContractor']) !!}
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputLocation', 'Location', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('location', null , ['placeholder' => 'Location', 'class' => 'form-control', 'id' => 'inputLocation']) !!}
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputProducts', 'Products', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('products', null , ['placeholder' => 'Products', 'class' => 'form-control', 'id' => 'inputProducts']) !!}
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputSupplies', 'Status', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('supplied', null , ['placeholder' => 'Status', 'class' => 'form-control', 'id' => 'inputSupplies']) !!}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>