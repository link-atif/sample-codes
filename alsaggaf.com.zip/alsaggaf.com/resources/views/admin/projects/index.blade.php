<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>All Projects</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><a href="{{ route('admin.project.create', $tt_content_id) }}" class="btn btn-primary"> Add Project</a></li>
                </ul>
            </div>

            <div class="filter-wrapper">
                <div class="search-holder">
                    <i class="fa fa-search"></i>
                    <input type="text" class="form-control" placeholder="Search">
                </div>
            </div>

            @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif

            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Project Name</th>
                                    <th scope="col">Project Description</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($projects as $project)
                                    <tr>
                                        <td> {{ $loop->iteration }} </td>
                                        <td>{{ $project->name }}</td>
                                        <td>{{ \Illuminate\Support\Str::limit($project->description, 50, $end='...') }}</td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.project.edit', [$tt_content_id, $project->id]) }}">Edit</a> 
                                                <a data-toggle="modal" data-target="#deleteModal_{{$project->id}}" role="button">Delete</a>
                                                <!-- Modal -->
                                                <div class="modal fade" id="deleteModal_{{$project->id}}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel_{{$project->id}}" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel_{{$project->id}}">Delete Project</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure, you wants to delete ...
                                                            </div>
                                                            <div class="modal-footer">
                                                                {!! Form::open(['method' => 'delete', 'route' => ['admin.project.destroy', $tt_content_id, $project->id], 'class' => 'form-horizontal']) !!}
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                                {!! Form::close() !!}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>