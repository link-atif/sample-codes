<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>{{ config('app.name', 'Laravel') }}</title>
        <!-- Styles -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet"/>
         <style type="text/css">
            #cover_image_preview img{
                width: 125px;
                height: 125px;
                margin-top: 10px;
                margin-bottom: 10px;
            }

            #image_preview img{
                width: 125px;
                height: 125px;
                margin-top: 10px;
                margin-bottom: 10px;
            }

            .imageThumb {
              max-height: 75px;
              border: 2px solid;
              padding: 1px;
              cursor: pointer;
            }
            .pip {
              display: inline-block;
              margin: 10px 10px 0 0;
            }
            .remove {
              display: block;
              background: #444;
              border: 1px solid black;
              color: white;
              text-align: center;
              cursor: pointer;
            }
            .remove:hover {
              background: white;
              color: black;
            }

        </style>
        <link rel="stylesheet" href="{{ asset('css/admin-app.css') }}">
        <!-- Scripts -->
         <script type="text/javascript">
        function encodeImageFileAsURL(image,id,old_image) {
            var filesSelected = document.getElementById(image).files;
            if (filesSelected.length > 0) {
                $("#"+id).empty();
                for (var i = 0 ; i <filesSelected.length; i++) {
                    var fileToLoad = filesSelected[i];
                    var fileReader = new FileReader();
                    fileReader.onload = function(fileLoadedEvent) {
                        var srcData = fileLoadedEvent.target.result; // <--- data: base64
                        $("<span class=\"pip\">" +
                            "<img class=\"imageThumb\" src=\"" + srcData + "\" title=\"" + srcData.name + "\"/>" +
                            "<br/><span class=\"remove\">Remove image</span>" +
                            "</span>").insertAfter("#"+image);
                          $(".remove").click(function(){
                            $(this).parent(".pip").remove();
                            cleanInputs(image);
                          });

                        //var newImage = document.createElement('img');
                        //newImage.src = srcData;
                        //document.getElementById(id).appendChild(newImage);
                        //document.getElementById(id).innerHTML += newImage.outerHTML;
                    }
                     fileReader.readAsDataURL(filesSelected[i]);
                }
                if(old_image !=""){
                    document.getElementById(old_image).style.display = 'none';
                }
            }
        }

        function cleanInputs(fileEle){
            $("#"+fileEle).val("");
            var parEle = $(fileEle).parent();
            var newEle = $(fileEle).clone()
            $(fileEle).remove();
            $(parEle).prepend(newEle);
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    </head>
    <body>
        @include('admin.partials.nav')
        @include('admin.partials.aside')
        <main class="main-content">
            {{ $slot }}
        </main>
        @livewireScripts
        <script src="{{ asset('js/admin-app.js') }}" defer></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js" defer></script>
    </body>
</html>