<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::model($media, ['method' => 'put', 'route' => ['admin.media.update', $tt_content_id, $media->id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
            <div class="title-head">
                <h2>Edit Media</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><a href="{{ route('admin.media.index', $tt_content_id) }}" class="btn btn-primary"> Back </a></li>
                    <li class="btn-item">
                        {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                    </li>
                </ul>
            </div>

            <div class="card-form-wrapper">
                <div class="card-item">
                    <div class="card-holder">
                        <div class="row">
                            <div class="col-lg-12">
                                <h2 style="font-size: 26px;">Right text with left image</h2>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row">
                                    {!! Form::label('inputTitle', 'Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('title', null , ['placeholder' => 'Title', 'class' => 'form-control', 'id' => 'inputTitle']) !!}
                                        <span class="text-danger">{{ $errors->first('title') }}</span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputShortDescription', 'Short Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('short_description', null , ['placeholder' => 'Short Description', 'class' => 'form-control', 'id' => 'inputShortDescription']) !!}
                                        <span class="text-danger">{{ $errors->first('short_description') }}</span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputArticle', 'Article', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('article', null , ['placeholder' => 'Article', 'class' => 'form-control', 'id' => 'inputArticle']) !!}
                                        <span class="text-danger">{{ $errors->first('article') }}</span>
                                    </div>
                                </div>
                            </div>


                            <div class="col-lg-6">
                                <div class="form-group files">
                                    {!! Form::file('image',['class' => 'form-control', 'id' => 'inputImage', 'onChange' => 'encodeImageFileAsURL("inputImage", "image_preview", "old_image");']) !!}
                                    <div class="content">Drag or Drop media Logo Image <span class="required">*</span></div>
                                    <span class="text-danger">{{ $errors->first('image') }}</span>
                                </div>
                                <div style="padding-top: 5px;" id="image_preview"></div>
                                <div id="old_image">
                                    @if($media->image !="")
                                    <img width="125px" height="125px" src="{{ asset('images/media/'.$media->image) }}">
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {{--edit 2nd --}}
                <div class="card-item">
                    <div class="card-holder">
                        <div class="row">
                            <div class="col-lg-12">
                                <h2 style="font-size: 26px;">Left image with Right text</h2>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group row">
                                    {!! Form::label('inputTitle_1', 'Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('title_1', null , ['placeholder' => 'Title', 'class' => 'form-control', 'id' => 'title_1']) !!}
                                        <span class="text-danger">{{ $errors->first('title_1') }}</span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputShortDescription_1', 'Short Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('short_description_1', null , ['placeholder' => 'Short Description', 'class' => 'form-control', 'id' => 'inputShortDescription_1']) !!}
                                        <span class="text-danger">{{ $errors->first('short_description_1') }}</span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputArticle_1', 'Article', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('article_1', null , ['placeholder' => 'Article', 'class' => 'form-control', 'id' => 'inputArticle_1']) !!}
                                        <span class="text-danger">{{ $errors->first('article_1') }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group files">
                                    {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputImage_1', 'onChange' => 'encodeImageFileAsURL("inputImage_1", "image_preview", "old_image_1");']) !!}
                                    <div class="content">Drag or Drop media Logo Image <span class="required">*</span></div>
                                    <span class="text-danger">{{ $errors->first('image_1') }}</span>
                                </div>
                                <div style="padding-top: 5px;" id="image_preview"></div>
                                <div id="old_image_1">
                                    @if($media->image_1 !="")
                                    <img width="125px" height="125px" src="{{ asset('images/media/'.$media->image_1) }}">
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {{--edit 3nd --}}
                <div class="card-item">
                    <div class="card-holder">
                        <div class="row">
                            <div class="col-lg-12">
                                <h2 style="font-size: 26px;">Right text with left image</h2>
                            </div>
                            <div class="col-lg-6">

                                <div class="form-group row">
                                    {!! Form::label('inputTitle_2', 'Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('title_2', null , ['placeholder' => 'Title', 'class' => 'form-control', 'id' => 'title_2']) !!}
                                        <span class="text-danger">{{ $errors->first('title_2') }}</span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputShortDescription_2', 'Short Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('short_description_2', null , ['placeholder' => 'Short Description', 'class' => 'form-control', 'id' => 'inputShortDescription_2']) !!}
                                        <span class="text-danger">{{ $errors->first('short_description_2') }}</span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputArticle_2', 'Article', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('article_2', null , ['placeholder' => 'Article', 'class' => 'form-control', 'id' => 'inputArticle_2']) !!}
                                        <span class="text-danger">{{ $errors->first('article_2') }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group files">
                                    {!! Form::file('image_2',['class' => 'form-control', 'id' => 'inputImage_2', 'onChange' => 'encodeImageFileAsURL("inputImage_2", "image_preview", "old_image_2");']) !!}
                                    <div class="content">Drag or Drop media Logo Image <span class="required">*</span></div>
                                    <span class="text-danger">{{ $errors->first('image_2') }}</span>
                                </div>
                                <div style="padding-top: 5px;" id="image_preview"></div>
                                <div id="old_image_2">
                                    @if($media->image_2 !="")
                                    <img width="125px" height="125px" src="{{ asset('images/media/'.$media->image_2) }}">
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {!! Form::close() !!}
            </div>
        </div>
</x-master-layout>