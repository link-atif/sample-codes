<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>Media</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><a href="{{ url('/admin/pages/11') }}" class="btn btn-primary"> Back </a></li>
                    <li class="btn-item"><a href="{{ route('admin.media.create', $tt_content_id) }}" class="btn btn-primary"> Add Media</a></li>
                </ul>
            </div>
            @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Short Description</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($medias as $media)
                                    <tr>
                                        <td> {{ $loop->iteration }} </td>
                                        <td>{{ $media->title }}</td>
                                        <td>{{ $media->short_description }}</td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.media.edit', [$tt_content_id, $media->id]) }}">Edit</a> 
                                                <a data-toggle="modal" data-target="#deleteModal_{{$media->id}}">Delete</a>
                                                <!-- Modal -->
                                                <div class="modal fade" id="deleteModal_{{$media->id}}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel_{{$media->id}}" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel_{{$media->id}}">Delete Media</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure, you wants to delete ...
                                                            </div>
                                                            <div class="modal-footer">
                                                                {!! Form::open(['method' => 'delete', 'route' => ['admin.media.destroy', $tt_content_id, $media->id], 'class' => 'form-horizontal']) !!}
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                                {!! Form::close() !!}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>