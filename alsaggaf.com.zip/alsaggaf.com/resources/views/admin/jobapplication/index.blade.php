<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>JobApplication</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><a href="{{ url('/admin/pages/11') }}" class="btn btn-primary"> Back </a></li>
                </ul>
            </div>
            <div class="filter-wrapper">
                <div class="search-holder">
                    
                </div>
                <div class="filter-section">
                    {{ $jobapplication->links('vendor.pagination.custom-pagination') }}
                </div>
            </div>
            @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Full Name</th>
                                    <th scope="col">Phone No</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">City</th>
                                    <th scope="col">Country</th>
                                    <th scope="col">Position</th>
                                    <th scope="col">Submission Date</th>
                                    <th scope="col">Document</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($jobapplication as $jobapplication)
                                    <tr>
                                        <td> {{ $loop->iteration }} </td>
                                        <td>{{ $jobapplication->full_name }}</td>
                                        <td>{{ $jobapplication->phone_number }}</td>
                                        <td>{{ $jobapplication->email }}</td>
                                        <td>{{ $jobapplication->city }}</td>
                                        <td>{{ $jobapplication->country }}</td>
                                        <td>{{ $jobapplication->position }}</td>
                                        <td>{{ date("F d Y", strtotime($jobapplication->submission_date)) }}</td>
                                        <td>
                                            <a href="{{ asset('/images/job-applications/'.$jobapplication->document) }}" target="_blank" class="btn_sm btn-primary btn-sm">
                                            <img class="icon small btn-sm" src="{{ asset('images/icon') }}/download-icon.svg" alt="dropdown-icon" />

                                            </a>   
                                        </td>

                                        <td>
                                            <div class="btn-group">
                                                <a data-toggle="modal" data-target="#deleteModal_{{$jobapplication->id}}">Delete</a>
                                                <!-- Modal -->
                                                <div class="modal fade" id="deleteModal_{{$jobapplication->id}}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel_{{$jobapplication->id}}" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel_{{$jobapplication->id}}">Delete JobApplication</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure, you wants to delete ...
                                                            </div>
                                                            <div class="modal-footer">
                                                                {!! Form::open(['method' => 'delete', 'route' => ['admin.jobapplication.destroy', $jobapplication->id], 'class' => 'form-horizontal']) !!}
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                                {!! Form::close() !!}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>