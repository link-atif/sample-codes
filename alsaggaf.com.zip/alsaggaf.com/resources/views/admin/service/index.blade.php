<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>Our Services</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><a href="{{ url('/admin/pages/13') }}" class="btn btn-primary"> Back</a></li>
                    <li class="btn-item"><a href="{{ route('admin.service.create', $tt_content_id) }}" class="btn btn-primary"> Add Service</a></li>
                </ul>
            </div>

            <div class="filter-wrapper">
                <div class="search-holder">
                    <i class="fa fa-search"></i>
                    <input type="text" class="form-control" placeholder="Search">
                </div>
            </div>

            @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif

            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Service Name</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($services as $service)
                                    <tr>
                                        <td> {{ $loop->iteration }} </td>
                                        <td>{{ $service->name }}</td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.service.edit', [$tt_content_id, $service->id]) }}">Edit</a> 
                                                <a data-toggle="modal" data-target="#deleteModal_{{$service->id}}" role="button">Delete</a>
                                                <!-- Modal -->
                                                <div class="modal fade" id="deleteModal_{{$service->id}}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel_{{$service->id}}" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel_{{$service->id}}">Delete Service</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure, you wants to delete ...
                                                            </div>
                                                            <div class="modal-footer">
                                                                {!! Form::open(['method' => 'delete', 'route' => ['admin.service.destroy', $tt_content_id, $service->id], 'class' => 'form-horizontal']) !!}
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                                {!! Form::close() !!}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>