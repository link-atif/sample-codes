<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>{{ $tt_content->title }}</h2>
            </div>
            @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
            <div class="card-form-wrapper">
                <!-- Default box -->
                @if($tt_content->component_id == 4)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputBlock1Title', 'Block 1 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Block 1 Title', 'class' => 'form-control', 'id' => 'inputBlock1Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock1text', 'Block 1 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Block 1 Text', 'class' => 'form-control', 'id' => 'inputBlock1text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock1Image', 'Block 1 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputBlock1Image',  'onChange' => 'encodeImageFileAsURL("image_1", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 1 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_1 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_1) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock2Title', 'Block 2 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_2', null , ['placeholder' => 'Block 2 Title', 'class' => 'form-control', 'id' => 'inputBlock2Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock2text', 'Block 2 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_2', null , ['placeholder' => 'Block 2 Text', 'class' => 'form-control', 'id' => 'inputBlock2text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock2Image', 'Block 2 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_2',['class' => 'form-control', 'id' => 'inputBlock2Image',  'onChange' => 'encodeImageFileAsURL("image_2", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 2 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_2 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_2) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock3Title', 'Block 3 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_3', null , ['placeholder' => 'Block 3 Title', 'class' => 'form-control', 'id' => 'inputBlock3Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock3text', 'Block 3 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_3', null , ['placeholder' => 'Block 3 Text', 'class' => 'form-control', 'id' => 'inputBlock3text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock3Image', 'Block 3 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_3',['class' => 'form-control', 'id' => 'inputBlock3Image',  'onChange' => 'encodeImageFileAsURL("image_3", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 3 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_3 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_3) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock4Title', 'Block 4 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_4', null , ['placeholder' => 'Block 4 Title', 'class' => 'form-control', 'id' => 'inputBlock4Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock4text', 'Block 4 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_4', null , ['placeholder' => 'Block 4 Text', 'class' => 'form-control', 'id' => 'inputBlock4text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock4Image', 'Block 4 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_4',['class' => 'form-control', 'id' => 'inputBlock4Image',  'onChange' => 'encodeImageFileAsURL("image_4", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 4 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_4 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_4) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 5)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputBannerTitle', 'Banner Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Banner Title', 'class' => 'form-control', 'id' => 'inputBannerTitle']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBannerButtonLabel', 'Button Label', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('input_2', null , ['placeholder' => 'Button Label', 'class' => 'form-control', 'id' => 'inputBannerButtonLabel']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBannerButtonLink', 'Button Link', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('link_1', null , ['placeholder' => 'Button Link', 'class' => 'form-control', 'id' => 'inputBannerButtonLink']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBannerImage', 'Banner Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputBannerImage',  'onChange' => 'encodeImageFileAsURL("image_1", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Banner Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_1 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_1) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 6)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputBannerText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputBannerText']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBannerButtonLabel', 'Button Label', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('input_1', null , ['placeholder' => 'Button Label', 'class' => 'form-control', 'id' => 'inputBannerButtonLabel']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBannerButtonLink', 'Button Link', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('link_1', null , ['placeholder' => 'Button Link', 'class' => 'form-control', 'id' => 'inputBannerButtonLink']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBannerImage', 'Banner Main Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                         <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputBannerImage',  'onChange' => 'encodeImageFileAsURL("image_1", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Banner Main Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_1 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_1) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBannerDisscountImage', 'Banner Discount Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                         <div class="files">
                                            {!! Form::file('image_2',['class' => 'form-control', 'id' => 'inputBannerDisscountImage',  'onChange' => 'encodeImageFileAsURL("image_2", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Banner Discount Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_2 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_2) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 7)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputTitle', 'Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Title', 'class' => 'form-control', 'id' => 'inputTitle']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 8)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputTitle', 'Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Title', 'class' => 'form-control', 'id' => 'inputTitle']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputDate', 'Date when Sales End', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_2', null , ['placeholder' => 'MM-DD-YYYY', 'class' => 'form-control', 'id' => 'inputDate']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBannerBackgroundImage', 'Banner Background Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputBannerBackgroundImage',  'onChange' => 'encodeImageFileAsURL("image_1", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Banner Background Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_1 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_1) }}">
                                        @endif
                                    </div>

                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 10)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputText']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputReadmoreLink', 'Readmore Link', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('link_1', null , ['placeholder' => 'Readmore Link', 'class' => 'form-control', 'id' => 'inputReadmoreLink']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputRightImage', 'Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputRightImage',  'onChange' => 'encodeImageFileAsURL("image_1", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_1 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_1) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 11)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputBlock1Title', 'Block 1 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Block 1 Title', 'class' => 'form-control', 'id' => 'inputBlock1Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock1text', 'Block 1 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Block 1 Text', 'class' => 'form-control', 'id' => 'inputBlock1text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock1Image', 'Block 1 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputBlock1Image',  'onChange' => 'encodeImageFileAsURL("image_1", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 1 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_1 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_1) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock2Title', 'Block 2 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_2', null , ['placeholder' => 'Block 2 Title', 'class' => 'form-control', 'id' => 'inputBlock2Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock2text', 'Block 2 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_2', null , ['placeholder' => 'Block 2 Text', 'class' => 'form-control', 'id' => 'inputBlock2text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock2Image', 'Block 2 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_2',['class' => 'form-control', 'id' => 'inputBlock2Image',  'onChange' => 'encodeImageFileAsURL("image_2", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 2 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_2 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_2) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock3Title', 'Block 3 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_3', null , ['placeholder' => 'Block 3 Title', 'class' => 'form-control', 'id' => 'inputBlock3Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock3text', 'Block 3 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_3', null , ['placeholder' => 'Block 1 Text', 'class' => 'form-control', 'id' => 'inputBlock3text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock3Image', 'Block 3 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_3',['class' => 'form-control', 'id' => 'inputBlock3Image',  'onChange' => 'encodeImageFileAsURL("image_3", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 3 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_3 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_3) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock4Title', 'Block 4 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_4', null , ['placeholder' => 'Block 4 Title', 'class' => 'form-control', 'id' => 'inputBlock4Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock4text', 'Block 4 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_4', null , ['placeholder' => 'Block 4 Text', 'class' => 'form-control', 'id' => 'inputBlock4text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock4Image', 'Block 4 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_4',['class' => 'form-control', 'id' => 'inputBlock4Image',  'onChange' => 'encodeImageFileAsURL("image_4", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 4 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_4 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_4) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 13)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputTitle', 'Projects Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Projects Title', 'class' => 'form-control', 'id' => 'inputTitle']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputDescription', 'Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Description', 'class' => 'form-control', 'id' => 'inputDescription']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 15)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputTitle', 'Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Title', 'class' => 'form-control', 'id' => 'inputTitle']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputText']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputButtonLabel', 'Download Button Label', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Download Button Label', 'class' => 'form-control', 'id' => 'inputButtonLabel']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputUploadBusinessProfile', 'File', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputUploadBusinessProfile']) !!}
                                            <div class="content">Drag or Drop File <span class="required">*</span></div>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 16)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputText']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputButtonLabel', 'Download Button Label', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Download Button Label', 'class' => 'form-control', 'id' => 'inputButtonLabel']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputUploadBusinessProfile', 'File', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputUploadBusinessProfile']) !!}
                                            <div class="content">Drag or Drop File <span class="required">*</span></div>
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputImage', 'Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_2',['class' => 'form-control', 'id' => 'inputImage',  'onChange' => 'encodeImageFileAsURL("image_2", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_2 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_2) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 17)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputText']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputImage', 'Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                         <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputImage',  'onChange' => 'encodeImageFileAsURL("image_1", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_1 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_1) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 18)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputText']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 19)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 20)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputAddress', 'Address', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Address', 'class' => 'form-control', 'id' => 'inputAddress']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputContactNumber', 'Contact Number', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Contact Number', 'class' => 'form-control', 'id' => 'inputContactNumber']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputWhatsappNumber', 'Whatsapp Number', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_2', null , ['placeholder' => 'Whatsapp Number', 'class' => 'form-control', 'id' => 'inputWhatsappNumber']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputEmail', 'E-Mail', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_3', null , ['placeholder' => 'E-Mail', 'class' => 'form-control', 'id' => 'inputEmail']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 22)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 23)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('text_1', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputText']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputButtonLabel', 'Button Label', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Button Label', 'class' => 'form-control', 'id' => 'inputButtonLabel']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 24)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row ">
                                    {!! Form::label('inputBannerImage', 'Banner Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_4',['class' => 'form-control', 'id' => 'inputBannerImage',  'onChange' => 'encodeImageFileAsURL("image_4", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Banner Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_4 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_4) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock1Title', 'Block 1 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_1', null , ['placeholder' => 'Block 1 Title', 'class' => 'form-control', 'id' => 'inputBlock1Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock1text', 'Block 1 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Block 1 Text', 'class' => 'form-control', 'id' => 'inputBlock1text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock1Image', 'Block 1 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_1',['class' => 'form-control', 'id' => 'inputBlock1Image',  'onChange' => 'encodeImageFileAsURL("image_1", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 1 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_1 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_1) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock2Title', 'Block 2 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_2', null , ['placeholder' => 'Block 2 Title', 'class' => 'form-control', 'id' => 'inputBlock2Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock2text', 'Block 2 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_2', null , ['placeholder' => 'Block 2 Text', 'class' => 'form-control', 'id' => 'inputBlock2text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock2Image', 'Block 2 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_2',['class' => 'form-control', 'id' => 'inputBlock2Image',  'onChange' => 'encodeImageFileAsURL("image_2", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 2 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_2 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_2) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock3Title', 'Block 3 Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('input_3', null , ['placeholder' => 'Block 3 Title', 'class' => 'form-control', 'id' => 'inputBlock3Title']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputBlock3text', 'Block 3 Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_3', null , ['placeholder' => 'Block 3 Text', 'class' => 'form-control', 'id' => 'inputBlock3text']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    {!! Form::label('inputBlock3Image', 'Block 3 Image', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="files">
                                            {!! Form::file('image_3',['class' => 'form-control', 'id' => 'inputBlock3Image',  'onChange' => 'encodeImageFileAsURL("image_3", "image_preview", "old_image");']) !!}
                                            <div class="content">Drag or Drop Block 3 Image <span class="required">*</span></div>
                                        </div>
                                        <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div id="old_image">
                                        @if($tt_content->image_3 !="")
                                            <img width="125px" height="125px" src="{{ asset('images/'.$tt_content->image_3) }}">
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 25)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 28)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputText', 'style' => 'height: 500px;']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 29)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputHeadline', 'Headline', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('headline_1', null , ['placeholder' => 'Headline', 'class' => 'form-control', 'id' => 'inputHeadline']) !!}
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::textarea('text_1', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputText']) !!}
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 31)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputCategory', 'Category', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="select-item">
                                            {!! Form::select('input_1', $tt_content->product_categories, null , ['placeholder' => 'Choose Category', 'class' => 'form-control', 'id' => 'inputCategory']) !!}
                                            <span class="text-danger">{{ $errors->first('input_1') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @elseif($tt_content->component_id == 32)
                    <div class="card">
                        <div class="card-body">
                            {!! Form::model($tt_content, ['method' => 'put', 'route' => ['admin.component.update', $tt_content->id], 'class' => 'form-horizontal', 'files' => true]) !!}
                                <div class="form-group row">
                                    {!! Form::label('inputCategory', 'Category', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="select-item">
                                            {!! Form::select('input_1', $tt_content->product_categories, null , ['placeholder' => 'Choose Category', 'class' => 'form-control', 'id' => 'inputCategory']) !!}
                                            <span class="text-danger">{{ $errors->first('input_1') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row ">
                                    <div class="offset-sm-3 col-sm-9">
                                        {!! Form::submit('Submit', ['class' => 'btn btn-danger']) !!}
                                    </div>
                                </div>
                            {!! Form::close() !!}
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                @endif
            </div>
        </div>
    </div>
</x-master-layout>