<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::model($job, ['method' => 'put', 'route' => ['admin.jobs.update', $tt_content_id, $job->id], 'class' => 'form-horizontal']) !!}
                <div class="title-head">
                    <h2>Add Job</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            <a href="{{ route('admin.jobs.index', $tt_content_id) }}" class="btn btn-primary"> Back </a>
                        </li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>
                @if(session()->has('message'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif

                <div class="card-form-wrapper">
                    <div class="card-item basic-detail">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputPosition', 'Position', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('position', null , ['placeholder' => 'Position', 'class' => 'form-control', 'id' => 'inputPosition']) !!}
                                            <span class="text-danger">{{ $errors->first('position') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputTeam', 'Team', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('team', null , ['placeholder' => 'Team', 'class' => 'form-control', 'id' => 'inputTeam']) !!}
                                            <span class="text-danger">{{ $errors->first('team') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputLocation', 'Location', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('location', null , ['placeholder' => 'Location', 'class' => 'form-control', 'id' => 'inputLocation']) !!}
                                            <span class="text-danger">{{ $errors->first('location') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputLinkedinLink', 'Linkedin Link', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('linkedin', null , ['placeholder' => 'Linkedin Link', 'class' => 'form-control', 'id' => 'inputLinkedinLink']) !!}
                                            <span class="text-danger">{{ $errors->first('linkedin') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputDivision', 'Divisions', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            <div class="select-item">
                                                {!! Form::select('service_id', $divisions, null , ['placeholder' => 'Choose Division', 'class' => 'form-control', 'id' => 'inputDivision']) !!}
                                                <span class="text-danger">{{ $errors->first('service_id') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputShortDescription', 'Short Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('short_description', null , ['placeholder' => 'Short Description', 'class' => 'form-control', 'id' => 'inputShortDescription']) !!}
                                            <span class="text-danger">{{ $errors->first('short_description') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputResponsibilities', 'Job Responsibilities', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('responsibilities', null , ['placeholder' => 'Job Responsibilities', 'class' => 'form-control', 'id' => 'inputResponsibilities']) !!}
                                            <span class="text-danger">{{ $errors->first('responsibilities') }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>