<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::model($faq, ['method' => 'put', 'route' => ['admin.faq.update', $tt_content_id, $faq->id], 'class' => 'form-horizontal']) !!}
                <div class="title-head">
                    <h2>Edit FAQ Accordion</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>

                <div class="card-form-wrapper">
                    <div class="card-item">
                        <div class="card-holder">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputTitle', 'Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('title', null , ['placeholder' => 'Title', 'class' => 'form-control', 'id' => 'inputTitle']) !!}
                                            <span class="text-danger">{{ $errors->first('title') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputText', 'Text', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('text', null , ['placeholder' => 'Text', 'class' => 'form-control', 'id' => 'inputText']) !!}
                                            <span class="text-danger">{{ $errors->first('text') }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>   