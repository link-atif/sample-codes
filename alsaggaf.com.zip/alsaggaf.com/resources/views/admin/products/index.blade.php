<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>All Products</h2>
                <ul class="btn-group h-list">
                    <li class="btn-item"><a href="{{ route('admin.products.create') }}" class="btn btn-primary"> Add Product</a></li>
                    <li class="btn-item"><a href="{{ route('admin.products.file-import-export') }}" class="btn btn-primary"> Import CSV</a></li>
                </ul>
            </div>
            <!-- Search -->
            <div class="filter-wrapper row px-4">
                <div class="col-lg-10">
                    <form action="{{route('admin.products.search')}}" method="GET" role="search">
                    <div class="row">
                        {{csrf_field()}}
                        <input type="text" class="col-lg-3 mr-10" value="@if(isset($name)){{$name}} @endif" name="name" placeholder="Search By Name">
                        <input type="text" class="col-lg-3 mr-10" value="@if(isset($id)){{$id}} @endif" name="id" placeholder="Search By ID">
                        {!! Form::select('category', $categories, isset($category) ? $category : null, ['placeholder' => 'Search By Category', 'class' => 'pl-40 col-lg-3 mr-10', 'id' => 'inputCategory', 'name' => 'category']) !!}
                        <button type="submit" class="btn btn-primary btn-search col-lg-1">Search</button>
                    </div>
                    </form> 
                </div>
                <div class="col-lg-2 pr-0">
                    <a href="{{ route('admin.products.index') }}" class="btn btn-search btn-primary float-right">Reset</a>
                </div>
            </div>
            <!-- Search Ends-->
             @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
          
            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                    @if(isset($products))
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col" style="width: 6%;"></th>
                                    <th scope="col" style="width: 8%;">Id</th>
                                    <th scope="col" style="width: 30%;">Title</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Qty</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="myTable">
                                @foreach($products as $product)
                                    <tr>
                                        <td>
                                            <div class="custom-control">
                                                <span><img src="@if($product->product_image !="") {{ asset('images') }}/catalog/products/{{ $product->product_image }} @else {{ asset('images/no-image.png') }} @endif" alt="{{ $product->title }}" /></span>
                                            </div>
                                        </td>
                                        <td>{{ $product->sku }}</td>
                                        <td>{{ \Illuminate\Support\Str::limit($product->title, 50, $end='...') }}</td>
                                        <td>{{App\Http\Controllers\Admin\ProductsController::getCategory($product->category_id);}}</td>
                                        <td>{{ $product->qty }}</td>
                                        <td>{{ $product->price }}</td>
                                        @if($product->status == 0)
                                            <td> In Active </td>
                                        @else 
                                            <td> <span class='text-success'>Active</span> </td>
                                        @endif
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.products.edit', $product->id) }}">Edit</a> 
                                                <a data-toggle="modal" data-target="#deleteModal_{{ $product->id }}" role="button">
                                                    Delete
                                                </a>
                                                <!-- Delete Modal -->
                                                <div class="modal fade" id="deleteModal_{{ $product->id }}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel_{{ $product->id }}" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="deleteModalLabel_{{ $product->id }}">Delete Product</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                Are you sure, you wants to delete ...
                                                            </div>
                                                            <div class="modal-footer">
                                                                {!! Form::open(['method' => 'delete', 'route' => ['admin.products.destroy',$product->id], 'class' => 'form-horizontal']) !!}
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-primary">Delete</button>
                                                                {!! Form::close() !!}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @endif
                    </div>
                    {{ $products->links() }}
                </div>
            </div>
        </div>
    </div>
</x-master-layout>