<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::open(['method' => 'post', 'route' => ['admin.products.store'], 'class' => 'form-horizontal']) !!}
                <div class="title-head">
                    <h2>Add Product</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            <a href="{{ route('admin.products.index') }}" class="btn btn-primary"> Back </a>
                        </li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>

                <div class="card-form-wrapper">
                    <div class="card-item basic-detail">
                        <div class="card-holder">
                            <h5>Product Type</h5>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputProducttype', 'Product Type', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            <div class="select-item">
                                                {!! Form::select('product_type', [ 0 => 'Single Product', '1' => 'Configureable Product'], null , ['placeholder' => 'Choose Product Type', 'class' => 'form-control', 'id' => 'inputProducttype']) !!}
                                                <span class="text-danger">{{ $errors->first('product_type') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>