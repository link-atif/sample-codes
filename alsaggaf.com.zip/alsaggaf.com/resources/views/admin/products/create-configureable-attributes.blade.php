<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::open(['method' => 'post', 'route' => ['admin.products.store'], 'class' => 'form-horizontal']) !!}
                <div class="title-head">
                    <h2>Add Product</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            <a href="{{ route('admin.products.index') }}" class="btn btn-primary"> Back </a>
                        </li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>

                <div class="card-form-wrapper">
                    <div class="card-item basic-detail">
                        <div class="card-holder">
                            <h5>Configureable Attributes</h5>
                            <div class="form-group row">
                                <div class="col-12">
                                    <div class="custom-control custom-checkbox d-flex align-items-center Justify-content-center">
                                        <input type="checkbox" name="color" value="1" class="custom-control-input" id="inputColorAttribute"/>
                                        <label class="custom-control-label" for="inputColorAttribute">
                                            <span> Color Attribute </span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-12">
                                    <div class="custom-control custom-checkbox d-flex align-items-center Justify-content-center">
                                        <input type="checkbox" name="size" value="2" class="custom-control-input" id="inputSizeAttribute"/>
                                        <label class="custom-control-label" for="inputSizeAttribute">
                                            <span> Size Attribute </span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>