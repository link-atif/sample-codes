<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::model($product, ['method' => 'put', 'route' => ['admin.products.update', $product->id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                <div class="title-head">
                    <h2>Add Single Product Details</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item">
                            <a href="{{ route('admin.products.index') }}" class="btn btn-primary"> Back </a>
                        </li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>
                @if(session()->has('message'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                @if($errors->first('product_attribute_set_id'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>Error !</strong> Please Choose Product Specification Attribute ..!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                @if($errors->first('value'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>Error !</strong> Please Choose Product Specification Attribute Value ..!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                <div class="card-form-wrapper">
                    <div class="card-item basic-detail">
                        <div class="card-holder">
                            <h5>Basic Detail</h5>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputProductTitle', 'Product Title', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('title', null , ['placeholder' => 'Product Title', 'class' => 'form-control', 'id' => 'inputProductTitle']) !!}
                                            <span class="text-danger">{{ $errors->first('title') }}</span>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('textarea', 'Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('description', null , ['placeholder' => 'Description', 'class' => 'form-control', 'id' => 'textarea']) !!}
                                            <span class="text-danger">{{ $errors->first('description') }}</span>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        {!! Form::label('inputStatus', 'Status', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            <div class="select-item">
                                                {!! Form::select('status', ['0' => 'In Active', '1' => 'Active'], null , ['placeholder' => 'Choose Status', 'class' => 'form-control', 'id' => 'inputStatus']) !!}
                                                <span class="text-danger">{{ $errors->first('status') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {!! Form::label('inputfeature', 'Featured', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            <div class="select-item">
                                                {!! Form::select('featured_product', ['0' => 'No', '1' => 'Yes'], null , ['placeholder' => 'Choose featured', 'class' => 'form-control', 'id' => 'inputfeature']) !!}
                                                <span class="text-danger">{{ $errors->first('featured_product') }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group files">
                                        {!! Form::file('product_image[]',['class' => 'form-control', 'id' => 'inputProductImages', 'multiple' => 'multiple' , 'onChange' =>'encodeImageFileAsURL("inputProductImages", "image_preview",   "old_image");']) !!}
                                        <div class="content">Drag or Drop Product Image <span class="required">*</span></div>
                                        <span class="text-danger">{{ $errors->first('product_image') }}</span>
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                    @if($product->product_image)
                                        <div class="form-group row">
                                            {!! Form::label('textarea', 'Product Images', ['class' => 'col-sm-3 col-form-label']) !!}
                                            <div class="col-sm-9">
                                                @foreach($product->images as $image)
                                                    <div>
                                                        <a data-toggle="modal" data-target="#deleteModal_{{ $image->id }}" role="button">
                                                            <i class="fas fa-trash pr-3"></i> 
                                                            <span style="margin-top:5px;">
                                                            @if($image->product_image !="")
                                                                <img width="125px" height="125px" src="{{ asset('images/catalog/products/'.$image->product_image) }}">
                                                            @endif
                                                            </span>
                                                        </a>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-item tab-area">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="generalInfo" data-toggle="tab" href="#general-info" role="tab" aria-selected="true">General Info</a>
                            </li>
                            <li class="nav-item" style="display:none;">
                                <a class="nav-link" id="inventoryTab" data-toggle="tab" href="#inventory-tab" role="tab"  aria-selected="false">Inventory</a>
                            </li>
                           
                            <li class="nav-item" style="display:none;">
                                <a class="nav-link" id="returnsAndExchange" data-toggle="tab" href="#returns-and-exchange" role="tab" aria-selected="false">Returns & Exchange</a>
                            </li>
                            <li class="nav-item" style="display:none;">
                                <a class="nav-link" id="shipmentInformation" data-toggle="tab" href="#shipment-information" role="tab" aria-selected="false">Shipment Information</a>
                            </li>
                            <li class="nav-item" style="display:none;">
                                <a class="nav-link" id="warrenty" data-toggle="tab" href="#warranty-information" role="tab" aria-selected="false">Warranty</a>
                            </li>
                        </ul>
                        <div class="card-holder">
                            <div class="tab-content">
                                <!-- Tab General Info -->
                                <div class="tab-pane fade show active" id="general-info" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group row">
                                                {!! Form::label('inputProductId', 'Product ID/SKU', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('sku', null , ['placeholder' => 'Product ID/SKU', 'class' => 'form-control', 'id' => 'inputProductId']) !!}
                                                    <span class="text-danger">{{ $errors->first('sku') }}</span>
                                                </div>
                                            </div>


                                            <div class="form-group row">
                                                {!! Form::label('inputCategory', 'Categories', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    <div class="select-item ">
                                                        {!! Form::select('category_id[]', $categories, explode(',', rtrim($product->category_id, ',')) ,['multiple' => 'multiple' ,  'class' => 'form-control' , 'id' => 'inputCategory']) !!}
                                                        <span class="text-danger">{{ $errors->first('category_id') }}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group row">
                                                {!! Form::label('inputBrand', 'Brands', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    <div class="select-item">
                                                        {!! Form::select('brand_id', $product->brands, null , ['placeholder' => 'Choose Brands', 'class' => 'form-control', 'id' => 'inputBrand']) !!}
                                                        <span class="text-danger">{{ $errors->first('brand_id') }}</span>
                                                    </div>
                                                </div>
                                            </div>


                                            {{-- <div class="form-group row">
                                                {!! Form::label('inputSubBrand', 'Sub Brands', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    <div class="select-item">
                                                        {!! Form::select('sub_brand_id', $product->sub_brands, null , ['placeholder' => 'Choose Sub Brands', 'class' => 'form-control', 'id' => 'inputSubBrand']) !!}
                                                        <span class="text-danger">{{ $errors->first('sub_brand_id') }}</span>
                                                    </div>
                                                </div>
                                            </div> --}}


                                            <div class="form-group row" style="display:none;">
                                                {!! Form::label('inputOrigin', 'Origin', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('origin', null , ['placeholder' => 'Origin', 'class' => 'form-control', 'id' => 'inputOrigin']) !!}
                                                    <span class="text-danger">{{ $errors->first('origin') }}</span>
                                                </div>
                                            </div>
                                            <div class="form-group row" style="display:none;">
                                                {!! Form::label('inputMaterial', 'Material', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('material', null , ['placeholder' => 'Material', 'class' => 'form-control', 'id' => 'inputMaterial']) !!}
                                                    <span class="text-danger">{{ $errors->first('material') }}</span>
                                                </div>
                                            </div>
                                            {{-- <div class="form-group row">
                                                {!! Form::label('inputProductType', 'Product Type', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('prod_type', null , ['placeholder' => 'Product Type', 'class' => 'form-control' , 'id' => 'inputProductType']) !!}
                                                    <span class="text-danger">{{ $errors->first('prod_type') }}</span>
                                                </div>
                                            </div> --}}
                                        </div>
                                        <div class="col-lg-6">
                                            <!-- <div class="form-group row d-flex justify-content-end">
                                                <a data-toggle="modal" data-target="#product-specifications-model" class="btn btn-primary mr-15"> Add Product Specification</a>
                                            </div> -->
                                            <div class="form-group row">
                                                {!! Form::label('inputProductSpecifications', 'Product Specifications', ['class' => 'col-sm-3 col-form-label']) !!}
                                            </div>
                                            <div class="form-group row">
                                                {!! Form::label('inputProductSpecifications', 'Product Specification Attribute', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    <div class="select-item">
                                                        {!! Form::select('product_attribute_set_id', $product->product_specification_attributes, null , ['placeholder' => 'Choose Product Specification Attribute', 'class' => 'form-control', 'id' => 'inputProductSpecifications']) !!}
                                                        <span class="text-danger">{{ $errors->first('product_attribute_set_id') }}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                {!! Form::label('inputAttribteValue', 'Attribute Value', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('value', null , ['placeholder' => 'Attribute Value', 'class' => 'form-control', 'id' => 'inputAttribteValue']) !!}
                                                    <span class="text-danger">{{ $errors->first('value') }}</span>
                                                </div>
                                            </div>
                                            <div class="modal-footer justify-content-right">
                                                <div class="action-link">
                                                    <button type="button" onClick="submitForm();" class="btn btn-primary">Save Product Specification</button>
                                                </div>
                                            </div>
                                            @foreach($product->product_specifications_attributes_values as $att_value)
                                                <div class="form-group row">
                                                    {!! Form::label('', $att_value->product_attribute_set->attribute_name, ['class' => 'col-sm-3 col-form-label']) !!}
                                                    <div class="col-sm-9">
                                                        <a data-toggle="modal" data-target="#product-specifications-delete-model-{{ $att_value->id }}" role="button">
                                                            <i class="fas fa-trash pr-3"></i>
                                                        </a>
                                                        <!-- <a data-toggle="modal" data-target="#product-specifications-edit-model-{{ $att_value->id }}" role="button">
                                                            <i class="fas fa-edit pr-3"></i>
                                                        </a> -->
                                                        {{ $att_value->value }}
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                <!-- Tab Product Inventory -->
                                <div class="tab-pane fade" id="inventory-tab" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group row">
                                                {!! Form::label('inputQuantity', 'Quantity', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('qty', null , ['placeholder' => 'Quantity', 'class' => 'form-control', 'id' => 'inputQuantity']) !!}
                                                    <span class="text-danger">{{ $errors->first('qty') }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Tab B2B Inventory
                                <div class="tab-pane fade" id="b2b-stock" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group row">
                                                {!! Form::label('inputQuantity', 'B2B Quantity', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('b2b_qty', null , ['placeholder' => 'B2B Quantity', 'class' => 'form-control', 'id' => 'inputQuantity']) !!}
                                                    <span class="text-danger">{{ $errors->first('b2b_qty') }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->
                                <!-- Tab Product Returns & Exchange Policy -->
                                <div class="tab-pane fade" id="returns-and-exchange" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group row">
                                                {!! Form::label('inputReturnsAndExchangePolicy', 'Returns and Exchange Policy', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::textarea('returns_and_exchange', null , ['placeholder' => 'Returns and Exchange Policy', 'class' => 'form-control', 'id' => 'inputReturnsAndExchangePolicy']) !!}
                                                    <span class="text-danger">{{ $errors->first('returns_and_exchange') }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Tab Product Returns & Exchange Policy -->
                                <div class="tab-pane fade" id="shipment-information" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group row">
                                                {!! Form::label('inputShipmentInformation', 'Shipment Information', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('shipment_information', null , ['placeholder' => 'Shipment Information', 'class' => 'form-control', 'id' => 'inputShipmentInformation']) !!}
                                                    <span class="text-danger">{{ $errors->first('shipment_information') }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Tab Product Warranty -->
                                <div class="tab-pane fade" id="warranty-information" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group row">
                                                {!! Form::label('inputWarranty', 'Warranty', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::textarea('warranty', null , ['placeholder' => 'Warranty', 'class' => 'form-control', 'id' => 'inputWarranty']) !!}
                                                    <span class="text-danger">{{ $errors->first('warranty') }}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-item tab-area">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="priceTab" data-toggle="tab" href="#price-tab" role="tab" aria-selected="true">Price</a>
                            </li>
                        </ul>
                        <div class="card-holder">
                            <div class="tab-content">
                                <!-- Tab Price -->
                                <div class="tab-pane fade show active" id="general-info" role="tabpanel">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group row">
                                                {!! Form::label('inputPrice', 'Price', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('price', null , ['placeholder' => 'Price', 'class' => 'form-control', 'id' => 'inputPrice']) !!}
                                                    <span class="text-danger">{{ $errors->first('price') }}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- <div class="col-lg-6">
                                            <div class="form-group row">
                                                {!! Form::label('inputCost', 'Cost', ['class' => 'col-sm-3 col-form-label']) !!}
                                                <div class="col-sm-9">
                                                    {!! Form::text('cost', null , ['placeholder' => 'Cost', 'class' => 'form-control', 'id' => 'inputCost']) !!}
                                                    <span class="text-danger">{{ $errors->first('cost') }}</span>
                                                </div>
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
            <!-- Categories -->
    {{--    <div class="card-form-wrapper">
                <div class="card-item basic-detail">
                    <div class="card-holder">
                        <h5>Select Categories</h5>
                        <div class="row">
                            <div class="col-12">
                                <div class="all-product-table">
                                    <div class="table-wrapper mb-30" style="box-shadow: none;">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th scope="col" style="width: 6%;"></th>
                                                        <th scope="col" style="width: 8%;">Id</th>
                                                        <th scope="col" style="width: 30%;">Name</th>
                                                        <th scope="col">Parent Category</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($product->product_categories as $category)
                                                        <tr>
                                                            <td>
                                                                <div class="custom-control custom-checkbox">
                                                                    {!! Form::open(['method' => 'post', 'route' => ['admin.products.category.update', $product->id], 'class' => 'form-horizontal']) !!}
                                                                        <input type="hidden" name="category" value="{{ $category->id }}" >
                                                                        <input type="checkbox" name="category_id" value="{{ $category->id }}" {{ (in_array($category->id, explode(',', rtrim($product->category_id, ',')))) ? "checked='checked'" : ''}}  class="custom-control-input" id="customCheck-{{ $category->id }}" onchange="this.form.submit();"/>
                                                                        <label class="custom-control-label" for="customCheck-{{ $category->id }}">
                                                                            <span><img src="{{ asset('images') }}/catalog/category/{{ $category->thumbnail }}" alt="{{ $category->name }}" /></span>
                                                                        </label>
                                                                    {!! Form::close() !!}
                                                                </div>
                                                            </td>
                                                            <td>{{ $category->id }}</td>
                                                            <td>{{ \Illuminate\Support\Str::limit($category->name, 50, $end='...') }}</td>
                                                            <td>
                                                                {{ $category->parent }}
                                                            </td>
                                                        </tr>
                                                        @foreach($category->sub as $item)
                                                            <tr>
                                                                <td>
                                                                    <div class="custom-control custom-checkbox">
                                                                        {!! Form::open(['method' => 'post', 'route' => ['admin.products.category.update', $product->id], 'class' => 'form-horizontal']) !!}
                                                                            <input type="hidden" name="category" value="{{ $item->id }}" >
                                                                            <input type="checkbox" name="category_id" value="{{ $item->id }}" {{ (in_array($item->id, explode(',', rtrim($product->category_id, ',')))) ? "checked='checked'" : ''}}  class="custom-control-input" id="customCheck-{{ $item->id }}" onchange="this.form.submit();"/>
                                                                            <label class="custom-control-label" for="customCheck-{{ $item->id }}">
                                                                                <span><img src="{{ asset('images') }}/catalog/category/{{ $item->thumbnail }}" alt="{{ $item->name }}" /></span>
                                                                            </label>
                                                                        {!! Form::close() !!}
                                                                    </div>
                                                                </td>
                                                                <td>{{ $item->id }}</td>
                                                                <td>{{ \Illuminate\Support\Str::limit($item->name, 50, $end='...') }}</td>
                                                                <td>
                                                                    {{ $item->parent }}
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>  --}}
        </div>
    </div>
    <!-- Product Image Modal -->
    @foreach($product->images as $image)
        <div class="modal fade" id="deleteModal_{{ $image->id }}" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel_{{ $image->id }}" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel_{{ $image->id }}">Delete Product Image</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        Are you sure, you wants to delete ...
                    </div>
                    <div class="modal-footer">
                        {!! Form::open(['method' => 'delete', 'route' => ['admin.product.image.destroy',$product->id, $image->id], 'class' => 'form-horizontal']) !!}
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Delete</button>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
    <!-- Product Specification Model -->
    <div class="modal fade modal-xxl quick-view-modal" id="product-specifications-model">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button class="close-btn" data-dismiss="modal">
                        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                        </svg>
                    </button>
                </div>
                {!! Form::open(['method' => 'post', 'route' => ['admin.product.specification.store',$product->id], 'class' => 'form-horizontal']) !!}
                    <div class="modal-body">
                        <div class="pdp-content-wrapper">
                            <div class="form-group row">
                                {!! Form::label('inputProductSpecifications', 'Product Specification Attribute', ['class' => 'col-sm-3 col-form-label']) !!}
                                <div class="col-sm-9">
                                    <div class="select-item">
                                        {!! Form::select('product_attribute_set_id', $product->product_specification_attributes, null , ['placeholder' => 'Choose Product Specification Attribute', 'class' => 'form-control', 'id' => 'inputProductSpecifications']) !!}
                                        <span class="text-danger">{{ $errors->first('product_attribute_set_id') }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                {!! Form::label('inputAttribteValue', 'Attribute Value', ['class' => 'col-sm-3 col-form-label']) !!}
                                <div class="col-sm-9">
                                    {!! Form::text('value', null , ['placeholder' => 'Attribute Value', 'class' => 'form-control', 'id' => 'inputAttribteValue']) !!}
                                    <span class="text-danger">{{ $errors->first('value') }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-center">
                        <div class="action-link">
                            <button type="submit" class="btn btn-primary">Save Product Specification Attribute Value</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
    <!-- Product Specification Model -->
    @foreach($product->product_specifications_attributes_values as $att_value)
        <div class="modal fade modal-xxl quick-view-modal" id="product-specifications-edit-model-{{ $att_value->id }}">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button class="close-btn" data-dismiss="modal">
                            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                            </svg>
                        </button>
                    </div>
                    {!! Form::model($att_value, ['method' => 'put', 'route' => ['admin.product.specification.update', $att_value->product_id, $att_value->id], 'class' => 'form-horizontal']) !!}
                        <div class="modal-body">
                            <div class="pdp-content-wrapper">
                                <div class="form-group row">
                                    {!! Form::label('inputProductSpecifications', 'Product Specification Attribute', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        <div class="select-item">
                                            {!! Form::select('product_attribute_set_id', $product->product_specification_attributes, $att_value->product_attribute_set_id , ['placeholder' => 'Choose Product Specification Attribute', 'class' => 'form-control', 'id' => 'inputProductSpecifications', 'disabled' => 'disabled']) !!}
                                            <span class="text-danger">{{ $errors->first('product_attribute_set_id') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    {!! Form::label('inputAttribteValue', 'Attribute Value', ['class' => 'col-sm-3 col-form-label']) !!}
                                    <div class="col-sm-9">
                                        {!! Form::text('value', null , ['placeholder' => 'Attribute Value', 'class' => 'form-control', 'id' => 'inputAttribteValue']) !!}
                                        <span class="text-danger">{{ $errors->first('value') }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer justify-content-center">
                            <div class="action-link">
                                <button type="submit" class="btn btn-primary">Save Product Specification Attribute Value</button>
                            </div>
                        </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    @endforeach
    <!-- Product Image Modal -->
    @foreach($product->product_specifications_attributes_values as $att_value)
        <div class="modal fade modal-xxl quick-view-modal" id="product-specifications-delete-model-{{ $att_value->id }}">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button class="close-btn" data-dismiss="modal">
                            <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                            </svg>
                        </button>
                    </div>
                    <div class="modal-body">
                        Are you sure, you wants to delete Product Specification Attribute Value ({{ $att_value->product_attribute_set->attribute_name }})
                    </div>
                    <div class="modal-footer">
                        {!! Form::open(['method' => 'delete', 'route' => ['admin.product.specification.delete',$att_value->product_id, $att_value->id], 'class' => 'form-horizontal']) !!}
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Delete</button>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
    @endforeach
    <script type="text/javascript">
        $(document).ready(function(){
            $('#inputCategory').select2({
                placeholder: "Choose Category",
                tags: true,
                allowClear: true
            });         
        });
   
        function submitForm(){
            var id = '{{ $product->id }}';
            var inputProductSpecifications = $("#inputProductSpecifications").val();
            var inputAttribteValue = $("#inputAttribteValue").val();
            if(inputProductSpecifications == ""){
                alert('Please Select Product Specification Attribute');
                return false;
            }
              if(inputAttribteValue == ""){
                alert('Please Add Product Specification Attribute Value');
                return false;
              }
              $.ajax({
                  type: 'POST',
                  dataType: 'json',
                  url: '{{ route("admin.product.specification.store", $product->id) }}',
                  data: {"_token": "{{ csrf_token() }}",'product_attribute_set_id' : inputProductSpecifications,  'value' : inputAttribteValue},
                  success: function(result) {
                    console.log(result);
                      if(result.status == true){
                        window.location.reload(true);  
                      }
                  },
                  error: function(response) {
                     window.location.reload(true);
                  }
              });
        }
    </script>


</x-master-layout>