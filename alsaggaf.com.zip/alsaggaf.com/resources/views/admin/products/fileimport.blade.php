<x-master-layout>
    <div class="main-wrapper">
       
        <div class="dashboard-wrapper">
             @if(session()->has('message'))
                <div class="alert alert-primary alert-dismissible fade show" role="alert">
                    <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
        <form action="{{ route('admin.products.file-import') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class=" row form-group">
                <div class="custom-file text-left col-lg-6">
                    <input type="file" name="filename" required="filename" class=" form-control mb-10" id="customFile">
                    <button class="btn btn-primary">Import</button>
                    {{-- <a class="btn btn-primary" href="{{ route('admin.products.file-export') }}">Export Data</a> --}}
                    <a class="btn btn-primary" href="{{ asset('/csvSample/CSV_sample.csv') }}" target="_blank">Sample CSV</a> 
                </div>
            </div>
              
        </form>
        
         </div>
         <div class="dashboard-wrapper">
        <form action="{{ route('admin.products.file-update','message') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <div class=" row form-group">
                <div class="custom-file text-left col-lg-6">
                    <input type="file" name="filename" required="filename" class=" form-control mb-10" id="customFile">
                    <button class="btn btn-primary">Import Specifications</button> 
                </div>
            </div>
              
        </form>
        
         </div>
     </div>
 </x-master-layout>