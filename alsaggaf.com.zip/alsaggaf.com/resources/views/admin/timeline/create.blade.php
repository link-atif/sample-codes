<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            {!! Form::open(['method' => 'post', 'route' => ['admin.timeline.store', $tt_content_id], 'class' => 'form-horizontal']) !!}
                <div class="title-head">
                    <h2>Create Timeline</h2>
                    <ul class="btn-group h-list">
                        <li class="btn-item"><a href="{{ route('admin.timeline.index', $tt_content_id) }}" class="btn btn-primary"> Back </a></li>
                        <li class="btn-item">
                            {!! Form::submit('Save', ['class' => 'btn btn-primary']) !!}
                        </li>
                    </ul>
                </div>

                <div class="card-form-wrapper">
                    <div class="card-item">
                        <div class="card-holder">
                            <div class="row">
                            <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputYear', 'Year', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::text('year', null , ['placeholder' => 'Year', 'class' => 'form-control', 'id' => 'inputYear']) !!}
                                            <span class="text-danger">{{ $errors->first('year') }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group row">
                                        {!! Form::label('inputDescription', 'Description', ['class' => 'col-sm-3 col-form-label']) !!}
                                        <div class="col-sm-9">
                                            {!! Form::textarea('description', null , ['placeholder' => 'Description', 'class' => 'form-control', 'id' => 'inputDescription']) !!}
                                            <span class="text-danger">{{ $errors->first('description') }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</x-master-layout>