<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>Orders</h2>
            </div>
            <div class="filter-wrapper">
                <div class="search-holder">
                    
                </div>
                <div class="filter-section">
                    {{ $refunds->links('vendor.pagination.custom-pagination') }}
                </div>
            </div>
            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Id</th>
                                    <th scope="col">Order Id</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Qty</th>
                                    <th scope="col">Refund Creation</th>
                                    <th scope="col">Customer</th>
                                    <th scope="col">Type</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">View</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($refunds as $refund)
                                    <tr>
                                        <td>{{ str_pad($refund->id, 8, '0', STR_PAD_LEFT) }}</td>
                                        <td>{{ str_pad($refund->order_id, 8, '0', STR_PAD_LEFT) }}</td>
                                        <td>{{ $refund->cart_detail->product_qty * $refund->cart_detail->product_price }}</td>
                                        <td>{{ $refund->cart_detail->product_qty }}</td>
                                        <td>{{ \Carbon\Carbon::parse($refund->created_at)->format('d, F Y') }}</td>
                                        <td>{{ $refund->fe_user->name }}</td>
                                        <td>
                                            @if($refund->order->transaction->transaction_type == 1)
                                                Credit
                                            @elseif($refund->order->transaction->transaction_type == 2) 
                                                Debit
                                            @else
                                                Cash on Delivery
                                            @endif
                                        </td>
                                        <td>
                                            @if($refund->status == 0)
                                                Under Process
                                            @elseif($refund->status == 1)
                                                Required to return product
                                            @elseif($refund->status == 2)
                                                Refund under process
                                            @elseif($refund->status == 3)
                                                Refund Processed
                                            @elseif($refund->status == 4)
                                                Request rejected due to exceeding 15 days
                                            @elseif($refund->status == 5)
                                                Request rejected due to product failing quality check
                                            @endif
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.refunds.show', $refund->id) }}">View</a> 
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>