<!--Mobile menu-->
<aside class="mobile-sidebar for-mobile">
    <nav class="nav-holder">
        <div class="mobile-logo">
            <a href="{{ route('dashboard') }}">
                <img src="{{ asset('images/logo.svg') }}" alt="Al Saggaf Co"/>
            </a>
        </div>
        <ul class="v-list nav-list">
            <li>
                <a href="{{ route('dashboard') }}" class="dashboard">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M17.5 7.8C17.5 7.8 17.5 7.8 17.5 7.8L10.2 0.5C9.9 0.2 9.4 0 9 0 8.6 0 8.1 0.2 7.8 0.5L0.5 7.8C0.5 7.8 0.5 7.8 0.5 7.8 -0.2 8.5-0.2 9.5 0.5 10.2 0.8 10.5 1.2 10.6 1.6 10.7 1.6 10.7 1.6 10.7 1.6 10.7H1.9V16.1C1.9 17.1 2.8 18 3.9 18H6.7C7 18 7.3 17.8 7.3 17.5V13.2C7.3 12.7 7.7 12.4 8.2 12.4H9.8C10.3 12.4 10.7 12.7 10.7 13.2V17.5C10.7 17.8 11 18 11.3 18H14.1C15.2 18 16.1 17.1 16.1 16.1V10.7H16.3C16.8 10.7 17.2 10.5 17.5 10.2 18.2 9.5 18.2 8.5 17.5 7.8V7.8Z" fill="currentColor"/></svg>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a href="#" class="product dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><style>.a{fill:currentColor;}</style><path d="M5.4 0H1C0.5 0 0 0.5 0 1V3.6C0 4.2 0.5 4.7 1 4.7H5.4C6 4.7 6.4 4.2 6.4 3.6V1C6.4 0.5 6 0 5.4 0Z" class="a"/><path d="M5.4 5.8H1C0.5 5.8 0 6.3 0 6.9V13C0 13.5 0.5 14 1 14H5.4C6 14 6.4 13.5 6.4 13V6.9C6.4 6.3 6 5.8 5.4 5.8Z" class="a"/><path d="M13 9.3H8.6C8 9.3 7.6 9.8 7.6 10.4V13C7.6 13.5 8 14 8.6 14H13C13.5 14 14 13.5 14 13V10.4C14 9.8 13.5 9.3 13 9.3Z" class="a"/><path d="M13 0H8.6C8 0 7.6 0.5 7.6 1V7.1C7.6 7.7 8 8.2 8.6 8.2H13C13.5 8.2 14 7.7 14 7.1V1C14 0.5 13.5 0 13 0V0Z" class="a"/></svg>
                    <span>Products</span>
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="{{ route('admin.products.index') }}">All Products</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.category.index') }}">Categories</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.attribute-set.index') }}">Attributes</a></li>
                </ul>
            </li>
            <li>
                <a href="{{ route('admin.orders.index') }}" class="orders">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none"><style>.a{fill:currentColor;}</style><path d="M13.3 14.5L12.6 5C12.5 4.4 12 3.9 11.4 3.9H9.9V6.1C9.9 6.4 9.7 6.6 9.4 6.6 9.1 6.6 8.9 6.4 8.9 6.1V3.9H4.4V6.1C4.4 6.4 4.2 6.6 3.9 6.6 3.6 6.6 3.4 6.4 3.4 6.1V3.9H1.9C1.3 3.9 0.8 4.4 0.8 5L0 14.5C-0.1 15.2 0.2 16 0.7 16.5 1.2 17.1 2 17.4 2.7 17.4H10.6C11.3 17.4 12.1 17.1 12.6 16.5 13.1 16 13.4 15.2 13.3 14.5ZM8.9 9.6L6.3 12.2C6.2 12.3 6.1 12.3 6 12.3 5.9 12.3 5.7 12.3 5.6 12.2L4.4 11C4.2 10.8 4.2 10.5 4.4 10.3 4.6 10.1 4.9 10.1 5.1 10.3L6 11.1 8.2 8.9C8.4 8.8 8.7 8.8 8.9 8.9 9.1 9.1 9.1 9.4 8.9 9.6Z" class="a"/><path d="M6.7 0.6C4.9 0.6 3.4 2.1 3.4 3.9V3.9H4.4V3.9C4.4 2.6 5.4 1.6 6.7 1.6 7.9 1.6 8.9 2.6 8.9 3.9V3.9H9.9V3.9C9.9 2.1 8.4 0.6 6.7 0.6Z" class="a"/></svg>
                    <span>Orders</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.newsletter.index') }}" class="newsletter">
                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="17" viewBox="0 0 11 17" fill="none"><style>.a{fill:currentColor;}</style><path d="M6.5 3.7V0.9H2.5C1.1 0.9 0 2 0 3.4V13.6C0 15 1.1 16.1 2.5 16.1H8.5C9.9 16.1 11 15 11 13.6V5H7.7C7 5 6.5 4.4 6.5 3.7Z" class="a"/><path d="M7.3 1.8V3.3C7.3 3.8 7.7 4.2 8.2 4.2H10C10.5 4.2 10.9 3.8 10.9 3.4L7.9 0.9C7.6 1.1 7.3 1.4 7.3 1.8Z" class="a"/></svg>
                    <span>NewsLetter</span>
                </a>
            </li>

            <li>
                <a href="{{ route('admin.jobapplication.index') }}" class="jobapplication">
                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="17" viewBox="0 0 11 17" fill="none"><style>.a{fill:currentColor;}</style><path d="M6.5 3.7V0.9H2.5C1.1 0.9 0 2 0 3.4V13.6C0 15 1.1 16.1 2.5 16.1H8.5C9.9 16.1 11 15 11 13.6V5H7.7C7 5 6.5 4.4 6.5 3.7Z" class="a"/><path d="M7.3 1.8V3.3C7.3 3.8 7.7 4.2 8.2 4.2H10C10.5 4.2 10.9 3.8 10.9 3.4L7.9 0.9C7.6 1.1 7.3 1.4 7.3 1.8Z" class="a"/></svg>
                    <span>JobApplication</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.contact.index') }}" class="contact">
                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="17" viewBox="0 0 11 17" fill="none"><style>.a{fill:currentColor;}</style><path d="M6.5 3.7V0.9H2.5C1.1 0.9 0 2 0 3.4V13.6C0 15 1.1 16.1 2.5 16.1H8.5C9.9 16.1 11 15 11 13.6V5H7.7C7 5 6.5 4.4 6.5 3.7Z" class="a"/><path d="M7.3 1.8V3.3C7.3 3.8 7.7 4.2 8.2 4.2H10C10.5 4.2 10.9 3.8 10.9 3.4L7.9 0.9C7.6 1.1 7.3 1.4 7.3 1.8Z" class="a"/></svg>
                    <span>Contacts</span>
                </a>
            </li>
            <!-- <li>
                <a href="#" class="qoutes">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="16" viewBox="0 0 12 16" fill="none"><path d="M11.5 0H0.5C0.2 0 0 0.2 0 0.5V14.2C0 14.3 0 14.4 0.1 14.5L1.5 15.9C1.7 16 2 16 2.2 15.9L3.2 14.8 4.3 15.9C4.4 16 4.5 16 4.6 16 4.7 16 4.9 16 4.9 15.9L6 14.8 7 15.9C7.1 16 7.2 16 7.4 16 7.5 16 7.6 16 7.7 15.9L8.8 14.8 9.8 15.9C9.9 16 10 16 10.1 16 10.3 16 10.4 16 10.5 15.9L11.8 14.5C11.9 14.4 12 14.3 12 14.2V0.5C12 0.2 11.8 0 11.5 0ZM5.5 3.5V3C5.5 2.7 5.7 2.5 6 2.5 6.3 2.5 6.5 2.7 6.5 3V3.5H7C7.3 3.5 7.5 3.7 7.5 4 7.5 4.2 7.3 4.5 7 4.5H5.7C5.4 4.5 5.1 4.7 5.1 5 5.1 5.3 5.4 5.5 5.7 5.5H6.3C7.1 5.5 7.8 6.2 7.8 7 7.8 7.8 7.2 8.4 6.5 8.5V9C6.5 9.3 6.3 9.5 6 9.5 5.7 9.5 5.5 9.3 5.5 9V8.5H5C4.7 8.5 4.5 8.3 4.5 8 4.5 7.7 4.7 7.5 5 7.5H6.3C6.6 7.5 6.9 7.3 6.9 7 6.9 6.7 6.6 6.5 6.3 6.5H5.7C4.8 6.5 4.2 5.8 4.2 5 4.2 4.2 4.8 3.6 5.5 3.5ZM8.5 12H3.5C3.2 12 3 11.8 3 11.5 3 11.3 3.2 11 3.5 11H8.5C8.8 11 9 11.3 9 11.5 9 11.8 8.8 12 8.5 12Z" fill="currentColor"/></svg>
                    <span>Quotes</span>
                </a>
            </li>
            <li>
                <a href="#" class="customers">
                    <svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none"><style>.a{fill:currentColor;}</style><path d="M9.2 6.2C10.9 6.2 12.3 4.8 12.3 3.1 12.3 1.4 10.9 0 9.2 0 7.4 0 6.1 1.4 6.1 3.1 6.1 4.8 7.4 6.2 9.2 6.2Z" class="a"/><path d="M15.5 6.2C16.6 6.2 17.4 5.3 17.4 4.3 17.4 3.2 16.6 2.3 15.5 2.3 14.4 2.3 13.5 3.2 13.5 4.3 13.5 5.3 14.4 6.2 15.5 6.2Z" class="a"/><path d="M2.9 6.2C4 6.2 4.8 5.3 4.8 4.3 4.8 3.2 4 2.3 2.9 2.3 1.8 2.3 0.9 3.2 0.9 4.3 0.9 5.3 1.8 6.2 2.9 6.2Z" class="a"/><path d="M4.8 8C4 7.4 3.3 7.4 2.4 7.4 1.1 7.4 0 8.5 0 9.9V13.8C0 14.4 0.5 14.8 1.1 14.8 3.6 14.8 3.3 14.9 3.3 14.7 3.3 11.9 2.9 9.9 4.8 8Z" class="a"/><path d="M10 7.5C8.5 7.3 7.1 7.5 5.9 8.4 4 10 4.3 12.1 4.3 14.7 4.3 15.4 4.9 16 5.6 16 13.1 16 13.4 16.2 13.9 15.2 14 14.9 14 15 14 11.8 14 9.2 11.8 7.5 10 7.5Z" class="a"/><path d="M15.9 7.4C15 7.4 14.3 7.4 13.5 8 15.4 9.9 15.1 11.8 15.1 14.7 15.1 14.9 14.8 14.8 17.2 14.8 17.8 14.8 18.3 14.3 18.3 13.7V9.9C18.3 8.5 17.2 7.4 15.9 7.4Z" class="a"/></svg>
                    <span>Customers</span>
                </a>
            </li> -->
            <li>
                <a href="{{ route('admin.refunds.index') }}" class="refund">
                    <svg xmlns="http://www.w3.org/2000/svg" width="19" height="17" viewBox="0 0 19 17" fill="none"><style>.a{fill:#0A2568;}</style><path d="M16.1 12.2C15.5 12.2 15 11.9 14.7 11.4L14 10.3C13.3 11.8 12 12.8 10.4 13.2 10.4 13.2 10.4 13.2 10.4 13.2 9.7 13.3 9.1 13.3 8.4 13.2 6.7 12.8 5.3 11.6 4.7 10H5C5.4 10 5.7 9.5 5.4 9.1L3.2 5.8C3 5.5 2.5 5.5 2.3 5.8L0.1 9.1C-0.2 9.5 0.1 10 0.6 10H1.3C2 13.7 5.4 16.6 9.4 16.6 11.7 16.6 13.9 15.6 15.5 14 16 13.4 16.5 12.7 16.9 12 16.6 12.1 16.4 12.2 16.1 12.2Z" class="a"/><path d="M18.3 6.6H17.6C16.7 2.4 12.6-0.5 8.3 0.1 5.4 0.5 3.1 2.3 2 4.7 2.7 4.3 3.7 4.5 4.1 5.2L4.9 6.3C5.5 4.9 6.8 3.8 8.3 3.5 10.9 2.9 13.3 4.3 14.1 6.6H13.9C13.4 6.6 13.2 7.1 13.4 7.5L15.6 10.8C15.8 11.1 16.3 11.1 16.5 10.8L18.7 7.5C19 7.1 18.7 6.6 18.3 6.6Z" class="a"/></svg>
                    <span>Refunds</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.cancellation.index') }}" class="cancellation">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 0C3.2 0 0 3.1 0 7 0 10.8 3.2 14 7 14 10.9 14 14 10.8 14 7 14 3.1 10.9 0 7 0ZM10.5 9.3C10.8 9.6 10.8 10.1 10.5 10.4 10.2 10.7 9.6 10.7 9.3 10.4L7 8.1 4.7 10.4C4.4 10.7 3.8 10.7 3.5 10.4 3.2 10.1 3.2 9.6 3.5 9.3L5.8 7 3.5 4.7C3.2 4.4 3.2 3.8 3.5 3.5 3.8 3.2 4.4 3.2 4.7 3.5L7 5.8 9.3 3.5C9.6 3.2 10.2 3.2 10.5 3.5 10.8 3.8 10.8 4.4 10.5 4.7L8.2 7 10.5 9.3Z" fill="currentColor"/></svg>
                    <span>Cancellation</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.user.index') }}" class="users">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 9 13" fill="none"><style>.a{fill:currentColor;}</style><path d="M4.2 5.2C5.6 5.2 6.8 4 6.8 2.7 6.8 1.3 5.6 0.2 4.2 0.2 2.7 0.2 1.5 1.3 1.5 2.7 1.5 4 2.7 5.2 4.2 5.2Z" class="a"/><path d="M4.9 6.2C3.5 6 2.4 6.2 1.4 6.9 -0.3 8.2 0 9.9 0 12 0 12.5 0.5 13 1.1 13 7.6 13 7.8 13.2 8.2 12.4 8.3 12.1 8.3 12.2 8.3 9.6 8.3 7.6 6.4 6.2 4.9 6.2Z" class="a"/></svg>
                    <span>Users</span>
                </a>
            </li>
            <li>
                <a href="#" class="cms-page dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="17" viewBox="0 0 11 17" fill="none"><style>.a{fill:currentColor;}</style><path d="M6.5 3.7V0.9H2.5C1.1 0.9 0 2 0 3.4V13.6C0 15 1.1 16.1 2.5 16.1H8.5C9.9 16.1 11 15 11 13.6V5H7.7C7 5 6.5 4.4 6.5 3.7Z" class="a"/><path d="M7.3 1.8V3.3C7.3 3.8 7.7 4.2 8.2 4.2H10C10.5 4.2 10.9 3.8 10.9 3.4L7.9 0.9C7.6 1.1 7.3 1.4 7.3 1.8Z" class="a"/></svg>
                    <span>CMS Pages</span>
                </a>
                <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="{{ route('admin.pages.show', 1) }}">Home</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 2) }}">Category Detail</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 3) }}">All Categories</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 5) }}">Offers & Discounts</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 17) }}">Terms & Conditions</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 18) }}">Shipping & Delivery</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 19) }}">Warranty Policy</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 20) }}">Exchange & Return Policy</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 21) }}">Account Verification Process</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 22) }}">FAQ</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 6) }}">Corporate Home</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 9) }}">Corporate Projects</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 10) }}">Corporate About</a></li>
                    <li><a class="dropdown-item" href="/admin/21/media">Corporate Media</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 12) }}">Corporate Contact</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 13) }}">Corporate Career</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 14) }}">Corporate Jobs Openings</a></li>
                </ul>
            </li>
            <!-- <li>
                <a href="#" class="settings">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M13.7 5.8L12.1 5.4C12 5.1 11.8 4.8 11.7 4.6L12.5 3.2C12.6 3 12.6 2.8 12.5 2.7L11.3 1.5C11.2 1.4 11 1.4 10.8 1.5L9.4 2.3C9.2 2.2 8.9 2 8.6 1.9L8.2 0.3C8.1 0.1 8 0 7.8 0H6.2C6 0 5.8 0.1 5.8 0.3L5.4 1.9C5.1 2 4.8 2.2 4.5 2.3L3.1 1.5C3 1.4 2.8 1.4 2.6 1.5L1.5 2.7C1.3 2.8 1.3 3 1.4 3.2L2.2 4.6C2.1 4.8 2 5.1 1.9 5.4L0.3 5.8C0.1 5.9 0 6 0 6.2V7.8C0 8 0.1 8.2 0.3 8.2L1.9 8.6C2 8.9 2.1 9.2 2.2 9.5L1.4 10.9C1.3 11 1.3 11.2 1.5 11.4L2.6 12.5C2.8 12.7 3 12.7 3.1 12.6L4.5 11.8C4.8 11.9 5.1 12 5.4 12.1L5.8 13.7C5.8 13.9 6 14 6.2 14H7.8C8 14 8.1 13.9 8.2 13.7L8.6 12.1C8.9 12 9.2 11.9 9.4 11.8L10.8 12.6C11 12.7 11.2 12.7 11.3 12.5L12.5 11.4C12.6 11.2 12.6 11 12.5 10.9L11.7 9.5C11.8 9.2 12 8.9 12.1 8.6L13.7 8.2C13.9 8.2 14 8 14 7.8V6.2C14 6 13.9 5.9 13.7 5.8ZM7 9.1C5.8 9.1 4.9 8.2 4.9 7 4.9 5.9 5.8 5 7 5 8.1 5 9 5.9 9 7 9 8.2 8.1 9.1 7 9.1Z" fill="currentColor"/></svg>
                    <span>Settings</span>
                </a>
            </li> -->
            <li>
                <a href="{{ route('admin.sale.index') }}" class="settings">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M13.7 5.8L12.1 5.4C12 5.1 11.8 4.8 11.7 4.6L12.5 3.2C12.6 3 12.6 2.8 12.5 2.7L11.3 1.5C11.2 1.4 11 1.4 10.8 1.5L9.4 2.3C9.2 2.2 8.9 2 8.6 1.9L8.2 0.3C8.1 0.1 8 0 7.8 0H6.2C6 0 5.8 0.1 5.8 0.3L5.4 1.9C5.1 2 4.8 2.2 4.5 2.3L3.1 1.5C3 1.4 2.8 1.4 2.6 1.5L1.5 2.7C1.3 2.8 1.3 3 1.4 3.2L2.2 4.6C2.1 4.8 2 5.1 1.9 5.4L0.3 5.8C0.1 5.9 0 6 0 6.2V7.8C0 8 0.1 8.2 0.3 8.2L1.9 8.6C2 8.9 2.1 9.2 2.2 9.5L1.4 10.9C1.3 11 1.3 11.2 1.5 11.4L2.6 12.5C2.8 12.7 3 12.7 3.1 12.6L4.5 11.8C4.8 11.9 5.1 12 5.4 12.1L5.8 13.7C5.8 13.9 6 14 6.2 14H7.8C8 14 8.1 13.9 8.2 13.7L8.6 12.1C8.9 12 9.2 11.9 9.4 11.8L10.8 12.6C11 12.7 11.2 12.7 11.3 12.5L12.5 11.4C12.6 11.2 12.6 11 12.5 10.9L11.7 9.5C11.8 9.2 12 8.9 12.1 8.6L13.7 8.2C13.9 8.2 14 8 14 7.8V6.2C14 6 13.9 5.9 13.7 5.8ZM7 9.1C5.8 9.1 4.9 8.2 4.9 7 4.9 5.9 5.8 5 7 5 8.1 5 9 5.9 9 7 9 8.2 8.1 9.1 7 9.1Z" fill="currentColor"/></svg>
                    <span>Sales & Offers</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.brand.index') }}" class="settings">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M13.7 5.8L12.1 5.4C12 5.1 11.8 4.8 11.7 4.6L12.5 3.2C12.6 3 12.6 2.8 12.5 2.7L11.3 1.5C11.2 1.4 11 1.4 10.8 1.5L9.4 2.3C9.2 2.2 8.9 2 8.6 1.9L8.2 0.3C8.1 0.1 8 0 7.8 0H6.2C6 0 5.8 0.1 5.8 0.3L5.4 1.9C5.1 2 4.8 2.2 4.5 2.3L3.1 1.5C3 1.4 2.8 1.4 2.6 1.5L1.5 2.7C1.3 2.8 1.3 3 1.4 3.2L2.2 4.6C2.1 4.8 2 5.1 1.9 5.4L0.3 5.8C0.1 5.9 0 6 0 6.2V7.8C0 8 0.1 8.2 0.3 8.2L1.9 8.6C2 8.9 2.1 9.2 2.2 9.5L1.4 10.9C1.3 11 1.3 11.2 1.5 11.4L2.6 12.5C2.8 12.7 3 12.7 3.1 12.6L4.5 11.8C4.8 11.9 5.1 12 5.4 12.1L5.8 13.7C5.8 13.9 6 14 6.2 14H7.8C8 14 8.1 13.9 8.2 13.7L8.6 12.1C8.9 12 9.2 11.9 9.4 11.8L10.8 12.6C11 12.7 11.2 12.7 11.3 12.5L12.5 11.4C12.6 11.2 12.6 11 12.5 10.9L11.7 9.5C11.8 9.2 12 8.9 12.1 8.6L13.7 8.2C13.9 8.2 14 8 14 7.8V6.2C14 6 13.9 5.9 13.7 5.8ZM7 9.1C5.8 9.1 4.9 8.2 4.9 7 4.9 5.9 5.8 5 7 5 8.1 5 9 5.9 9 7 9 8.2 8.1 9.1 7 9.1Z" fill="currentColor"/></svg>
                    <span>Brands</span>
                </a>
            </li>
            <!-- <li>
                <a href="{{ route('admin.featured-products.index') }}" class="settings">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M13.7 5.8L12.1 5.4C12 5.1 11.8 4.8 11.7 4.6L12.5 3.2C12.6 3 12.6 2.8 12.5 2.7L11.3 1.5C11.2 1.4 11 1.4 10.8 1.5L9.4 2.3C9.2 2.2 8.9 2 8.6 1.9L8.2 0.3C8.1 0.1 8 0 7.8 0H6.2C6 0 5.8 0.1 5.8 0.3L5.4 1.9C5.1 2 4.8 2.2 4.5 2.3L3.1 1.5C3 1.4 2.8 1.4 2.6 1.5L1.5 2.7C1.3 2.8 1.3 3 1.4 3.2L2.2 4.6C2.1 4.8 2 5.1 1.9 5.4L0.3 5.8C0.1 5.9 0 6 0 6.2V7.8C0 8 0.1 8.2 0.3 8.2L1.9 8.6C2 8.9 2.1 9.2 2.2 9.5L1.4 10.9C1.3 11 1.3 11.2 1.5 11.4L2.6 12.5C2.8 12.7 3 12.7 3.1 12.6L4.5 11.8C4.8 11.9 5.1 12 5.4 12.1L5.8 13.7C5.8 13.9 6 14 6.2 14H7.8C8 14 8.1 13.9 8.2 13.7L8.6 12.1C8.9 12 9.2 11.9 9.4 11.8L10.8 12.6C11 12.7 11.2 12.7 11.3 12.5L12.5 11.4C12.6 11.2 12.6 11 12.5 10.9L11.7 9.5C11.8 9.2 12 8.9 12.1 8.6L13.7 8.2C13.9 8.2 14 8 14 7.8V6.2C14 6 13.9 5.9 13.7 5.8ZM7 9.1C5.8 9.1 4.9 8.2 4.9 7 4.9 5.9 5.8 5 7 5 8.1 5 9 5.9 9 7 9 8.2 8.1 9.1 7 9.1Z" fill="currentColor"/></svg>
                    <span>Featured Products</span>
                </a>
            </li> -->
        </ul>
    </nav>
</aside>

<aside class="left-sidebar for-desktop">
    <nav class="menu-sidebar-wrapper">
        <ul class="v-list">
            <li>
                <a href="{{ route('dashboard') }}" class="dashboard">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M17.5 7.8C17.5 7.8 17.5 7.8 17.5 7.8L10.2 0.5C9.9 0.2 9.4 0 9 0 8.6 0 8.1 0.2 7.8 0.5L0.5 7.8C0.5 7.8 0.5 7.8 0.5 7.8 -0.2 8.5-0.2 9.5 0.5 10.2 0.8 10.5 1.2 10.6 1.6 10.7 1.6 10.7 1.6 10.7 1.6 10.7H1.9V16.1C1.9 17.1 2.8 18 3.9 18H6.7C7 18 7.3 17.8 7.3 17.5V13.2C7.3 12.7 7.7 12.4 8.2 12.4H9.8C10.3 12.4 10.7 12.7 10.7 13.2V17.5C10.7 17.8 11 18 11.3 18H14.1C15.2 18 16.1 17.1 16.1 16.1V10.7H16.3C16.8 10.7 17.2 10.5 17.5 10.2 18.2 9.5 18.2 8.5 17.5 7.8V7.8Z" fill="currentColor"/></svg>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a href="#" class="product dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><style>.a{fill:currentColor;}</style><path d="M5.4 0H1C0.5 0 0 0.5 0 1V3.6C0 4.2 0.5 4.7 1 4.7H5.4C6 4.7 6.4 4.2 6.4 3.6V1C6.4 0.5 6 0 5.4 0Z" class="a"/><path d="M5.4 5.8H1C0.5 5.8 0 6.3 0 6.9V13C0 13.5 0.5 14 1 14H5.4C6 14 6.4 13.5 6.4 13V6.9C6.4 6.3 6 5.8 5.4 5.8Z" class="a"/><path d="M13 9.3H8.6C8 9.3 7.6 9.8 7.6 10.4V13C7.6 13.5 8 14 8.6 14H13C13.5 14 14 13.5 14 13V10.4C14 9.8 13.5 9.3 13 9.3Z" class="a"/><path d="M13 0H8.6C8 0 7.6 0.5 7.6 1V7.1C7.6 7.7 8 8.2 8.6 8.2H13C13.5 8.2 14 7.7 14 7.1V1C14 0.5 13.5 0 13 0V0Z" class="a"/></svg>
                    <span>Products</span>
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="{{ route('admin.products.index') }}">All Products</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.category.index') }}">Categories</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.attribute-set.index') }}">Attributes</a></li>
                </ul>
            </li>
            <li>
                <a href="{{ route('admin.orders.index') }}" class="orders">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none"><style>.a{fill:currentColor;}</style><path d="M13.3 14.5L12.6 5C12.5 4.4 12 3.9 11.4 3.9H9.9V6.1C9.9 6.4 9.7 6.6 9.4 6.6 9.1 6.6 8.9 6.4 8.9 6.1V3.9H4.4V6.1C4.4 6.4 4.2 6.6 3.9 6.6 3.6 6.6 3.4 6.4 3.4 6.1V3.9H1.9C1.3 3.9 0.8 4.4 0.8 5L0 14.5C-0.1 15.2 0.2 16 0.7 16.5 1.2 17.1 2 17.4 2.7 17.4H10.6C11.3 17.4 12.1 17.1 12.6 16.5 13.1 16 13.4 15.2 13.3 14.5ZM8.9 9.6L6.3 12.2C6.2 12.3 6.1 12.3 6 12.3 5.9 12.3 5.7 12.3 5.6 12.2L4.4 11C4.2 10.8 4.2 10.5 4.4 10.3 4.6 10.1 4.9 10.1 5.1 10.3L6 11.1 8.2 8.9C8.4 8.8 8.7 8.8 8.9 8.9 9.1 9.1 9.1 9.4 8.9 9.6Z" class="a"/><path d="M6.7 0.6C4.9 0.6 3.4 2.1 3.4 3.9V3.9H4.4V3.9C4.4 2.6 5.4 1.6 6.7 1.6 7.9 1.6 8.9 2.6 8.9 3.9V3.9H9.9V3.9C9.9 2.1 8.4 0.6 6.7 0.6Z" class="a"/></svg>
                    <span>Orders</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.newsletter.index') }}" class="orders">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="18" viewBox="0 0 14 18" fill="none"><style>.a{fill:currentColor;}</style><path d="M13.3 14.5L12.6 5C12.5 4.4 12 3.9 11.4 3.9H9.9V6.1C9.9 6.4 9.7 6.6 9.4 6.6 9.1 6.6 8.9 6.4 8.9 6.1V3.9H4.4V6.1C4.4 6.4 4.2 6.6 3.9 6.6 3.6 6.6 3.4 6.4 3.4 6.1V3.9H1.9C1.3 3.9 0.8 4.4 0.8 5L0 14.5C-0.1 15.2 0.2 16 0.7 16.5 1.2 17.1 2 17.4 2.7 17.4H10.6C11.3 17.4 12.1 17.1 12.6 16.5 13.1 16 13.4 15.2 13.3 14.5ZM8.9 9.6L6.3 12.2C6.2 12.3 6.1 12.3 6 12.3 5.9 12.3 5.7 12.3 5.6 12.2L4.4 11C4.2 10.8 4.2 10.5 4.4 10.3 4.6 10.1 4.9 10.1 5.1 10.3L6 11.1 8.2 8.9C8.4 8.8 8.7 8.8 8.9 8.9 9.1 9.1 9.1 9.4 8.9 9.6Z" class="a"/><path d="M6.7 0.6C4.9 0.6 3.4 2.1 3.4 3.9V3.9H4.4V3.9C4.4 2.6 5.4 1.6 6.7 1.6 7.9 1.6 8.9 2.6 8.9 3.9V3.9H9.9V3.9C9.9 2.1 8.4 0.6 6.7 0.6Z" class="a"/></svg>
                    <span>Newsletter</span>
                </a>
            </li>

            <li>
                <a href="{{ route('admin.jobapplication.index') }}" class="jobapplication">
                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="17" viewBox="0 0 11 17" fill="none"><style>.a{fill:currentColor;}</style><path d="M6.5 3.7V0.9H2.5C1.1 0.9 0 2 0 3.4V13.6C0 15 1.1 16.1 2.5 16.1H8.5C9.9 16.1 11 15 11 13.6V5H7.7C7 5 6.5 4.4 6.5 3.7Z" class="a"/><path d="M7.3 1.8V3.3C7.3 3.8 7.7 4.2 8.2 4.2H10C10.5 4.2 10.9 3.8 10.9 3.4L7.9 0.9C7.6 1.1 7.3 1.4 7.3 1.8Z" class="a"/></svg>
                    <span>JobApplication</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.contact.index') }}" class="contact">
                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="17" viewBox="0 0 11 17" fill="none"><style>.a{fill:currentColor;}</style><path d="M6.5 3.7V0.9H2.5C1.1 0.9 0 2 0 3.4V13.6C0 15 1.1 16.1 2.5 16.1H8.5C9.9 16.1 11 15 11 13.6V5H7.7C7 5 6.5 4.4 6.5 3.7Z" class="a"/><path d="M7.3 1.8V3.3C7.3 3.8 7.7 4.2 8.2 4.2H10C10.5 4.2 10.9 3.8 10.9 3.4L7.9 0.9C7.6 1.1 7.3 1.4 7.3 1.8Z" class="a"/></svg>
                    <span>Contacts</span>
                </a>
            </li>
            <!-- <li>
                <a href="#" class="qoutes">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="16" viewBox="0 0 12 16" fill="none"><path d="M11.5 0H0.5C0.2 0 0 0.2 0 0.5V14.2C0 14.3 0 14.4 0.1 14.5L1.5 15.9C1.7 16 2 16 2.2 15.9L3.2 14.8 4.3 15.9C4.4 16 4.5 16 4.6 16 4.7 16 4.9 16 4.9 15.9L6 14.8 7 15.9C7.1 16 7.2 16 7.4 16 7.5 16 7.6 16 7.7 15.9L8.8 14.8 9.8 15.9C9.9 16 10 16 10.1 16 10.3 16 10.4 16 10.5 15.9L11.8 14.5C11.9 14.4 12 14.3 12 14.2V0.5C12 0.2 11.8 0 11.5 0ZM5.5 3.5V3C5.5 2.7 5.7 2.5 6 2.5 6.3 2.5 6.5 2.7 6.5 3V3.5H7C7.3 3.5 7.5 3.7 7.5 4 7.5 4.2 7.3 4.5 7 4.5H5.7C5.4 4.5 5.1 4.7 5.1 5 5.1 5.3 5.4 5.5 5.7 5.5H6.3C7.1 5.5 7.8 6.2 7.8 7 7.8 7.8 7.2 8.4 6.5 8.5V9C6.5 9.3 6.3 9.5 6 9.5 5.7 9.5 5.5 9.3 5.5 9V8.5H5C4.7 8.5 4.5 8.3 4.5 8 4.5 7.7 4.7 7.5 5 7.5H6.3C6.6 7.5 6.9 7.3 6.9 7 6.9 6.7 6.6 6.5 6.3 6.5H5.7C4.8 6.5 4.2 5.8 4.2 5 4.2 4.2 4.8 3.6 5.5 3.5ZM8.5 12H3.5C3.2 12 3 11.8 3 11.5 3 11.3 3.2 11 3.5 11H8.5C8.8 11 9 11.3 9 11.5 9 11.8 8.8 12 8.5 12Z" fill="currentColor"/></svg>
                    <span>Quotes</span>
                </a>
            </li>
            <li>
                <a href="#" class="customers">
                    <svg xmlns="http://www.w3.org/2000/svg" width="19" height="16" viewBox="0 0 19 16" fill="none"><style>.a{fill:currentColor;}</style><path d="M9.2 6.2C10.9 6.2 12.3 4.8 12.3 3.1 12.3 1.4 10.9 0 9.2 0 7.4 0 6.1 1.4 6.1 3.1 6.1 4.8 7.4 6.2 9.2 6.2Z" class="a"/><path d="M15.5 6.2C16.6 6.2 17.4 5.3 17.4 4.3 17.4 3.2 16.6 2.3 15.5 2.3 14.4 2.3 13.5 3.2 13.5 4.3 13.5 5.3 14.4 6.2 15.5 6.2Z" class="a"/><path d="M2.9 6.2C4 6.2 4.8 5.3 4.8 4.3 4.8 3.2 4 2.3 2.9 2.3 1.8 2.3 0.9 3.2 0.9 4.3 0.9 5.3 1.8 6.2 2.9 6.2Z" class="a"/><path d="M4.8 8C4 7.4 3.3 7.4 2.4 7.4 1.1 7.4 0 8.5 0 9.9V13.8C0 14.4 0.5 14.8 1.1 14.8 3.6 14.8 3.3 14.9 3.3 14.7 3.3 11.9 2.9 9.9 4.8 8Z" class="a"/><path d="M10 7.5C8.5 7.3 7.1 7.5 5.9 8.4 4 10 4.3 12.1 4.3 14.7 4.3 15.4 4.9 16 5.6 16 13.1 16 13.4 16.2 13.9 15.2 14 14.9 14 15 14 11.8 14 9.2 11.8 7.5 10 7.5Z" class="a"/><path d="M15.9 7.4C15 7.4 14.3 7.4 13.5 8 15.4 9.9 15.1 11.8 15.1 14.7 15.1 14.9 14.8 14.8 17.2 14.8 17.8 14.8 18.3 14.3 18.3 13.7V9.9C18.3 8.5 17.2 7.4 15.9 7.4Z" class="a"/></svg>
                    <span>Customers</span>
                </a>
            </li> -->
            <li>
                <a href="{{ route('admin.refunds.index') }}" class="refund">
                    <svg xmlns="http://www.w3.org/2000/svg" width="19" height="17" viewBox="0 0 19 17" fill="none"><style>.a{fill:#0A2568;}</style><path d="M16.1 12.2C15.5 12.2 15 11.9 14.7 11.4L14 10.3C13.3 11.8 12 12.8 10.4 13.2 10.4 13.2 10.4 13.2 10.4 13.2 9.7 13.3 9.1 13.3 8.4 13.2 6.7 12.8 5.3 11.6 4.7 10H5C5.4 10 5.7 9.5 5.4 9.1L3.2 5.8C3 5.5 2.5 5.5 2.3 5.8L0.1 9.1C-0.2 9.5 0.1 10 0.6 10H1.3C2 13.7 5.4 16.6 9.4 16.6 11.7 16.6 13.9 15.6 15.5 14 16 13.4 16.5 12.7 16.9 12 16.6 12.1 16.4 12.2 16.1 12.2Z" class="a"/><path d="M18.3 6.6H17.6C16.7 2.4 12.6-0.5 8.3 0.1 5.4 0.5 3.1 2.3 2 4.7 2.7 4.3 3.7 4.5 4.1 5.2L4.9 6.3C5.5 4.9 6.8 3.8 8.3 3.5 10.9 2.9 13.3 4.3 14.1 6.6H13.9C13.4 6.6 13.2 7.1 13.4 7.5L15.6 10.8C15.8 11.1 16.3 11.1 16.5 10.8L18.7 7.5C19 7.1 18.7 6.6 18.3 6.6Z" class="a"/></svg>
                    <span>Refunds</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.cancellation.index') }}" class="cancellation">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 0C3.2 0 0 3.1 0 7 0 10.8 3.2 14 7 14 10.9 14 14 10.8 14 7 14 3.1 10.9 0 7 0ZM10.5 9.3C10.8 9.6 10.8 10.1 10.5 10.4 10.2 10.7 9.6 10.7 9.3 10.4L7 8.1 4.7 10.4C4.4 10.7 3.8 10.7 3.5 10.4 3.2 10.1 3.2 9.6 3.5 9.3L5.8 7 3.5 4.7C3.2 4.4 3.2 3.8 3.5 3.5 3.8 3.2 4.4 3.2 4.7 3.5L7 5.8 9.3 3.5C9.6 3.2 10.2 3.2 10.5 3.5 10.8 3.8 10.8 4.4 10.5 4.7L8.2 7 10.5 9.3Z" fill="currentColor"/></svg>
                    <span>Cancellation</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.user.index') }}" class="users">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 9 13" fill="none"><style>.a{fill:currentColor;}</style><path d="M4.2 5.2C5.6 5.2 6.8 4 6.8 2.7 6.8 1.3 5.6 0.2 4.2 0.2 2.7 0.2 1.5 1.3 1.5 2.7 1.5 4 2.7 5.2 4.2 5.2Z" class="a"/><path d="M4.9 6.2C3.5 6 2.4 6.2 1.4 6.9 -0.3 8.2 0 9.9 0 12 0 12.5 0.5 13 1.1 13 7.6 13 7.8 13.2 8.2 12.4 8.3 12.1 8.3 12.2 8.3 9.6 8.3 7.6 6.4 6.2 4.9 6.2Z" class="a"/></svg>
                    <span>Users</span>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a href="#" class="cms-page dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <svg xmlns="http://www.w3.org/2000/svg" width="11" height="17" viewBox="0 0 11 17" fill="none"><style>.a{fill:currentColor;}</style><path d="M6.5 3.7V0.9H2.5C1.1 0.9 0 2 0 3.4V13.6C0 15 1.1 16.1 2.5 16.1H8.5C9.9 16.1 11 15 11 13.6V5H7.7C7 5 6.5 4.4 6.5 3.7Z" class="a"/><path d="M7.3 1.8V3.3C7.3 3.8 7.7 4.2 8.2 4.2H10C10.5 4.2 10.9 3.8 10.9 3.4L7.9 0.9C7.6 1.1 7.3 1.4 7.3 1.8Z" class="a"/></svg>
                    <span>CMS Pages</span>
                </a>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 1) }}">Home</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 2) }}">Category Detail</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 3) }}">All Categories</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 5) }}">Offers & Discounts</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 17) }}">Terms & Conditions</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 18) }}">Shipping & Delivery</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 19) }}">Warranty Policy</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 20) }}">Exchange & Return Policy</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 21) }}">Account Verification Process</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 22) }}">FAQ</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 6) }}">Corporate Home</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 9) }}">Corporate Projects</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 10) }}">Corporate About</a></li>
                    <li><a class="dropdown-item" href="/admin/21/media">Corporate Media</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 12) }}">Corporate Contact</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 13) }}">Corporate Career</a></li>
                    <li><a class="dropdown-item" href="{{ route('admin.pages.show', 14) }}">Corporate Jobs Openings</a></li>
                </ul>
            </li>
            <!-- <li>
                <a href="#" class="settings">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M13.7 5.8L12.1 5.4C12 5.1 11.8 4.8 11.7 4.6L12.5 3.2C12.6 3 12.6 2.8 12.5 2.7L11.3 1.5C11.2 1.4 11 1.4 10.8 1.5L9.4 2.3C9.2 2.2 8.9 2 8.6 1.9L8.2 0.3C8.1 0.1 8 0 7.8 0H6.2C6 0 5.8 0.1 5.8 0.3L5.4 1.9C5.1 2 4.8 2.2 4.5 2.3L3.1 1.5C3 1.4 2.8 1.4 2.6 1.5L1.5 2.7C1.3 2.8 1.3 3 1.4 3.2L2.2 4.6C2.1 4.8 2 5.1 1.9 5.4L0.3 5.8C0.1 5.9 0 6 0 6.2V7.8C0 8 0.1 8.2 0.3 8.2L1.9 8.6C2 8.9 2.1 9.2 2.2 9.5L1.4 10.9C1.3 11 1.3 11.2 1.5 11.4L2.6 12.5C2.8 12.7 3 12.7 3.1 12.6L4.5 11.8C4.8 11.9 5.1 12 5.4 12.1L5.8 13.7C5.8 13.9 6 14 6.2 14H7.8C8 14 8.1 13.9 8.2 13.7L8.6 12.1C8.9 12 9.2 11.9 9.4 11.8L10.8 12.6C11 12.7 11.2 12.7 11.3 12.5L12.5 11.4C12.6 11.2 12.6 11 12.5 10.9L11.7 9.5C11.8 9.2 12 8.9 12.1 8.6L13.7 8.2C13.9 8.2 14 8 14 7.8V6.2C14 6 13.9 5.9 13.7 5.8ZM7 9.1C5.8 9.1 4.9 8.2 4.9 7 4.9 5.9 5.8 5 7 5 8.1 5 9 5.9 9 7 9 8.2 8.1 9.1 7 9.1Z" fill="currentColor"/></svg>
                    <span>Settings</span>
                </a>
            </li> -->
            <li>
                <a href="{{ route('admin.sale.index') }}" class="settings">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M13.7 5.8L12.1 5.4C12 5.1 11.8 4.8 11.7 4.6L12.5 3.2C12.6 3 12.6 2.8 12.5 2.7L11.3 1.5C11.2 1.4 11 1.4 10.8 1.5L9.4 2.3C9.2 2.2 8.9 2 8.6 1.9L8.2 0.3C8.1 0.1 8 0 7.8 0H6.2C6 0 5.8 0.1 5.8 0.3L5.4 1.9C5.1 2 4.8 2.2 4.5 2.3L3.1 1.5C3 1.4 2.8 1.4 2.6 1.5L1.5 2.7C1.3 2.8 1.3 3 1.4 3.2L2.2 4.6C2.1 4.8 2 5.1 1.9 5.4L0.3 5.8C0.1 5.9 0 6 0 6.2V7.8C0 8 0.1 8.2 0.3 8.2L1.9 8.6C2 8.9 2.1 9.2 2.2 9.5L1.4 10.9C1.3 11 1.3 11.2 1.5 11.4L2.6 12.5C2.8 12.7 3 12.7 3.1 12.6L4.5 11.8C4.8 11.9 5.1 12 5.4 12.1L5.8 13.7C5.8 13.9 6 14 6.2 14H7.8C8 14 8.1 13.9 8.2 13.7L8.6 12.1C8.9 12 9.2 11.9 9.4 11.8L10.8 12.6C11 12.7 11.2 12.7 11.3 12.5L12.5 11.4C12.6 11.2 12.6 11 12.5 10.9L11.7 9.5C11.8 9.2 12 8.9 12.1 8.6L13.7 8.2C13.9 8.2 14 8 14 7.8V6.2C14 6 13.9 5.9 13.7 5.8ZM7 9.1C5.8 9.1 4.9 8.2 4.9 7 4.9 5.9 5.8 5 7 5 8.1 5 9 5.9 9 7 9 8.2 8.1 9.1 7 9.1Z" fill="currentColor"/></svg>
                    <span>Sales & Offers</span>
                </a>
            </li>
            <li>
                <a href="{{ route('admin.brand.index') }}" class="settings">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M13.7 5.8L12.1 5.4C12 5.1 11.8 4.8 11.7 4.6L12.5 3.2C12.6 3 12.6 2.8 12.5 2.7L11.3 1.5C11.2 1.4 11 1.4 10.8 1.5L9.4 2.3C9.2 2.2 8.9 2 8.6 1.9L8.2 0.3C8.1 0.1 8 0 7.8 0H6.2C6 0 5.8 0.1 5.8 0.3L5.4 1.9C5.1 2 4.8 2.2 4.5 2.3L3.1 1.5C3 1.4 2.8 1.4 2.6 1.5L1.5 2.7C1.3 2.8 1.3 3 1.4 3.2L2.2 4.6C2.1 4.8 2 5.1 1.9 5.4L0.3 5.8C0.1 5.9 0 6 0 6.2V7.8C0 8 0.1 8.2 0.3 8.2L1.9 8.6C2 8.9 2.1 9.2 2.2 9.5L1.4 10.9C1.3 11 1.3 11.2 1.5 11.4L2.6 12.5C2.8 12.7 3 12.7 3.1 12.6L4.5 11.8C4.8 11.9 5.1 12 5.4 12.1L5.8 13.7C5.8 13.9 6 14 6.2 14H7.8C8 14 8.1 13.9 8.2 13.7L8.6 12.1C8.9 12 9.2 11.9 9.4 11.8L10.8 12.6C11 12.7 11.2 12.7 11.3 12.5L12.5 11.4C12.6 11.2 12.6 11 12.5 10.9L11.7 9.5C11.8 9.2 12 8.9 12.1 8.6L13.7 8.2C13.9 8.2 14 8 14 7.8V6.2C14 6 13.9 5.9 13.7 5.8ZM7 9.1C5.8 9.1 4.9 8.2 4.9 7 4.9 5.9 5.8 5 7 5 8.1 5 9 5.9 9 7 9 8.2 8.1 9.1 7 9.1Z" fill="currentColor"/></svg>
                    <span>Brands</span>
                </a>
            </li>
            <!-- <li>
                <a href="{{ route('admin.featured-products.index') }}" class="settings">
                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M13.7 5.8L12.1 5.4C12 5.1 11.8 4.8 11.7 4.6L12.5 3.2C12.6 3 12.6 2.8 12.5 2.7L11.3 1.5C11.2 1.4 11 1.4 10.8 1.5L9.4 2.3C9.2 2.2 8.9 2 8.6 1.9L8.2 0.3C8.1 0.1 8 0 7.8 0H6.2C6 0 5.8 0.1 5.8 0.3L5.4 1.9C5.1 2 4.8 2.2 4.5 2.3L3.1 1.5C3 1.4 2.8 1.4 2.6 1.5L1.5 2.7C1.3 2.8 1.3 3 1.4 3.2L2.2 4.6C2.1 4.8 2 5.1 1.9 5.4L0.3 5.8C0.1 5.9 0 6 0 6.2V7.8C0 8 0.1 8.2 0.3 8.2L1.9 8.6C2 8.9 2.1 9.2 2.2 9.5L1.4 10.9C1.3 11 1.3 11.2 1.5 11.4L2.6 12.5C2.8 12.7 3 12.7 3.1 12.6L4.5 11.8C4.8 11.9 5.1 12 5.4 12.1L5.8 13.7C5.8 13.9 6 14 6.2 14H7.8C8 14 8.1 13.9 8.2 13.7L8.6 12.1C8.9 12 9.2 11.9 9.4 11.8L10.8 12.6C11 12.7 11.2 12.7 11.3 12.5L12.5 11.4C12.6 11.2 12.6 11 12.5 10.9L11.7 9.5C11.8 9.2 12 8.9 12.1 8.6L13.7 8.2C13.9 8.2 14 8 14 7.8V6.2C14 6 13.9 5.9 13.7 5.8ZM7 9.1C5.8 9.1 4.9 8.2 4.9 7 4.9 5.9 5.8 5 7 5 8.1 5 9 5.9 9 7 9 8.2 8.1 9.1 7 9.1Z" fill="currentColor"/></svg>
                    <span>Featured Products</span>
                </a>
            </li> -->
        </ul>
    </nav>
</aside>