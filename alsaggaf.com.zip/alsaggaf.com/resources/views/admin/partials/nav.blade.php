<!-- Header -->
<header class="main-header">
    <div class="menu-overlay"></div>
    <div class="container-fluid">
        <div class="header-top">
            <div class="header-logo">
                <a href="{{ route('dashboard') }}">
                    <img src="{{ asset('images/logo.svg') }}" alt="AL SAGGAF CO"/>
                </a>
            </div>
            <div class="header-menu">
                <ul class="h-list">
                    <li><span>E-Sales Admin</span></li>
                    <li>
                        <div class="dropdown show">
                            <a class="btn btn-default dropdown-toggle " href="#" id="dropdownMenuLink" data-toggle="dropdown">
                                
                                <span class="mr-5">{{Auth::user()->name }}</span>
                                
                            </a>
                            <ul class="dropdown-menu v-list dropdown-menu-right">
                                <li><a class="dropdown-item" href="{{ route('admin.user.show', Auth::user()->id) }}"><i class="fa fa-user"></i><span class="ml-10">Account</span></a></li>
                                <li><a class="dropdown-item" href="{{ route('admin.user.edit', Auth::user()->id) }}"><i class="fa fa-cog"></i><span class="ml-10">Settings</span></a></li>
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <li>
                                        <a class="dropdown-item" role="button"  onclick="event.preventDefault();this.closest('form').submit();">
                                            <i class="fas fa-sign-out-alt"></i>
                                            <span class="ml-10">Sign Out</span>
                                        </a>
                                    </li>
                                </form>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="nav-icon">
                <span class="menu-btn"><i class="fa fa-bars"></i></span>
            </div>
        </div>
    </div>
</header>