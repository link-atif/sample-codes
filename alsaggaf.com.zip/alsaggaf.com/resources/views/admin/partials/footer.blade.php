<footer class="main-footer">
    <strong>Copyright &copy; 2021 <a href="{{ url('/') }}">Alsaggaf CO</a>.</strong> All rights reserved.
</footer>