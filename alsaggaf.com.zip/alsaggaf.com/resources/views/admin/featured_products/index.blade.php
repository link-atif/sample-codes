<x-master-layout>
    <div class="main-wrapper">
        <div class="dashboard-wrapper">
            <div class="title-head">
                <h2>Featured Products</h2>
            </div>
            <div class="filter-wrapper">
                <div class="search-holder">
                    
                </div>
                <div class="filter-section">
                    {{ $products->links('vendor.pagination.custom-pagination') }}
                </div>
            </div>
            <div class="all-product-table">
                <div class="table-wrapper mb-30">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col" style="width: 6%;"></th>
                                    <th scope="col" style="width: 8%;">Id</th>
                                    <th scope="col" style="width: 30%;">Title</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Qty</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Product Type</th>
                                    <th scope="col">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($products as $product)
                                    <tr>
                                        <td>
                                            <div class="custom-control custom-checkbox">
                                                {!! Form::open(['method' => 'post', 'route' => ['admin.featured-product.store', $product->id], 'class' => 'form-horizontal']) !!}
                                                    <input type="checkbox" value="{{ $product->featured_product }}" {{ $product->featured_product ? "checked='checked'" : ''}}  class="custom-control-input" id="customCheck-{{ $product->id }}" onchange="this.form.submit();"/>
                                                    <label class="custom-control-label" for="customCheck-{{ $product->id }}">
                                                        <span><img src="{{ asset('images') }}/catalog/products/{{ $product->product_image }}" alt="{{ $product->title }}" /></span>
                                                    </label>
                                                {!! Form::close() !!}
                                            </div>
                                        </td>
                                        <td>{{ $product->sku }}</td>
                                        <td>{{ \Illuminate\Support\Str::limit($product->title, 50, $end='...') }}</td>
                                        <td>
                                            @if($product->category_id)
                                                {{ $product->category->name }}
                                            @endif
                                        </td>
                                        <td>{{ $product->qty }}</td>
                                        <td>{{ $product->price }}</td>
                                        <td>{{ $product->product_type }}</td>
                                        <td>{!! $product->status !!}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-master-layout>