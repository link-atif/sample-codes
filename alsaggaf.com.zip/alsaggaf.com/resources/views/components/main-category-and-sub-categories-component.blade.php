@foreach($content as $category)
    <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="category-list-item">
            <div class="content-holder">
                <a href="{{ route('category-detail-page', $category->id) }}">
                    <div class="image-item" style="background-image: url(/images/catalog/category/{{ $category->cover_image }});"></div>
                    <div class="category-caption">
                        <p>{{ $category->name }}</p>
                    </div>
                </a>
            </div>
            <nav class="category-content">
                <ul class="v-list">
                    @foreach($category->sub_categories as $sub_category)
                        @if($sub_category->name)
                            <li><a href="{{ route('category-detail-page', $sub_category->id) }}">{{ $sub_category->name }}</a></li>
                        @endif
                    @endforeach
                </ul>
            </nav>
        </div>
    </div>
@endforeach