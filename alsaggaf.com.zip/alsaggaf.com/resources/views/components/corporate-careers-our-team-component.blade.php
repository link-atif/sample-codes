<div class="our-team-section grey-bg">
    <div class="container">
        <div class="team-slider-wrapper">
            <div class="title-head pb-30 pt-0">
                <h5 class="mb-0">{{ $content($id)->headline_1 }}</h5>
            </div>
            <div class="prev-arrow"><i class="fa fa-arrow-left" aria-hidden="true"></i></div>
            <div class="row slick-instance">
                @foreach($content($id)->teams as $team)
                    <div class="col-3">
                        <div class="card-team-item">
                            <div class="image-holder">
                                <img src="{{ asset('images/team') }}/{{ $team->image }}" alt="{{ $team->name }}" class="img-fluid" />
                            </div>
                            <div class="content-holder">
                                <div class="member-name">
                                    {{ $team->designation }}
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="slide-count-wrap">
                {{--
                <div class="prev-arrow-dots"><i class="fa fa-angle-left"></i></div>
                <span class="current"></span> / <span class="total"></span>
                <div class="next-arrow-dots"><i class="fa fa-angle-right"></i></div>
                --}}
            </div>

            <div class="next-arrow"><i class="fa fa-arrow-right" aria-hidden="true"></i></div>
        </div>
    </div>
</div>