<div class="newsletter-wrapper">
    <div class="container">
        <div class="newsletter-form">
            <p>Register to our newsletter</p>
            <form>
                <div class="input-group">
                    <input type="text" class="form-control" id="email" placeholder="Email Address"/>
                    <button id="send" type="button" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
        <div id="message"></div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function() {
    $(document).on('click','#send', function(){
      $("#message").empty();
      var email = $("#email").val();
      if(email == ""){
        $("#message").append('<div class="col-sm-12 alert alert-danger white-text">Please enter a valid Email!</div>');
        return false;
      }
      $.ajax({
          type: 'POST',
          dataType: 'json',
          url: '{{ route("newsletter") }}',
          data: {"_token": "{{ csrf_token() }}",'email' : email },
          success: function(result) {
            console.log(result);
              if(result.status == true){
                    $("#message").append('<div class="col-sm-12 alert alert-success white-text">'+result.msg+'</div>');
              }else{
                $("#message").append('<div class="col-sm-12 alert alert-danger white-text">'+result.msg+'</div>');
              }
          },
          error: function(response) {
             $("#message").append('<div class="col-sm-12 alert alert-danger white-text">'+response.responseJSON.errors.email+'</div>');
          }
      });
    });
});
</script>