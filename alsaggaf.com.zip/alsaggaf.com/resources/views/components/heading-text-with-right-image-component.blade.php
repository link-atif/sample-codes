<div class="leading-health-section">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="content-holder">
                    <h1>{{ $content($id)->headline_1 }}</h1>
                    <p>
                        {!! nl2br($content($id)->text_1) !!}
                        <!--<a href="{{ $content($id)->link_1 }}">Read more</a>-->
                    </p>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="image-holder">
                    <img src="{{ asset('images') }}/{{ $content($id)->image_1 }}" alt="{{ $content($id)->headline_1 }}" class="img-fluid" />
                </div>
            </div>
        </div>
    </div>
</div>