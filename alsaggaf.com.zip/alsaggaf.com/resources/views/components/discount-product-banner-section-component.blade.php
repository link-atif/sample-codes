<section class="discounted-product">
    <div class="container">
        <div class="product-holder">
                <div class="product-banner" style="background-image: url({{ asset('images') }}/{{ $content($id)->image_1 }});" alt="discounted banner"></div>
                <div class="product-caption">
                    <img src="{{ asset('images') }}/{{ $content($id)->image_2 }}"  alt="30% OFF" class="img-fluid"/>
                    <p>{!! nl2br($content($id)->text_1 ) !!}</p>
                    <a href="{{ $content($id)->link_1 }}" class="btn btn-white">{{ $content($id)->input_1 }}</a>
                </div>
            </div>
        </div>
    </div>
</section>