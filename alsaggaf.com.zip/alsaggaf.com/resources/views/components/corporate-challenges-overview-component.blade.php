<div class="content-item-holder grey-bg">
    <div class="container">
        <div class="challenge-section">
            <h5>{{ $content($id)->headline_1 }}</h5>
            <p>{!! nl2br($content($id)->text_1) !!}</p>
        </div>
    </div>
</div>