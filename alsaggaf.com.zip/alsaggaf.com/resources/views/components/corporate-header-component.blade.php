<!-- corporateHeader -->
<header class="main-header corporate-header">
    <div class="menu-overlay"></div>
    <div class="container">
        <div class="header-top">

            <div class="header-menu-section">
                <nav class="mobile-nav">
                    <ul class="h-list">
                       
                        <div class="nav-icon">
                            <span class="menu-btn"><i class="fa fa-bars"></i></span>
                        </div>
                        
                         <li class="mobile-logo">
                             <a href="{{ route('corporate') }}">
                                <img src="{{ asset('images') }}/brand/logo.svg" alt="logo"/>
                            </a>
                        </li>
                        
                        <li class="dropdown search-dropdown mobile-search">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="{{ asset('images') }}/icon/search.svg" alt="search"/>
                            </a>
                            {!! Form::open(['method' => 'post', 'route' => ['corporateSearch'], 'class' => 'form-horizontal', 'id' => 'searchFormMobile']) !!}
                            <ul class="dropdown-menu search-dropdown-menu dropdown-menu-right">
                                <div class="search-wrapper">
                                    <div class="search-holder">
                                         {!! Form::text('corporateSearch', request()->corporateSearch ? request()->corporateSearch : '' , ['placeholder' => 'Search for products and collections', 'class' => 'form-control', 'id' => 'searchProductsMobile', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <div id="suggesstion-box-mobile"></div>
                                </div>
                            </ul>
                            {!! Form::close() !!}
                        </li>
                        
                       <!-- <li class="nav-item">
                            <a href="{{ url('/') }}">
                           <img src="{{ asset('images') }}/icon/cart.svg" alt="cart"/>
                                <span>Shop Online</span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdown09" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span>En</span>
                                <span class="flag-icon flag-icon-us"> </span>
                                <i class="fa fa-angle-down"></i>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="dropdown09">
                                <a class="dropdown-item" href="#fr">
                                    <span>Fr</span>
                                    <span class="flag-icon flag-icon-fr"></span>
                                </a>
                                <a class="dropdown-item" href="#it"> 
                                    <span>It</span>
                                    <span class="flag-icon flag-icon-it"></span>
                                </a>
                                <a class="dropdown-item" href="#ru">
                                    <span>Ru</span>
                                    <span class="flag-icon flag-icon-ru"></span>
                                </a>
                            </div>
                        </li> -->
                    </ul>
                </nav>

                <nav class="primary-menu-wrapper">
                    <ul class="h-list mega-menu-holder py-3">
                        <li class="header-logo">
                             <a href="{{ route('corporate') }}">
                                <img src="{{ asset('images') }}/brand/logo.svg" alt="logo"/>
                            </a>
                        </li>
                        
                        <li class="dropdown mega-dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="">
                                <span>Categories</span>
                                <i class="fa fa-angle-down"></i>
                            </a>
                            <x-MainMenuCorporateCategoryListingComponent />
                        </li>

                        <li class="dropdown mega-dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="">
                                <span>Brands</span>
                                <i class="fa fa-angle-down"></i>
                            </a>
                            <x-mainMenuBrandsListingComponent />
                        </li>
                        <li>
                            <a href="{{ route('projects') }}">
                                <span>Projects</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('about-us') }}">
                                <span>About Us</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('media') }}">
                                <span>Media</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('careers') }}">
                                <span>Careers</span>
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('contact') }}">
                                <span>Contact</span>
                            </a>
                        </li>
                         
                        <li class="dropdown search-dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <img src="{{ asset('images') }}/icon/search.svg" alt="search"/>
                            </a>
                            {!! Form::open(['method' => 'post', 'route' => ['corporateSearch'], 'class' => 'form-horizontal', 'id' => 'searchForm']) !!}
                            <ul class="dropdown-menu search-dropdown-menu dropdown-menu-right">
                                <div class="search-wrapper">
                                    <div class="search-holder">
                                         {!! Form::text('corporateSearch', request()->corporateSearch ? request()->corporateSearch : '' , ['placeholder' => 'Search for products and collections', 'class' => 'form-control', 'id' => 'searchProducts', 'autocomplete' => 'off']) !!}
                                    </div>
                                    <div id="suggesstion-box"></div>
                                </div>
                            </ul>
                            {!! Form::close() !!}
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>


<!--Mobile menu-->
<aside class="primary-mobile-menu">
    <nav class="nav-holder">
        <div class="mobile-logo">
            <a href="{{ route('corporate') }}">
                <img src="{{ asset('images') }}/brand/logo.svg" alt="logo"/>
            </a>
        </div>
        <ul class="v-list nav-list">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <span>Categories</span>
                    <i class="fa fa-angle-down"></i>
                </a>
                <x-MainMenuCorporateCategoryListingComponent />
            </li>

            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <span>Brands</span>
                    <i class="fa fa-angle-down"></i>
                </a>
                <x-mainMenuBrandsListingComponent />
            </li>

            <li>
                <a href="{{ route('projects') }}">
                    <span>Projects</span>
                </a>
            </li>
            <li>
                <a href="{{ route('about-us') }}"><span>About Us</span></a>
            </li>
    {{--    <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <span>About</span>
                    <i class="fa fa-angle-down"></i>
                </a>
                <ul class="dropdown-menu">
                    <li><a href="{{ route('careers') }}">Careers</a></li>
                </ul>
            </li> --}}
            <li>
                <a href="{{ route('media') }}">
                    <span>Media</span>
                </a>
            </li>
            <li>
                <a href="{{ route('careers') }}">
                    <span>Careers</span>
                </a></li>
            <li>
                <a href="{{ route('contact') }}">
                    <span>Contact</span>
                </a>
            </li>
        </ul>
    </nav>
</aside>