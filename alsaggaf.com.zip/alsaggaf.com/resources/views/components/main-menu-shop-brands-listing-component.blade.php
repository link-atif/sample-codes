<ul class="dropdown-menu mega-dropdown-menu flex-wrap">
    @foreach($content as $brand)
        <li class="col-sm-4"><a href="{{ route('brand-products', $brand->id) }}">{{ $brand->name }}</a></li>
    @endforeach
</ul>