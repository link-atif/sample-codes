<aside class="left-sidebar">
    <nav class="left-sidebar-nav">
        <h5>Categories</h5>
        <ul class="v-list nav-list-item boxscroll">
            @foreach($content as $category)
                <li><a href="{{ route('category-detail-page', $category->id) }}">{{ $category->name }}</a></li>
            @endforeach
        </ul>
    </nav>
</aside>