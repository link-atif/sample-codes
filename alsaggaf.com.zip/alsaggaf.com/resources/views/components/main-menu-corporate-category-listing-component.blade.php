<ul class="dropdown-menu mega-dropdown-menu flex-wrap">
    @foreach($content as $category)
        <li class="col-sm-4"><a href="{{ route('corporate-category', $category->id) }}">{{ $category->name }}</a></li>
    @endforeach
</ul>