<div class="title-head pt-15 pb-45">
    <h2 class="mb-20">{{ $content($id)->headline_1 }}</h2>
    <p>{{ $content($id)->text_1 }}</p>
    @if($content($id)->image_1 !="")
    <a href="{{ asset('images') }}/{{ $content($id)->image_1 }}" target="_blank" class="btn btn-primary">
                            <span class="mr-10"> {{ $content($id)->input_1 }} </span>
                            <img class="icon" src="{{ asset('images') }}/icon/download-icon.svg" alt="dropdown-icon">
                        </a>
    @endif
</div>