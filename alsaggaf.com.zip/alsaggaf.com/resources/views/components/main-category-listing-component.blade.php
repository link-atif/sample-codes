<ul class="dropdown-menu mega-dropdown-menu flex-wrap">
    @foreach($content as $category)
        <li class="col-sm-4"><a href="{{ route('category-detail-page', $category->id) }}">{{ $category->name }}</a></li>
    @endforeach
</ul>