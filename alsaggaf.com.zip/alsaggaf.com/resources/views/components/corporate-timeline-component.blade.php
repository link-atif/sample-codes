<div class="corporate-widgets-section">
    <div class="widget-steps">
        <div class="container">
            <div class="h-scroll h_scroll">
                @foreach($content($id) as $timeline)
                    <div class="item">
                        <div class="inner">
                            <h4 class="title">{{ $timeline->year }}</h4>
                            <div>{!! nl2br($timeline->description) !!}</div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" async>
    $(document).ready(function(){
        $(".h_scroll").css("touch-action", "pan-x");
        
    });
</script>