<!-- Header -->
<header class="main-header">
    <div class="menu-overlay"></div>
    <div class="container">
        <div class="header-top">
            <div class="header-logo">
                <a href="{{ route('home-page') }}">
                    <img src="{{ asset('images') }}/brand/logo.svg" alt="logo"/>
                </a>
            </div>
            <div class="search-wrapper">
                {!! Form::open(['method' => 'post', 'route' => ['simple.search'], 'class' => 'form-horizontal', 'id' => 'search-form']) !!}
                <div class="search-holder">
                    <i class="fa fa-search" type="submit" role="button"></i>
                    {!! Form::text('search_query', request()->search_query ? request()->search_query : '' , ['placeholder' => 'Search for products and collections', 'class' => 'form-control', 'id' => 'inputSearch']) !!}
                    <div id="searchResults" class="cart-nav-item">
                        <ul class="dropdown-menu dropdown-cart dropdown-menu-right">
                            
                        </ul>
                    </div>
                </div>
                {!! Form::close() !!}
            </div>

            <div class="tag-item">
                <span>Black Friday</span>
            </div>

            <div class="nav-icon">
                <span class="menu-btn"><i class="fa fa-bars"></i></span>
            </div>

            <nav class="top-nav">
                <ul class="h-list">
                    <!-- <li class="nav-item">
                        <a href="#">
                            <i class="far fa-heart"></i>
                            <span>Whishlist</span>
                        </a>
                    </li> -->
                    <x-shopMiniCartComponent />
                    <li class="nav-item user-login-menu">
                        @if(!$content->auth)
                            <a href="{{ route('signin') }}">
                                <svg width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M3.85547 4.65908C3.85547 2.50428 5.60975 0.75 7.76455 0.75C9.91936 0.75 11.6736 2.50428 11.6736 4.65908C11.6736 6.81389 9.91936 8.56816 7.76455 8.56816C5.60975 8.56816 3.85547 6.81389 3.85547 4.65908Z" stroke="#0A2568" stroke-width="1.5"/>
                                    <path d="M2.5027 12.8882L2.5027 12.8882C3.63931 11.7341 5.13866 11.1035 6.72979 11.1035H8.80049C10.3917 11.1035 11.891 11.7341 13.0276 12.8882C14.1046 13.9817 14.7189 15.4042 14.7759 16.92H0.754363C0.811381 15.4042 1.4257 13.9817 2.5027 12.8882Z" stroke="#0A2568" stroke-width="1.5"/>
                                </svg>
                                <span>Sign In</span>
                            </a>
                        @else
                            <a href="#" class="dropdown-toggle" type="button" data-toggle="dropdown">
                                <figure class="icon-rounded image-holder profile_picture_header">
                                    <img src="{{ asset('images/users/') }}/{{ $content->profile_picture }}" class="base-image" alt="{{ $content->name }}">
                                </figure>
                                <span>{{ \Illuminate\Support\Str::limit($content->name, 14, $end='...') }}</span>
                            </a>
                            <div class="dropdown-menu profile-menu" aria-labelledby="dropdownMenuButton">
                                <div class="bg-top-menu">
                                    <div class="bg-top-img"></div>
                                </div>
                                <ul>
                                    <li><a href="{{ route('myaccount') }}" class="dropdown-item">Edit Profile</a></li>
                                    <li><a href="{{ route('myaccount.orders') }}" class="dropdown-item">Orders</a></li>
                                    <li><a href="{{ route('myaccount.returns') }}" class="dropdown-item">Returns</a></li>
                                    <li>
                                        <form method="POST" action="{{ route('myaccount.logout') }}">
                                            @csrf
                                            <a role="button" class="dropdown-item" onclick="event.preventDefault();this.closest('form').submit();">
                                                Log Out
                                            </a>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        @endif
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdown09" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span>En</span>
                            <span class="flag-icon flag-icon-us"> </span>
                            <i class="fa fa-angle-down"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdown09">
                            <a class="dropdown-item" href="#fr">
                                <span>Fr</span>
                                <span class="flag-icon flag-icon-fr"></span>
                            </a>
                            <a class="dropdown-item" href="#it"> 
                                <span>It</span>
                                <span class="flag-icon flag-icon-it"></span>
                            </a>
                            <a class="dropdown-item" href="#ru">
                                <span>Ru</span>
                                <span class="flag-icon flag-icon-ru"></span>
                            </a>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>

        <nav class="primary-menu-wrapper">
            <ul class="h-list mega-menu-holder">
                <li class="dropdown mega-dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="{{ asset('images') }}/icon/shop-category.png" alt="Shopping cart" />
                        <span>Shop by Category</span>
                        <i class="fa fa-angle-down"></i>
                    </a>
                    <x-mainCategoryListingComponent />
                </li>

                <li class="dropdown mega-dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img src="{{ asset('images') }}/icon/brand.png" alt="Shopping cart" />
                        <span>Brands</span>
                        <i class="fa fa-angle-down"></i>
                    </a>
                    <x-mainMenuShopBrandsListingComponent />
                </li>

                <li>
                    <a href="{{ route('sales-listing-page') }}">
                        <img src="{{ asset('images') }}/icon/discount.png" alt="Offers & Discount" />
                        <span>Offers & Discount</span>
                    </a>
                </li>

                <li>
                    <a href="{{ route('corporate') }}">
                        <img src="{{ asset('images') }}/icon/corporate.png" alt="Corporate" />
                        <span>Corporate</span>
                    </a>
                </li>

                <li>
                    <a href="{{ route('contact') }}">
                        <img src="{{ asset('images') }}/icon/contact.png" alt="Contact" />
                        <span>Contact</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</header>

<!--Mobile menu-->
<aside class="primary-mobile-menu">
    <nav class="nav-holder">
        <ul class="v-list nav-list">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <img src="{{ asset('images') }}/icon/shop-category.png" alt="Shopping cart" />
                    <span>Shop by Category</span>
                    <i class="fa fa-angle-down"></i>
                </a>
                <x-mainCategoryListingComponent />
            </li>

            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <img src="{{ asset('images') }}/icon/brand.png" alt="Brand" />
                    <span>Brand</span>
                    <i class="fa fa-angle-down"></i>
                </a>
                <x-mainMenuShopBrandsListingComponent />
            </li>

            <li>
                <a href="{{ route('sales-listing-page') }}">
                    <img src="{{ asset('images') }}/icon/discount.png" alt="Offers & Discount" />
                    <span>Offers & Discount</span>
                </a>
            </li>

            <li>
                <a href="{{ route('corporate') }}">
                    <img src="{{ asset('images') }}/icon/corporate.png" alt="Corporate" />
                    <span>Corporate</span>
                </a>
            </li>

            <li>
                <a href="{{ route('contact') }}">
                    <img src="{{ asset('images') }}/icon/contact.png" alt="Contact" />
                    <span>Contact</span>
                </a>
            </li>
        </ul>
    </nav>
</aside>