<ul class="dropdown-menu mega-dropdown-menu flex-wrap">
    @foreach($content as $brand)
        <li class="col-sm-4"><a href="{{ route('brands-detail', $brand->id) }}">{{ $brand->name }}</a></li>
    @endforeach
</ul>