<div class="sales-banner mb-40">
    <div class="banner-wrapper">
        <div class="image-item" style="background-image: url({{ asset('images') }}/{{ $content($id)->image_1 }});"></div>
        <div class="banner-caption">
            <h1>{{ $content($id)->input_1 }}</h1>
            <div id="clock-c" class="countdown py-4"></div>
            <span id="salesCounterDate" class="d-none"> {{ $content($id)->input_2 }} </span>
            <span id="salesCounterDate1" class="d-block"> </span>
        </div>
    </div>
</div>