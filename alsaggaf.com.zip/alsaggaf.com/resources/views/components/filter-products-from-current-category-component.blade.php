<div class="filtered-products">
    <div class="container">
        <div class="title-head pt-0 pb-25">
            <h5 class="mb-0">{{ $content($id, $category)->products->total() }} results found for '{{ $content($id, $category)->category[0]->name }}'</h5>
            <div class="filter-list">
                {{ $content($id, $category)->products->links('vendor.pagination.custom-products-pagination') }}
            </div>
        </div>
        <div class="product-wrapper row justify-content-start">
            @foreach($content($id, $category)->products as $product)
                <div class="product-list-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                    <div class="product-card">
                        <div class="product-image">
                            <a href="{{ route('product-detail-page', $product->id) }}">
                                <img src="{{ asset('images') }}/catalog/products/{{ $product->product_image }}" loading="lazy" alt="Produt Image" class="img-fluid"/>
                            </a>
                        </div>
                        <div class="product-title">
                            <a href="{{ route('product-detail-page', $product->id) }}">{{ $product->title }} </a>
                        </div>
                        <div class="product-price">
                            <div class="price"><strong>{{ $product->price }} </strong> <span>SAR</span> </div>
                            <!-- <div class="strike-price"><span>{{ $product->cost }} SAR</span></div> -->
                        </div>
                        <!-- <div class="btn-group">
                            <a href="javascript:void(0);" class="btn-item" data-toggle="tooltip" data-placement="left" title="Add to whishlist"><i class="fa fa-heart"></i></a>
                        </div> -->
                        <div class="quick-view">
                            <button class="btn btn-transparent" data-toggle="modal" data-target="#quick-view-modal-{{ $product->id }}"><i class="fa fa-search mr-10"></i> <strong>Quick View</strong></button>
                        </div>
                    </div>
                </div>
                <!-- Modal Quick View-->
                <div class="modal fade modal-xxl quick-view-modal" id="quick-view-modal-{{ $product->id }}">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button class="close-btn" data-dismiss="modal">
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M9.81712 9.81714C9.57327 10.061 9.1822 10.061 8.93835 9.81714L5 5.87924L1.06165 9.81714C0.817806 10.061 0.426731 10.061 0.182885 9.81714C-0.0609616 9.57332 -0.0609616 9.18229 0.182885 8.93847L4.12123 5.00057L0.182885 1.06268C-0.0609616 0.81886 -0.0609616 0.427833 0.182885 0.184014C0.302507 0.0644045 0.463538 0 0.619968 0C0.776398 0 0.937428 0.0598049 1.05705 0.184014L4.9954 4.12191L8.93375 0.184014C9.05337 0.0644045 9.2144 0 9.37083 0C9.53186 0 9.68829 0.0598049 9.80791 0.184014C10.0518 0.427833 10.0518 0.81886 9.80791 1.06268L5.87877 5.00057L9.81712 8.93847C10.061 9.18229 10.061 9.57332 9.81712 9.81714Z" fill="currentColor"/>
                                    </svg>
                                </button>
                            </div>
                            {!! Form::open(['method' => 'post', 'route' => ['admin.product.cart.add', $product->id], 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                                <div class="modal-body">
                                    <div class="pdp-content-wrapper">
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <div class="pdp-slider-section">
                                                    <!--product large slider-->
                                                    <div class="pdp-slider-holder">
                                                        <div class="pdp-gallery-slider">
                                                            @foreach($product->images as $image)
                                                                <div class="slide-item">
                                                                    <div class="image-holder">
                                                                        <img src="{{ asset('images') }}/catalog/products/{{ $image->product_image }}" loading="lazy" class="img-fluid" alt="Slide Image"/>
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        </div>
                                                        <!-- <nav class="slider-actions-btn">
                                                            <ul class="h-list justify-content-center align-items-center">
                                                                <li>
                                                                    <a href="">
                                                                        <i class="far fa-heart"></i>
                                                                        <span>Add to Wishlist</span>
                                                                    </a>
                                                                </li>
                                                                <li class="dropdown">
                                                                    <a href="#"class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                        <i class="fa fa-share-alt"></i>
                                                                        <span>Share</span>
                                                                    </a>
                                                                    <div class="dropdown-menu">
                                                                        <ul class="h-list">
                                                                            <li class="dd-menu-item">
                                                                                <a href=""><img src="{{ asset('images/social') }}/wahtsapp.png" alt="WhatsApp" /></a>
                                                                            </li>
                                                                            <li class="dd-menu-item">
                                                                                <a href=""><img src="{{ asset('images/social') }}/snapchat.png" alt="Snapchat" /></a>
                                                                            </li>
                                                                            <li class="dd-menu-item">
                                                                                <a href=""><img src="{{ asset('images/social') }}/facebook.png" alt="Facebook" /></a>
                                                                            </li>
                                                                            <li class="dd-menu-item">
                                                                                <a href=""><img src="{{ asset('images/social') }}/instagram.png" alt="Instagram" /></a>
                                                                            </li>
                                                                            <li class="dd-menu-item">
                                                                                <a href=""><img src="{{ asset('images/social') }}/linkedin.png" alt="Linkedin" /></a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </li>
                                                                <li>
                                                                    <a href="">
                                                                        <i class="fa fa-envelope"></i>
                                                                        <span>Email</span>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                        </nav> -->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-5">
                                                <!--product Info Details-->
                                                <div class="pdp-info-detail">
                                                    <h4 class="product-title">{{ $product->title }}</h4>
                                                    <!-- <div class="rating-wrapper h-list">
                                                        <div class="stars">
                                                            <span class="fa fa-star checked"></span>
                                                            <span class="fa fa-star checked"></span>
                                                            <span class="fa fa-star checked"></span>
                                                            <span class="far fa-star"></span>
                                                            <span class="far fa-star"></span>
                                                        </div>
                                                        <span class="review-no">(14)</span>
                                                    </div> -->

                                                    <div class="product-price">
                                                        <div class="price">{{ $product->price}} <span>SAR</span></div>
                                                        <div class="product-discount">
                                                            <div class="discount-item"><span>Sale Starts</span> <strong>Nov 15, 11:00 AM</strong> </div>
                                                        </div>
                                                    </div>

                                                    <div class="shipping-info-text">{{ $product->shipment_information }}</div>
                                                    <div class="product-attributes">
                                                        <div class="product-quantity">
                                                            <div class="product-qty-wrapper">
                                                                <label class="info-label">Quantity</label>
                                                                {!! Form::text('qty', null , ['placeholder' => '20', 'class' => 'form-control']) !!}
                                                            </div>
                                                            @if($errors->first('qty'))
                                                                <span class="text-danger">{{ $errors->first('qty') }}</span>
                                                            @endif
                                                        </div>
                                                        @if($product->product_type == 'Configurable Product')
                                                            @if($product->size->isNotEmpty())
                                                                <div class="product-size">
                                                                    <div class="sizes-wrapper">
                                                                        <label class="info-label">Size</label>
                                                                        <div class="select-item">
                                                                            <select name="size" class="form-control">
                                                                                <option value=""> Size </option>
                                                                                @foreach($product->size as $size)
                                                                                    <option value="{{ $size->id }}"> {{ $size->size }} </option>
                                                                                @endforeach
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            @endif
                                                            @if($product->color->isNotEmpty())
                                                                <div class="product-color">
                                                                    <div class="color-wrapper">
                                                                        <label class="info-label">colors</label>
                                                                        <div class="color-swatches h-list">
                                                                            @foreach($product->color as $color)
                                                                                <div class="custom-input-wrapper">
                                                                                    <input type="radio" class="custom-input" data-toggle="tooltip" title="{{ $color->color}}" value="{{ $color->id }}" name="color" />
                                                                                    <span class="color"></span>
                                                                                </div>
                                                                            @endforeach
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            @endif
                                                        @endif
                                                    </div>

                                                    <div class="product-action-btns">
                                                        <div class="btn-item">
                                                            <button type="submit" class="add-to-cart btn btn-primary">Add to Cart</a>
                                                        </div>
                                                        <!-- <div class="btn-item">
                                                            <button class="like btn btn-transparent" type="button">Add to Quote</button>
                                                            <div class="info-text">Are you a Distributor?</div>
                                                        </div> -->
                                                    </div>

                                                    <div id="accordion" class="accordion-wrapper">
                                                        <div class="card-collapse-item">
                                                            <div class="card-header">
                                                                <a class="card-link text-black" data-toggle="collapse" href="#collapseOne">
                                                                    <h5>Product Description</h5>
                                                                    <span class="icon-btn"><i class="fa fa-plus"></i></span>
                                                                </a>
                                                            </div>
                                                            <div id="collapseOne" class="collapse show" data-parent="#accordion">
                                                                <div class="card-body">
                                                                    <div class="content-holder">
                                                                        <p>{{ \Illuminate\Support\Str::limit($product->description, 150, $end='...') }}</p>
                                                                        <a href="{{ route('product-detail-page', $product->id) }}" class="item-link">Read More</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="card-collapse-item">
                                                            <div class="card-header">
                                                                <a class="collapsed card-link text-black" data-toggle="collapse" href="#collapseTwo">
                                                                    <h5>Product Specification</h5>
                                                                    <span class="icon-btn"><i class="fa fa-plus"></i></span>
                                                                </a>
                                                            </div>
                                                            <div id="collapseTwo" class="collapse" data-parent="#accordion">
                                                                <div class="card-body">
                                                                    <ul class="v-list">
                                                                        @foreach($product->product_specifications_attributes as $attribute)
                                                                        <li class="content-list-item">
                                                                            <strong>{{ $attribute->product_attribute_set->attribute_name }}:</strong>
                                                                            <span>{{ $attribute->value }}</span>
                                                                        </li>
                                                                        @endforeach
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="card-collapse-item">
                                                            <div class="card-header">
                                                                <a class="collapsed card-link text-black" data-toggle="collapse" href="#collapseThree">
                                                                    <h5>Returns & Exchange Policy</h5>
                                                                    <span class="icon-btn"><i class="fa fa-plus"></i></span>
                                                                </a>
                                                            </div>
                                                            <div id="collapseThree" class="collapse" data-parent="#accordion">
                                                                <div class="card-body">
                                                                    <div class="content-holder">
                                                                        <p>{{ \Illuminate\Support\Str::limit($product->returns_and_exchange, 150, $end='...') }}</p>
                                                                        <a href="{{ route('product-detail-page', $product->id) }}" class="item-link">Read More</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            {!! Form::close() !!}
                            <div class="modal-footer justify-content-center">
                                <div class="action-link">
                                    <a href="{{ route('product-detail-page', $product->id) }}" class="link-item">View Full Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="load-more-btn text-center mb-50">
            @if($content($id, $category)->products->hasPages())
                @if($content($id, $category)->products->hasMorePages())
                    <a href="{{ $content($id, $category)->products->nextPageUrl() }}" class="btn btn-transparent">Load More...</a>
                @else
                    <a href="{{ route('category-detail-page', $category) }}" class="btn btn-transparent">First Page</a>
                @endif
            @endif
        </div>
    </div>
</div>