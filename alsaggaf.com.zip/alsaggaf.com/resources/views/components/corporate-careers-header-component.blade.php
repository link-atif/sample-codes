<div class="title-head pt-15 pb-45">
    <h2 class="mb-20">{{ $content($id)->headline_1}}</h2>
    <p>{!! nl2br($content($id)->text_1) !!}</p>
    <a href="{{ route('careers-listing') }}" class="btn btn-primary">{{ $content($id)->input_1}}</a>
</div>