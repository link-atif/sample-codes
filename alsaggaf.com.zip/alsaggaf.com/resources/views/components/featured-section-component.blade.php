<div class="featured-section">
    <div class="container">
        <div class="row grid-gutters-11 featured-wrapper">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="featured-item">
                    <div class="content-holder">
                        <div class="image-holder">
                            <img src ="{{ asset('images') }}/{{ $content($id)->image_1 }}" alt="{{ $content($id)->input_1 }}"/> 
                        </div>
                        <div class="content-desc">
                            <h3>{{ $content($id)->input_1 }}</h3>
                            <p>{{ $content($id)->text_1 }} </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="featured-item">
                    <div class="content-holder">
                        <div class="image-holder">
                            <img src ="{{ asset('images') }}/{{ $content($id)->image_2 }}" alt="{{ $content($id)->input_2 }}"/> 
                        </div>
                        <div class="content-desc">
                            <h3>{{ $content($id)->input_2 }}</h3>
                            <p>{{ $content($id)->text_2 }} </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="featured-item">
                    <div class="content-holder">
                        <div class="image-holder">
                            <img src ="{{ asset('images') }}/{{ $content($id)->image_3 }}" alt="{{ $content($id)->input_3 }}"/> 
                        </div>
                        <div class="content-desc">
                            <h3>{{ $content($id)->input_3 }}</h3>
                            <p>{{ $content($id)->text_3 }} </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="featured-item">
                    <div class="content-holder">
                        <div class="image-holder">
                            <img src ="{{ asset('images') }}/{{ $content($id)->image_4 }}" alt="{{ $content($id)->input_4 }}"/> 
                        </div>
                        <div class="content-desc">
                            <h3>{{ $content($id)->input_4 }}</h3>
                            <p>{{ $content($id)->text_4 }} </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>