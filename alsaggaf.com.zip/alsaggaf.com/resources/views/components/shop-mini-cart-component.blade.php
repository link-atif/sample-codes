<li class="nav-item cart-nav-item">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <i class="fa fa-shopping-cart"></i>
        <span class="count">{{ $content->count }}</span>
    </a>
    @if($content->count > 0)
        <ul class="dropdown-menu dropdown-cart dropdown-menu-right">
            @foreach($content->cart_details as $key => $item)
                <li>
                    <div class="cart-item-wrapper">
                        <div class="item-left">
                            <div class="image-holder">
                                <img src="{{ asset('images') }}/catalog/products/{{ $item->product_detail->images[0]->product_image }}" alt="{{ $item->title }}" class="img-fluid" />
                            </div>
                            <div class="item-info">
                                <div class="item-name">{{ \Illuminate\Support\Str::limit($item->product_detail->title, 20, $end='...') }}</div>
                                <div class="item-price">{{ $item->product_qty * $item->product_price }} SAR</div>
                            </div>
                        </div>
                        {!! Form::open(['method' => 'delete', 'route' => ['admin.product.cart.delete', $item->id], 'class' => 'form-horizontal']) !!}
                            <div class="item-right">
                                <button class="btn btn-xs btn-danger pull-right" type="submit" > x </button>
                            </div>
                        {!! Form::close() !!}
                    </div>
                </li>
            @endforeach
            <li class="view-cart-button"><a href="{{ route('shopping-cart') }}" class="text-center btn btn-transparent btn-block">View Cart</a></li>
        </ul>
    @else
        <ul class="dropdown-menu dropdown-cart dropdown-menu-right">
            <li>
                <div class="cart-item-wrapper">
                    <div class="item-left">
                        <div class="item-info">
                            <div class="item-name">Cart is Empty ..!</div>
                        </div>
                        <div class="item-right">
                            <button class="btn btn-xs btn-danger pull-right" type="button" > x </button>
                        </div>
                    </div>
                </div>
            </li>
        </ul>
    @endif
</li>