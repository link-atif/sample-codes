<div class="recent-products mb-50">
    <div class="container">
        <div class="title-head pt-0 pb-30">
            <h5>Related Products</h5>
        </div>
        <div class="product-wrapper row">
            <div class="product-list-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/products/pd-thumb2.jpg" alt="Produt Image" class="img-fluid"/>
                    </div>
                    <div class="product-title">
                        <a href="#">Alchemist 001 Collection EDP </a>
                    </div>
                    <div class="product-price">
                        <div class="price"><strong>169.50 </strong> <span>SAR</span> </div>
                        <div class="strike-price"><span>199.50 SAR</span></div>
                    </div>
                    <div class="btn-group">
                        <a href="javascript:void(0);" class="btn-item" data-toggle="tooltip" data-placement="left" title="Add to whishlist"><i class="fa fa-heart"></i></a>
                    </div>
                    <div class="quick-view">
                        <button class="btn btn-transparent"><i class="fa fa-search mr-10"></i> <strong>Quick View</strong></button>
                    </div>
                </div>
            </div>

            <div class="product-list-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/products/pd-thumb2.jpg" alt="Produt Image" class="img-fluid"/>
                    </div>
                    <div class="product-title">
                        <a href="#">Alchemist 001 Collection EDP </a>
                    </div>
                    <div class="product-price">
                        <div class="price"><strong>169.50 </strong> <span>SAR</span> </div>
                        <div class="strike-price"><span>199.50 SAR</span></div>
                    </div>
                    <div class="btn-group">
                        <a href="javascript:void(0);" class="btn-item" data-toggle="tooltip" data-placement="left" title="Add to whishlist"><i class="fa fa-heart"></i></a>
                    </div>
                    <div class="quick-view">
                        <button class="btn btn-transparent"><i class="fa fa-search mr-10"></i> <strong>Quick View</strong></button>
                    </div>
                </div>
            </div>

            <div class="product-list-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/products/pd-thumb2.jpg" alt="Produt Image" class="img-fluid"/>
                    </div>
                    <div class="product-title">
                        <a href="#">Alchemist 001 Collection EDP </a>
                    </div>
                    <div class="product-price">
                        <div class="price"><strong>169.50 </strong> <span>SAR</span> </div>
                        <div class="strike-price"><span>199.50 SAR</span></div>
                    </div>
                    <div class="btn-group">
                        <a href="javascript:void(0);" class="btn-item" data-toggle="tooltip" data-placement="left" title="Add to whishlist"><i class="fa fa-heart"></i></a>
                    </div>
                    <div class="quick-view">
                        <button class="btn btn-transparent"><i class="fa fa-search mr-10"></i> <strong>Quick View</strong></button>
                    </div>
                </div>
            </div>

            <div class="product-list-item col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/products/pd-thumb2.jpg" alt="Produt Image" class="img-fluid"/>
                    </div>
                    <div class="product-title">
                        <a href="#">Alchemist 001 Collection EDP </a>
                    </div>
                    <div class="product-price">
                        <div class="price"><strong>169.50 </strong> <span>SAR</span> </div>
                        <div class="strike-price"><span>199.50 SAR</span></div>
                    </div>
                    <div class="btn-group">
                        <a href="javascript:void(0);" class="btn-item" data-toggle="tooltip" data-placement="left" title="Add to whishlist"><i class="fa fa-heart"></i></a>
                    </div>
                    <div class="quick-view">
                        <button class="btn btn-transparent"><i class="fa fa-search mr-10"></i> <strong>Quick View</strong></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>