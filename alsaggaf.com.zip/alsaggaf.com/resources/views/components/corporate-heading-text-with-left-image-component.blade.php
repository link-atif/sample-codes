<div class="content-item-holder grey-bg">
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="image-holder">
                    <img src="{{ asset('images') }}/{{ $content($id)->image_1 }}" alt="about image" class="img-fluid"/>
                </div>
            </div>
            <div class="col-sm-9">
                <div class="content-holder">
                    <h5>{{ $content($id)->headline_1 }}</h5>
                    <p>{!! nl2br($content($id)->text_1) !!}</p>
                </div>
            </div>
        </div>
    </div>
</div>