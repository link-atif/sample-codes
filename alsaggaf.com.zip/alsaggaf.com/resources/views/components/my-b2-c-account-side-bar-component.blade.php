<aside class="left-sidebar">
    <nav class="left-sidebar-nav menu-sidebar">
        <ul class="v-list nav-list-item">
            <li class="{{ 'myaccount/orders' === request()->path() ? 'active' : '' }}"><a href="{{ route('myaccount.orders') }}">Orders</a></li>
            <li class="{{ 'myaccount/returns' === request()->path() ? 'active' : '' }}"><a href="{{ route('myaccount.returns') }}">Returns</a></li>
            <li class="{{ 'myaccount' === request()->path() ? 'active' : '' }}"><a href="{{ route('myaccount') }}">Personal Details</a></li>
            <!-- <li><a href="shopping-address.html">Shipping Address</a></li>
            <li><a href="preference.html">Preference</a></li> -->
            <form method="POST" action="{{ route('myaccount.logout') }}">
                @csrf
                <li>
                    <a role="button"  onclick="event.preventDefault();this.closest('form').submit();">
                        Log Out
                    </a>
                </li>
            </form>
        </ul>
    </nav>
</aside>