
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD0GBu0ofo9m19r3CUCqz1pKnoMaSNanp0"></script>

<style type="text/css">
#mapCanvas {
    width: 100%;
    height: 481px;
}
</style>
<div class="branches-section">
    <div class="map-section">
        <div id="mapCanvas"></div>
    </div>
</div>
<script>

var map;

var stores = @json($locations);

function initMap() {
    map = new google.maps.Map(document.getElementById('mapCanvas'), {
    zoom: 5,
    center: {
      lat: parseFloat(stores[0][1]),
      lng: parseFloat(stores[0][2])
    }
  });
  setMarkers(map);
}

var markers = [];

// Data for the markers consisting of a name, a LatLng and a zIndex for the
// order in which these markers should display on top of each other.


function setMarkers(map) {
  // Adds markers to the map.
  for (var i = 0; i < stores.length; ++i) {
    var store = stores[i];
    var marker = new google.maps.Marker({
      position: {
        lat: parseFloat(store[1]),
        lng: parseFloat(store[2])
      },
      map: map,
      icon: {
      url: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png"
    },
      animation: google.maps.Animation.DROP,
      title: store[0]
    });
    
    var infowindow = new google.maps.InfoWindow({
      content: store[0]
    });
    
    marker.infobox = infowindow;
  
    markers.push(marker);

    google.maps.event.addListener(marker, 'click', (function(marker, i) {
      return function() {

        // Close all other infoboxes
        for (var j = 0; j < markers.length; j++) {
          markers[j].infobox.close(map);
        }

        // Open correct info box
        markers[i].infobox.open(map, markers[i]);
      }
    })(marker, i))
  }
}

function openMarker(event) {

  var targetElement = event.currentTarget;
  
  var id = targetElement.getAttribute("data-markerindex");
  
  // Close all other infoboxes
  for (var j = 0; j < markers.length; j++) {
    markers[j].infobox.close(map, markers[j]);
  }

  // Open correct info box
  markers[id].infobox.open(map, markers[id]);
}
    
var clickhandles = document.getElementsByClassName("js-click-store");

for (var i = 0; i < clickhandles.length; i++) {
  clickhandles[i].addEventListener('click', openMarker, false);
}

google.maps.event.addDomListener(window, 'load', initMap);

</script>