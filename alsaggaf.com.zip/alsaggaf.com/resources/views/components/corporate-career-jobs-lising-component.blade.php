<div class="corporate-openings">
    <div class="container">
        <div class="table-holder">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Position</th>
                            <th scope="col">Team</th>
                            <th scope="col">Location</th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tbody>
                        @if($content($id)->jobs)
                        @foreach($content($id)->jobs as $job)
                            <tr>
                                <td><a href="{{ route('careers-detail', $job->id) }}">{{ $job->position }}</a></td>
                                <td>{{ $job->team }}</td>
                                <td>{{ $job->location }}</td>
                                <td>
                                    <div class="action-btns">
                                        <a href="{{ $job->linkedin }}"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.7383 13.5H10.75V8.4375C10.75 8.0625 10.5625 7.73438 10.1875 7.45312C9.83594 7.14844 9.46094 6.99609 9.0625 6.99609C8.66406 6.99609 8.33594 7.13672 8.07812 7.41797C7.84375 7.69922 7.72656 8.03906 7.72656 8.4375V13.5H4.73828V4.5H7.72656V6.01172C7.96094 5.61328 8.34766 5.29688 8.88672 5.0625C9.42578 4.80469 9.91797 4.67578 10.3633 4.67578C11.3008 4.67578 12.0977 5.01562 12.7539 5.69531C13.4102 6.35156 13.7383 7.13672 13.7383 8.05078V13.5ZM3.22656 13.5H0.238281V4.5H3.22656V13.5ZM1.75 0C2.14844 0 2.48828 0.152344 2.76953 0.457031C3.07422 0.738281 3.22656 1.08984 3.22656 1.51172C3.22656 1.91016 3.07422 2.26172 2.76953 2.56641C2.48828 2.84766 2.13672 2.98828 1.71484 2.98828C1.31641 2.98828 0.964844 2.84766 0.660156 2.56641C0.378906 2.26172 0.238281 1.91016 0.238281 1.51172C0.238281 1.08984 0.378906 0.738281 0.660156 0.457031C0.964844 0.152344 1.32812 0 1.75 0Z" fill="currentColor"></path></svg></a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>