<div class="banner-wrapper">
    <div class="image-item" style="background-image: url('/images/{{ $content($id)->image_1 }}');"></div>
    <div class="banner-caption">
        <h1>{{ $content($id)->input_1 }}</h1>
        <a href="{{ $content($id)->link_1 }}" class="btn btn-primary">{{ $content($id)->input_2 }}</a href="{{ $content($id)->input_1 }}">
    </div>
</div>