<style>
    
    .left {
        float: left;
        width: 50%;
        text-align: left;
        font-size: 1.5rem;
    }
    
    .right {
        float: right;
        width: 50%;
        text-align: right;
        font-size: 15px;
        line-height: normal;
        padding-top: 1px;
    }
    
    /* Clear floats after the columns */
    .column:after {
        content: "";
        display: table;
        clear: both;
    }
    
</style>

@foreach($content($id)->projects as $project)
    <div class="col-md-6 col-sm-12">
        <div class="project-list-item">
            <div class="content-holder">
                <div class="image-item"><img src="{{ asset('images/projects') }}/{{ $project->image }}" alt="{{ $project->name }}" class="img-fluid" /></div>
            </div>
            <nav class="project-content">
                <h5>{{ $project->name }}</h5>
                <div class="row">
                    <div class="col-md-6">
                       <div class="column">
                            <h5 class="blue left">Year of Execution :</h5>
                            <p class="right">{{ $project->year_of_execution }}</p>
                        </div>
                        <div class="column">
                            <h5 class="blue left">Contractor :</h5>
                            <p class="right">{{ $project->contractor }}</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                         <div class="column">
                            <h5 class="blue left">Location :</h5>
                            <p class="right">{{ $project->location }}</p>
                        </div>
                        <div class="column">
                            <h5 class="blue left">Status :</h5>
                            <p class="right">{{ $project->supplied }}</p>
                        </div>
                    </div>
                </div>
                <div class="row" style="display: none;" id="{{ $project->id.'_more' }}">
                    <div class="col-md-6">
                       <div class="column">
                            <h5 class="blue left">Supervising Entity :</h5>
                            <p class="right">{{ $project->supervising_entity }}</p>
                       </div>
                        <div class="column">
                            <h5 class="blue left">Implementing :</h5>
                            <p class="right">{{ $project->implementing }}</p>
                       </div>
                    </div>
                    <div class="col-md-6">
                        <div class="column">
                            <h5 class="blue left">Products :</h5>
                            <p class="right">{{ $project->products }}</p>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="project-desc">
                            <p>{{ $project->description }}</p>
                        </div>
                    </div>
                </div>
                 <a href="javascript:;" onClick="showMore('{{ $project->id }}')" id="{{ $project->id.'_btn' }}">Read More</a>
            </nav>
        </div>
    </div>
@endforeach

<script>
function showMore(id) {
  var moreText = document.getElementById(id+"_more");
  var btnText = document.getElementById(id+"_btn");

  if (moreText.style.display === "none") {
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline-flex";
  } else {
    btnText.innerHTML = "Read More"; 
    moreText.style.display = "none";
  }
}
</script>