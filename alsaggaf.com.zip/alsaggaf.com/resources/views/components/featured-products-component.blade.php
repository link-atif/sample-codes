<div class="best-seller mt-minus corporate-products mt-1">
    <div class="container">
        <div class="title-head">
            <h2>{{$content->categoryName}}</h2>
        </div>
        <div class="product-wrapper justify-content-start">
            @foreach($content as $product)
                <div class="product-list-item">
                    <div class="product-card">
                        <div class="product-image">
                            <img src="{{ asset('images') }}/catalog/products/{{ $product->product_image }}" alt="{{ $product->title }}" class="img-fluid"/>
                        </div>
                        <div class="product-title">
                            <a href="{{ url('/') }}/corporate/product/{{ $product->id }}">{{ $product->title }}</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>