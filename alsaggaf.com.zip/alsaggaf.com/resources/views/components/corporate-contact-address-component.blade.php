<aside class="left-sidebar">
    <nav class="left-sidebar-nav menu-sidebar">
        <div class="contact-info-list">
            <div class="title-info"> {{ $content($id)->headline_1 }} </div>
            <div class="address-info">
                <p>{!! nl2br($content($id)->text_1) !!}</p>
            </div>
            <ul class="v-list social-info">
                <li>
                    <img src="{{ asset('images/icon') }}/phone-icon.svg" alt="Phone" class="img-fluid"/>
                    <span> {{ $content($id)->input_1 }} </span>
                </li>
                <li>
                    <img src="{{ asset('images/icon') }}/whatsapp-icon.svg" alt="Phone" class="img-fluid"/>
                    <span> {{ $content($id)->input_2 }} </span>
                </li>
                <li>
                    <img src="{{ asset('images/icon') }}/email-icon.svg" alt="Phone" class="img-fluid"/>
                    <span> {{ $content($id)->input_3 }}</span>
                </li>
            </ul>
        </div>
    </nav>
</aside>