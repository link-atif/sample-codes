 <div class="right-content-area contact-form">
    <div class="content-card contact-info-card">
         @if(session()->has('message'))
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                        <strong>{{ session()->get('status') }}!</strong> {{ session()->get('message') }}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                @endif
                @if ($errors->has('g-recaptcha-response'))
                    <span class="help-block">
                        <strong>{{ $errors->first('g-recaptcha-response') }}</strong>
                    </span>
                @endif
        <form method="POST" action="{{ route('contact.store') }}">
           
            @csrf
            <div class="row">
                <div class="col-sm-6 form-group">
                    <input type="text" class="form-control" name="name" placeholder="Full Name *" required="name">
                </div>
                <div class="col-sm-6 form-group">
                    <input type="text" class="form-control" placeholder="Subject" name="subject">
                </div>
                <div class="col-sm-6 form-group">
                    <input type="text" class="form-control" placeholder="Phone Number *" name="phone_no" required="no">
                </div>
                <div class="col-sm-6 form-group">
                    <input type="email" class="form-control" required="email" placeholder="Email *" name="email">
                </div>
            </div>
            <div class="form-group">
                <textarea class="form-control" placeholder="How can we help you ?" name="content" required="content"></textarea>
            </div>
            <button class="btn btn-primary" type="submit">Submit</button>
        </form>
    </div>
</div>