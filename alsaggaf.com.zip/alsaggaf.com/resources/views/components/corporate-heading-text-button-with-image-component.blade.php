<div class="content-item-holder">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 order-sm-2">
                <div class="image-holder">
                    <img src="{{ asset('images') }}/{{ $content($id)->image_2 }}" alt="about image" class="img-fluid"/>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="content-holder order-sm-1">
                    <h5>{{ $content($id)->headline_1 }}</h5>
                    <p>{!! nl2br($content($id)->text_1) !!}</p>
                    
                   {{-- @if($content($id)->image_1 && $content($id)->input_1)
                      <a href="{{ asset('images') }}/{{ $content($id)->image_1 }}" target="_blank" class="btn btn-primary">
                            <span class="mr-10"> {{ $content($id)->input_1 }} </span>
                            <img class="icon" src="{{ asset('images') }}/icon/download-icon.svg" alt="dropdown-icon">
                    </a>
                    @endif --}}
                </div>
            </div>
        </div>
    </div>
</div>