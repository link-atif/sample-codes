<section class="brand-section">
    <div class="container">
        <div class="brand-slider">
            <div class="title-head">
                <h2>{{ $content($id)->input_1 }}</h2>
            </div>
            <div class="row grid-gutters-11 slick-instance">
                @foreach($content($id)->carousals as $carousal)
                    <div class="col-sm-2">
                        <div class="brand-item">
                            <img src="{{ asset('images') }}/brands-carousal/{{ $carousal->image }}" alt="{{ $carousal->name }}" class="img-fluid"/>
                        </div>
                    </div>
                @endforeach
            </div>
            <div class="slide-count-wrap">
                <span class="prev-arrow"><i class="fa fa-angle-left"></i></span>
                <span class="current"></span> / <span class="total"></span>
                <span class="next-arrow"><i class="fa fa-angle-right"></i></span>
            </div>
        </div>
    </div>
</section>