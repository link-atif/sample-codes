<div class="title-head pt-15 pb-45">
    <h2 class="mb-20">{{ $content($id)->headline_1 }}</h2>
    <p>{{ $content($id)->text_1 }}</p>
</div>