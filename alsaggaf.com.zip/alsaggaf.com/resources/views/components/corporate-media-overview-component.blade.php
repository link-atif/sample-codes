<div class="latest-media-section media-section">
    <div class="container">
        <div class="title-head pt-15 pb-30">
            <h2>{{ $content($id)->headline_1 }}</h2>
        </div>
        <div class="row latest-media-wrapper">
            @foreach($content($id)->medias as $media)
                <div class="col-sm-4">
                    <a href="{{ route('media.show', $media->id) }}">
                        <div class="latest-media-item">
                            <div class="image-holder">
                                <img src="{{ asset('images/media') }}/{{ $media->image }}" alt="{{ $media->title }}" class="img-fluid" />
                            </div>
                            <div class="content-holder">
                                <h4>{{ $media->title }}</h4>
                                <p>{!! nl2br($media->short_description) !!}</p>
                            </div>
                        </div>
                    </a>
                </div>
            @endforeach
        </div>
        <div class="text-center">
            <button class="btn btn-transparent mb-45">View All</button>
        </div>
    </div>
</div>