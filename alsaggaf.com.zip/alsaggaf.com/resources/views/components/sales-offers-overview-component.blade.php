<div class="sales-category-wrapper">
    @foreach($content($id) as $category)
        @if($category->sales->isNotEmpty())
        <div class="sales-content-holder mb-25">
            <h5 class="pb-30"> {{ $category->name }}</h5>
            <div class="row">
                @foreach($category->sales as $sale)
                    <div class="col-lg-6 col-md-12">
                        <div class="sales-list-item">
                            <div class="content-holder">
                                <div class="image-item" style="background-image: url({{ asset('images/offers') }}/{{ $sale->image }});"></div>
                                <div class="category-caption">
                                    <p> {{ $sale->title }} </p>
                                </div>
                                @if($sale->percentage)
                                    <div class="discount-item">
                                        <div class="discount">{{ $sale->percentage }}% off</div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
        @endif
    @endforeach
    <div class="text-center">
        <button class="btn btn-transparent">Load More...</button>
    </div>
</div>