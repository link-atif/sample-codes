<div class="services-section">
    <div class="container">
        <div class="services-wrapper">
            <div class="row">
                @foreach($content($id)->services as $service)
                    <div class="col-sm-4">
                        @if($service->service_id != "")
                        <a href="{{ route('services-jobs', $service->service_id )}}">
                        @endif
                        <div class="services-item">
                            <div class="image-holder">
                                <img src="{{ asset('images/service')}}/{{ $service->image }}" alt="{{ $service->name }}" class="img-fluid" />
                            </div>
                            <div class="content-holder">
                                <h5>{{ $service->name }}</h5>
                            </div>
                        </div>
                        @if($service->service_id != "")
                        </a>
                        @endif
                    </div>
                @endforeach     
            </div>
        </div>
    </div>
</div>