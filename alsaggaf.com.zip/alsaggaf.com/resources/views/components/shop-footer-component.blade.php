<!-- Footer -->
<footer class="footer">
    <div class="container">
        <div class="row footer-wrapper">
            <div class="col-md-3 col-sm-6">
                <div class="content-holder">
                    <div class="footer-logo">
                        <img src="{{ asset('images') }}/brand/logo.svg" alt="footer logo"/>
                    </div>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ac purus ac nequ auctor scelerisque. </p>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="content-holder">
                    <h5>Menu</h5>
                    <ul class="v-list">
                        <li><a href="{{ route('all-category') }}">Categories</a></li>
                        <li><a href="{{ route('corporate') }}">Corporate website</a></li>
                        <li><a href="{{ route('faq') }}">FAQ</a></li>
                        <li><a href="{{ route('contact') }}">Contact</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="content-holder">
                    <h5>Quick Links</h5>
                    <ul class="v-list">
                        <li><a href="{{ route('terms-and-conditions') }}">Terms and Conditions</a></li>
                        <li><a href="{{ route('shipping-and-delivery') }}">Shipping and Delivery</a></li>
                        <li><a href="{{ route('warranty-policy') }}">Warranty Policy</a></li>
                        <li><a href="{{ route('exchange-and-return-policy') }}">Exchange and Return Policy</a></li>
                        <li><a href="{{ route('account-verification-process') }}">Account Verification Process</a></li>
                    </ul>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="social-nav">
                    <ul class="v-list content-holder">
                        <li>
                            <div class="content-item">
                                <span class="label-title">Toll Free</span>
                                <span class="label-info">+966 122 500989</span>
                            </div>
                        </li>
                        <li>
                            <div class="content-item">
                                <span class="label-title">Email</span>
                                <span class="label-info"><a href="mailto:info@alsaggaf.com">info@alsaggaf.com</a></span>
                            </div>
                        </li>
                        <li>
                            <div class="content-item">
                                <span class="label-title">Social</span>
                                <ul class="h-list">
                                    <li>
                                        <a href="#">
                                            <svg width="16" height="15" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M7.72656 0C6.36719 0 5.11328 0.339844 3.96484 1.01953C2.81641 1.67578 1.90234 2.57812 1.22266 3.72656C0.566406 4.875 0.238281 6.12891 0.238281 7.48828C0.238281 8.73047 0.507812 9.89062 1.04688 10.9688C1.60938 12.0234 2.37109 12.9023 3.33203 13.6055C4.29297 14.3086 5.37109 14.7422 6.56641 14.9062V9.66797H4.66797V7.48828H6.56641V5.83594C6.56641 4.92188 6.8125 4.20703 7.30469 3.69141C7.82031 3.17578 8.51172 2.91797 9.37891 2.91797C9.94141 2.91797 10.5039 2.96484 11.0664 3.05859V4.92188H10.1172C9.69531 4.92188 9.37891 5.03906 9.16797 5.27344C8.98047 5.48438 8.88672 5.75391 8.88672 6.08203V7.48828H10.9961L10.6445 9.66797H8.88672V14.9062C10.1055 14.7188 11.1953 14.2734 12.1562 13.5703C13.1172 12.8672 13.8672 11.9883 14.4062 10.9336C14.9453 9.85547 15.2148 8.70703 15.2148 7.48828C15.2148 6.12891 14.875 4.875 14.1953 3.72656C13.5391 2.57812 12.6367 1.67578 11.4883 1.01953C10.3398 0.339844 9.08594 0 7.72656 0Z" fill="currentColor"/>
                                            </svg>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M11.0543 0H2.66634C1.32752 0 0.238281 1.0798 0.238281 2.40699V10.722C0.238281 12.0493 1.32752 13.1293 2.66634 13.1293H11.0543C12.3931 13.1293 13.4825 12.0495 13.4825 10.722V2.40699C13.4825 1.0798 12.3933 0 11.0543 0ZM6.86028 10.8868C4.45636 10.8868 2.50048 8.94791 2.50048 6.56455C2.50048 4.18145 4.45636 2.24256 6.86028 2.24256C9.26449 2.24256 11.2205 4.18145 11.2205 6.56455C11.2205 8.94752 9.26424 10.8868 6.86028 10.8868ZM11.3605 3.13617C10.7915 3.13617 10.3287 2.6774 10.3287 2.11357C10.3287 1.54975 10.7915 1.09098 11.3605 1.09098C11.9293 1.09098 12.392 1.54975 12.392 2.11357C12.392 2.6774 11.9293 3.13617 11.3605 3.13617Z" fill="currentColor"/>
                                                <path d="M6.86154 3.70703C5.47375 3.70703 4.34375 4.8266 4.34375 6.20229C4.34375 7.57865 5.47375 8.69849 6.86154 8.69849C8.24988 8.69849 9.37891 7.57865 9.37891 6.20229C9.37891 4.82691 8.24949 3.70703 6.86154 3.70703Z" fill="currentColor"/>
                                            </svg>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <svg width="16" height="13" viewBox="0 0 16 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M15.918 1.51172C15.3555 1.76953 14.7461 1.94531 14.0898 2.03906C14.7695 1.61719 15.2383 1.01953 15.4961 0.246094C14.8633 0.621094 14.1836 0.878906 13.457 1.01953C12.8242 0.339844 12.0273 0 11.0664 0C10.1992 0 9.44922 0.316406 8.81641 0.949219C8.18359 1.58203 7.86719 2.34375 7.86719 3.23438C7.86719 3.46875 7.90234 3.71484 7.97266 3.97266C6.66016 3.90234 5.41797 3.57422 4.24609 2.98828C3.09766 2.37891 2.125 1.58203 1.32812 0.597656C1.04688 1.08984 0.90625 1.62891 0.90625 2.21484C0.90625 2.77734 1.03516 3.29297 1.29297 3.76172C1.55078 4.23047 1.89062 4.60547 2.3125 4.88672C1.82031 4.88672 1.33984 4.75781 0.871094 4.5V4.53516C0.871094 5.30859 1.11719 5.98828 1.60938 6.57422C2.10156 7.16016 2.71094 7.53516 3.4375 7.69922C3.17969 7.76953 2.89844 7.80469 2.59375 7.80469C2.40625 7.80469 2.20703 7.78125 1.99609 7.73438C2.20703 8.39062 2.58203 8.92969 3.12109 9.35156C3.68359 9.75 4.30469 9.96094 4.98438 9.98438C3.83594 10.8984 2.51172 11.3555 1.01172 11.3555C0.753906 11.3555 0.496094 11.3438 0.238281 11.3203C1.73828 12.2812 3.37891 12.7617 5.16016 12.7617C7.03516 12.7617 8.69922 12.2812 10.1523 11.3203C11.4883 10.4766 12.5312 9.32812 13.2812 7.875C13.9844 6.49219 14.3359 5.07422 14.3359 3.62109L14.3008 3.19922C14.9336 2.75391 15.4727 2.19141 15.918 1.51172Z" fill="currentColor"/>
                                            </svg>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M13.7383 13.5H10.75V8.4375C10.75 8.0625 10.5625 7.73438 10.1875 7.45312C9.83594 7.14844 9.46094 6.99609 9.0625 6.99609C8.66406 6.99609 8.33594 7.13672 8.07812 7.41797C7.84375 7.69922 7.72656 8.03906 7.72656 8.4375V13.5H4.73828V4.5H7.72656V6.01172C7.96094 5.61328 8.34766 5.29688 8.88672 5.0625C9.42578 4.80469 9.91797 4.67578 10.3633 4.67578C11.3008 4.67578 12.0977 5.01562 12.7539 5.69531C13.4102 6.35156 13.7383 7.13672 13.7383 8.05078V13.5ZM3.22656 13.5H0.238281V4.5H3.22656V13.5ZM1.75 0C2.14844 0 2.48828 0.152344 2.76953 0.457031C3.07422 0.738281 3.22656 1.08984 3.22656 1.51172C3.22656 1.91016 3.07422 2.26172 2.76953 2.56641C2.48828 2.84766 2.13672 2.98828 1.71484 2.98828C1.31641 2.98828 0.964844 2.84766 0.660156 2.56641C0.378906 2.26172 0.238281 1.91016 0.238281 1.51172C0.238281 1.08984 0.378906 0.738281 0.660156 0.457031C0.964844 0.152344 1.32812 0 1.75 0Z" fill="currentColor"/>
                                            </svg>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="copyright-section">
            <div class="copyright-wrapper">
                <p>Copyright © 2020 Al Saggaf. All Rights Reserved. Site by <a href="#">GO-Gulf</a></p>
                <ul class="h-list payment-ways">
                    <li><a href="#"><img src="{{ asset('images') }}/visa.png" alt="card icon"/></a></li>
                    <li><a href="#"><img src="{{ asset('images') }}/mada.png" alt="card icon"/></a></li>
                    <li><a href="#"><img src="{{ asset('images') }}/mastercard.png" alt="card icon"/></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<div class="action-btn-section">
    <div class="btn-holder">
        <div class="v-list">
            <span class="btn-item cog-go-top" data-toggle="modal" data-target="#preferencesModel"><i class="fa fa-cog"></i></span>
            <a href="javascript:void(0)" data-go-top="goToUP" class="btn-item arrow-go-top"><i class="fa fa-arrow-up"></i></a>
        </div>
    </div>
</div>