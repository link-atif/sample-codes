<!--Intro Banner-->
<section class="intro-banner">
    <div class="slick-instance banner-section">
        @foreach($content($id)->slider as $slide)
            <div class="banner-item">
                <div class="content-holder">
                    <div class="slider_j_st">
                        
                        <img class="image-item desktop_slider" src="{{ asset('images/slider') }}/{{ $slide->image }}" alt="">
                        <img class="image-item mobile_slider" src="{{ asset('images/slider') }}/{{ $slide->mobile_image }}" alt="">
                        {{-- <img class="image-item mobile_slider" src="https://alsaggaf.go-demo.com/images/mobi_03.png" alt=""> --}}
                        

                    <div class="container">
                        
                        <div class="banner-caption">
                            <h1>{!! nl2br($slide->headline) !!}</h1>
                            <a href="{{ $slide->button_link }}" class="btn btn-primary">{{ $slide->button_label }}</a>
                       
                            <!--<div class="slide-count-wrap">-->
                            <!--     @for ($i = 0; $i < count($content($id)->slider); $i++)-->
                            <!--    <span class="next-arrow1"><i class="fa fa-sm fa-circle"></i></span>-->
                            <!--     @endfor-->
                            <!--</div>-->
                           
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</section>