<div class="latest-media-section">
    <div class="container">
    <div class="title-head">
            <h2>Latest Media</h2>
    </div>
                    <div class="row latest-media-wrapper">
                        @foreach($content as $media)
                            <div class="col-sm-4">
                                <a href="{{ route('media.show', $media->id) }}">
                                    <div class="latest-media-item">
                                        <div class="image-holder">
                                            <img src="{{ asset('images/media') }}/{{ $media->image }}" alt="{{ $media->title }}" class="img-fluid" />
                                        </div>
                                        <div class="content-holder">
                                            <h4>{{ $media->title }}</h4>
                                           <!-- <p>{!! nl2br($media->short_description) !!}</p>-->
                                        </div>
                                    </div>
                                </a>
                            </div>
                        @endforeach
                    </div> 

        <div class="text-center">
            <a href="{{ route('media') }}" class="btn btn-transparent mb-45">More Media</a>
        </div>
    </div>
</div>