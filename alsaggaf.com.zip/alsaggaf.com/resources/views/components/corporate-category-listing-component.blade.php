<div class="product-category bg-white mt-minus pt-40 pb-0">
    <div class="container">
        <div class="product-wrapper">
            @foreach($content as $category)
                <a href="{{ route('corporate-category', $category->id) }}">
                <div class="product-list-item">
                    <div class="product-card">
                        <div class="product-image">
                            <img src="{{ asset('images/catalog/category') }}/{{ $category->thumbnail }}" alt="{{ $category->name }}" class="img-fluid"/>
                        </div>
                        <div class="product-title">
                            <a href="#">{{ $category->name }}</a>
                        </div>
                        <div class="quick-view mt-10">
                            <a class="btn btn-transparent" href="{{ route('corporate-category', $category->id) }}"><strong>Explore</strong></a>
                        </div>
                    </div>
                </div>
                </a>
            @endforeach 
        </div>
        <div class="text-center pt-10 pb-10">
            <a href="{{ route('corporate-all-products') }}" class="btn btn-transparent">View All</a>
        </div>
    </div>
</div>