<div class="product-category pt-0 pb-40">
    <div class="container">
        <div class="title-head pt-0 pb-30">
            <h2>{{ $content($id, $category)->category[0]->name }}</h2>
        </div>
        <div class="product-wrapper justify-content-start">
            @foreach($content($id, $category)->sub_categories as $category)
                <div class="product-list-item">
                    <div class="product-card">
                        <div class="product-image">
                            <img src="{{ asset('images') }}/catalog/category/{{ $category->thumbnail }}" alt="{{ $category->name }}" class="img-fluid"/>
                        </div>
                        <div class="product-title">
                            <a href="{{ route('category-detail-page', $category->id) }}"> {{ $category->name }} </a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>