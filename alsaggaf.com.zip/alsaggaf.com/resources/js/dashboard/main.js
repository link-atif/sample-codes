$(document).on("click", ".nav-icon", function () {
    $("body").addClass("show-mobile-nav");
});
$(document).on("click", ".menu-overlay", function () {
    $("body").removeClass("show-mobile-nav");
});




