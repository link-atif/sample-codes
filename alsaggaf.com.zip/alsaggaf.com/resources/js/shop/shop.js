require('./../bootstrap');
require('alpinejs');
window.Popper = require('popper.js').default;
window.$ = window.jQuery = require('jquery');
require('./../../../node_modules/bootstrap/dist/js/bootstrap');
require('./vendor/slick.min.js');
require('./vendor/jquery.countdown.min.js');
require('./vendor/jquery.nicescroll.min.js');
require('./main');

// Scripts added in html files:


// PDP Gallery Slider
$('.corporate-pdp-wrapper .pdp-gallery-slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    dots: true,
    asNavFor: '.pdp-thumb-slider'
});
$('.corporate-pdp-wrapper .pdp-thumb-slider').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    asNavFor: '.pdp-gallery-slider',
    dots: true,
    arrows:true,
    focusOnSelect: true,
    vertical: true,
    verticalSwiping: true,
    responsive: [
        {
            breakpoint:767,
            settings: {
                slidesToShow: 4,
                slidesToScroll: 1,
                vertical:false,
                verticalSwiping: false,
            }
        },
        {
            breakpoint:575,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                vertical:false,
                verticalSwiping: false,
            }
        }
    ]
});

$('.shop--pdp-wrapper .pdp-gallery-slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true
});

$('.quick-view-modal').on('shown.bs.modal', function (e) {
    $('.pdp-gallery-slider').slick('refresh');
    $('.quick-view-modal').addClass('open');
});

// Sales Counter
function getNextDate() {
    var nextDateForCounter = $('#salesCounterDate').html();
    return new Date(new Date(nextDateForCounter) );
}

$('#clock-c').countdown(getNextDate(), function(event) {
var $this = $(this).html(event.strftime(''
    + '<div class="date-item"><div class="h1">%D :</div> <div class="date-title">Days%!d</div> </div>'
    + '<div class="date-item"><div class="h1">%H :</div> <div class="date-title">Hours</div> </div>'
    + '<div class="date-item"><div class="h1">%M :</div> <div class="date-title">Minutes</div> </div>'
    + '<div class="date-item"><div class="h1">%S </div> <div class="date-title">Seconds</div> </div>'));
});

$(document).on("click", ".nav-item .custom-toggle", function(e){
    e.stopImmediatePropagation();
    $(this).parent().toggleClass("open");
    $(this).parent().find("> .dropdown-toggle").next().slideToggle();
});