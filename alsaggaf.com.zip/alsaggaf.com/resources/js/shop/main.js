$(document).ready(function () {
    $('.loginOptionsModal').click(function (event) {
        $("#openModal").removeClass('show');  
        $("#openModal").css('display', 'none');  
    });
    customScript.init({
        // main_header: ".main-header",
        nav_icon: ".main-header .nav-icon",
        // main_footer: ".main-footer",
    });
});

var self;
var customScript = {
    init: function (settings) {
        this.settings = settings;
        self = this;
        this.headerSticky();

        $('.boxscroll').niceScroll({
            cursorcolor: "#444",
            cursoropacitymin: 0.21,
            background: "#C4C4C4",
            cursorborder: "0",
            autohidemode: true,
            cursorminheight: 30,
            horizrailenabled:false
        });

        $('.widget-steps .h-scroll').niceScroll({
            cursorcolor: "#444",
            cursoropacitymin: 0.21,
            background: "#C4C4C4",
            cursorborder: "0",
            autohidemode: true,
            cursorminheight: 30,
            horizrailenabled: true
        });

        $('.boxSlimScroll').niceScroll({
            cursorcolor: "#0A2568",
            cursoropacitymin: 0.21,
            background: "#C4C4C4",
            cursorborder: "0",
            cursorwidth: 2,
            autohidemode: true,
            cursorminheight: 30,
            horizrailenabled:false
        });

        // $(".product-list-item").hover(function() {
        //     $(this).find('.quick-view').css("display","block");
        // },function(){
        //     $(this).find('.quick-view').css("display","none");
        //     }
        // );

        // this.moveToSection(".intro-anchor");
        // this.backTopScroll();
        $(function () {
            $('[data-toggle="tooltip"]').tooltip()
        });
        // $('.slick-instance').slick();

        var $gallery = $('.intro-banner .slick-instance');
        var $gallery1 = $('.brand-slider .slick-instance');
        var $teamSlider = $('.team-slider-wrapper .slick-instance');
        var slideCount = null;

        $(document).ready(function() {
            $gallery.slick({
                swipe: true,
                swipeToSlide: true,
                touchThreshold: 10,
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: true,
	            arrows: false,
                // prevArrow: $('.prev-arrow1'),
                // nextArrow: $('.next-arrow1'),
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                            dots: true,
                        }
                    }
                ]
            });
            $gallery1.slick({
                speed: 250,
                swipe: true,
                swipeToSlide: true,
                touchThreshold: 10,
                slidesToShow: 6,
                slidesToScroll: 6,
                dots: true,
	            arrows: false,
                // prevArrow: $('.prev-arrow'),
                // nextArrow: $('.next-arrow'),
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 4,
                            slidesToScroll: 4
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 3
                        }
                    }
                ]
            });

            $teamSlider.slick({
                speed: 250,
                swipe: true,
                swipeToSlide: true,
                touchThreshold: 10,
                slidesToShow: 4,
                slidesToScroll: 1,
                arrows:true,
                prevArrow: $('.prev-arrow'),
                nextArrow: $('.next-arrow'),
                responsive: [
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 3
                        }
                    },

                    {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1,
                        }
                    },

                    {
                        breakpoint: 575,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                        }
                    }
                ]
            });
        });

        var slideCount = null;
        $gallery.on('init', function(event, slick){
            slideCount = slick.slideCount;
            var $el = $('.intro-banner .slide-count-wrap').find('.total');
            $el.text(slideCount);
            // setSlideCount();
            setCurrentSlideNumber(slick.currentSlide);
        });

        $gallery.on('beforeChange', function(event, slick, currentSlide, nextSlide){
            setCurrentSlideNumber(nextSlide);
        });

        var slideCount = null;
        $gallery1.on('init', function(event, slick){
            slideCount = slick.slideCount;
            // setSlideCount();
            var $el = $('.brand-slider .slide-count-wrap').find('.total');
            $el.text(slideCount);
            setCurrentSlideNumber(slick.currentSlide);
        });

        $gallery1.on('beforeChange', function(event, slick, currentSlide, nextSlide){
            setCurrentSlideNumber(nextSlide);
        });

        $teamSlider.on('init', function(event, slick){
            slideCount = slick.slideCount;
            setSlideCount();
            setCurrentSlideNumber(slick.currentSlide);
        });

        $teamSlider.on('beforeChange', function(event, slick, currentSlide, nextSlide){
            setCurrentSlideNumber(nextSlide);
        });
        function setSlideCount() {
            var $el = $('.slide-count-wrap').find('.total');
            $el.text(slideCount);
        }

        function setCurrentSlideNumber(currentSlide) {
            var $el = $('.slide-count-wrap').find('.current');
            $el.text(currentSlide + 1);
        }

        /*Add class when scroll down*/
        $(window).on("scroll", function (event) {
            var scroll = $(window).scrollTop();
            if (scroll >= 50) {
                $(".action-btn-section .btn-item").addClass("show");
            } else {
                $(".action-btn-section .btn-item").removeClass("show");
            }
        });

        /*Animation anchor*/
        $('.arrow-go-top').on("click", function () {
            var navTarget =  $(this).attr('data-go-top');
            if(navTarget.length){
                $('html, body').animate({scrollTop : 0},800);
                return false;
            }
        });

        // new WOW().init();

        $(document).on("click", ".nav-icon", function () {
            $("body").addClass("show-mobile-nav");
        });
        $(document).on("click", ".menu-overlay", function () {
            $("body").removeClass("show-mobile-nav");
        });

        // Ajax auto complete search input form:
        $("#inputSearch").keyup(function(){
            //     $query = document.getElementById('inputSearch').value;
            
            var query = $('#inputSearch').val();
            var _token = $("input[name=_token]").val();
            if(query.length >= 4) {
                $.ajax({
                    url: "/ajax/search",
                    method: "POST",
                    headers: { 'csrftoken' : $("input[name=_token]").val(), '_token' : $("input[name=_token]").val() },
                    data: { _token: _token, query: query },
                    success: function (data) {
                        $("#searchResults .dropdown-cart").html(data);
                    }
                });
                $('#searchResults .dropdown-cart').show();
            } else {
                $('#searchResults .dropdown-cart').hide();
            }
        });
        $('body').click(function() {
            $('#searchResults .dropdown-cart').hide();
        });
        $.ajaxSetup({ headers: { 'csrftoken' : $("input[name=_token]").val(), '_token' : $("input[name=_token]").val() } });
    },

    /*--Sticky header --*/
    headerSticky: function (e) {
        if ($('.main-header').length > 0) {
            var stickyOffset = $('.main-header .primary-menu-wrapper').offset().top,
                stickyHeight = $('.main-header .primary-menu-wrapper').height();
                $(window).on('scroll' , function () {
                    if ($(window).scrollTop() >= stickyOffset) {
                        $('.main-header .primary-menu-wrapper').addClass('sticky');
                        $('.main-header .primary-menu-wrapper').css('padding-top', stickyHeight);
                    } else {
                        $('.main-header .primary-menu-wrapper').removeClass('sticky');
                        $('.main-header').css('padding-top', 0);
                }
            });
        }
    }



    // moveToSection: function (handler) {
    //     $(handler).on("click", function (event) {
    //         event.preventDefault();
    //         var ref = $(this).attr("data-ref");
    //         $("html, body").animate({
    //             scrollTop: $(ref).offset().top - 80
    //         }, 1000);
    //     });
    // },

    // backTopScroll: function () {
    //     $(window).scroll(function () {
    //         if ($(this).scrollTop() > 100) {
    //             $('.scrollbtn').fadeIn();
    //         } else {
    //             $('.scrollbtn').fadeOut();
    //         }
    //     });
    //     $('.scrollbtn').click(function () {
    //         $("html, body").animate({
    //             scrollTop: 0
    //         }, 600);
    //         return false;
    //     });
    // }
    
}