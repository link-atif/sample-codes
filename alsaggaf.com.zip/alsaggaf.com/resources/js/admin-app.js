require('./bootstrap');
require('alpinejs');
window.Popper = require('popper.js').default;
window.$ = window.jQuery = require('jquery');
require('./../../node_modules/bootstrap/dist/js/bootstrap');
require('./../../node_modules/bootstrap-datepicker/js/bootstrap-datepicker');
require('./dashboard/main');
$('.datepicker').datepicker({
    format: 'dd/mm/yyyy',
    startDate: '-3d'
});