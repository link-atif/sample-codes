<?php



use Illuminate\Support\Facades\Route;

// Dashboard Controller Imports

use App\Http\Controllers\Admin\AdminUserController;

use App\Http\Controllers\Admin\ProductsController;

use App\Http\Controllers\Admin\ProductCategoryController;

use App\Http\Controllers\Admin\ProductAttributeSetController;

use App\Http\Controllers\Admin\ConfigurateSimpleProductController;

use App\Http\Controllers\Admin\SliderController;

use App\Http\Controllers\Admin\BrandsCarousalSliderController;

use App\Http\Controllers\Admin\SalesOffersController;

use App\Http\Controllers\Admin\AdminProjectsController;

use App\Http\Controllers\Admin\CorporateChallangesController;

use App\Http\Controllers\Admin\AdminCorporateMediaController;

use App\Http\Controllers\Admin\OurTeamController;

use App\Http\Controllers\Admin\LocationController;
use App\Http\Controllers\Admin\NewsLetterController;
use App\Http\Controllers\Admin\ContactController;
use App\Http\Controllers\Admin\JobApplicationsController;
use App\Http\Controllers\Admin\CorporateCareerServicController;

use App\Http\Controllers\Admin\JobsOpeningController;

use App\Http\Controllers\Admin\BrandsController;

use App\Http\Controllers\Admin\CheckoutFormController;

use App\Http\Controllers\Admin\ProductOrdersController;

use App\Http\Controllers\Admin\ProductRefundsController;

use App\Http\Controllers\Admin\AdminFAQController;

use App\Http\Controllers\Admin\ProductCancelController;



// Shop Controller Imports

use App\Http\Controllers\Shop\ShopHomeController;

use App\Http\Controllers\Shop\ShopCategoryDetailController;

use App\Http\Controllers\Shop\ShopProductDetailController;

use App\Http\Controllers\Shop\ShopAllCategoryController;

use App\Http\Controllers\Shop\SalesListingController;

use App\Http\Controllers\Shop\ShopCartController;

use App\Http\Controllers\Shop\ShopCheckoutController;

use App\Http\Controllers\Shop\ShopB2CRegistraionController;

use App\Http\Controllers\Shop\MyAccountController;

use App\Http\Controllers\Shop\TermsAndConditionsController;

use App\Http\Controllers\Shop\ShippingAndDeliveryController;

use App\Http\Controllers\Shop\WarrantyPolicyController;

use App\Http\Controllers\Shop\ExchangeAndReturnPolicyController;

use App\Http\Controllers\Shop\AccountVerficationProcessController;

use App\Http\Controllers\Shop\FAQController;

use App\Http\Controllers\Shop\SearchController;

use App\Http\Controllers\Shop\RegistrationController;

use App\Http\Controllers\Shop\BestSellerController;



// Corporate Controller Imports

use App\Http\Controllers\Corporate\CorporateHomeController;

use App\Http\Controllers\Corporate\CorporateCategoryController;

use App\Http\Controllers\Corporate\CorporatePDPController;

use App\Http\Controllers\Corporate\CorporateProjectsController;

use App\Http\Controllers\Corporate\CorporateAboutUsController;

use App\Http\Controllers\Corporate\CorporateMediaController;

use App\Http\Controllers\Corporate\CorporateContactController;

use App\Http\Controllers\Corporate\CorporateCareerController;

use App\Http\Controllers\Corporate\CorporateCareerListingController;

use App\Http\Controllers\Corporate\CorporateBrandDetailPageController;

use App\Http\Controllers\Corporate\CorporateSearchController;

// CMS Controller Imports 

use App\Http\Controllers\Admin\AdminPageController;

use App\Http\Controllers\Admin\AdminComponentController;

Route::middleware(['auth:sanctum', 'verified'])->get('admin/products/file-import-export', [ProductsController::class,'fileImportExport'])->name('admin.products.file-import-export');
Route::middleware(['auth:sanctum', 'verified'])->post('admin/products/file-import', [ProductsController::class, 'fileImport'])->name('admin.products.file-import');

Route::middleware(['auth:sanctum', 'verified'])->get('/admin/products/search', [ProductsController::class, 'search'])->name('admin.products.search');

Route::middleware(['auth:sanctum', 'verified'])->post('/admin/category/search', [ProductCategoryController::class, 'search'])->name('admin.category.search');

Route::middleware(['auth:sanctum', 'verified'])->post('admin/products/file-update', [ProductsController::class, 'fileUpdate'])->name('admin.products.file-update');

Route::post('/ajax-search', [CorporateSearchController::class, 'loadMore'])->name('ajaxSearch');

/*

|--------------------------------------------------------------------------



| Web Routes

|--------------------------------------------------------------------------

|

| Here is where you can register web routes for your application. These

| routes are loaded by the RouteServiceProvider within a group which

| contains the "web" middleware group. Now create something great!

|

*/



// Shop Routes

Route::get('/abc', [ShopHomeController::class, 'index'])->name('home-page');

Route::post('/shop-category/{id}', [ShopCategoryDetailController::class, 'filterProducts'])->name('category-detail-page.filter');

Route::post('/best-seller', [BestSellerController::class, 'filterProducts'])->name('best-seller-page.filter');

Route::get('/shop-category/{id}', [ShopCategoryDetailController::class, 'index'])->name('category-detail-page');

Route::get('/category', [ShopAllCategoryController::class, 'index'])->name('all-category');

Route::get('/shop-product/{id}', [ShopProductDetailController::class, 'index'])->name('product-detail-page');

Route::get('/sales', [SalesListingController::class, 'index'])->name('sales-listing-page');

Route::post('/products/{product}/cart', [ProductsController::class, 'addToCart'])->name('admin.product.cart.add');

Route::delete('/products/{product}/cart', [ProductsController::class, 'removeFromCart'])->name('admin.product.cart.delete');

Route::get('/cart', [ShopCartController::class, 'index'])->name('shopping-cart');

Route::get('/shipping-and-contact-info', [ShopCheckoutController::class, 'index'])->name('shipping-and-contact-info');

Route::post('/update-cart/{id}', [ProductsController::class, 'updateCart'])->name('update-cart');

Route::post('/checkout-step-1', [CheckoutFormController::class, 'checkoutStep1'])->name('checkout-step-1');

Route::get('/review-and-payments/{id}', [CheckoutFormController::class, 'index'])->name('review-and-payments');

Route::post('/checkout-step-2/{id}', [CheckoutFormController::class, 'checkoutStep2'])->name('checkout-step-2');

Route::get('/thank-you/{id}/{order_id}', [CheckoutFormController::class, 'checkoutFinalStep'])->name('thank-you');

Route::get('/transaction-failed/{id}/{order_id}', [CheckoutFormController::class, 'transactionFailed'])->name('transaction-failed');

Route::get('/thank-you/purchase', [CheckoutFormController::class, 'paymentValidation'])->name('payment-validation');

Route::get('/signin', [RegistrationController::class, 'signin'])->name('signin');

Route::get('/registration/{f_user_r?}', [RegistrationController::class, 'index'])->name('registration');

Route::post('/registration/{f_user_r?}', [RegistrationController::class, 'signup'])->name('signup');

Route::get('/registration/{id}/user', [RegistrationController::class, 'user_type'])->name('user-type');

Route::get('/registration/{id}/preferences/{type}', [RegistrationController::class, 'preferences'])->name('preferences');

Route::post('/registration/{id}/preferences/{type}', [RegistrationController::class, 'savePreferences'])->name('preferences.save');

Route::get('/thanks-signup/{id}', [RegistrationController::class, 'thanksSignUp'])->name('thanks-signup');

Route::get('/distributor-registration', [RegistrationController::class, 'distributorRegistration'])->name('distributor-registration');

Route::post('/distributor-registration/{type}', [RegistrationController::class, 'saveDistributorRegistration'])->name('distributor-registration.save');

Route::get('/fe_user/{type}', [RegistrationController::class, 'saveUserType'])->name('save-user-type');

Route::post('/fe_user/preferences', [RegistrationController::class, 'saveUserPreferences'])->name('save-user-preferences');

Route::post('/fe_user/signin', [RegistrationController::class, 'feUserSignIn'])->name('fe_user_sign_in');

Route::post('/myaccount/logout', [MyAccountController::class, 'logOut'])->name('myaccount.logout');

Route::post('/myaccount/checkout-login', [MyAccountController::class, 'checkoutLogin'])->name('myaccount.checkout.login');

Route::get('/myaccount/orders', [MyAccountController::class, 'myOrders'])->name('myaccount.orders');

Route::get('/myaccount/orders/{id}', [MyAccountController::class, 'orderDetails'])->name('myaccount.orders.detail');

Route::get('/myaccount/orders/{id}/product/{p_id}/return', [MyAccountController::class, 'returnProduct'])->name('myaccount.orders.product.return');

Route::post('/myaccount/orders/{id}/product/{p_id}/return', [MyAccountController::class, 'applyReturn'])->name('myaccount.orders.product.return.apply');

Route::get('/myaccount/returns', [MyAccountController::class, 'myReturns'])->name('myaccount.returns');

Route::get('/myaccount', [MyAccountController::class, 'index'])->name('myaccount');

Route::get('/brands/{id}', [CorporateBrandDetailPageController::class, 'allProducts'])->name('brand-products');

Route::get('/terms-and-condtions', [TermsAndConditionsController::class, 'index'])->name('terms-and-conditions');

Route::get('/shipping-and-delivery', [ShippingAndDeliveryController::class, 'index'])->name('shipping-and-delivery');

Route::get('/warranty-policy', [WarrantyPolicyController::class, 'index'])->name('warranty-policy');

Route::get('/exchange-and-return-policy', [ExchangeAndReturnPolicyController::class, 'index'])->name('exchange-and-return-policy');

Route::get('/account-verification-process', [AccountVerficationProcessController::class, 'index'])->name('account-verification-process');

Route::get('/faq', [FAQController::class, 'index'])->name('faq');

Route::post('/ajax/search', [SearchController::class, 'ajaxSearch'])->name('ajax.search');

Route::post('/search', [SearchController::class, 'search'])->name('simple.search');

Route::post('/stock/product/{id}/notify', [ProductsController::class, 'notifyMe'])->name('product.qty.notify');

Route::get('/best-seller', [BestSellerController::class, 'index'])->name('best-seller');




// Corporate Routes:
Route::get('locales/{lang}', [LocalizationController::class, 'index']);

Route::group(['middleware'=> ['localization']], function(){
	Route::get('/Search', [CorporateSearchController::class, 'corporateSearch'])->name('corporateSearch');
	Route::post('/Search', [CorporateSearchController::class, 'corporateSearch'])->name('corporateSearch');
	Route::post('/autocomplete', [CorporateSearchController::class, 'autocomplete'])->name('autocomplete');
	Route::post('/ajax-search', [CorporateSearchController::class, 'loadMore'])->name('ajaxSearch');
	Route::get('/category/{id}/{brand_id?}', [CorporateCategoryController::class, 'index'])->name('corporate-category');
	Route::get('/product/{id}', [CorporatePDPController::class, 'index'])->name('corporate-product');
	Route::get('/products', [CorporateCategoryController::class, 'allProducts'])->name('corporate-all-products');
	Route::get('/products/featured', [CorporateCategoryController::class, 'allFeaturedProducts'])->name('corporate-all-products.featured');
	Route::get('/projects', [CorporateProjectsController::class, 'index'])->name('projects');
	Route::get('/about', [CorporateAboutUsController::class, 'index'])->name('about-us');
	Route::get('/media', [CorporateMediaController::class, 'index'])->name('media');
	Route::post('/ajax-media', [CorporateMediaController::class, 'loadMore'])->name('ajaxMedia');
	Route::post('/ajax-products', [CorporateCategoryController::class, 'loadMore'])->name('ajaxProducts');
	Route::get('/media/{id}', [CorporateMediaController::class, 'show'])->name('media.show');
	Route::get('/contact', [CorporateContactController::class, 'index'])->name('contact');
	Route::post('/contact', [CorporateContactController::class, 'store'])->name('contact.store');
	Route::get('/career', [CorporateCareerController::class, 'index'])->name('careers');
	Route::get('/career-listing', [CorporateCareerListingController::class, 'index'])->name('careers-listing');
	Route::get('/services-jobs/{id?}', [CorporateCareerListingController::class, 'index'])->name('services-jobs');
	Route::get('/career-listing/{id}', [JobsOpeningController::class, 'careerDetail'])->name('careers-detail');
	Route::post('/job-application', [JobsOpeningController::class, 'jobApplication'])->name('submit.application');
	Route::get('/brands/{id}', [CorporateBrandDetailPageController::class, 'index'])->name('brands-detail');
	Route::get('/all-products/{id}', [CorporateBrandDetailPageController::class, 'allProducts'])->name('brands-products');
	Route::get('/', [CorporateHomeController::class, 'index'])->name('corporate');
	Route::post('/newsletter', [CorporateHomeController::class, 'store'])->name('newsletter');
});


// require __DIR__.'/auth.php';



// Dashboard Routes

Route::middleware(['auth:sanctum', 'verified'])->get('/dashboard', function () {

    return view('admin.dashboard');

})->name('dashboard');



Route::middleware(['auth:sanctum', 'verified'])->resource('admin/user', AdminUserController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->delete('admin/products/{product}/image/{image}', [ProductsController::class, 'deleteImage'])->name('admin.product.image.destroy');

Route::middleware(['auth:sanctum', 'verified'])->post('admin/products/{product}/attr', [ProductsController::class, 'addProductSpecification'])->name('admin.product.specification.store');

Route::middleware(['auth:sanctum', 'verified'])->put('admin/products/{product}/attr/{attr_id}', [ProductsController::class, 'updateProductSpecification'])->name('admin.product.specification.update');

Route::middleware(['auth:sanctum', 'verified'])->delete('admin/products/{product}/attr/{attr_id}', [ProductsController::class, 'deleteProductSpecification'])->name('admin.product.specification.delete');

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/products/{p_id}/attribute', ConfigurateSimpleProductController::class, ['as'=> 'admin.products']);

Route::middleware(['auth:sanctum', 'verified'])->post('admin/products/category/{id}', [ProductsController::class, 'addProductCategory'])->name('admin.products.category.update');

Route::middleware(['auth:sanctum', 'verified'])->post('admin/products/{id}similar/product/{v_id}', [ProductsController::class, 'addSimilarProducts'])->name('admin.products.similar.update');

Route::middleware(['auth:sanctum', 'verified'])->get('admin/products/configureable-attributes', [ProductsController::class, 'createConfigureableAttributes'])->name('admin.products.configureable-products.create');

Route::middleware(['auth:sanctum', 'verified'])->post('admin/products/configureable-attributes/{id}/color', [ProductsController::class, 'addConfigureableAttributesColor'])->name('admin.product.color.store');

Route::middleware(['auth:sanctum', 'verified'])->put('admin/products/configureable-attributes/{id}/color', [ProductsController::class, 'updateConfigureableAttributesColor'])->name('admin.product.color.update');

Route::middleware(['auth:sanctum', 'verified'])->delete('admin/products/configureable-attributes/{id}/color', [ProductsController::class, 'deleteConfigureableAttributesColor'])->name('admin.product.color.delete');

Route::middleware(['auth:sanctum', 'verified'])->post('admin/products/configureable-attributes/{id}/size', [ProductsController::class, 'addConfigureableAttributesSize'])->name('admin.product.size.store');

Route::middleware(['auth:sanctum', 'verified'])->put('admin/products/configureable-attributes/{id}/size', [ProductsController::class, 'updateConfigureableAttributesSize'])->name('admin.product.size.update');

Route::middleware(['auth:sanctum', 'verified'])->delete('admin/products/configureable-attributes/{id}/size', [ProductsController::class, 'deleteConfigureableAttributesSize'])->name('admin.product.size.delete');

Route::middleware(['auth:sanctum', 'verified'])->post('admin/products/configureable-attributes/{id}/b2c/qty', [ProductsController::class, 'addB2CQty'])->name('admin.product.b2c.qty.store');

Route::middleware(['auth:sanctum', 'verified'])->put('admin/products/configureable-attributes/{id}/b2c/qty', [ProductsController::class, 'updateB2CQty'])->name('admin.product.b2c.qty.update');

Route::middleware(['auth:sanctum', 'verified'])->put('admin/products/configureable-attributes/{id}/b2b/qty', [ProductsController::class, 'updateB2BQty'])->name('admin.product.b2b.qty.update');

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/jobapplication', JobApplicationsController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/products', ProductsController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/category', ProductCategoryController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/attribute-set', ProductAttributeSetController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/slider', SliderController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/brands-carousal', BrandsCarousalSliderController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/project', AdminProjectsController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/timeline', CorporateChallangesController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/media', AdminCorporateMediaController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/location', LocationController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/team', OurTeamController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/division', CorporateCareerServicController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/jobs', JobsOpeningController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/sale', SalesOffersController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/brand', BrandsController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->post('admin/brand/{id}/sub_brand', [BrandsController::class, 'addSubBrand'])->name('admin.sub_brand.add');

Route::middleware(['auth:sanctum', 'verified'])->put('admin/sub_brand/{id}', [BrandsController::class, 'updateSubBrand'])->name('admin.sub-brand.update');

Route::middleware(['auth:sanctum', 'verified'])->delete('admin/sub_brand/{id}', [BrandsController::class, 'deleteSubBrand'])->name('admin.sub-brand.delete');

Route::middleware(['auth:sanctum', 'verified'])->put('admin/orders/{id}/status/', [ProductOrdersController::class, 'updateOrderStatus'])->name('admin.update-order-status');

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/orders', ProductOrdersController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->put('admin/refunds/{id}/status/', [ProductRefundsController::class, 'updateRefundStatus'])->name('admin.update-refund-status');

Route::middleware(['auth:sanctum', 'verified'])->post('admin/refunds/{id}/process/', [ProductRefundsController::class, 'processRefund'])->name('admin.update-refund.process');

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/refunds', ProductRefundsController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/cancellation', ProductCancelController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->get('admin/featured-products', [ProductsController::class, 'featuredProducts'])->name('admin.featured-products.index');

Route::middleware(['auth:sanctum', 'verified'])->post('admin/featured-products/{id}', [ProductsController::class, 'addFeaturedProduct'])->name('admin.featured-product.store');

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/{tt_content_id}/faq', AdminFAQController::class, ['as'=> 'admin']);
Route::middleware(['auth:sanctum', 'verified'])->resource('admin/newsletter', NewsLetterController::class, ['as'=> 'admin']);
Route::middleware(['auth:sanctum', 'verified'])->resource('admin/contact', ContactController::class, ['as'=> 'admin']);


// CMS Pages Route

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/pages', AdminPageController::class, ['as'=> 'admin']);

Route::middleware(['auth:sanctum', 'verified'])->resource('admin/component', AdminComponentController::class, ['as'=> 'admin']);



Route::any('/{any}', [ShopHomeController::class, 'index']);


