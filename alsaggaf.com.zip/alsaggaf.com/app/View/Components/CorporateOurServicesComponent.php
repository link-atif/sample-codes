<?php

namespace App\View\Components;

use Illuminate\View\Component;
use App\Models\TtContent;
use App\Models\Service;

class CorporateOurServicesComponent extends Component
{
    public $id;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($id)
    {
        $this->id = $id;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        return view('components.corporate-our-services-component');
    }

    /**
     *  Get The content
     * 
     */
    public function content($id) {
        $content = TtContent::find($id);
        $content->services = Service::leftJoin('jobs', 'services.id', '=', 'service_id')->groupBy('services.id')
                                       ->get();
        return $content;
    }
}
