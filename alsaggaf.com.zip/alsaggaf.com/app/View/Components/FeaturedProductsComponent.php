<?php

namespace App\View\Components;

use Illuminate\View\Component;
use App\Models\Product;
use App\Models\ProductCategory;


class FeaturedProductsComponent extends Component
{

    public $item;
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($id, $name)
    {
        $this->id = $id;
        $this->name = $name;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        return view('components.featured-products-component');
    }

    /**
     *  Get The content
     * 
     */
    public function content() {
        $content = Product::where('featured_product', 1)
                                ->where('category_id', 'LIKE', "%,".$this->id.",%")
                                ->limit(5)
                                ->get(); 
        $content->categoryName = $this->name;
        return $content;
    }
}
