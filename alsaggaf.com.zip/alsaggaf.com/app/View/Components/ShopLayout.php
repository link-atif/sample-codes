<?php

namespace App\View\Components;

use Illuminate\View\Component;
use App\Models\ProductCategory;

class ShopLayout extends Component
{
    /**
     * Get the view / contents that represents the component.
     *
     * @return \Illuminate\View\View
     */
    public function render()
    {
        $categories = ProductCategory::where('parent_id', 0)
                                        ->get();
        return view('shop.layouts.shop', compact('categories'));
    }
}
