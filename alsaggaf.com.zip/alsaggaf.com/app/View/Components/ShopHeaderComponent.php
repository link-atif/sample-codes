<?php

namespace App\View\Components;

use Cookie;
use Illuminate\View\Component;
use App\Models\FeUser;

class ShopHeaderComponent extends Component
{
    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        return view('components.shop-header-component');
    }

    /**
     *  Get The content
     * 
     */
    public function content() {
        if(request()->cookie('user_data')) {
            $user_data = unserialize(request()->cookie('user_data'));
            if($user_data['id'] != 0) {
                $content = FeUser::findOrFail($user_data['id']);
                if(array_key_exists('auth', $user_data) && $user_data['auth'] == true) {
                    $content->auth = true;
                } else {
                    $content->auth = false;
                }
            } else {
                $content = new FeUser;
                $content->auth = false;
            }
        } else {
            $content = new FeUser;
            $content->auth = false;
        }
        return $content;
    }
}
