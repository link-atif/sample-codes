<?php

namespace App\Imports;
use Image;
use App\Http\Controllers\Admin\ProductsController;
use App\Models\Product;
use App\Models\Brand;
use App\Models\ProductCategory;
use App\Models\ContentImage;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithStartRow;
use App\Models\ProductAttributeSet;
use Maatwebsite\Excel\Concerns\ToCollection;
use App\Models\ProductAttributeValue;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;
use Image as InterventionImage;
class ProductsImport implements ToCollection,WithStartRow
{
     public function startRow(): int
    {
        return 2;
    }

    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    private $type;

    public function __construct($type){
        $this->type = $type;
    }

   public function collection(Collection $rows)
    {    
        if($this->type === 'update')
        {
        foreach ($rows as $key => $row) {
             $product_id = Product::where('sku','=',$row[0])->pluck('id')->first();
            $check = ProductAttributeValue::where('product_id','=',$product_id)->get();
            if( $check->isEmpty()){

                if($row[1] != ""){
                $this->saveProductSpecifications($row[1], $product_id);
                 }
             }

            }
        }

        if($this->type === 'import')
        {
            foreach ($rows as $key => $row) {
            $array =  [
                'sku'                   => $row[0],
                'title'                 => $row[1],
                'description'           => $row[2],
                'status'                => $row[4],
                'featured_product'      => $row[5],
                'price'                 => $row[6],
                'category_id'           => $this->getCategoryId($row[7]),
                'brand_id'              => $this->getBrandsId($row[8])
            ];
            $id = DB::table('products')->insertGetId($array);
            if($row[9] != ""){
                $this->saveProductSpecifications($row[9], $id);
            } 
            if($row[3] != ""){
                $this->saveImages($row[3], $id);
            }
            }

        }
        
    }

    public function getCategoryId($string){
        if($string !=""){
            $ids =  [];
            $catString = explode(',',$string);
            if(count($catString) > 1){
                foreach ($catString as $key => $value) {
                    $cat = trim($value);
                    $id =  ProductCategory::where('name', '=', $cat)->pluck('id')->first();    
                    if($id != null){
                        $ids[] = $id;
                    }else{
                        $ids[] = DB::table('product_categories')->insertGetId(['name' => $cat, 'parent_id' => 0, 'featured' => 0]);
                    }
                }
                $catIds =  ',' . implode(',', $ids) . ',';
                return $catIds;
            }
            $id =  ProductCategory::where('name', '=', $catString)->pluck('id')->first();
            if($id != null){
                $catId =  ',' .  $id . ',';
            }else{
                $id = DB::table('product_categories')->insertGetId(['name' => $catString, 'parent_id' => 0, 'featured' => 0]);
                $catId =  ',' . $id . ',';   
            }
            return $catId;
        }
        return "";
    }   

    public function getBrandsId($string){
        if(!empty($string)){
            $id =  Brand::where('name', '=', $string)->pluck('id')->first();
            if($id != null){
                return $id;
            }else{
                $id = DB::table('brands')->insertGetId(['name' => $string]);
                return $id; 
            }
        }
        return "";
    }

    public function saveProductSpecifications($string, $id){
        if($string !=""){
            $specString = explode(',',$string);
            if(count($specString) > 1){
                foreach ($specString as $key => $s) {
                    $spec = trim($s);
                    $specs = explode(':', $spec);
                    if(count($specs) > 1){
                        $specId =  ProductAttributeSet::where('attribute_name', '=', $specs[0])->pluck('id')->first();    
                        if($specId != null){
                            $array = array(
                                'product_attribute_set_id' => $specId,
                                'product_id' => $id,
                                'value' => $specs[1],
                                'attribute_type' => 0,
                            );
                            DB::table('product_attribute_values')->insert($array);
                        }else{
                            $specId = DB::table('product_attribute_sets')->insertGetId(['attribute_name' => $specs[0], 'attr_type' => 0]);
                            $array = array(
                                'product_attribute_set_id' => $specId,
                                'product_id' => $id,
                                'value' => $specs[1],
                                'attribute_type' => 0,
                            );
                            DB::table('product_attribute_values')->insert($array);
                        }
                    }
                }
            }else{
                $spec = trim($string);
                $specs = explode(':', $spec);
                if(count($specs) > 1){
                    $specId =  ProductAttributeSet::where('attribute_name', '=', $specs[0])->pluck('id')->first();    
                    if($specId != null){
                        $array = array(
                            'product_attribute_set_id' => $specId,
                            'product_id' => $id,
                            'value' => $specs[1],
                            'attribute_type' => 0,
                        );
                        DB::table('product_attribute_values')->insert($array);
                    }else{
                        $specId = DB::table('product_attribute_sets')->insertGetId(['attribute_name' => $specs[0], 'attr_type' => 0]);
                        $array = array(
                            'product_attribute_set_id' => $specId,
                            'product_id' => $id,
                            'value' => $specs[1],
                            'attribute_type' => 0,
                        );
                        DB::table('product_attribute_values')->insert($array);
                    }
                }
            }
        }
    }

    public function saveImages($string, $id){
        if($string !=""){
            $image_name = explode(',',$string);
            foreach ($image_name as $key => $value) {
                if(file_exists('images/products/'.$value)){
                    $sourcePath = 'images/products/'.$value;
                    $filename   = 'images/catalog/products/'.$value;
                    InterventionImage::make($sourcePath)->resize(400, 400)->save($filename);
                    $allImages = array('product_id' => $id,'product_image' => $value);
                    if($key == 0){
                        $array = array('product_image' => $value);
                        DB::table('products')->where('id', '=', $id)->update($array);
                    }
                    DB::table('content_images')->insert($allImages);
                }
            }
        } 
    }
}
 