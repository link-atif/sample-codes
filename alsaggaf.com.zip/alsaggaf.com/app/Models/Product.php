<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Nicolaslopezj\Searchable\SearchableTrait;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;
    use SearchableTrait;

    /**
     * Searchable rules.
     *
     * @var array
     */

    protected $table ="products";
    protected $searchable = [
        /**
         * Columns and their priority in search results.
         * Columns with higher values are more important.
         * Columns with equal values have equal importance.
         *
         * @var array
         */
        'columns' => [
            'products.title' => 10,
        ],
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'sku',
        'title',
        'sku',
        'description',
        'product_image',
        'category_id',
        'product_specifications',
        'qty',
        'b2b_qty',
        'price',
        'cost',
        'product_type',
        'featured_product',
        'related_product_id',
        'similar_product_id',
        'returns_and_exchange',
        'shipment_information',
        'brand_id',
        'is_recommended',
        'sales_count',
        'certification',
        'origin',
        'material',
        'status',
        'warranty',
    ];

    public function getStatusAttribute($value)
    {
        return $value;
        // if($value == 0) {
        //     return 'In Active';
        // } else {
        //     return "<span class='text-success'>Active</span>";
        // }
    }

    /*
     *  Relation ship with category table
     * 
     * 
     */
    public function category() {
        return $this->belongsTo(ProductCategory::class);
    }

    public function getProductTypeAttribute($value)
    {
        if($value == 0) {
            return 'Simple Product';
        } else {
            return 'Configurable Product';
        }
    }

    public function images() {
        return $this->hasMany(ContentImage::class)->orderBy('id','DESC');
    }

    public function configurable_simple_product() {
        return $this->hasMany(ConfigurableSimpleProduct::class)->whereNotNull('qty');
    }

    public function b2b_configurable_simple_product() {
        return $this->hasMany(ConfigurableSimpleProduct::class)->whereNotNull('b2b_qty');
    }

    public function product_specifications_attributes() {
        return $this->hasMany(ProductAttributeValue::class, 'product_id', 'id')->where('attribute_type', 0);
    }

    public function brand() {
        return $this->belongsTo(Brand::class, 'brand_id', 'id');
    }

    public function color() {
        return $this->hasMany(Color::class, 'product_id', 'id');
    }

    public function size() {
        return $this->hasMany(Size::class, 'product_id', 'id');
    }

    public function configureable_attribute_value() {
        return $this->hasMany(ConfigureableAttributeValue::class, 'product_id', 'id');
    }
}