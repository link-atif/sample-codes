<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'tt_content_id',
        'name',
        'supervising_entity',
        'implementing',
        'year_of_execution',
        'contractor',
        'location',
        'products',
        'supplied',
        'description',
        'image',
    ];
}
