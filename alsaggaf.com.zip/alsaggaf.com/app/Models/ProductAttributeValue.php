<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductAttributeValue extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'product_attribute_set_id',
        'product_id',
        'value',
        'attribute_type',
    ];

    /*
     *  Relation ship with category table
     * 
     * 
     */
    public function product_attribute_set() {
        return $this->belongsTo(ProductAttributeSet::class);
    }
}
