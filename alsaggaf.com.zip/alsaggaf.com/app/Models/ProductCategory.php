<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Nicolaslopezj\Searchable\SearchableTrait;
use Illuminate\Database\Eloquent\Model;

class ProductCategory extends Model
{
    use HasFactory;
    use SearchableTrait;

    protected $table ="product_categories";
    protected $searchable = [
        /**
         * Columns and their priority in search results.
         * Columns with higher values are more important.
         * Columns with equal values have equal importance.
         *
         * @var array
         */
        'columns' => [
            'product_categories.name' => 10,
        ],
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */


    protected $fillable = [
        'name',
        'parent_id',
        'order',
        'parent',
        'featured',
        'catalog',
    ];

    public function getParentAttribute($value)
    {
        if($this->parent_id == 0) {
            return 'Root Category';
        } else {
            $category = ProductCategory::findOrFail($this->parent_id);
            return $category->name;
        }
    }
}
