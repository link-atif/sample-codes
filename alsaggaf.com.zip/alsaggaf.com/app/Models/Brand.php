<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Brand extends Model
{
    use HasFactory;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'short_description',
        'website',
        'email',
        'description',
    ];

    public function sub_brands() {
        return $this->hasMany(SubBrand::class, 'brand_id', 'id');
    }
}
