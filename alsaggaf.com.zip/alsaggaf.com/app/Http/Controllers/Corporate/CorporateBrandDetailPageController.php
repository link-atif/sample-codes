<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Brand;
use App\Models\Product;

class CorporateBrandDetailPageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        $brand = Brand::findOrFail($id);
        return view('corporate.pages.brand-detail', compact('brand'));
    }

    public function allProducts($id) {
        $brand = Brand::findOrFail($id);
        $brands = Brand::get();
        $products = Product::where('brand_id', $id)
                                ->where('status', 1)
                                ->latest()
                                ->paginate(15);
        return view('corporate.pages.brands-product', compact('products', 'brand', 'brands'));
    }
}
