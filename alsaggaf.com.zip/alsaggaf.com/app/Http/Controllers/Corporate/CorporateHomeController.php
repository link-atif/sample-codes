<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TtContent;
use App\Models\NewsLetter;
use App\Models\ProductCategory;
use App\Models\Product;

class CorporateHomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tt_contents = TtContent::where('page_id', 6)
                                    ->get();
        $features = ProductCategory::select('product_categories.id','product_categories.featured','product_categories.name')
        ->where('product_categories.featured', 1)
        ->join('products','product_categories.id','=','products.category_id')->groupBy('product_categories.id')->get();
        
        return view('corporate.pages.index', compact(['tt_contents', 'features']));
    }

    public function store(Request $request)
      {
         $input = $request->all();
         $request->validate([
          'email' => 'required|email|unique:news_letters|max:255',
         ]);

         $check = NewsLetter::create($input);
         $arr = array('msg' => 'Something went wrong. Please try again later', 'status' =>false);
         if($check){ 
            $arr = array('msg' => 'Successfully Submitted', 'status' => true);
         }
        return response()->json($arr);
      }
}
