<?php

namespace App\Http\Controllers\Corporate;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\TtContent;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\Brand;
class CorporateCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id = 0, $brand_id = "")
    {
        $parent_categories = ProductCategory::where('parent_id', 0)
                                                ->get();
        $categories = array();
        $count = 0;
        foreach($parent_categories as $category){
            $categories[$count] = $category;
            $categories[$count]->sub_categories = $this->subCategories($category->id);
            $count++;
        }
        if($id == 0) {
            $id = $categories[0]->id;
        }
        $category = ProductCategory::findOrFail($id);
        $brands =  $this->getBrands($id);
        $array = array(
            'status' => 1,
        );
        if($brand_id !=""){
            $array['brand_id'] = $brand_id;
        }
        $products = Product::latest()
                                ->where('category_id', 'LIKE', "%,".$id.",%")
                                ->where($array)
                                ->paginate(15);
        return view('corporate.pages.category', compact(['products', 'categories', 'category', 'brands', 'brand_id']));
    }

    public function subCategories($id) {
        $categories =  ProductCategory::where('parent_id', $id)
                                        ->orderBy('order', 'ASC')
                                        ->get();
        return $categories;
    }

    public function getBrands($id){
        $brands = [];
        $brandIds = Product::selectRaw('DISTINCT(brand_id)')->where('brand_id', '!=', null)
        ->where('status', 1)->where('category_id', 'LIKE', "%,".$id.",%")->get()->toArray();
        if(!empty($brandIds)){
            foreach($brandIds as $key => $b){
                $brands[$key]['name'] = Brand::where('id', $b['brand_id'])->pluck('name')->first();    
                $brands[$key]['id'] = $b['brand_id']; 
            }
        }
        return $brands;
    }   

    public function allProducts($id = 0) {
        $parent_categories = ProductCategory::where('parent_id', 0)
                                                ->get();
        $categories = array();
        $count = 0;
        foreach($parent_categories as $category){
            $categories[$count] = $category;
            $categories[$count]->sub_categories = $this->subCategories($category->id);
            $count++;
        }
        if($id == 0) {
            $id = $categories[0]->id;
        }
        $category = ProductCategory::findOrFail($id);
        $products = Product::where('title', '!=', "")->where('status', 1)->paginate(15);
        return view('corporate.pages.products', compact(['products', 'categories', 'category']));
    }
    
    public function allFeaturedProducts($id = 0) {
        $parent_categories = ProductCategory::where('parent_id', 0)
                                                ->get();
        $categories = array();
        $count = 0;
        foreach($parent_categories as $category){
            $categories[$count] = $category;
            $categories[$count]->sub_categories = $this->subCategories($category->id);
            $count++;
        }
        if($id == 0) {
            $id = $categories[0]->id;
        }
        $category = ProductCategory::findOrFail($id);
        $products = Product::where('featured_product', 1)
                                ->where('status', 1)
                                ->paginate(20);
        return view('corporate.pages.featured-products', compact(['products', 'categories', 'category']));
    }
}
