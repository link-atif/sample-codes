<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Models\ProductCategory;
use Image;

class ProductCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($offset = 20)
    {
        $categories = ProductCategory::paginate($offset);
        return view('admin.category.index', compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

     public function search(Request $request) {

      $name = $request->input('name');

        if($name === null)
            return redirect('admin/category');
        if($name != '')
        {   $categories = ProductCategory::where('name','like','%'.$name.'%')
                            ->paginate(20);
        }
 
        return view('admin.category.index', compact(['categories','name']));
    }

    public function create()
    {
        $categories = ProductCategory::get();
        $categoryArray = array();
        $categoryArray[0] = 'Root Category';
        $product_categories = ProductCategory::where('parent_id', '0')
                                                ->orderBy('order', 'ASC')
                                                ->get();
        foreach($product_categories as $category) {
            $categoryArray[$category->id] = $category->name;
            $subCategoryArray = $this->subCategories($category->id, 1);
            foreach($subCategoryArray as $key => $sub_category) {
                $categoryArray[$key] = $sub_category;
            }
        }
        $categories->product_categories = $categoryArray;
        return view('admin.category.create', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Form Validation
        $this->validate($request, [
            'name' => 'required|string',
            'order' => 'required|integer',
            'parent_id' => 'required',
            'featured' => 'required',
            'description' => 'required',
            'thumbnail' => 'required',
           
        ]);

        $product_category = new ProductCategory;
        if($thumbnail = $request->file('thumbnail')) {
            $name = $thumbnail->getClientOriginalName();
            $oldImage4 = $product_category->thumbnail;
            File::delete('images/catalog/category/'.$oldImage4);
            $count = 1;
            while(file_exists('images/'.$name)) {
                $filename = pathinfo($name, PATHINFO_FILENAME);
                $extension = pathinfo($name, PATHINFO_EXTENSION);
                $name = pathinfo($thumbnail->getClientOriginalName(), PATHINFO_FILENAME).'-'.$count++.'.'.$extension;
            }
            Image::make($thumbnail)->resize(300, 300)->save('images/catalog/category/'.$name);
            //$thumbnail->move('images/catalog/category/',$name);
            $product_category->thumbnail = $name;
        }
     
        if($catalog = $request->file('catalog')) {
            $file=$request->catalog;        
            $filename=time().'.'.$file->getClientOriginalExtension();
            $request->catalog->move('assets',$filename);
            $product_category->catalog=$filename;
        }

        $product_category->name = $request->name;
        $product_category->order = $request->order;
        $product_category->parent_id = $request->parent_id;
        $product_category->featured = $request->featured;
        $product_category->description = $request->description;

        $product_category->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Category added successfully...');
        return redirect('admin/category');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

   
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $category = ProductCategory::findOrFail($id);
        $categoryArray = array();
        $categoryArray[0] = 'Root Category';
        $product_categories = ProductCategory::where('parent_id', '0')
                                                ->orderBy('order', 'ASC')
                                                ->get();
        foreach($product_categories as $main_category) {
            $categoryArray[$main_category->id] = $main_category->name;
            $subCategoryArray = $this->subCategories($category->id, 1);
            foreach($subCategoryArray as $key => $sub_category) {
                $categoryArray[$key] = $sub_category;
            }
        }
        $category->product_categories = $categoryArray;
        return view('admin.category.edit', compact('category'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $product_category = ProductCategory::findOrFail($id);
    
        if($thumbnail = $request->file('thumbnail')) {
            $name = $thumbnail->getClientOriginalName();
            $oldThumbnail = $product_category->thumbnail;
            File::delete('images/catalog/category/'.$oldThumbnail);
            $count = 1;
            while(file_exists('images/'.$name)) {
                $filename = pathinfo($name, PATHINFO_FILENAME);
                $extension = pathinfo($name, PATHINFO_EXTENSION);
                $name = pathinfo($thumbnail->getClientOriginalName(), PATHINFO_FILENAME).'-'.$count++.'.'.$extension;
            }
            Image::make($thumbnail)->resize(300, 300)->save('images/catalog/category/'.$name);
            //$thumbnail->move('images/catalog/category/',$name);
            $product_category->thumbnail = $name;
        }
        if($catalog = $request->file('catalog')) {
            $file=$request->catalog;
            $filename=time().'.'.$file->getClientOriginalExtension();
            $request->catalog->move('assets',$filename);
            $product_category->catalog=$filename;
        }
        
        $product_category->name = $request->name;
        $product_category->order = $request->order;
        $product_category->parent_id = $request->parent_id;
        $product_category->featured = $request->featured;
        $product_category->description = $request->description;
        $product_category->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Category updated successfully...');
        return redirect('admin/category');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        ProductCategory::destroy($id);
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Category deleted successfully...');
        return redirect('admin/category');
    }

    public function subCategories($id, $level) {
        $categoryArray = array();
        $categories =  ProductCategory::where('parent_id', $id)
                                        ->orderBy('order', 'ASC')
                                        ->get();
        foreach($categories as $product_category) {
            if($level == 1) {
                $categoryArray[$product_category->id] = '- '.$product_category->name;
            } else if($level == 2) {
                $categoryArray[$product_category->id] = '-- '.$product_category->name;
            } else if($level == 3) {
                $categoryArray[$product_category->id] = '--- '.$product_category->name;
            } else if($level == 4) {
                $categoryArray[$product_category->id] = '---- '.$product_category->name;
            } else if($level == 5) {
                $categoryArray[$product_category->id] = '----- '.$product_category->name;
            } else if($level == 6) {
                $categoryArray[$product_category->id] = '------ '.$product_category->name;
            } else if($level == 7) {
                $categoryArray[$product_category->id] = '------- '.$product_category->name;
            } else if($level == 8) {
                $categoryArray[$product_category->id] = '-------- '.$product_category->name;
            } else if($level == 9) {
                $categoryArray[$product_category->id] = '--------- '.$product_category->name;
            } else if($level == 10) {
                $categoryArray[$product_category->id] = '----------- '.$product_category->name;
            }
            $subCategoryArray = $this->subCategories($product_category->id, $level);
            foreach($subCategoryArray as $key => $sub_category) {
                if($level == 1) {
                    $categoryArray[$key] = '- '.$sub_category;
                } else if($level == 2) {
                    $categoryArray[$key] = '-- '.$sub_category;
                } else if($level == 3) {
                    $categoryArray[$key] = '--- '.$sub_category;
                } else if($level == 4) {
                    $categoryArray[$key] = '---- '.$sub_category;
                } else if($level == 5) {
                    $categoryArray[$key] = '----- '.$sub_category;
                } else if($level == 6) {
                    $categoryArray[$key] = '------ '.$sub_category;
                } else if($level == 7) {
                    $categoryArray[$key] = '------- '.$sub_category;
                } else if($level == 8) {
                    $categoryArray[$key] = '-------- '.$sub_category;
                } else if($level == 9) {
                    $categoryArray[$key] = '--------- '.$sub_category;
                } else if($level == 10) {
                    $categoryArray[$key] = '----------- '.$sub_category;
                }
            }
        }
        return $categoryArray;
    }
}
