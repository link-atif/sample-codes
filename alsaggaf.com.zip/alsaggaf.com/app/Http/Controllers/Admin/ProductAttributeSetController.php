<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ProductAttributeSet;

class ProductAttributeSetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($offset = 20)
    {
        $product_attribute_sets = ProductAttributeSet::paginate($offset);
        return view('admin.attribute_set.index', compact('product_attribute_sets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.attribute_set.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Form Validation
        $this->validate($request, [
            'attribute_name' => 'required|string',
        ]);

        $product_attribute = new ProductAttributeSet;
        $product_attribute->attribute_name = $request->attribute_name;
        $product_attribute->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Attribute added successfully...');
        return redirect('admin/attribute-set');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product_attribute_set = ProductAttributeSet::findOrFail($id);
        return view('admin.attribute_set.edit', compact('product_attribute_set'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $product_attribute = ProductAttributeSet::findOrFail($id);
        $product_attribute->attribute_name = $request->attribute_name;
        $product_attribute->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Attribute updated successfully...');
        return redirect('admin/attribute-set');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        ProductAttributeSet::destroy($id);
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Attribute deleted successfully...');
        return redirect('admin/attribute-set');
    }
}
