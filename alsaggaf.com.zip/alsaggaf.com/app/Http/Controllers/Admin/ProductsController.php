<?php

namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\Input;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Cookie;
use Illuminate\Support\Facades\File;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ProductsImport;
use App\Exports\ProductsExport;
use App\Models\ProductCategory;
use App\Models\Product;
use App\Models\ContentImage;
use App\Models\ProductAttributeSet;
use App\Models\ProductAttributeValue;
use App\Models\Brand;
use App\Models\SubBrand;
use App\Models\CartDetail;
use App\Models\Order;
use App\Models\ConfigureableAttribute;
use App\Models\Color;
use App\Models\Size;
use App\Models\ConfigureableAttributeValue;
use App\Models\NotifyMeStock;
use Image;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::where('title','!=', '')->paginate(20);
        $categoryArray = array();
        $product_categories = ProductCategory::where('parent_id', '0')
                                                ->orderBy('order', 'ASC')
                                                ->get();
        foreach($product_categories as $category) {
            $categoryArray[$category->id] = $category->name;
            $subCategoryArray = $this->subCategories($category->id, 1);
            foreach($subCategoryArray as $key => $sub_category) {
                $categoryArray[$key] = $sub_category;
            }
        }
        $categories = $categoryArray;

        return view('admin.products.index', compact(['products','categories']));
    }

     public function fileImportExport()
    {
       return view('admin.products.fileimport');
    }
    /**
    * @return \Illuminate\Support\Collection
    */
    public function fileImport(Request $request) 
    {

    Excel::import(new ProductsImport('import'), $request->file('filename'));
        //->update('temp'));
       
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data added successfully...');
        return back();
    }    

    public function fileUpdate(Request $request) 
    {

    Excel::import(new ProductsImport('update'), $request->file('filename'));
        //->update('temp'));
       
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data updated successfully...');
        return back();
    }

    public function search(Request $request) {

         $categoryArray = array();
        $product_categories = ProductCategory::where('parent_id', '0')
                                                ->orderBy('order', 'ASC')
                                                ->get();
        foreach($product_categories as $category) {
            $categoryArray[$category->id] = $category->name;
            $subCategoryArray = $this->subCategories($category->id, 1);
            foreach($subCategoryArray as $key => $sub_category) {
                $categoryArray[$key] = $sub_category;
            }
        }
        $categories = $categoryArray;
       $name = $request->input('name');
       $id = $request->input('id');
        $category = $request->input('category');

        if($name === null && $category === null && $id === null)
        {
            return redirect('admin/products');
        }
        
        if($name != '' && $category === null && $id === null)
        {  
            $products = Product::where('title','like','%'.$name.'%')->paginate(20);
        }
        if($id != '' && $name === null && $category === null)
        {  
            $products = Product::where('sku','=',$id)->paginate(20);
        }
        if($category != '' && $name === null && $id === null)
        {
            $products = Product::whereRaw("FIND_IN_SET($category,category_id)")->paginate(20);
        }
        if($name != '' && $category != '')
        {
            $products = Product::where('title','like','%'.$name.'%')
                        ->orwhere('sku','=',$id)
                        ->whereRaw("FIND_IN_SET($category,category_id)")
                        ->paginate(20);
        }
        
        return view('admin.products.index', compact(['products','categories','name','id','category']));
       
    }


    public static function getCategory($string){
        if($string !=""){
            $catString =  [];
            $catId = explode(',',$string);
            if(count($catId) > 1){
                foreach ($catId as $key => $value) {
                    $cat = trim($value);
                    $name =  ProductCategory::where('id', '=', $cat)->pluck('name')->first();  
                    $catString[] = $name;
                }
                $category = trim(implode(',', $catString),",");
                return $category;
            }
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //return view('admin.products.check-product-type');
        $product = new Product;
        $product->product_type = 0;
        $product->save();
        return redirect('admin/products/'.$product->id.'/edit');
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function createConfigureableAttributes()
    {
        return view('admin.products.create-configureable-attributes');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Form Validation
        $this->validate($request, [
            'product_type' => 'required',
        ]);
        $product = new Product;
        $product->product_type = $request->product_type;
        $product->save();
        return redirect('admin/products/'.$product->id.'/edit');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product = Product::findOrFail($id);
        $categoryArray = array();
        $product_categories = ProductCategory::where('parent_id', '0')
                                                ->orderBy('order', 'ASC')
                                                ->get();

        foreach($product_categories as $category) {
            $categoryArray[$category->id] = $category->name;
            $subCategoryArray = $this->subCategories($category->id, 1);
            foreach($subCategoryArray as $key => $sub_category) {
                $categoryArray[$key] = $sub_category;
            }
        }
        $categories = $categoryArray;




        foreach($product_categories as $category) {
            $category->sub = ProductCategory::where('parent_id', $category->id)
                                                ->orderBy('order', 'ASC')
                                                ->get();
        } 
        $product->product_categories = $product_categories;

        $product->similar_products = Product::where('id', '!=', $product->id)
                                                ->paginate(20);
        $brandArray = array();
        $product_brands = Brand::get();
        foreach($product_brands as $brand) {
            $brandArray[$brand->id] = $brand->name;
        }
        $product->brands = $brandArray;
        $subBrandArray = array();
        $product_sub_brands = SubBrand::get();
        foreach($product_sub_brands as $sub_brand) {
            $subBrandArray[$sub_brand->id] = $sub_brand->name;
        }
        $product->sub_brands = $subBrandArray;
        $productSpecificationsAttributesArray= array();
        $attributes = ProductAttributeSet::where('attr_type', 0)
                                                ->get();
        foreach($attributes as $attribute) {
            $productSpecificationsAttributesArray[$attribute->id] = $attribute->attribute_name;
        }
        $product->product_specification_attributes = $productSpecificationsAttributesArray;
        $product->product_specifications_attributes_values = ProductAttributeValue::where('product_id', $product->id)
                                                                            ->where('attribute_type', 0)
                                                                            ->get();
        if($product->product_type == 'Simple Product') {
            return view('admin.products.create', compact(['product','categories']));
        } else {
            $attributes = ProductAttributeSet::get();
            $attributesArray = array();
            foreach($attributes as $attr) {
                $attributesArray[$attr->id] = $attr->attribute_name;
            }
            $product->attributes = $attributesArray;
           
            return view('admin.products.configureable-product-create', compact(['product','categories']));
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // dd($request);
        $product = Product::findOrFail($id);
        if($request->hasFile('product_image')) {
            $allImagesPaths = array();
            $counter = 0;
            foreach($request->file('product_image') as $image) {
                $destinationPath = 'images/catalog/products/';
                $filename = $image->getClientOriginalName();
                $name = $filename;
                $count = 1;
                while(file_exists('images/catalog/products/'.$filename)) {
                    $filename = pathinfo($name, PATHINFO_FILENAME);
                    $extension = pathinfo($name, PATHINFO_EXTENSION);
                    $filename = pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME).'-'.$count++.'.'.$extension;
                }
                Image::make($image)->resize(400, 400)->save('images/catalog/products/'.$filename);
                //$image->move($destinationPath, $filename);
                $allImagesPaths[ ]['product_image'] = $filename;
                if($counter == 0) {
                    $product->product_image = $filename;
                    $counter++;
                }
            }
            $product->images()->createMany($allImagesPaths);
        }
        $product->title = $request->title;
        $product->sku = $request->sku;
        $product->description = $request->description;
        $product->featured_product = $request->featured_product;
        $product->product_specifications = $request->product_specifications;
        $product->returns_and_exchange = $request->returns_and_exchange;
        $product->shipment_information = $request->shipment_information;
        $product->warranty = $request->warranty;
        //$product->is_recommended = $request->is_recommended;
        if($product->product_type == 0) {
            $product->qty = $request->qty;
            //$product->b2b_qty = $request->b2b_qty;
        }
        $product->price = $request->price;
        $product->cost = $request->cost;
        $product->brand_id = $request->brand_id;
        //$product->sub_brand_id = $request->sub_brand_id;
        $product->origin = $request->origin;
        $product->material = $request->material;
        //$product->certification = $request->certification;
       // $product->prod_type = $request->prod_type;
        $product->status = $request->status;

        if($request->category_id) {
            $product->category_id =  ',' . implode(',', $request->category_id) . ',';
        }

        $product->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect('admin/products/'.$product->id.'/edit');
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function addConfigureableAttributesColor(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $configureableAttribute = ConfigureableAttribute::where('product_id', $product->id)
                                                            ->get();
        if($configureableAttribute->isNotEmpty()) {
            $configureableAttribute = ConfigureableAttribute::findOrFail($configureableAttribute[0]->id);
            $configureableAttribute->color = $configureableAttribute->color + 1;
            $configureableAttribute->save();

            $color = new Color;
            $color->product_id = $product->id;
            $color->configureable_attribute_id = $configureableAttribute->id;
            $color->color = $request->color;
            $color->save();
        } else {
            $configureableAttribute = new ConfigureableAttribute;
            $configureableAttribute->product_id = $product->id;
            $configureableAttribute->color = 1;
            $configureableAttribute->save();

            $color = new Color;
            $color->product_id = $product->id;
            $color->configureable_attribute_id = $configureableAttribute->id;
            $color->color = $request->color;
            $color->save();
        }

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect()->back();
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateConfigureableAttributesColor(Request $request, $id)
    {
        $color = Color::findOrFail($id);
        $color->color = $request->color;
        $color->save();

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect()->back();
    }
    
    /**.
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteConfigureableAttributesColor($id)
    {
        $color = Color::findOrFail($id);
        $configureableAttributeId = $color->configureable_attribute_id;
        $color->delete();

        $configureableAttribute = ConfigureableAttribute::findOrFail($configureableAttributeId);
        $configureableAttribute->color = $configureableAttribute->color -1;
        $configureableAttribute->save();

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect()->back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function addConfigureableAttributesSize(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $configureableAttribute = ConfigureableAttribute::where('product_id', $product->id)
                                                            ->get();
        if($configureableAttribute->isNotEmpty()) {
            $configureableAttribute = ConfigureableAttribute::findOrFail($configureableAttribute[0]->id);
            $configureableAttribute->size = $configureableAttribute->size + 1;
            $configureableAttribute->save();

            $size = new Size;
            $size->product_id = $product->id;
            $size->configureable_attribute_id = $configureableAttribute->id;
            $size->size = $request->size;
            $size->save();
        } else {
            $configureableAttribute = new ConfigureableAttribute;
            $configureableAttribute->product_id = $product->id;
            $configureableAttribute->size = 1;
            $configureableAttribute->save();

            $size = new Size;
            $size->product_id = $product->id;
            $size->configureable_attribute_id = $configureableAttribute->id;
            $size->size = $request->size;
            $size->save();
        }

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect()->back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateConfigureableAttributesSize(Request $request, $id)
    {
        $size = Size::findOrFail($id);
        $size->size = $request->size;
        $size->save();

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect()->back();
    }
    
    /**.
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteConfigureableAttributesSize($id)
    {
        $size = Size::findOrFail($id);
        $configureableAttributeId = $size->configureable_attribute_id;
        $size->delete();

        $configureableAttribute = ConfigureableAttribute::findOrFail($configureableAttributeId);
        $configureableAttribute->size = $configureableAttribute->color -1;
        $configureableAttribute->save();

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect()->back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function addB2CQty(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $configureableAttributeValue = new ConfigureableAttributeValue;
        $configureableAttributeValue->color = $request->color ? $request->color : null;
        $configureableAttributeValue->size = $request->size ? $request->size : null;
        $configureableAttributeValue->product_id = $id;
        $configureableAttributeValue->qty = $request->qty;
        $configureableAttributeValue->save();

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect()->back();
    }
     
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateB2CQty(Request $request, $id)
    {
        $configureableAttributeValue = ConfigureableAttributeValue::findOrFail($id);
        $configureableAttributeValue->qty = $request->qty;
        $configureableAttributeValue->save();

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect()->back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateB2BQty(Request $request, $id)
    {
        $configureableAttributeValue = ConfigureableAttributeValue::findOrFail($id);
        $configureableAttributeValue->b2b_qty = $request->b2b_qty;
        $configureableAttributeValue->save();

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product data saved successfully...');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = Product::findOrFail($id);
        $images = ContentImage::where('product_id', $id)
                                    ->get();
       $status = $product->delete();
       if($status) {
            foreach($images as $image) {
                $img = $image->product_image;
                File::delete('images/catalog/products/'.$img);
                $image->delete();
            }
            \Session::flash('status', 'Success'); 
            \Session::flash('message', 'Product deleted successfully...');
            return redirect('admin/products');
        } else {
            \Session::flash('status', 'Error'); 
            \Session::flash('message', 'Some thing went wrong, Please try again later...');
            return redirect('admin/products');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteImage($product_id, $image_id)
    {
        $image = ContentImage::findOrFail($image_id);
        $status = ContentImage::destroy($image_id);
        if($status) {
            File::delete('images/catalog/products/'.$image->product_image);
            \Session::flash('status', 'Success'); 
            \Session::flash('message', 'Product Image deleted successfully...');
            return redirect('admin/products/'.$product_id.'/edit');
        } else {
            \Session::flash('status', 'Error'); 
            \Session::flash('message', 'Some thing went wrong, Please try again later...');
            return redirect('admin/products/'.$product_id.'/edit');
        }
    }

    public function subCategories($id, $level) {
        $categoryArray = array();
        $categories =  ProductCategory::where('parent_id', $id)
                                        ->orderBy('order', 'ASC')
                                        ->get();
        foreach($categories as $product_category) {
            if($level == 1) {
                $categoryArray[$product_category->id] = '- '.$product_category->name;
            } else if($level == 2) {
                $categoryArray[$product_category->id] = '-- '.$product_category->name;
            } else if($level == 3) {
                $categoryArray[$product_category->id] = '--- '.$product_category->name;
            } else if($level == 4) {
                $categoryArray[$product_category->id] = '---- '.$product_category->name;
            } else if($level == 5) {
                $categoryArray[$product_category->id] = '----- '.$product_category->name;
            } else if($level == 6) {
                $categoryArray[$product_category->id] = '------ '.$product_category->name;
            } else if($level == 7) {
                $categoryArray[$product_category->id] = '------- '.$product_category->name;
            } else if($level == 8) {
                $categoryArray[$product_category->id] = '-------- '.$product_category->name;
            } else if($level == 9) {
                $categoryArray[$product_category->id] = '--------- '.$product_category->name;
            } else if($level == 10) {
                $categoryArray[$product_category->id] = '----------- '.$product_category->name;
            }
            $subCategoryArray = $this->subCategories($product_category->id, $level);
            foreach($subCategoryArray as $key => $sub_category) {
                if($level == 1) {
                    $categoryArray[$key] = '- '.$sub_category;
                } else if($level == 2) {
                    $categoryArray[$key] = '-- '.$sub_category;
                } else if($level == 3) {
                    $categoryArray[$key] = '--- '.$sub_category;
                } else if($level == 4) {
                    $categoryArray[$key] = '---- '.$sub_category;
                } else if($level == 5) {
                    $categoryArray[$key] = '----- '.$sub_category;
                } else if($level == 6) {
                    $categoryArray[$key] = '------ '.$sub_category;
                } else if($level == 7) {
                    $categoryArray[$key] = '------- '.$sub_category;
                } else if($level == 8) {
                    $categoryArray[$key] = '-------- '.$sub_category;
                } else if($level == 9) {
                    $categoryArray[$key] = '--------- '.$sub_category;
                } else if($level == 10) {
                    $categoryArray[$key] = '----------- '.$sub_category;
                }
            }
        }
        return $categoryArray;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addProductSpecification(Request $request, $id)
    {
        // Form Validation
        $this->validate($request, [
            'product_attribute_set_id' => 'required',
            'value' => 'required',
        ]);
        $attribute = new ProductAttributeValue;
        $attribute->product_attribute_set_id = $request->product_attribute_set_id;
        $attribute->value = $request->value;
        $attribute->product_id = $id;
        $attribute->attribute_type = 0;
        $attribute->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Specification Attribute Value saved...');
        //return redirect('admin/products/'.$id.'/edit');
        $arr = array('msg' => 'Successfully Submitted', 'status' => true);
        return response()->json($arr);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateProductSpecification(Request $request, $id, $attr_id)
    {
        // Form Validation
        $attribute = ProductAttributeValue::findOrFail($attr_id);
        $attribute->value = $request->value;
        $attribute->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Specification Attribute Value saved...');
        return redirect('admin/products/'.$id.'/edit');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteProductSpecification($id, $attr_id)
    {
        // Form Validation
        $attribute = ProductAttributeValue::findOrFail($attr_id);
        $status = $attribute->delete();
        if($status) {
            \Session::flash('status', 'Success'); 
            \Session::flash('message', 'Product Specification Attribute Value deleted...');
            return redirect('admin/products/'.$id.'/edit');
        } else {
            \Session::flash('status', 'Error'); 
            \Session::flash('message', 'Some thing went wrong, Please try again later...');
            return redirect('admin/products/'.$id.'/edit');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addProductCategory(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        if($product->category_id) {
            if($request->category_id) {
                $product->category_id = $product->category_id . $request->category_id . ',';
            } else {
                $categories = explode(',', $product->category_id);
                if (in_array($request->category, $categories)) {
                    unset($categories[array_search($request->category,$categories)]);
                }
                $product->category_id = implode(',', $categories);
            }
        } else {
            $product->category_id = ',' . $request->category_id . ',';
        }
        $product->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Category saved...');
        return redirect()->back();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addSimilarProducts(Request $request, $id, $v_id)
    {
        $product = Product::findOrFail($id);
        if($product->similar_product_id) {
            if($request->product_id) {
                $product->similar_product_id = $product->similar_product_id . $request->product_id . ',';
            } else {
                $products = explode(',', $product->similar_product_id);
                if (in_array($request->product, $products)) {
                    unset($products[array_search($request->product, $products)]);
                }
                $product->similar_product_id = implode(',', $products);
            }
        } else {
            $product->similar_product_id = ',' . $request->product_id . ',';
        }
        $product->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Category saved...');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addToCart(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        // Form Validation
        if($product->product_type == 'Configurable Product') {
            if(!$product->color->isNotEmpty()) {
                $this->validate($request, [
                    'qty' => 'required',
                    'size' => 'required',
                ]);
            } elseif(!$product->size->isNotEmpty()) {
                $this->validate($request, [
                    'qty' => 'required',
                    'color' => 'required',
                ]);
            } else {
                $this->validate($request, [
                    'qty' => 'required',
                    'size' => 'required',
                    'color' => 'required',
                ]);
            }
            foreach($product->configureable_attribute_value as $result) {
                if($result->color == $request->color && $result->size == $request->size) {
                    if($request->qty > $result->qty) {
                        \Session::flash('error', 'Error'); 
                        \Session::flash('message', 'Product Stock Not available...');
                        \Session::flash('is_available', 0);
                        return redirect()->back();
                    }
                }
            }
        }else {
            $this->validate($request, [
                'qty' => 'required',
            ]);
            if($request->qty > $product->qty) {
                \Session::flash('error', 'Error'); 
                \Session::flash('message', 'Product Stock Not available...');
                \Session::flash('is_available', 0);
                return redirect()->back();
            }
        }
        if(request()->cookie('order_details') != null) {
            $order = Order::findOrFail(request()->cookie('order_details'));
            $flag = false;
            foreach($order->cart_details as $item) {
                if($item->product_id == $id) {
                    $item->product_qty += $request->qty;
                    $item->product_price = $product->price;
                    if($product->product_type == 'Configurable Product') {
                        $item->color = $request->color;
                        $item->size = $request->size;
                    }
                    $item->save();

                    $order->cart_sub_total += ($request->qty * $product->price);
                    $order->cart_total += ($request->qty * $product->price);
                    $order->save();
                    
                    $flag = true;
                }
            }
            if(!$flag) {
                $cart = new CartDetail;
                $cart->order_id = $order->id;
                $cart->product_id = $product->id;
                $cart->product_qty = $request->qty;
                if($product->product_type == 'Configurable Product') {
                    $cart->product_color = $request->color;
                    $cart->product_size = $request->size;
                }
                $cart->product_price = $product->price;
                $cart->save();

                $order->cart_sub_total += $cart->product_qty * $cart->product_price;
                $order->cart_total +=$cart->product_qty * $cart->product_price;
                $order->save();
            }
        } else {
            $order = new Order;
            $order->cart_sub_total = $request->qty * $product->price;
            $order->vat_charges = $order->cart_sub_total * 0.05;
            $order->shippment_charges = env('SHIPMENT_CHARGES');
            $order->cart_total = $order->cart_sub_total + $order->vat_charges + $order->shippment_charges;
            $order->soft_delete = 1;
            $order->status = 1;
            $order->save();

            $cart = new CartDetail;
            $cart->order_id = $order->id;
            $cart->product_id = $product->id;
            if($product->product_type == 'Configurable Product') {
                $cart->product_color = $request->color;
                $cart->product_size = $request->size;
            }
            $cart->product_qty = $request->qty;
            $cart->product_price = $product->price;
            $cart->save();

            Cookie::queue(cookie()->forever('order_details', $order->id));
        }
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product added to the cart successfully...');
        return redirect()->back();
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function removeFromCart(Request $request, $id)
    {
        if(request()->cookie('order_details')) {
            $order = Order::findOrFail(request()->cookie('order_details'));
            foreach($order->cart_details as $item) {
                if($item->id == $id) {
                    $order->cart_sub_total -= ($item->product_qty * $item->product_price);
                    $order->cart_total -= ($item->product_qty * $item->product_price);
                    $order->save();
                    $item->delete();
                }
            }
        }
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product removed from the cart successfully...');
        return redirect()->back();
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateCart(Request $request, $id)
    {
        if(request()->cookie('order_details')) {
            $order = Order::findOrFail(request()->cookie('order_details'));
            foreach($order->cart_details as $item) {
                if($item->id == $id) {
                    $oldItemTotal = $item->product_qty * $item->product_price;
                    $newitemTotal = $request->qty * $item->product_price;
                    $item->product_qty = $request->qty;
                    $item->save();

                    $order->cart_sub_total += $newitemTotal - $oldItemTotal; 
                    $order->cart_total += $newitemTotal - $oldItemTotal; 
                    $order->save();
                }
            }
        }
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Product Quantity from the cart updated successfully...');
        return redirect()->back();
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function featuredProducts() {
        $products = Product::paginate(20);
        return view('admin.featured_products.index', compact('products'));
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addFeaturedProduct(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $product->featured_product = !$product->featured_product;
        $product->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Featured Product updated successfully...');
        return redirect()->back();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function notifyMe(Request $request, $id)
    {
        $notify_me = new NotifyMeStock;
        $notify_me->product_id = $id;
        $notify_me->email = $request->email;
        $notify_me->status = 0;
        $notify_me->save();

        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'You will be notified once product stock will be updated...');
        return redirect()->back();
    }
   
   
    

}
