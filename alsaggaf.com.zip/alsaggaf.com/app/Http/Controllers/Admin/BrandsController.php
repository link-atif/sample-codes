<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Brand;
use App\Models\SubBrand;
use Image;
use Illuminate\Support\Facades\File;

class BrandsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $brands = Brand::paginate(20);
        return view('admin.brands.index', compact('brands'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.brands.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'string|required',
            'short_description' => 'required',
            'description' => 'required',
            'image'=>'required',
        ]);
        $brand = new Brand;
        if($image = $request->file('image')) {
            $name = $image->getClientOriginalName();
            $count = 1;
            while(file_exists('images/brand/'.$name)) {
                $filename = pathinfo($name, PATHINFO_FILENAME);
                $extension = pathinfo($name, PATHINFO_EXTENSION);
                $name = pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME).'-'.$count++.'.'.$extension;
            }
            Image::make($image)->resize(152, 124)->save('images/brand/'.$name);
            $brand->image = $name;
        }
        $brand->name = $request->name;
        $brand->website = $request->website;
        $brand->email = $request->email;
        $brand->short_description = $request->short_description;
        $brand->description = $request->description;
        $brand->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'New Brand saved successfully...');
        return redirect('admin/brand');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $brand = Brand::findOrFail($id);
        return view('admin.brands.edit', compact('brand'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $brand = Brand::findOrFail($id);
        if($image = $request->file('image')) {
            $oldImage = $brand->image;
            $name = $image->getClientOriginalName();
            $count = 1;
            while(file_exists('images/brand/'.$name)) {
                $filename = pathinfo($name, PATHINFO_FILENAME);
                $extension = pathinfo($name, PATHINFO_EXTENSION);
                $name = pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME).'-'.$count++.'.'.$extension;
            }
             Image::make($image)->resize(152, 124)->save('images/brand/'.$name);
            $brand->image = $name;
            File::delete('images/brand/'.$oldImage);
        }
        $brand->name = $request->name;
        $brand->website = $request->website;
        $brand->email = $request->email;
        $brand->short_description = $request->short_description;
        $brand->description = $request->description;
        $brand->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Brand saved successfully...');
        return redirect('admin/brand');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $brand = Brand::findOrFail($id);
        $image = $brand->image;
        $status = $brand->delete();
        if($status) {
            File::delete('images/brand/'.$image);
            \Session::flash('status', 'Success'); 
            \Session::flash('message', 'Brand deleted successfully...');
            return redirect('admin/brand');
        } else {
            \Session::flash('status', 'Error'); 
            \Session::flash('message', 'Some thing went wrong, Please try again later...');
            return redirect('admin/brand');
        }
    }
    
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function addSubBrand(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'string|required',
        ]);
        $sub_brand = new SubBrand;
        $sub_brand->name = $request->name;
        $sub_brand->brand_id = $id;
        $sub_brand->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'New Sub Brand saved successfully...');
        return redirect()->back();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function updateSubBrand(Request $request, $id)
    {
        $sub_brand = SubBrand::findOrFail($id);
        $sub_brand->name = $request->name;
        $sub_brand->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Sub Brand updated successfully...');
        return redirect()->back();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function deleteSubBrand($id)
    {
        $sub_brand = SubBrand::findOrFail($id);
        $sub_brand->delete();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Sub Brand deleted successfully...');
        return redirect()->back();
    }
}
