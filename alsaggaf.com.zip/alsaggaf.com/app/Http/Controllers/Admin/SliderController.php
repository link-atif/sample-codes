<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use App\Models\Slider;
use Image;

class SliderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($tt_content_id)
    {
        $slider = Slider::where('tt_content_id', $tt_content_id)
                                ->get();
        $slider->tt_content_id = $tt_content_id;
        return view('admin.slider.index', compact('slider'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($tt_content_id)
    {
        return view('admin.slider.create', compact('tt_content_id'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($tt_content_id, Request $request)
    {
        // Form Validation
        $this->validate($request, [
            'headline' => 'string|required',
            'button_label' => 'string|required',
            'button_link' => 'string|required',
            'image' => 'required',
            'mobile_image' => 'required'
        ]);
        $slider = new Slider;
        if($image = $request->file('image')) {
            $name = $image->getClientOriginalName();
            $count = 1;
            while(file_exists('images/slider/'.$name)) {
                $filename = pathinfo($name, PATHINFO_FILENAME);
                $extension = pathinfo($name, PATHINFO_EXTENSION);
                $name = pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME).'-'.$count++.'.'.$extension;
            }
            $image->move('images/slider/',$name);
            $slider->image = $name;
        }
        
        if($mobile_image = $request->file('mobile_image')) {
            $m_name = $mobile_image->getClientOriginalName();
            $m_count = 1;
            while(file_exists('images/slider/'.$m_name)) {
                $m_filename = pathinfo($m_name, PATHINFO_FILENAME);
                $m_extension = pathinfo($m_name, PATHINFO_EXTENSION);
                $m_name = pathinfo($mobile_image->getClientOriginalName(), PATHINFO_FILENAME).'-'.$m_count++.'.'.$m_extension;
            }
            //$mobile_image->move('images/slider/',$m_name);
            Image::make($mobile_image)->resize(400, 500)->save('images/slider/'.$m_name);
            $slider->mobile_image = $m_name;
        }
        
        $slider->tt_content_id  = $tt_content_id;
        $slider->headline       = $request->headline;
        $slider->button_label   = $request->button_label;
        $slider->button_link    = $request->button_link;
        $slider->sort_order     = $request->sort_order;
        $slider->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Slider Slide saved successfully...');
        return redirect('admin/'.$tt_content_id.'/slider');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($tt_content_id, $id)
    {
        $slide = Slider::findOrFail($id);
        return view('admin.slider.edit', compact('slide'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $tt_content_id, $id)
    {
        $slide = Slider::findOrFail($id);
        if($image = $request->file('image')) {
            $oldImage = $slide->image;
            $name = $image->getClientOriginalName();
            $count = 1;
            while(file_exists('images/slider/'.$name)) {
                $filename = pathinfo($name, PATHINFO_FILENAME);
                $extension = pathinfo($name, PATHINFO_EXTENSION);
                $name = pathinfo($image->getClientOriginalName(), PATHINFO_FILENAME).'-'.$count++.'.'.$extension;
            }
            $image->move('images/slider/',$name);
            $slide->image = $name;
            File::delete('images/slider/'.$oldImage);
        }
        
        if($mobile_image = $request->file('mobile_image')) {
            $m_oldImage = $slide->mobile_image;
            $m_name = $mobile_image->getClientOriginalName();
            $m_count = 1;
            while(file_exists('images/slider/'.$m_name)) {
                $m_filename = pathinfo($m_name, PATHINFO_FILENAME);
                $m_extension = pathinfo($m_name, PATHINFO_EXTENSION);
                $m_name = pathinfo($mobile_image->getClientOriginalName(), PATHINFO_FILENAME).'-'.$m_count++.'.'.$m_extension;
            }
            //$mobile_image->move('images/slider/',$m_name);
            Image::make($mobile_image)->resize(400, 500)->save('images/slider/'.$m_name);
            $slide->mobile_image = $m_name;
            File::delete('images/slider/'.$m_oldImage);
        }
        
        $slide->headline        = $request->headline;
        $slide->button_label    = $request->button_label;
        $slide->button_link     = $request->button_link;
        $slide->sort_order     = $request->sort_order;
        $slide->save();
        \Session::flash('status', 'Success'); 
        \Session::flash('message', 'Slider Slide saved successfully...');
        return redirect('admin/'.$tt_content_id.'/slider');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($tt_content_id, $id)
    {
        $slide = Slider::findOrFail($id);
        $image = $slide->image;
        $m_image = $slide->mobile_image;
        $status = $slide->delete();
        if($status) {
            File::delete('images/slider/'.$image);
            File::delete('images/slider/'.$m_image);
            \Session::flash('status', 'Success'); 
            \Session::flash('message', 'Slider Slide deleted successfully...');
            return redirect('admin/'.$tt_content_id.'/slider');
        } else {
            \Session::flash('status', 'Error'); 
            \Session::flash('message', 'Some thing went wrong, Please try again later...');
            return redirect('admin/'.$tt_content_id.'/slider');
        }
    }
}
