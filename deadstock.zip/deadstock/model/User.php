<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use \Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Tymon\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'username',
        'email',
        'password',
        'is_admin',
        'user_status',
        'user_token',
        'dob',
        'phoneNumber',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
        'google_token',
        'twitter_token',
        'facebook_token',
        'token_secret',
        'google', 'twitter', 'facebook',
    ];

    protected $appends = ['roles_name', 'phone', 'vendor'];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'is_admin' => 'boolean',
        'created_at' => 'datetime:m/d/Y',
        'last_login' => 'datetime:m/d/Y',
    ];

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    /**
     * Scope a query to search user by name.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $search
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeSearch($query, $search)
    {
        if ($search) {
            $query->where('first_name', 'like', '%'.$search.'%');
            $query->orWhere('last_name', 'like', '%'.$search.'%');
            $query->orWhere('email', 'like', '%'.$search.'%');
            $query->orWhere('username', 'like', '%'.$search.'%');
        }

        return $query;
    }

    /**
     * Scope a query get user who have roles.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $search
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeHasRole($query, $role)
    {
        $query->whereHas(
            'roles',
            function ($q) use ($role) {
                return $q->where('name', $role);
            }
        );

        return $query;
    }

    /**
     * Scope a query to search user by start date.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $search
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfStartDate($query, $start_date)
    {
        if ($start_date) {
            $query->whereDate('created_at', '>=', $start_date.' 00:00:00');
        }

        return $query;
    }

    /**
     * Scope a query to search user by end date.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $search
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOfEndDate($query, $end_date)
    {
        if ($end_date) {
            $query->whereDate('created_at', '<=', $end_date.' 23:59:59');
        }

        return $query;
    }

    // Get a list of roles
    public function roles()
    {
        return $this->belongsToMany(Role::class, 'role_user', 'user_id', 'role_id');
    }

    // check user role
    public function hasRole($role)
    {
        return self::where('role', $role)->get();
    }

    // Get a list of wishlists
    public function wishLists()
    {
        return $this->hasMany(WishList::class);
    }

    // Get a list of addresses
    public function addresses()
    {
        return $this->hasMany(Address::class, 'user_id', 'id');
    }

    /**
     * Returns the user's payment methods.
     *
     * @return HasMany
     */
    public function paymentMethods(): HasMany
    {
        return $this->hasMany(PaymentMethod::class);
    }

    // Get a list of payment methods
    public function paymentmethod()
    {
        return $this->hasMany(PayoutMethod::class, 'vendor_id', 'id');
    }

    // return roles in comma sepreated
    public function getRolesNameAttribute()
    {
        return $this->roles->pluck('name')->implode(',');
    }

    // return the phone number of users from addresses table
    public function getPhoneAttribute()
    {
        return $this->addresses->where('type', 'Standard')->pluck('phone')->implode(',');
    }

    // checked if user have check_account it will return connection other wise not connected
    public function getVendorAttribute()
    {
        if ($this->paymentmethod->pluck('check_account')->implode(',') != '') {
            return true;
        } else {
            return false;
        }
    }
}
