<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Faker\Factory;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class AdminUsersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::factory(10)->create();
        $roles = Role::first();
        // Create 3 admin users
        for ($i = 1; $i <= 3; $i++) {
            $this->faker = Factory::create();
            $user = User::create([
                'first_name' => $this->faker->firstname(),
                'last_name' => $this->faker->lastname(),
                'username' => $this->faker->username(),
                'email' => 'admin'.$i.'@email.com',
                'email_verified_at' => now(),
                'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                'is_admin' => true,
            ]);
            $user_id = $user->id;
            $user->roles()->attach(1);
        }
        // Create sellers/ vendor users
        for ($j = 1; $j <= 4; $j++) {
            $this->vendorFaker = Factory::create();
            $vendor = User::create([
                'first_name' => $this->vendorFaker->firstname(),
                'last_name' => $this->vendorFaker->lastname(),
                'username' => $this->vendorFaker->username(),
                'email' => 'vendor'.$j.'@yopmail.com',
                'email_verified_at' => now(),
                'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                'is_admin' => false,
            ]);
            $user_id = $vendor->id;
            $vendor->roles()->attach(7);
        }
    }
}
