<?php

namespace App\Http\Controllers;

use App\Exports\ExportUser;
use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\role_user;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Crypt;

/**
 * Class CouponsController.
 */
class UsersController extends Controller
{

    /**
     * Swagger notation for get all users
     * ------------------------------.
     ** @OA\Get(
     *      path="api/users?status=All&page=1&take=10&start_date=&end_date=",
     *      summary="Get All users list with pagination",
     *      description="get all users list",
     *      tags={"Users"},
     *      @OA\RequestBody(
     *          required=true,
     *          @OA\MediaType(
     *              mediaType="application/x-www-form-urlencoded",
     *              @OA\Schema(
     *                  required={"status","page","take"},
     *                  @OA\Property(
     *                      property="status",
     *                      type="string",
     *                      description="All/Super Admin/Admin/ other roles etc"
     *                  ),
     *                  @OA\Property(
     *                      property="page",
     *                      type="integer",
     *                      description="Page number 1 2 3"
     *                  ),
     *                  @OA\Property(
     *                      property="take",
     *                      type="integer",
     *                      description="how much record need to show"
     *                  ),
     *              )
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(ref="#/components/schemas/UserResource"),
     *      ),
     *      @OA\Response(
     *          response=401,
     *          description="Wrong credentials response",
     *          @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Unauthorized")
     *          )
     *      )
     *  )
     * Swagger notation for get all users
     *------------------------------------------
     * Get All Users Listing.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getUsers(Request $request)
    {
        $request->validate([
            'search' => 'string|nullable',
        ]);

        // if role selected from front end then filter users with role name
        if ($request->status !== 'All') {
            $query = User::with(['roles:name', 'addresses:phone', 'paymentmethod'])->hasRole($request->status);
        } else { // if no role selected from front end then get all users
            $query = User::with(['roles:name', 'addresses', 'paymentmethod'])->orderBy('created_at', 'desc');
        }
        if ($request->has('search')) {
            $query->search($request->search);
        }
        if ($request->has('start_date')) {
            $query->OfStartDate($request->start_date);
        }
        if ($request->has('end_date')) {
            $query->OfEndDate($request->end_date);
        }

        $data = $query->paginate($request->input('take', 10));

        return response()->json($data, 200);
    }

    /**
     * Swagger notation for get user count against roles and list of roles
     * ------------------------------.
     ** @OA\Get(
     *      path="api/users/count?status=All",
     *      summary="Get all counts against roles and list of roles as another field",
     *      description="Get count of user against roles and list of roles as another field",
     *      tags={"Users"},
     *      @OA\RequestBody(
     *          required=true,
     *          @OA\MediaType(
     *              mediaType="application/x-www-form-urlencoded",
     *              @OA\Schema(
     *                  required={"status"},
     *                  @OA\Property(
     *                      property="status",
     *                      type="string",
     *                      description="All"
     *                  ),
     *              )
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(
     *              oneOf={
     *                  @OA\Schema(ref="#/components/schemas/RoleResource"),
     *              },
     *              @OA\Property(property="count", type="object", example="{'All':124,'Super Admin':5,'Admin':2,'Authenticator':0,'Business Manager':2,'Customer Services':2,'Order Managers':1,'Vendor':4}" ),
     *          )
     *      ),
     *      @OA\Response(
     *          response=401,
     *          description="Wrong credentials response",
     *          @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Unauthorized")
     *          )
     *      ),
     *  )
     * Swagger notation for get user count against roles and list of roles
     *------------------------------------------
     * Get All Users Listing.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getUsersCount()
    {
        $data = [];
        $data['count']['All'] = User::count();

        // getting count of users role wise
        $roles = Role::all();
        foreach ($roles as $role) {
            $data['count'][$role->name] = User::query()->hasRole($role->name)->count();
        }
        $data['roles'] = $roles;
        return $data;
    }

    /**
     * Get User details including roles, address and payment method.
     *
     ** @OA\Get(
     *      path="/api/user/{id}",
     *      summary="Get user details",
     *      description="Return user details including roles, address and payment method",
     *      tags={"Users"},
     *      @OA\Parameter(
     *          name="id",
     *          description="User ID",
     *          in="query",
     *          required=true,
     *          @OA\Schema(
     *              type="number"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(ref="#/components/schemas/UserResource")
     *      ),
     *      @OA\Response(
     *          response=404,
     *          description="User is not found",
     *          @OA\JsonContent(ref="#/components/schemas/NotFoundResource")
     *      ),
     * )
     */
    public function getUserDetail($id)
    {
        if (intval($id) <= 0) {
            return response()->json(['success'=>false, 'message'=>'invalid id'], 422);
        }
        $query = User::with(['roles:name', 'addresses', 'paymentmethod'])->findOrFail($id);
        // creating random token and saving in db so admin might want to login as user
        $query->user_token =  Str::random(60);
        $query->save();
        $admin_encrypted_id = Crypt::encryptString(Auth::user()->id."~".Auth::user()->email);
        $roles = Role::all();
        return response()->json(array("user"=>$query,"admin_id"=>$admin_encrypted_id,"roles"=>$roles), 200);
    }

    /**
     * Delete user role
     *
     ** @OA\Delete(
     *      path="/api/users/{user}/role/{role}",
     *      summary="Delete user role",
     *      description="Return updated user object",
     *      tags={"Users"},
     *      @OA\Parameter(
     *          name="id",
     *          description="user id",
     *          in="query",
     *          required=true,
     *          @OA\Schema(
     *              type="number"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="role",
     *          description="role id",
     *          in="query",
     *          required=true,
     *          @OA\Schema(
     *              type="number"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(ref="#/components/schemas/UserResource")
     *      ),
     *      @OA\Response(
     *          response=404,
     *          description="User or role not found",
     *          @OA\JsonContent(ref="#/components/schemas/NotFoundResource")
     *      ),
     * )
     */
    public function deleteUserRole(Request $request, User $user, Role $role) 
    {        
        if($user->roles->contains($role)){
            $user->roles()->detach($role->id);
            // get again user detail to get latest data of user after deleting role
            $user->refresh();
            return response()->json(array("success"=>true,"user"=>$user), 200);
        }
        return response()->json(array("success"=>false), 422);
    }


    /**
     * Assign role to user
     *
     ** @OA\Put(
     *      path="/api/users/{user}/role/{role}",
     *      summary="Delete user role",
     *      description="Return updated user object",
     *      tags={"Users"},
     *      @OA\Parameter(
     *          name="id",
     *          description="user id",
     *          in="query",
     *          required=true,
     *          @OA\Schema(
     *              type="number"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="role",
     *          description="role id",
     *          in="query",
     *          required=true,
     *          @OA\Schema(
     *              type="number"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(ref="#/components/schemas/UserResource")
     *      ),
     *      @OA\Response(
     *          response=404,
     *          description="User is not found",
     *          @OA\JsonContent(ref="#/components/schemas/NotFoundResource")
     *      ),
     * )
     */
    public function assignRole(Request $request, User $user, Role $role)
    {
        if(!$user->roles->contains($role)){
            $user->roles()->attach($role->id);
            // get again user detail to get latest data of user after adding role
            $user->refresh();
            return response()->json(array("success"=>true,"user"=>$user), 200);
        }
        return response()->json(array("success"=>false), 422);   
    }

    /**
     * Get User details including roles, address and payment method from user random token and admin encrypted key
     *
     ** @OA\Get(
     *      path="/user/user-detail-with-token/{user_token}/{admin_id}",
     *      summary="Get user details",
     *      description="Get User details including roles, address and payment method from user random token and admin encrypted key",
     *      tags={"Users"},
     *      @OA\Parameter(
     *          name="user_token",
     *          description="User token",
     *          in="query",
     *          required=true,
     *          @OA\Schema(
     *              type="string"
     *          )
     *      ),
     *      @OA\Parameter(
     *          name="admin_id",
     *          description="Admin encypted key",
     *          in="query",
     *          required=true,
     *          @OA\Schema(
     *              type="string"
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(ref="#/components/schemas/UserResource")
     *      ),
     *      @OA\Response(
     *          response=404,
     *          description="User is not found",
     *          @OA\JsonContent(ref="#/components/schemas/NotFoundResource")
     *      ),
     * )
     */
    public function userDetailWithToken($user_token,$admin_id)
    {
        $user_token_array = ['user_token' => $user_token];

        // decrypt admin token and get id and email
        $admin_array = $admin_encrypted_id = explode("~",Crypt::decryptString($admin_id));
        
        $validator = Validator::make($user_token_array, [
            'user_token' =>  'exists:users'
        ]);

        // return validation errors
        if ($validator->fails()) {
            return response()->json(['success'=>false, 'message'=>$validator->errors()], 422);
        }

        // checked admin token against id and email also checking has superadmin role
        $admin_user = User::with(['roles:name'])->where('email', $admin_array[1])->where("id",$admin_array[0])->hasRole('Super Admin')->first();

        if($admin_user){
            // getting user against token
            $user = User::with(['roles:name', 'addresses', 'paymentmethod'])->where('user_token',$user_token)->first();
            // remove token onces got data from against token so not used again
            $user->user_token = "";
            $user->save();
            $token = auth()->fromUser($user);
            return response()->json([
                'success' => 'true',
                'user' => $user,
                'token' => $token
            ], 200);
        }
        return response()->json([
                'success' => 'false',
                'message' => 'Invalid Token'
            ], 200);
    }

    /**
     * Add new user.
     *
     *  @OA\Post(
     *      path="/users",
     *      summary="Add new user",
     *      description="Add new user with role",
     *      tags={"Users"},
     *      @OA\RequestBody(
     *          required=true,
     *          @OA\MediaType(
     *              mediaType="application/json",
     *              @OA\Schema(
     *                  required={"first_name", "first_name","email","username","password"},
     *                  @OA\Property(
     *                      property="first_name",
     *                      type="string",
     *                      description="First Name",
     *                      example="Jhon"
     *                  ),
     *                  @OA\Property(
     *                      property="last_name",
     *                      type="string",
     *                      description="Last Name",
     *                      example="Jhon"
     *                  ),
     *                  @OA\Property(
     *                      property="email",
     *                      type="string",
     *                      description="Email unique",
     *                      example="Jhon"
     *                  ),
     *                  @OA\Property(
     *                      property="username",
     *                      type="string",
     *                      description="Username unique",
     *                      example="Jhon"
     *                  ),
     *                  @OA\Property(
     *                      property="password",
     *                      type="string",
     *                      description="Password min 8 character one capitcal and numberic with symbol",
     *                      example="Test123@"
     *                  ),
     *                  @OA\Property(
     *                      property="role",
     *                      type="int",
     *                      description="role to attach with user",
     *                      example="1"
     *                  )
     *              )
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(type="string", example="success")
     *      ),
     *      @OA\Response(
     *          response=404,
     *          description="Not found",
     *          @OA\JsonContent(ref="#/components/schemas/NotFoundResource")
     *      )
     *  )
     */
    public function addNewUser(Request $request)
    {
        // checked if user is admin other wise return access error
        if (! Auth::check() && Auth::user()->roles()->where('name', 'Super Admin')->exists()) {
            return response()->json(['success'=>false, 'message'=>'Admin access requried'], 401);
        }

        $validator = Validator::make($request->all(), [
            'first_name'    =>  'required|string|between:2,100',
            'last_name'     =>  'required',
            'email'         =>  'required|string|email|max:100|unique:users',
            'username'      =>  'required|string|unique:users',
            'password'      =>  ['required', Password::min(8)->mixedCase()->numbers()->symbols()],
        ]);
        // return validation errors
        if ($validator->fails()) {
            return response()->json(['success'=>false, 'message'=>$validator->errors()], 422);
        }

        $user = new User([
            'first_name'    =>  $request->first_name,
            'last_name'     =>  $request->last_name,
            'username'      =>  $request->username,
            'email'         =>  $request->email,
        ]);
        $user->password = Hash::make($request->password);
        $user->save();
        $user->roles()->attach($request->role);

        return response()->json([
            'success' => 'true',
            'message' => 'User successfully registered',
            'user' => $user,
        ], 200);
    }

    /**
     * Get users csv.
     *
     * @param Request $request
     * @return array
     * @throws Exception
     * @todo Get the users in csv formate
     */
    public function exportUsers(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'selectedColumns' =>  'required',
        ]);
        // if there is no column selected then it will give error to select column to export
        if ($validator->fails()) {
            return response()->json(['success'=>false, 'message'=>$validator->errors()], 422);
        }

        return Excel::download(new ExportUser($request), 'users.csv');
    }

        /**
     * Swagger notation for get all roles
     * ------------------------------.
     ** @OA\Get(
     *      path="api/users/roles",
     *      summary="Get All Roles",
     *      description="get all Roles",
     *      tags={"Users"},
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(ref="#/components/schemas/RoleResource"),
     *      ),
     *      @OA\Response(
     *          response=401,
     *          description="Wrong credentials response",
     *          @OA\JsonContent(
     *              @OA\Property(property="message", type="string", example="Unauthorized")
     *          )
     *      )
     *  )
     * Swagger notation for get all roles
     *------------------------------------------
     * Get All Users Listing.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getAllRoles()
    {
        $roles = Role::all();
        $roles_array[] = ['text'=>'Select Role', 'value'=>''];
        foreach ($roles as $role) {
            $roles_array[] = ['text'=>$role->name, 'value'=>$role->id];
        }

        return response()->json($roles_array, 200);
    }

    /**
     * Update user status.
     *
     *  @OA\Post(
     *      path="/api/user/update-status",
     *      summary="Update user status to active, deactive, block and delete",
     *      description="Update user status to active, deactive, block and delete",
     *      tags={"Users"},
     *      @OA\RequestBody(
     *          required=true,
     *          @OA\MediaType(
     *              mediaType="application/json",
     *              @OA\Schema(
     *                  required={"id", "status"},
     *                  @OA\Property(
     *                      property="id",
     *                      type="number",
     *                      description="User id",
     *                      example="1"
     *                  ),
     *                  @OA\Property(
     *                      property="status",
     *                      type="string",
     *                      description="setatus of user e.g active,deactive,block,delete",
     *                      example="active"
     *                  )
     *              )
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(type="string", example="success")
     *      ),
     *      @OA\Response(
     *          response=404,
     *          description="Not found",
     *          @OA\JsonContent(ref="#/components/schemas/NotFoundResource")
     *      )
     *  )
     */
    public function updateUserStatus(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id'     =>  'required|exists:users',
            'status' =>  'required|in:active,deactive,block,delete',
        ]);
        // return validation errors
        if ($validator->fails()) {
            return response()->json(['success'=>false, 'message'=>$validator->errors()], 422);
        }

        $user = User::findOrFail($request->id);
        if ($request->status === 'delete' && $user->user_status !== 'block') {
            return response()->json(['success'=>false, 'message'=>'User must be block first to delete'], 422);
        }
        $user->user_status = $request->status;
        $user->save();

        return response()->json([
            'success' => 'true',
            'message' => 'Updated user successfully',
            'user' => $user,
        ], 200);
    }

    /**
     * Refresh user token
     *
     *  @OA\Post(
     *      path="/api/user/refresh-login-token",
     *      summary="Update user token for login",
     *      description="Regenerate new token for user to login through token",
     *      tags={"Users"},
     *      @OA\RequestBody(
     *          required=true,
     *          @OA\MediaType(
     *              mediaType="application/json",
     *              @OA\Schema(
     *                  required={"id"},
     *                  @OA\Property(
     *                      property="id",
     *                      type="number",
     *                      description="User id",
     *                      example="1"
     *                  )
     *              )
     *          )
     *      ),
     *      @OA\Response(
     *          response=200,
     *          description="Success",
     *          @OA\JsonContent(type="string", example="success")
     *      ),
     *      @OA\Response(
     *          response=404,
     *          description="Not found",
     *          @OA\JsonContent(ref="#/components/schemas/NotFoundResource")
     *      )
     *  )
     */
    public function updateToken(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id'     =>  'required|exists:users',
        ]);
        // return validation errors
        if ($validator->fails()) {
            return response()->json(['success'=>false, 'message'=>$validator->errors()], 422);
        }
        $token = Str::random(60);
        $user = User::findOrFail($request->id);
        $user->user_token = $token;
        $user->save();

        return response()->json([
            'success' => 'true',
            'token' => $token,
        ], 200);
    }
}
