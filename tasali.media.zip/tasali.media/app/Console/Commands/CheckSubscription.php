<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Contracts\Users\UsersContract;
use Carbon\Carbon;
use App\User;
use App\Order;
use App\CreditCards;
use Contracts\Options\OptionsContract;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class CheckSubscription extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'check:premium';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Check if subscription end date expired';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(OptionsContract $config, User $user)
    {
        $this->config = $config;
        $this->user = $user;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $previous = Carbon::today()->subDays(2)->toDateString();
        $users = User::whereDate('premium_end_date','=', $previous)->where('role_id', '=', '1')->get();

        if($users != Null){
            foreach ($users as $key => $value) {
                $to_name = $value->name;
                $to_email = $value->email;
                $new_array = array(
                    "name" => $value->name
                );

                Mail::send('frontend.follow-up', $new_array, function($message) use ($to_name, $to_email) {
                    $message->to($to_email, $to_name)
                    ->subject('Tasali Media Follow Up');
                    $message->from('support@tasali.media','Tasali');
                });

                DB::table('schedule_response')->insert([
                    'response' => "done"
                ]);
            }
        }
        
        
    }
}
