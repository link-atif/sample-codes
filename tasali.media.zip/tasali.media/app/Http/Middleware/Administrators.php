<?php

namespace App\Http\Middleware;

use Closure;
use Contracts\Users\UsersContract;

class Administrators
{
    public function __construct(UsersContract $user)
    {
        $this->user = $user;
    }

    public function handle($request, Closure $next)
    {
        $user = $request->user();
        if(!$this->user->hasPermission($user, 'c-panel-login'))
            return redirect()->route('login')->with(['msgType' => 'error', 'msg' => trans('Validation.no_privilege')]);

        return $next($request);
    }
}
