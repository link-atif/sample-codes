<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Contracts\Movies\MoviesContract;
use Contracts\Shows\ShowsContract;
use Contracts\Search\SearchContract;
use Contracts\Genres\GenresContract;
use Contracts\Options\OptionsContract;
use Contracts\Images\ImagesContract;
use Auth;
use Symfony\Component\HttpFoundation\Session\Session;
use App\Http\Resources\ContinueCollection;
use App\Image;
use App\ContinueWatching;
use Cookie;
use App\CountryException;
use Storage;
use ImageLib;
use App\Http\Resources\Movie\MovieCollection;
use App\Http\Resources\User as UserResource;
use App\User;
class HomeController extends Controller
{
    public function __construct(MoviesContract $movies, ShowsContract $shows, GenresContract $genres, OptionsContract $options,ImagesContract $images, SearchContract $search)
    {
        $this->movies = $movies;
        $this->shows = $shows;
        $this->genres = $genres;
        $this->options = $options;
        $this->images = $images;
        $this->search = $search;
    }

    // home page
    public function index(Request $request)
    { 
        /* $user = UserResource::collection(User::all());
            dd($user);*/
       //$movies =  new MovieCollection($this->movies->getLatest());
        $data['title'] = trans('frontend.homepage');
        $landing_image = $this->options->getByName('landing_image');
        $data['image'] = $this->images->get($landing_image->value);
        if (!\Auth::check())
            return redirect(route('login'));//view('frontend.landing', $data);
        
        $data['slider']   = get_slider();
        $data['trending'] = $this->movies->getTrending(18);
        $data['recently'] = $this->movies->getLatest();
        //$data['shows']    = $this->shows->getByStatus(1);
        $data['genres']    = $this->genres->getForHomePage(1);
        //dd($data['genres']);
        //$data['forHomePage']    =  $this->genres->getByStatus(1);
        $data['coming']   = $this->movies->getComing();
        $data['continue_watching'] =  $this->search->continueWatching(\Auth::user())->toArray(); 
        //dd($data['continue_watching']);
        
        $watching = $request->session()->get('watching',0);
        if($watching == 0){
            $request->session()->put('watching',1);
        }       
        $data['watching'] = $request->session()->get('watching');
        if($data['watching'] == 1){
            $request->session()->put('watching',2);
            $data['user'] = \Auth::user();
            return view('frontend.who_is_watching', $data);    
        }
        
        $val = $request->session()->put('loader','home');
        if($val == 0){
            $request->session()->put('loader',1);
        }
        return view('frontend.home', $data);
    }

    public function search(Request $request)
    {
        $data['title'] = trans('frontend.homepage');

        $data['movies']   = $this->movies->search($request->keyword);
        $data['shows']    = $this->shows->search($request->keyword);

        return view('frontend.results', $data);
    }

    public function changeLanguage(Request $request, $locale)
    {
        $request->session()->put('locale', $locale);
        return redirect()->back();
    }

    public function country(){
        $data['title'] = "Country Blocked";
        return view('errors.503', $data);   
    }

    public function kidSection(){
        if(request()->session()->get('kid') > 0){
            request()->session()->put('kid',0);    
        }else{
            request()->session()->put('kid',1);
        }
        return redirect(route('home'));
    }

    /*public function removeWatching(Request $request){
        if($request->type == "movie")
            ContinueWatching::where('movie_id', $request->id)->where('user_id', \Auth::id())->delete();
        if($request->type == "episode")
            ContinueWatching::where('episode_id', $request->id)->where('user_id', \Auth::id())->delete();
        
        $gsItems = $this->search->continueWatching(\Auth::user())->toArray(); 
        return response()->json([
            'template' => view('frontend.components.reloadContinueWatching', compact('gsItems'))->render(),
            'type'     => 'success'
        ]);
    }*/
}
