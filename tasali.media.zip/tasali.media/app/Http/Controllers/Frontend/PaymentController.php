<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use Contracts\Payment\PaymentContract;
use Contracts\CreditCards\CreditCardContract;
use App\Order;
use App\CreditCards;
use App\Http\Controllers\Controller;
use App\User;
use App\Subscription;
use Carbon\Carbon;
use Contracts\Options\OptionsContract;
use App\paylane\PayLaneRestClient;
use Auth;
use App\Country;
use Cartalyst\Stripe\Stripe;
use App\Device;
use Jenssegers\Agent\Agent;

class PaymentController extends Controller
{
    public function __construct(PaymentContract $payment, CreditCardContract $cards, Order $order, User $user, Subscription $subscription, OptionsContract $config, CreditCards $credit)
    {
        $this->payment = $payment;
        $this->cards = $cards;
        $this->order = $order;
        $this->user = $user;
        $this->subscription = $subscription;
        $this->config = $config;
        $this->credit = $credit;
    }

    public function step2()
    {
        if (!\Auth::check()){
            return redirect(route('login'));
        }
        $data['title'] = trans('frontend.choose_payment');
        $data['desc']  = trans('frontend.choose_payment');
        $data['plans'] = Country::where('name', '=', Auth::user()->country)->first();
        return view('auth.register.step_2', $data);
    }

    public function step3()
    {
        if (!\Auth::check()){
            return redirect(route('login'));
        }
        $data['plans'] = Country::where('name', '=', Auth::user()->country)->first();
                
        /*$order = $this->order->where('user_id', Auth::user()->id)->get();
        $subscription = $this->subscription->where('user_id', Auth::user()->id)->first();
        dd($order);
        if($order > 0 && $subscription !=null){
            dd("here");
        }
        dd($order);*/
        return view('auth.register.payment', $data);
        
    }

    public function payment(Request $request)
    {        
        $this->validate($request, [
            'card_number'   => 'required',
            'expiration_month' => 'required',
            'expiration_year' => 'required',
            'name_on_card' => 'required',
            'card_code' => 'required|min:3|max:4'
        ]);

        $card = $this->cards->set($request, \Auth::id());
        return $this->cards->order($card, \Auth::id(), $request);
       
    }

    public function stripePayment(Request $request)
    {   
        $stripe = \Stripe::setApiKey(env('STRIPE_SECRET'));
        $stripe_token  = $request->stripeToken;
        $customer_id = "";
        $plan_id = Country::where('name', '=', Auth::user()->country)->pluck('plan_id')->first();
        $result = "";
        $arr = "";
        $current = Carbon::now();
        
        $order = $this->order->where('user_id', Auth::user()->id)->count();
        $subscription = $this->subscription->where('user_id', Auth::user()->id)->first();
        $plans = Country::where('name', '=', Auth::user()->country)->first();
        if($subscription !=null){
            $customer_id = $subscription->customer_id;
            try {
                $result = $stripe->subscriptions()->create($customer_id, array(
                  "plan"        => $plan_id
                ));

            }catch (Exception $e) {
                $array = $e->getJsonBody();
                return redirect()->back()->with(['msg-type' => 'error', 'msg' => $array['error']['message']]);
            }

            ////////////// pupulate data in db ///////////////////

            $cards = $stripe->cards()->all($customer_id);

            $card = CreditCards::create([
                'user_id'      => Auth::user()->id,
                'type'         => $cards['data'][0]['brand'],
                'name_on_card' => $cards['data'][0]['name'],
                'expiration_month'  => $cards['data'][0]['exp_month'],
                'expiration_year'  => $cards['data'][0]['exp_year'],
                'card_code'  => "",                    
                'card_number'  => "************".$cards['data'][0]['last4'],
                'is_default'   => true,
                'is_primary'   => 1,
                'card_token' => $cards['data'][0]['id'],
            ]);

            $order = $this->order->create([
                'amount'      => $plans->amount,
                'currency'    => $plans->curriency_code,
                'country'    => Auth::user()->country,
                'code'      => $plans->code,
                'description' => "Subscription for a month",
                'user_id'     => Auth::user()->id,
                'id_sale'     => $result['id'],
                'expiry_date' => Carbon::now()->addMonths(1),
                'status' => 'success',
                'card_id' => $card->id,
            ]);

            $subscription->update([
                'subscription_id' => $result['id'],
                'is_premium' => 1,
                'is_cancelled' => 0,
                'card_id' => $card->id,
                'start_date' => Carbon::now(),
                'end_date' => Carbon::now()->addMonths(1),
                'plan_name' => 'Subscription for a month, Your next billing date at'. Carbon::now()->addMonths(1)->toDateString(),
                'plan_id' => $plan_id,
            ]);

            $this->user->where('id', Auth::user()->id)->update([
                'is_premium' => 1,
                'premium_start_date' => Carbon::now(),
                'premium_end_date' => Carbon::now()->addMonths(1)
            ]);


            /////////////////////////////////////////////////////
        }else{
            /////////////// with trial ////////////////////
            if(config('common.payment.is_trial') ==  1){
                $trial_period = config('common.payment.trial_period');
                $BillCycleDate = $current->addDays($trial_period)->timestamp; 
                try{
                    $customer = $stripe->customers()->create(array(
                        'email' => $request->stripeEmail,
                        'source'  => $stripe_token
                    ));
                    $customer_id = $customer['id'];
                }catch (Exception $e) {
                    $array = $e->getJsonBody();
                    return redirect()->back()->with(['msg-type' => 'error', 'msg' => $array['error']['message']]);
                }
                
                 try {
                    $result = $stripe->subscriptions()->create($customer_id, array(
                      "plan"        => $plan_id,
                      "trial_end" => $BillCycleDate,
                      "prorate" => false
                    ));

                }catch (Exception $e) {
                    $array = $e->getJsonBody();
                    return redirect()->back()->with(['msg-type' => 'error', 'msg' => $array['error']['message']]);
                }

                $cards = $stripe->cards()->all($customer_id);

                $card = CreditCards::create([
                    'user_id'      => Auth::user()->id,
                    'type'         => $cards['data'][0]['brand'],
                    'name_on_card' => $cards['data'][0]['name'],
                    'expiration_month'  => $cards['data'][0]['exp_month'],
                    'expiration_year'  => $cards['data'][0]['exp_year'],
                    'card_code'  => "",                    
                    'card_number'  => "************".$cards['data'][0]['last4'],
                    'is_default'   => true,
                    'is_primary'   => 1,
                    'card_token' => $cards['data'][0]['id'],
                ]);

                $order = $this->order->create([
                    'amount'      => $plans->amount,
                    'currency'    => $plans->curriency_code,
                    'country'    => Auth::user()->country,
                    'code'      => $plans->code,
                    'description' => "Free Trial",
                    'user_id'     => Auth::user()->id,
                    'id_sale'     => $result['id'],
                    'expiry_date' => Carbon::now()->addDays($trial_period),
                    'status' => 'success',
                    'card_id' => $card->id,
                ]);

                $subscription = $this->subscription->create([
                    'user_id' => Auth::user()->id,
                    'subscription_id' => $result['id'],
                    'customer_id' => $customer_id,
                    'is_premium' => 1,
                    'card_id' => $card->id,
                    'start_date' => Carbon::now(),
                    'end_date' => Carbon::now()->addDays($trial_period),
                    'plan_name' => 'Free trial! Your next billing date at'. Carbon::now()->addDays($trial_period)->toDateString(),
                    'plan_id' => $plan_id,
                ]);

                $this->user->where('id', Auth::user()->id)->update([
                    'is_premium' => 1,
                    'premium_start_date' => Carbon::now(),
                    'premium_end_date' => Carbon::now()->addDays($trial_period)
                ]);
            }else{
                //////////// without trial ////////////
                try{
                    $customer = $stripe->customers()->create(array(
                        'email' => $request->stripeEmail,
                        'source'  => $stripe_token
                    ));
                    $customer_id = $customer['id'];
                }catch (Exception $e) {
                    $array = $e->getJsonBody();
                    return redirect()->back()->with(['msg-type' => 'error', 'msg' => $array['error']['message']]);
                }
                
                try {
                    $result = $stripe->subscriptions()->create($customer_id, array(
                      "plan"        => $plan_id
                    ));

                }catch (Exception $e) {
                    $array = $e->getJsonBody();
                    return redirect()->back()->with(['msg-type' => 'error', 'msg' => $array['error']['message']]);
                }

                $cards = $stripe->cards()->all($customer_id);

                $card = CreditCards::create([
                    'user_id'      => Auth::user()->id,
                    'type'         => $cards['data'][0]['brand'],
                    'name_on_card' => $cards['data'][0]['name'],
                    'expiration_month'  => $cards['data'][0]['exp_month'],
                    'expiration_year'  => $cards['data'][0]['exp_year'],
                    'card_code'  => "",                    
                    'card_number'  => "************".$cards['data'][0]['last4'],
                    'is_default'   => true,
                    'is_primary'   => 1,
                    'card_token' => $cards['data'][0]['id'],
                ]);

                $order = $this->order->create([
                    'amount'      => $plans->amount,
                    'currency'    => $plans->curriency_code,
                    'country'    => Auth::user()->country,
                    'code'      => $plans->code,
                    'description' => "Free Trial",
                    'user_id'     => Auth::user()->id,
                    'id_sale'     => $result['id'],
                    'expiry_date' => Carbon::now()->addMonths(1),
                    'status' => 'success',
                    'card_id' => $card->id,
                ]);

                $subscription = $this->subscription->create([
                    'user_id' => Auth::user()->id,
                    'subscription_id' => $result['id'],
                    'customer_id' => $customer_id,
                    'is_premium' => 1,
                    'card_id' => $card->id,
                    'start_date' => Carbon::now(),
                    'end_date' => Carbon::now()->addMonths(1),
                    'plan_name' => 'Your next billing date at'. Carbon::now()->addMonths(1)->toDateString(),
                    'plan_id' => $plan_id,
                ]);

                $this->user->where('id', Auth::user()->id)->update([
                    'is_premium' => 1,
                    'premium_start_date' => Carbon::now(),
                    'premium_end_date' => Carbon::now()->addMonths(1)
                ]);


            }

        }
            
            $ip = '103.138.11.1'; //\Request::ip();
            $agent = new Agent();
            $devices = new Device;
            $devices->ip = $ip;
            $devices->platform = $agent->platform();
            $devices->platform_version = $agent->version($agent->platform());
            $devices->browser = $agent->browser();
            $devices->browser_version = $agent->version($agent->browser());
            $devices->device = $agent->device();
            $devices->user_id = Auth::user()->id;
            $devices->device_token = Auth::user()->device_token;
            $devices->save();       
        
           // $this->payment->sendSubscription($subscription);
            return redirect(route('home'));     
    }

    public function paypalPayment(Request $request){
        $this->payment->paypalParams($request, \Auth::id());
    }

    public function paypalCheckout(Request $request){
        if($request->status !== "ERROR"){
            $salt        = 'YOUR_HASH_SALT';
            $status      = $request->status;
            $description = $request->description;
            $amount      = $request->amount;
            $currency    = $request->currency;
            $hash        = $request->hash;

            $id = '';
            if ($status !== 'ERROR') // success, get id_sale
                $id = $request->id_sale;

            //$calc_hash = sha1("{$salt}|{$status}|{$description}|{$amount}|{$currency}|{$id}");

            // check hash salt
            /*if ( $calc_hash !== $hash ) {
                return redirect(route('payment'))->with(['msg-type' => 'error', 'msg' => 'Wrong Hash']);
            }*/

             // check transaction status
            if($status == 'ERROR'){
                return redirect(route('payment'))->with(['msg-type' => 'error', 'msg' => 'transaction declined '.$request->error_description]);
            }

            $card = $this->credit->create([
                'user_id'      => \Auth::id(),
                'type'         => "paypal",
                'name_on_card' => "",
                'expiration_month'  => "",
                'expiration_year'  => "",
                'card_code'  => "",
                'card_number'  => "",
                'is_default'   => true,
                'is_primary'   => 1
            ]);

            $subscription_duration = $this->config->getByName('subscription_duration');
            $trial = $this->config->getByName('trial');
            $order = $this->order->create([
                'amount'      => Auth::user()->amount,
                'currency'    => Auth::user()->code,
                'country'    => Auth::user()->country,
                'description' => "Free trial",
                'user_id'     => \Auth::id(),
                'id_sale'     => $request->id_sale,
                'card_id'       => $card->id,
                'expiry_date' => Carbon::now()->addDays(($trial->value == 0 || $trial->value == null) ? $subscription_duration->value : $trial->value)
            ]);

            $subscription = $this->subscription->where('user_id', \Auth::id())->first();

            if ($subscription) {
                $subscription->update([
                    'is_cancelled' => 0,
                    'card_id' => $card->id,
                    'start_date' => Carbon::now(),
                    'end_date' => Carbon::now()->addDays(($trial->value == 0 || $trial->value == null) ? $subscription_duration->value : $trial->value),
                    'plan_name' => 'Your next billing date at 
                    '.Carbon::now()->addDays(($trial->value == 0 || $trial->value == null) ? $subscription_duration->value : $trial->value)->toDateString()
                ]);
            } else {
                $subscription = $this->subscription->create([
                    'user_id' => $order->user_id,
                    'card_id' => $card->id,
                    'is_premium' => 1,
                    'start_date' => Carbon::now(),
                    'end_date' => Carbon::now()->addDays(($trial->value == 0 || $trial->value == null) ? $subscription_duration->value : $trial->value),
                    'plan_name' => ''
                ]);
               $subscription->update(['plan_name' => 'Free trial, Your next billing date at '.Carbon::parse($subscription->end_date)->toDateString()]);
            }

            if ($trial->value == 0 || $trial->value == null) {
                $order->update(['description' => 'Subscription for a month']);
                $subscription->update(['plan_name' => 'Subscription for a month, Your next billing date at '.Carbon::parse($subscription->end_date)->toDateString()]);
                $subscription = $this->subscription->where('user_id', $order->user_id)->first();
                $this->user->where('id', $order->user_id)->update([
                    'is_premium' => 1,
                    'premium_start_date' => Carbon::now(),
                    'premium_end_date' => $subscription->end_date
                ]);
                $this->payment->sendSubscription($subscription);
                return redirect(route('home'));
            }

            $client = new PayLaneRestClient($this->username, $this->password);
            $refund_params = array(
                'id_sale' => $request->id_sale,
                'amount'  => Auth::user()->amount,
                'reason'  => 'Free Trial Refund',
            );

            // perform the refund:
            try {
                $status = $client->refund($refund_params);
            } catch (Exception $e) {
                // handle exceptions here
                return redirect(route('payment'))->with(['msg-type' => 'error', 'msg' => $status['error']['error_description']]);
            }

            // checking refund status:
            if ($client->isSuccess()) {
                $id_refund = $request->id_sale;
                $order->update(['id_sale' => $id_refund, 'status' => 'refund']);
                $subscription = $this->subscription->where('user_id', $order->user_id)->first();
                $this->user->where('id', $order->user_id)->update([
                    'is_premium' => 1,
                    'premium_start_date' => Carbon::now(),
                    'premium_end_date' => $subscription->end_date
                ]);
                $this->payment->sendSubscription($subscription);
                return redirect(route('home'));
            } else {
                return redirect(route('payment'))->with(['msg-type' => 'error', 'msg' => $status['error']['error_description']]);
            }
        }else{
            return redirect(route('payment'))->with(['msg-type' => 'error', 'msg' => $request->error_text]);
        }

    }

    public function renewPackage(Request $request){
        // Set your secret key: remember to change this to your live secret key in production
        // See your keys here: https://dashboard.stripe.com/account/apikeys
        //dd($payload);
        $stripe = \Stripe::setApiKey(env('STRIPE_SECRET'));
        
        // Retrieve the request's body and parse it as JSON
        $payload = \file_get_contents("php://input");
        $payload = json_decode($payload);
    
        //$this->db->insert("data_logs",array("data"=>json_encode($payload)));
        $sig_header = $_SERVER["HTTP_STRIPE_SIGNATURE"];

        $event = null;
        
       $endpoint_secret = "whsec_qrQI4m4goOsJ3kk24DRYLSTwlIjAz94u";
        
        try {
            //$event = \Stripe\Webhook::constructEvent($payload, $sig_header, $endpoint_secret); 
            //$event = $stripe->events()->find(str_replace("&#039;", "", $payload->id));
            //print_r($event);
            //die();
            //if (isset($event) && $event->type == "invoice.payment_failed") {
            if(isset($payload) && $payload->type== "invoice.payment_failed"){
                $subscription_id = $payload->data->object->subscription;

                $order = $this->order->where('id_sale', $subscription_id)->orderBy('id','DESC')->first();
                User::where('id', $order->user_id)->update([
                        'is_premium' => 0,
                    ]);

                $subscription = $this->subscription->where('user_id', $order->user_id)->first();
                $status = $stripe->subscriptions()->cancel($subscription->customer_id, $subscription->subscription_id);
                $cancelCard = CreditCards::where('user_id', $order->user_id)->delete();
                
                $subscription->update([
                    'is_cancelled' => 1,
                    "is_premium"  => 0
                ]);
                    
            }else if(isset($payload) && $payload->type == "invoice.payment_succeeded"){
                $subscription_id = $payload->data->object->subscription;
                $order = $this->order->where('id_sale', $subscription_id)->orderBy('id', 'DESC')->first();
                User::where('id', $order->user_id)->update([
                        'is_premium' => 1,
                        'premium_start_date' => Carbon::now(),
                        'premium_end_date' => Carbon::now()->addMonths(1)
                    ]);
                
                $orders = $this->order->create([
                    'amount'      => $order->amount,
                    'currency'    => $order->currency,
                    'country'     => $order->country,
                    'code'        => $order->code,
                    'description' => "Subscription for a month",
                    'user_id'     => $order->user_id,
                    'id_sale'     => $subscription_id,
                    'expiry_date' => Carbon::now()->addMonths(1),
                    'status'      => 'success',
                    'card_id'     => $order->card_id,
                ]);

                $subscription = $this->subscription->where('user_id', $order->user_id)->first();
                
                $subscription->update([
                    'is_cancelled' => 0,
                    'start_date' => Carbon::now(),
                    'end_date' => Carbon::now()->addMonths(1),
                    'plan_name' => 'Your next billing date at 
                    '.Carbon::now()->addMonths(1)->toDateString()
                ]);   
            }

                /*$subscription_row = $this->subscription_model->getSubscriptionDetailBySubscriptionID($subscription_id);
                
                $amount = $this->subscription_model->getAmountOfPlanId($subscription_row->plan_id);
                
                $next_recharge_date = date('Y-m-d', next_recharge_date($subscription_row->type));
                
                $this->subscription_model->updatePackageOfUser(array("next_recharge_date"=>$next_recharge_date),$subscription_row->id);
                
                if($subscription_row){
                    $array_payment_log = array(
                        "user_id"                       => $subscription_row->user_id,
                        "plan_id"                       => $subscription_row->plan_id,
                        "type"                          => $subscription_row->type,
                        "charge_date"                   => date("Y-m-d"),
                        "merchant_response"             => json_encode($event),
                        'amount'                        => $amount,
                        'subscription_id'               => $subscription_id,
                        'payment_type'                  => 'webhooks'
                    );
                    $this->subscription_model->insertpaymentLogs($array_payment_log);
                }*/
            }catch(\Cartalyst\Stripe\Exception\UnexpectedValueException $e) {
            // Invalid payload
            print_r($e);
            http_response_code(400); // PHP 5.4 or greater
            exit();
        } catch(\Cartalyst\Stripe\Error\SignatureVerification $e) {
            print_r($e);
            // Invalid signature
            http_response_code(400); // PHP 5.4 or greater
            exit();
        }
        http_response_code(200); // PHP 5.4 or greater
    }


}
