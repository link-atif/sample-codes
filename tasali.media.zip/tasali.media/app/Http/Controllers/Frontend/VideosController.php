<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Contracts\Videos\VideosContract;
use Contracts\Movies\MoviesContract;
use App\ContinueWatching;
use Contracts\Episodes\EpisodesContract;
class VideosController extends Controller
{
    public function __construct(VideosContract $videos, MoviesContract $movies, EpisodesContract $episodes)
    {
        $this->videos = $videos;
        $this->movies = $movies;
        $this->episodes = $episodes;
    }

    public function get(Request $request, $type, $id)
    {
        // try 
        // {
            $video = $this->videos->getByType($type, $id);
            if(!$video){
                return false;
            }
            $paused_at = 0;
            $show_id = "";
            if($type == 'show'){
                $episode = $this->episodes->get($id)->toArray();
                $show_id = $episode['show_id'];
                $paused = ContinueWatching::where("episode_id", $id)->where("user_id", \Auth::id())->get()->toArray();
            }else{
                $paused = ContinueWatching::where("movie_id", $id)->where("user_id", \Auth::id())->get()->toArray();
            }
            
            if(count($paused) > 0){
                $paused_at = $paused[0]['paused_at'];
            }
            
            return response()->json([
                'template' => view('frontend.components.player', compact('video','id','paused_at','type', 'show_id'))->render(),
                'url'      => videoUrl($video)
            ]);
        // } 
        // catch(\Exception $error) 
        // {
        //     return response()->json([
        //         'msg'  => trans('frontend.video_error')
        //     ], 404);
        // }
    }

    public function resume(Request $request){
        if($request->type == 'show'){
            $code = $this->episodes->paused($request, \Auth::id());    
        }else{
            $code = $this->movies->paused($request, \Auth::id());
        }
        if($code != \config("api.response_code.success")){
            return response()->json(["errors" => __('api.response_message.' . $code)]);
        }

        return response()->json(["message" => __('api.response_message.' . $code)]);
    }

    public function userlog(Request $request){
        if($request->type == 'show'){
            $code = $this->episodes->userlog($request, \Auth::id());    
        }else{
            $code = $this->movies->userlog($request, \Auth::id());
        }
        if($code != \config("api.response_code.success")){
            return response()->json(["errors" => __('api.response_message.' . $code)]);
        }

        return response()->json(["message" => __('api.response_message.' . $code)]);
    }

    public function removeWatching(Request $request){
        if($request->type == "movie")
            ContinueWatching::where('movie_id', $request->id)->where('user_id', \Auth::id())->delete();
        if($request->type == "episode")
            ContinueWatching::where('episode_id', $request->id)->where('user_id', \Auth::id())->delete();
        
        return response()->json(['type' => 'success']);
    }   
}
