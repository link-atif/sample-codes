<?php

namespace App\Http\Controllers\Frontend\Auth;

use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Contracts\CreditCards\CreditCardContract;
use Contracts\Options\OptionsContract;
use Contracts\Genres\GenresContract;
use Illuminate\Support\Facades\Mail;
use App\Mail\sendMail;
use App\Rules\GoogleRecaptcha;
use Symfony\Component\HttpFoundation\Session\Session;
use App\Country;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Device;
use Jenssegers\Agent\Agent;
use Auth;

class RegisterController extends Controller
{
    use RegistersUsers;
    protected $redirectTo;

    public function __construct(CreditCardContract $cards, OptionsContract $config, GenresContract $genres)
    {
        $this->middleware('guest');
        $this->redirectTo = route('registerStep2');
        $this->cards = $cards;
        $this->config = $config;
        $this->genres = $genres;
    }

    public function showRegistrationForm()
    {

        //$config = $this->config->getByName('amount');
        $data['title'] = trans('frontend.register');
        $data['desc']  = trans('frontend.register');
        $data['genres']    = $this->genres->getAll();
        $data['countries']  = Country::getAllCountries();
        return view('auth.register', $data);
    }

    public function step3()
    {
        $data['title'] = trans('frontend.setup_payment');
        $data['desc']  = trans('frontend.setup_payment');

        return view('auth.register.step_3', $data);
    }

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|max:20',
            'email'    => 'required|email|max:255|unique:users',
            'password' => 'required|min:6|confirmed|required_with:password_confirmation',
            'country' => 'required',
            'city'    => 'required'
        ]);
    }

    protected function create(array $data)
    {   
        $new_array = array(
            "name" => $data['name']
        );


        if(config('common.register.is_trial') == 1){
            $user = array( 
                'name' =>  $data['name'],
                'email' => $data['email'],
                'password' => bcrypt($data['password']),
                /*'code' => request()->session()->get('code'),
                'amount' => request()->session()->get('amount'),*/
                'country' => $data['country'],
                'city' => $data['city'],
                'preference' => "",
                'device_token' => $data['device_token'],
                'premium_start_date' => Carbon::now(),
                'premium_end_date' => Carbon::now()->addDays(config('common.register.trial_period'))
            );

            $result = User::create($user);
            $ip = '101.53.247.10'; //\Request::ip();
            $agent = new Agent();
            $devices = new Device;
            $devices->ip = $ip;
            $devices->platform = $agent->platform();
            $devices->platform_version = $agent->version($agent->platform());
            $devices->browser = $agent->browser();
            $devices->browser_version = $agent->version($agent->browser());
            $devices->device = $agent->device();
            $devices->user_id = $result->id;
            $devices->device_token = $result->device_token;
            $devices->save();
        }else{
            $user = array( 
                'name' =>  $data['name'],
                'email' => $data['email'],
                'password' => bcrypt($data['password']),
                /*'code' => request()->session()->get('code'),
                'amount' => request()->session()->get('amount'),*/
                'country' => $data['country'],
                'city' => $data['city'],
                'preference' => "",
                'device_token' => $data['device_token']
            );

            $result = User::create($user);
        } 

        $to_name = $data['name'];
        $to_email = $data['email'];
          
       /* Mail::send('frontend.signup-email', $new_array, function($message) use ($to_name, $to_email) {
            $message->to($to_email, $to_name)
            ->subject('Tasali Media Sign Up');
            $message->from('tasali@tasali.media','Tasali');
        });*/
        //oijjlyojvzkucvbi
        
        //Mail::to($data['email'])->send(new SendMail($new_array));
        return $result;
    }

    public function getCitiesList(Request $request){
        $cities = Country::getAllCities($request->code);
        return \Response::json($cities);
    }
}
