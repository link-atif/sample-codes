<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use Auth;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Contracts\Users\UsersContract;
use Contracts\Roles\RolesContract;
use Contracts\CreditCards\CreditCardContract;
use App\User;
use App\Order;
use App\Device;
use App\Subscription;
use App\CreditCards;
use Carbon\Carbon;
use Cartalyst\Stripe\Stripe;
use Illuminate\Support\Facades\DB;

class UsersController extends Controller
{
    public function __construct(UsersContract $users, RolesContract $roles,
Subscription $subscription)
    {
        $this->users = $users;
        $this->roles = $roles;
        $this->subscription = $subscription;
    }

    public function index(Request $request)
    {
        $this->users->hasPermission($request->user(), 'users-view', true); // check permission first

        $data['title'] = trans('backend.users');
        $data['users'] = $this->users->getPaginated();
        $data['roles'] = $this->roles->getAll();

        return view('backend.users.index', $data);
    }

    public function filter(Request $request)
    {
        $this->users->hasPermission($request->user(), 'users-view', true); // check permission first

        $users = $this->users->BackendFilter($request);

        $data['title'] = trans('backend.users');
        $data['users'] = $users->data;
        $data['count'] = $users->count;
        $data['roles'] = $this->roles->getAll();

        return view('backend.users.index', $data);
    }

    public function create(Request $request)
    {
        $this->users->hasPermission($request->user(), 'users-add', true); // check permission first

        $data['title'] = trans('backend.create_user');
        $data['roles'] = $this->roles->getAll();

        return view('backend.users.create', $data);
    }

    public function store(Request $request)
    {
        $this->users->hasPermission($request->user(), 'users-add', true); // check permission first

        $this->validate($request, [
            'name'     => 'required|min:3|max:20',
            'email'    => 'required|min:3|max:255|unique:users',
            'password' => 'required|min:3|max:255',
            'role'     => 'required',
        ]);

        $store = $this->users->set($request);

        if (!$store)
            return redirect()->back()->with(['msg-type' => 'danger', 'msg' => trans('backend.error_store')]);

        return redirect()->route('Backend::users.index')->with(['msg-type' => 'success', 'msg' => trans('backend.success_store')]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        $this->users->hasPermission($request->user(), 'users-edit', true); // check permission first

        $data['title'] = trans('backend.edit_user');
        $data['user']  = $this->users->get($id);
        $data['roles'] = $this->roles->getAll();

        return view('backend.users.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->users->hasPermission($request->user(), 'users-edit', true); // check permission first

        $this->validate($request, [
            'name'     => 'required|min:3|max:20',
            'email'    => 'required|min:3|max:255',
            'password' => 'max:255',
            'role'     => 'required',
        ]);

        $update = $this->users->update($request, $id);

        if (!$update)
            return redirect()->back()->with(['msg-type' => 'danger', 'msg' => trans('backend.error_update')]);

        return redirect()->route('Backend::users.index')->with(['msg-type' => 'success', 'msg' => trans('backend.success_update')]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $this->users->hasPermission($request->user(), 'users-delete', true); // check permission first

        $user =  User::where('id',$id)->first();
        if($user->role_id == 1){
            $stripe = \Stripe::setApiKey(env('STRIPE_SECRET'));
            $subscription = $this->subscription->where('user_id', $id)->where('is_cancelled', '0')->first();
            $subscription->update(['is_cancelled' => 1]);            
            if($subscription !=null){
                $status = $stripe->subscriptions()->cancel($subscription->customer_id, $subscription->subscription_id);
                $cancelCard = CreditCards::where('user_id', $id)->delete();
            }
        }
        $delete = $this->users->delete($id);

        if (!$delete)
            return redirect()->back()->with(['msg-type' => 'danger', 'msg' => trans('backend.error_delete')]);

        return redirect()->route('Backend::users.index')->with(['msg-type' => 'success', 'msg' => trans('backend.success_delete')]);
    }

    public function getAdmins(Request $request)
    {
        $this->users->hasPermission($request->user(), 'users-view', true); // check permission first

        $users = User::get();
        return view('backend.users.admins', compact('users'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroyAdmin($id)
    {
        $this->users->hasPermission($request->user(), 'users-delete', true); // check permission first

        $user = User::findOrFail($id);
        $user->delete();
        session()->flash('flash_message', 'Admin deleted!');
        return redirect('users/admin');
    }

    public function status(Request $request){
        $update = User::where('id',$request->id)->update([$request->type => $request->status]);
        if($request->type == "is_premium"){
            $stripe = \Stripe::setApiKey(env('STRIPE_SECRET'));
            $subscription = $this->subscription->where('user_id', $request->id)->where('is_cancelled', '0')->first();
            $subscription->update(['is_cancelled' => +(!$request->status)]);            
            $status = $stripe->subscriptions()->cancel($subscription->customer_id, $subscription->subscription_id);
            $cancelCard = CreditCards::where('user_id', $request->id)->delete();
            //$cancelCard = CreditCards::where('user_id', $request->id)->where('is_primary', 1)->update(['is_delete' => +(!$request->status)]);
        }
        if(!$update)
            return response()->json(['type' => 'error']);
        
        return response()->json(['type' => 'success']);
    }

    public function details($id)
    {
        $data['devices'] = Device::where('user_id',$id)->get();
        return view('backend.users.devices', $data);

    }

    public function removeDevices($id)
    {
        DB::table('devices')->where('id', $id)->delete();
        return redirect()->back();
    }

    public function extendSubscription(Request $request, $id){
        $data['title'] = trans('backend.extend_subscription');
        $data['user']  = $this->users->get($id);
        return view('backend.users.extend_subscription', $data);
    }

    public function updateSubscription(Request $request, $id){    
        $orders = Order::whereHas('card', function ($query) {
            $query->where('is_primary', 1)->where('is_delete',0);
        })->where('user_id', $id)->first();

        if(!$orders){    
            return redirect()->back()->with(['msg-type' => 'error', 'msg' => trans('backend.error_subscription')]);
        }
        Order::where('user_id', $id)->update(['status' => 'success', 'expiry_date' => $request->ex_date]);            
        User::where('id', $id)->update([
            'is_premium' => 1,
            'premium_end_date' => $request->ex_date
        ]);
        
        return redirect()->route('Backend::users.index')->with(['msg-type' => 'success', 'msg' => trans('backend.update_subscription')]);
    }

    public function logs($id){
        $data['logs'] = DB::table('user_logs')->select("*")->where('user_id', $id)->get();
        return view('backend.users.logs', $data);   
    }
}
