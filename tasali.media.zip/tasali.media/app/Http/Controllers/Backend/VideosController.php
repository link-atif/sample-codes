<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Contracts\Videos\VideosContract;
use Contracts\Movies\MoviesContract;
use Contracts\Shows\ShowsContract;
use Contracts\Episodes\EpisodesContract;
use Illuminate\Http\UploadedFile;
use Pion\Laravel\ChunkUpload\Exceptions\UploadMissingFileException;
use Pion\Laravel\ChunkUpload\Handler\AbstractHandler;
use Pion\Laravel\ChunkUpload\Handler\HandlerFactory;
use Pion\Laravel\ChunkUpload\Receiver\FileReceiver;
use Contracts\Users\UsersContract;

class VideosController extends Controller
{
    public function __construct(VideosContract $videos, ShowsContract $shows, MoviesContract $movies, EpisodesContract $episodes, UsersContract $users)
    {
        $this->videos   = $videos;
        $this->movies   = $movies;
        $this->shows    = $shows;
        $this->episodes = $episodes;
        $this->users    = $users;
    }

    public function index(Request $request)
    {
        $this->users->hasPermission($request->user(), 'videos-view', true); // check permission first

        $data['title']  = 'videos';
        $data['videos'] = $this->videos->getPaginated();

        return view('backend.videos.index', $data);
    }

    public function store(Request $request)
    {
        $this->users->hasPermission($request->user(), 'videos-view', true); // check permission first

        $receiver = new FileReceiver("file", $request, HandlerFactory::classFromRequest($request));
        
        if ($receiver->isUploaded() === false)
            throw new UploadMissingFileException();
        
        $save = $receiver->receive();
        
        if ($save->isFinished())
        {
            return $this->videos->set($save->getFile());
        }
        
        $handler = $save->handler();

        return response()->json([
            "done" => $handler->getPercentageDone()
        ]);
    }

    public function edit(Request $request, $id)
    {
        $this->users->hasPermission($request->user(), 'videos-edit', true); // check permission first

        $video = $this->videos->get($id);
        
        $data['title']  = 'edit Video: ' . $video->original_title;
        $data['movies'] = $this->movies->getAll();
        $data['shows']  = $this->shows->getAll();
        
        if (in_array($video->parent_type, ['show', 'trailer_show'])) {
            $episodes         = $this->episodes->getShowEpisodesByEpisodeId($video->parent);
            $data['episodes'] = $episodes->episodes;
            $data['showId']   = $episodes->show;
        }

        $data['video']  = $video;

        return view('backend.videos.edit', $data);
    }

    public function update(Request $request, $id)
    {
        $this->users->hasPermission($request->user(), 'videos-edit', true); // check permission first

        return $this->videos->update($request, $id);
    }

    public function destroy(Request $request, $id)
    {
        $this->users->hasPermission($request->user(), 'videos-delete', true); // check permission first

        return $this->videos->delete($id);
    }

    public function episodes(Request $request)
    {
        // try {
            $episodes = $this->episodes->getByShow($request->id);

            return response()->json([
                'type' => 'success',
                'data' => view('backend.videos.ajax.episodes', compact('episodes'))->render()
            ]);
        // } catch(\Exception $e) {
        //     return response()->json([
        //         'type' => 'error'
        //     ]);
        // }
    }
}
