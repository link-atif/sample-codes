<?php

namespace Contracts\Users;

use App\ContinueWatching;
use App\CreditCards;
use App\Option;
use App\Subscription;
use Contracts\CreditCards\CreditCardContract;
use Contracts\Subscriptions\SubscriptionContract;
use Illuminate\Http\Request;
use App\User;
use Contracts\Images\ImagesContract;

use Tymon\JWTAuth\JWTAuth as CustomAuth;

interface UsersContract
{

    public function __construct(
        User $user,
//        CustomAuth $auth,
        Option $option,
        CreditCardContract $cards,
//        Subscription $subscription,
        SubscriptionContract $subscription_contract,
        ImagesContract $images
    );

    public function get($id);

    public function getAll();

    public function getPaginated();

    public function set($data);

    public function update($data, $id);

    public function delete($id);

    public function hasPermission($user, $key, $redirect = false);

    public function changePasword($pass, $user);

    public function getByEmail($email);

    public function login($data);

    public function register($data);

    public function forgetPassword($data);

    public function addToList($data, $user);

    public function getMyList($user);

    public function editProfile($data, $user);

    public function uploadImage($data, $user);

    public function setPayment($data, $user, $withRenewalSubscription = false);

    public function getPayment($user);

    public function cancelSubscription($data, $user);

    public function renewalSubscription($data, $user);

    public function removeFromList($data, $user);

    public function checkUserSubscription($user, $freeSignUpOption);

    public function countAll();
    
    public function dateFilter($from_date, $to_date);

    public function totalVisitors($from_date, $to_date);    
}
