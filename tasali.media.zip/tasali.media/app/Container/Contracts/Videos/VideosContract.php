<?php

namespace Contracts\Videos;

use App\Video;
use Storage;

interface VideosContract
{
    function __construct(Video $video);
    function set($file);
    function setMulti($request, $id);
    function getAll();
    function uploadedToday($form_date, $to_date);
}