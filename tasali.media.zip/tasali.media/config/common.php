<?php

    // 1- if payment trial is on then register trial should be off, and vice versa.
	// 2- both should not be on at a time.
	// 3- both can be off, but not on.

return [
    'payment' => [
        'is_trial' => 1,
        'trial_period' => 14
    ],
    'register' => [
        'is_trial' => 0,
        'trial_period' => 7
    ]
    
];