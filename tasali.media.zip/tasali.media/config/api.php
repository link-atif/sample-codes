<?php
/**
 * Created by PhpStorm.
 * User: Backend Dev
 * Date: 3/15/2018
 * Time: 3:46 PM
 */

return [
    "response_code"     => [
        "social_email" => 1100,

        "success" => 200,

        "error"            => 400,
        "not_found"        => 404,
        "email_not_exist"  => 4100,
        "not_unique_email" => 4101,

        "wrong_credentials" => 4110,
        "expired_account"   => 4111,
        "failed_login"      => 4112,
        "failed_send_mail"  => 4113,
        "unauthorized_user" => 4114,

    ],

    "response_message"     => [
        "social_email" => 'This account is social',
        "success" => 'Success',
        "error"            => 'Somthing went worng',
        "not_found"        => 'Not found',
        "email_not_exist"  => 'Email does not exist',
        "not_unique_email" => 'This Email is already taken',
        "wrong_email"       => 'Email is not valid',
        "wrong_credentials" => 'Wrong Credentials',
        "expired_account"   => 'Expired Account',
        "failed_login"      => 'Failed Login',
        "unauthorized_user" => 'Unauthorized User',

    ],

    "home"              => [
        "sort" => [
            "trending" => "&sort=trending",
            "recently" => "",
            "coming"   => "&sort=coming"
        ]
    ],
    "credit_card_types" => [
        4 => "Visa",
        5 => "MasterCard",
        6 => "Discover",
    ],
    "track_types"       => [
        "shortcut" => [
            "movie" => "m",
            "show"  => "s",
            "genre" => "g"
        ]
    ]

];