<?php

use Illuminate\Database\Seeder;

class EpisodesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $seed = [
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],[
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 1,
                'season'   => 2
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ],
            [
                'image_id' => 1,
                'show_id'  => 2,
                'season'   => 1
            ]
        ];
        DB::table('episodes')->insert($seed);
    }
}
