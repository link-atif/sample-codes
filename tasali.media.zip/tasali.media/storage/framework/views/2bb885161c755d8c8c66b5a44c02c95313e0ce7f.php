<div class="row">
    <form class="" action="<?php echo e(route('Backend::movies.filter')); ?>" method="get">
        <div class="col-lg-2">
            <select class="form-control select2" name="genre">
                <option value="all">All Genres</option>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($genre->id); ?>" <?php echo e(Request::input('genre') == $genre->id ? 'selected' : null); ?>>
                        <?php echo e($genre->translate('en')->title); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-lg-2">
            <input class="form-control form-control-inline input-medium default-date-picker" type="text" autocomplete="off" name="date" placeholder="By Date" value="<?php echo e((Request::input('date'))?? ''); ?>" />
        </div>
        <div class="col-lg-2 pull-right">
            <button type="submit" class="btn btn-primary btn-block pull-right">Filter & Search</button>
        </div>
        <div class="col-lg-4 pull-right">
            <input type="text" name="keyword" value="<?php echo e((Request::input('keyword'))?? ""); ?>" placeholder="search..."
                    class="form-control">
        </div>
    </form>
</div>
<br>
<?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/movies/filter_form.blade.php ENDPATH**/ ?>