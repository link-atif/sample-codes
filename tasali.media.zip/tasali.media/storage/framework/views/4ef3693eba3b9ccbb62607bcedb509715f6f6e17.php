<?php $__env->startSection('content'); ?>
<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Edit User: <?php echo e($user->name); ?>

    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('Backend::users.index')); ?>">Users</a></li>
            <li class="active">Edit User: <?php echo e($user->name); ?></li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Edit User: <?php echo e($user->name); ?>

                </header>
                <div class="panel-body">
                    <?php echo $__env->make('backend.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form">
                        <form method="post" action="<?php echo e(route('Backend::users.update', $user->id)); ?>" class="cmxform form-horizontal tasi-form">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('put')); ?>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Name</label>
                                <div class="col-lg-5">
                                    <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                                </div>
                            </div>
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Email</label>
                                <div class="col-lg-5">
                                    <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                                </div>
                            </div>
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Password</label>
                                <div class="col-lg-5">
                                    <input type="password" name="password" class="form-control">
                                    <small class="text-danger"><?php echo app('translator')->getFromJson('backend.password_warning'); ?></small>
                                </div>
                            </div>
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Privilege</label>
                                <div class="col-lg-5">
                                    <select class="form-control" name="role">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->id); ?>" <?php echo e($role->id == $user->role->id ? 'selected' : ''); ?>>
                                                <?php echo e($role->label); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/users/edit.blade.php ENDPATH**/ ?>