<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h3 class="m-b-less">
        All Devices
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
            <li class="active">All Devices</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <section class="panel">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Platform</th>
                                <th>Platform Version</th>
                                <th>Browser</th>
                                <th>Browser Version</th>
                                <th>Device</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php if($devices !="null"): ?>
                            <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($d->platform); ?></td>
                                <td><?php echo e($d->platform_version); ?></td>
                                <td><?php echo e($d->browser); ?></td>
                                <td><?php echo e($d->browser_version); ?></td>
                                <td><?php echo e($d->device); ?></td>
                                <td>
                                    <ul class="list-unstyled list-inline">
                                        <li>
                                            <form action="<?php echo e(route('Backend::users.remove', $d->id)); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <button class="btn btn-danger btn-xs del-confirm" data-msg="<?php echo app('translator')->getFromJson('backend.confirm_delete'); ?>">
                                                    <i class="fa fa-trash-o "></i>
                                                </button>
                                            </form>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/users/devices.blade.php ENDPATH**/ ?>