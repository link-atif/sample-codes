<?php
    $devices = \App\Device::where('user_id', Session::get('user_id'))->get();
    Session::put('user_id', -1);
?>
<div class="col sm-12 alert alert-danger white-text">
<?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
    <div class="col-md-3">
        <label>Device-<?php echo e($key+1); ?></label>
    </div>
    <div class="col-md-3">
         <form action="<?php echo e(route('remove.device', $d->id)); ?>" id="delete_device-<?php echo e($d->id); ?>" method="post">
            <?php echo e(method_field('delete')); ?>

            <?php echo e(csrf_field()); ?>

            <a href="javascript:{}" onclick="document.getElementById('delete_device-'+'<?php echo e($d->id); ?>').submit();return confirm('Are you sure?')" 
            data-msg="<?php echo app('translator')->getFromJson('backend.confirm_delete'); ?>" class="mylinks">Delete</a>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/components/devices.blade.php ENDPATH**/ ?>