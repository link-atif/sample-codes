<?php $__env->startSection('content'); ?>

<!-- page head start-->
<div class="page-head">
    <h3><?php echo e($page_title); ?></h3>
    <span class="sub-title">Welcome to New Tasali <?php echo e($page_title); ?></span>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row">
        <?php echo $__env->make('backend.partials.filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data blue-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-desktop"></i></h1>
                        <h2 class="text-center">Shows: <?php echo e($shows); ?></h2>
                        <?php if($search == 0): ?>
                        <h4 class="text-center"><span class="p_5">Daily: <?php echo e($today_shows); ?> </span><span class="p_5"> Weekly: <?php echo e($weekly_shows); ?></span><span> Monthly: <?php echo e($monthly_shows); ?></span></h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data orange-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-video-camera"></i></h1>
                        <h2 class="text-center">Movies: <?php echo e($movies); ?></h2>
                        <?php if($search == 0): ?>    
                        <h4 class="text-center"><span class="p_5">Daily: <?php echo e($today_movies); ?> </span><span class="p_5"> Weekly: <?php echo e($weekly_movies); ?></span><span> Monthly: <?php echo e($monthly_movies); ?></span></h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data red-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-video-camera"></i></h1>
                        <h2 class="text-center">Genres: <?php echo e($genres); ?></h2>
                        <?php if($search == 0): ?>    
                        <h4 class="text-center"><span class="p_5">Daily: <?php echo e($today_genres); ?> </span><span class="p_5"> Weekly: <?php echo e($weekly_genres); ?></span><span> Monthly: <?php echo e($monthly_genres); ?></span></h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data green-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-play"></i></h1>
                        <h2 class="text-center">Episodes: <?php echo e($episodes); ?></h2>
                        <?php if($search == 0): ?>
                        <h4 class="text-center"><span class="p_5">Daily: <?php echo e($today_episodes); ?> </span><span class="p_5"> Weekly: <?php echo e($weekly_episodes); ?></span><span> Monthly: <?php echo e($monthly_episodes); ?></span></h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data blue-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-user"></i></h1>
                        <h2 class="text-center">Casts: <?php echo e($casts); ?></h2>
                        <?php if($search == 0): ?>
                        <h4 class="text-center"><span class="p_5">Daily: <?php echo e($today_casts); ?> </span><span class="p_5"> Weekly: <?php echo e($weekly_casts); ?></span><span> Monthly: <?php echo e($monthly_casts); ?></span></h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data red-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-users"></i></h1>
                        <h2 class="text-center">Users: <?php echo e($users); ?></h2>
                        <?php if($search == 0): ?>
                        <h4 class="text-center"><span class="p_5">Daily: <?php echo e($today_users); ?> </span><span class="p_5"> Weekly: <?php echo e($weekly_users); ?></span><span> Monthly: <?php echo e($monthly_users); ?></span></h4>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data red-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-users"></i></h1>
                        <h2 class="text-center">Today's Visitors : <?php echo e($total_visitors); ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-8 col-xl-8">
            <div class="revenue-column" style="background-color: #bed4de;">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Site Visits </h3></div>
                        <div id="regions_div" style="width: 710px; height: 300px;"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <section class="panel">
                <div><h3 style="color: black; text-align: center;">Site Revenue </h3></div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Country</th>
                                <th>Total users</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $site_visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php if($sv->country !=""): ?><img src="https://flagcdn.com/<?php echo e(strtolower(country_code($sv->country))); ?>.svg" width="30"> <?php endif; ?></td>
                                <td><?php echo e($sv->country); ?></td>
                                <td><?php echo e($sv->total); ?></td>
                                <td><?php echo e($sv->amount); ?> <?php echo e(currency_code($sv->country)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
</div>
<!--body wrapper end-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"><script type="text/javascript">
    google.charts.load('current', {
        'packages':['geochart'],
        // Note: you will need to get a mapsApiKey for your project.
        // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
        'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
      });
      google.charts.setOnLoadCallback(drawRegionsMap);

      function drawRegionsMap() {
        var data = google.visualization.arrayToDataTable([<?php echo $usersData ?>]);

        var options = {
            colorAxis: {colors: ['green', 'green']},
            legend: 'none',
            backgroundColor: '#bed4de',
            datalessRegionColor: '#ffffff'
        };

        var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

        chart.draw(data, options);
      }
</script>
<script type="text/javascript">
    function resetSearch(){
        window.location = "<?php echo e(route('Backend::home')); ?>";
    }
</script>
<script>
  $(document).ready(function() {
    $('#table, #uploaded-today, #users-table').DataTable();
} );
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/home.blade.php ENDPATH**/ ?>