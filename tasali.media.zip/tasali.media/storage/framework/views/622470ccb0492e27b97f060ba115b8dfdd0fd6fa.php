<div class="banner_main">
    <div id="demo">
        <div id="owl-demo14" class="owl-carousel">
          <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="item">
              <img src="<?php echo e(thumb($slide->image)); ?>" alt="">
                <!--<div class="overlay_gradient_fix"></div>-->
                <div class="banner_main_outer_content">
                    <div class="container padd_0">
                        <div class="col-md-7 padd_0">
                        <div class="slider_bg_tranparent">
                        <div class="rating_movie">
                          <span class="rating_cont"><i class="fas fa-star"></i><?php echo e($slide->rating_avg); ?></span>
                          <p>.</p>
                            <span class="rating_cont">
                                <span class="imdb">IMDb</span><?php echo e($slide->imdb->rate ?? null); ?>

                            </span>
                        </div>
                        <h2><?php echo e($slide->title); ?></h2>
                        <h6><?php echo e($slide->production); ?>,
                        <?php $__currentLoopData = $slide->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($genre->title); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> , 
            <?php echo e($slide->length); ?> min, <?php echo e($slide->age); ?></h6>
                        <p><?php echo e($slide->desc); ?></p>
                      <div class="play_button" id="item-slider-<?php echo e($slide->id); ?>">
                        <a href="<?php echo e($slide->season ? 'shows':'movies'); ?>/<?php echo e($slide->slug); ?>" class="watch_buttons active">
                          <i class="material-icons">play_arrow</i> <?php echo app('translator')->getFromJson('frontend.play'); ?>
                        </a>
                        <a href="#play_video" data-url="<?php echo e(route('video', ['trailer_'.($slide->season ? 'show' : 'movie'), $slide->id])); ?>" data-src="<?php echo e(asset('images/logo.png')); ?>" class="watch_buttons modal-trigger">
                            <i class="material-icons">play_arrow</i> <?php echo app('translator')->getFromJson('frontend.watch_trailer'); ?>
                        </a>
                        <?php 
                          $favoriteMovies = \Auth::user()->followingMovies->pluck('id')->toArray();
                          $favoriteShows = \Auth::user()->followingSeries->pluck('id')->toArray();
                          $favorites = array_merge($favoriteMovies, $favoriteShows);
                        ?>
                        <?php if(in_array($slide->id, $favorites)): ?>
                          <a class="watch_buttons removeList" href="javascript:" data-type="<?php echo e($slide->season ? 'show' : 'movie'); ?>" data-id="<?php echo e($slide->id); ?>" data-header="yes" id="remove-slider-<?php echo e($slide->id); ?>">
                            <i class="material-icons">check</i> <?php echo app('translator')->getFromJson('frontend.remove_from_my_list'); ?>
                          </a>
                        <?php else: ?>
                          <a class="watch_buttons addToList" href="javascript:" data-type="<?php echo e($slide->season ? 'show' : 'movie'); ?>" data-id="<?php echo e($slide->id); ?>" data-header="yes" id="add-slider-<?php echo e($slide->id); ?>">
                            <i class="material-icons">add</i> <?php echo app('translator')->getFromJson('frontend.add_to_my_list'); ?>
                          </a>
                        <?php endif; ?>
                      </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!--banner--><?php /**PATH D:\xampp7\htdocs\tasali\resources\views/frontend/components/header-swiper.blade.php ENDPATH**/ ?>