<?php if(!$gsItems->isEmpty()): ?>
<?php $kid = request()->session()->get('kid'); ?>
<?php  $counter = 0; 
      $count = count($gsItems);
?>
<div class="categery_slider">
  <div class="container">
    <h3><?php echo e($generalSwiperName); ?></h3>
    <div id="demo">
      <div id="<?php echo e($generalSwiperId); ?>" class="owl-carousel">
        <?php $__currentLoopData = $gsItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gsItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $counter = $counter + 1;  ?>
        <?php ( $gsUrl = $gsItem->season ? 'shows/' . $gsItem->slug :'movies/' . $gsItem->slug ) ?>
        <?php if($generalSwiperId =='recent' || $generalSwiperId =='trending' || $counter <= 18 ): ?>
        <div class="item">
          <div class="movie_col_inner">
            <a href="#!">
            <img src="<?php echo e(thumb($gsItem->poster)); ?>" alt="<?php echo e($gsItem->title); ?>">
            <div class="overlay_bg"></div>
            <div class="movie_col_overlay">
              <!-- <h5><?php echo e($gsItem->name); ?></h5>
              <h6><?php echo e($gsItem->production); ?>,<?php echo e($gsItem->length); ?> min, <?php echo e($gsItem->age); ?></h6>
              <p><?php echo e($gsItem->desc); ?></p> -->
              <div class="play_button_overlay" id="item-<?php echo e(str_replace(' ', '', $generalSwiperName)); ?>-<?php echo e($gsItem->id); ?>">
                <a href="<?php echo e($gsItem->production ? $gsUrl : '#!'); ?>" class="btn_overlay active">
                  <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M7.38906 5.85312L0.379025 1.01861C0.304816 0.967609 0.208609 0.962291 0.129323 1.00363C0.0497954 1.04544 0 1.12763 0 1.21755V10.8866C0 10.9765 0.0497954 11.0589 0.129323 11.1007C0.164615 11.1191 0.203291 11.1283 0.241725 11.1283C0.289829 11.1283 0.33769 11.1138 0.379025 11.0855L7.38906 6.251C7.45457 6.2058 7.49348 6.13159 7.49348 6.05206C7.49348 5.97253 7.45432 5.89832 7.38906 5.85312Z" fill="white"/>
                  </svg> 
                  <span><?php echo app('translator')->getFromJson('frontend.watch'); ?></span>
                </a>
                <?php
                  $favoriteMovies = \Auth::user()->followingMovies->pluck('id')->toArray();
                  $favoriteShows = \Auth::user()->followingSeries->pluck('id')->toArray();
                  $favorites = array_merge($favoriteMovies, $favoriteShows);
                ?>
                <?php if(in_array($gsItem->id, $favorites)): ?>
                <a class="btn_overlay removeList" href="javascript:" data-type="<?php echo e($gsItem->season ? 'show' : 'movie'); ?>" data-id="<?php echo e($gsItem->id); ?>" data-header="no" data-genres="<?php echo e(str_replace(' ', '', $generalSwiperName)); ?>" id="remove-<?php echo e(str_replace(' ', '', $generalSwiperName)); ?>-<?php echo e($gsItem->id); ?>">
                  <i class="fas fa-check"></i> <?php echo app('translator')->getFromJson('frontend.remove_from_my_list'); ?>
                </a>
                <?php else: ?>
                <a class="btn_overlay addToList" href="javascript:" data-type="<?php echo e($gsItem->season ? 'show' : 'movie'); ?>" data-id="<?php echo e($gsItem->id); ?>" data-header="no" data-genres="<?php echo e(str_replace(' ', '', $generalSwiperName)); ?>" id="add-<?php echo e(str_replace(' ', '', $generalSwiperName)); ?>-<?php echo e($gsItem->id); ?>">
                  <i class="fas fa-plus"></i> <?php echo app('translator')->getFromJson('frontend.add_to_my_list'); ?>
                </a>
                <?php endif; ?>
              </div>
            </div>
          </a>
          </div>
        </div>
        <?php endif; ?>
        <?php if(($generalSwiperId !='recent' && $generalSwiperId !='trending')): ?>
          <?php if($counter == 18): ?> 
          <div class="item">
            <div class="movie_col_inner">
              <div class="overlay_bg"></div>
              <div class="movie_col_overlay moco">
                <div class="play_button_overlay">
                  <a class="btn_overlay active" href="<?php echo e(route('genre', $generalSwiperId)); ?>"><?php echo app('translator')->getFromJson('frontend.show_more'); ?></a>
                </div>
              </div>              
            </div>
          </div>
          <?php endif; ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>
              <?php /**PATH C:\xampp\htdocs\tasali\resources\views/frontend/components/general-swiper.blade.php ENDPATH**/ ?>