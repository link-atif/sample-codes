<?php if(Session::has('msg')): ?>
    <div class="col sm-12 white-text alert <?php echo e(Session::get('msg-type') == 'error' ? 'alert-danger' : 'alert-success'); ?>">
        <?php echo e(Session::get('msg')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    </div>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
<div class="col sm-12 alert alert-danger white-text">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/components/errors.blade.php ENDPATH**/ ?>