<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta charset="utf-8">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/3.1.0/css/font-awesome.min.css" >
	<link href="https://fonts.googleapis.com/css?family=Tajawal&display=swap">

	<style type="text/css">
		@font-face {
		  font-family: 'Samsung Sharp Sans Regular';
		  font-style: normal;
		  font-weight: normal;
		  src: url('<?php echo e($message->embed(asset("assets/fonts/samsungsharpsans.woff"))); ?>') format('woff');
		  }
		  
		  @font-face {
		  font-family: 'Samsung Sharp Sans Medium';
		  font-style: normal;
		  font-weight: normal;
		  src: url('<?php echo e($message->embed(asset("assets/fonts/samsungsharpsans-medium.woff"))); ?>') format('woff');
		  }
		  
		  
		  @font-face {
		  font-family: 'Samsung Sharp Sans Bold';
		  font-style: normal;
		  font-weight: normal;
		  src: url('<?php echo e($message->embed(asset("assets/fonts/samsungsharpsans-bold.woff"))); ?>') format('woff');
		  }

		.welcome-main{
			background: url('<?php echo e($message->embed($data['background'])); ?>');
			background-size: cover;
			background-repeat: no-repeat;
			padding: 0;
			margin: 0;
		}

		.logo{
			width: 290px;
			height: auto;
			margin-top: 320px;
			margin-bottom: 68px;
		}

		.welcome-text-en{
			line-height: 55px;
			color: #fffffe;
		}

		.welcome-text-en h1{
			font-size: 45px;
			font-family: 'Samsung Sharp Sans Medium';
			margin-bottom: 40px;
		}

		.welcome-text-en h5{
			font-size: 30px;
			font-family: 'Samsung Sharp Sans Medium';
			margin-bottom: 40px;
		}

		.welcome-text-en p{
			font-size: 30px;
			font-family: 'Samsung Sharp Sans Medium';
		}

		.welcome-text-ar{
			line-height: 55px;
			color: #fffffe;
		}

		.welcome-text-ar h1{
			font-size: 45px;
			font-family: 'Tajawal';
			margin-bottom: 40px;
		}

		.welcome-text-ar h5{
			font-size: 30px;
			font-family: 'Tajawal';
			margin-bottom: 40px;
		}

		.welcome-text-ar p{
			font-size: 30px;
			font-family:'Tajawal';
		}

		.start-watch{
			margin: 150px 0;

		}

		.start-watch .button{
			padding: 62px 72px;
			background-image: linear-gradient(to right, rgba(199,144,54,1), rgba(252,244,162,1));
			font-size: 40px;
			color: #1a1714;
			font-family: 'Samsung Sharp Sans Medium';
			text-decoration: none;
		}

		.btn-bottom-text h1{
			font-size: 68px;
			color: #e8ce80;
			font-family:'Tajawal';	
		}

		.w-footer{
			margin-top: 100px;
			padding-bottom: 80px;
		}

		.footer-logo{
			width: 174px;
			height: auto;
		}

		.f-text{
			line-height: 100px;
			color: #e7ca7c;
			font-family: 'Samsung Sharp Sans Medium';
		}
		.text-center{
			text-align: center;
		}
		.text-left{
			text-align: left;
		}
		.text-right{
			text-align: right;
		}
	</style>
</head>
<body>
	<div class="container-fluid welcome-main">
		<div class="container">
			<div class="text-center">
				<img src="<?php echo e($message->embed($data['logo'])); ?>" class="logo">
			</div>
			<div class="text-left welcome-text-en">
				<h1>Hi <span>"<?php echo e($data['name']); ?>",</span></h1>
				<h5>Welcome to Tasali!</h5>
				<p>Your subscription has been successfully completed. Your next payment will be taken by direct debit one month from today. We hope you enjoy our service and look forward to seeing you soon! </p>
			</div>
			<div class="text-right welcome-text-ar">
				<h1 dir="rtl" lang="ar">مرحبا <span>"<?php echo e($data['name']); ?>"</span></h1>
				<h5 dir="rtl" lang="ar">اهلا بكم في تسالي</h5>
				<p dir="rtl" lang="ar">تم الانتهاء من اشتراكك بنجاح. سيتم أخذ دفعتك التالية عن طريق الخصم المباشر بعد شهر واحد من اليوم. نأمل أن تستمتع بخدمتنا ونتطلع إلى رؤيتك قريبًا!</p>
			</div>
			<div class="start-watch text-center">
				<a href="https://tasali.media" class="button"><i class="fa fa-play mr-4"></i> Start Watching</a>
			</div>
			<div class="text-center btn-bottom-text">
				<h1 dir="rtl" lang="ar">تسالي .. بيتك في بلدك الثان</h1>
			</div>
			<div class="row w-footer">
				<div class=" text-left">
					<img src="<?php echo e($message->embed($data['logo'])); ?>" class="footer-logo">
				</div>
				<div class="text-right f-text">All rights reserved &#169; <span>Tasali Media 2021</span></div>
			</div>	
		</div>
	</div>	
</body>
</html><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/dynamic_email_template.blade.php ENDPATH**/ ?>