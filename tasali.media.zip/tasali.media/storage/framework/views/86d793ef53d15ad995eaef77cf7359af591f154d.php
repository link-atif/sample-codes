<style>

@media  only screen and (min-width: 769px) and (max-width: 1024px){
.profile_tabs_section{
	margin-top: 100px;
	margin-bottom: 100px;

	}
}

@media  only screen and (min-width: 769px){
.profile_tabs_section{
	margin-top: 100px;
	}
}

@media  only screen and (min-width:768px){
.profile_tabs_section{
	margin-top: 100px;
	}
}

@media  only screen and (min-width:600px) and (max-width:768px){
.who_is_watching {
    	margin-bottom: 120px;
	}
}

@media  only screen and (min-width:425px) and (max-width:767px){
.profile_tabs_section{margin: 140px 0 100px;}

}

@media  only screen and (min-width:380px) and (max-width:424px){
.profile_tabs_section{margin: 70px 0 70px;}

}

@media  only screen and (min-width: 351px) and (max-width: 375px){
.profile_tabs_section {
    margin: 55px 0 54px;
}
}


@media  only screen and (max-width: 350px){
.profile_tabs_section {
    margin: 100px 0;
}

}

</style>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<div class="profile_tabs_section" style="color:#fff">
        <?php if(Session::has('flash_message')): ?>
	    <div class="alert alert-success alert-block fade in">
	        <button data-dismiss="alert" class="close close-sm" type="button">
	            <i class="fa fa-times"></i>
	        </button>
	        <p><?php echo e(Session::get('flash_message')); ?></p>
	    </div>
		<?php endif; ?>
        <div class="container">
            <div class="col-md-2 padd_0">
            </div>
            <div class="col-md-8 padd_0">
                <div class="tab-content">
                	<div class="profile_right_info_sec who_is_watching">
                    	<div class="tab-pane fade in active">
	                        <div class="info_edit_col">
                                <a href="<?php echo e(route('profile')); ?>">
	                                <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="profile_avatar_inner">
		                             		<?php if($user->avatar ==""): ?>
		                             		<img src="<?php echo e(asset('frontend/assets/images/avater.jpg')); ?>">
	                                		<?php endif; ?>
	                                		<?php if($user->avatar !=""): ?>
	                                		<img src="<?php echo e(asset('frontend/assets/images/avatar/'.$user->avatar.'.jpg')); ?>" height="auto">
	                                		<?php endif; ?>
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;"><?php echo e($user->name); ?></h5>
	                                	</div>
		                            </div>
		                        </a>
	                            <?php if(!empty($child)): ?>
	                            <?php $__currentLoopData = $child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                            <a href="#">
		                            <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="select_avataer_iner">
		                             		<?php if($ch->avatar ==""): ?>
		                             		<img src="<?php echo e(asset('frontend/assets/images/avater.jpg')); ?>">
	                                		<?php endif; ?>
	                                		<?php if($ch->avatar !=""): ?>
	                                		<img src="<?php echo e(asset('frontend/assets/images/avatar/'.$ch->avatar.'.jpg')); ?>" height="105px">
	                                		<?php endif; ?>
	                                	</div>
	                                	<a href="<?php echo e(route('profile.setting', $ch->id)); ?>">
		                                	<div class="edit-profile">
			                                    <i class="fas fa-edit"></i>
			                                </div>
		                                </a>
		                                <a href="<?php echo e(route('remove.profile', $ch->id)); ?>" onclick="confirm('Are You Sure to Remove this Profile.')">
			                                <div class="delete-profile">
			                                    <i class="fas fa-trash"></i>
			                                </div>
		                            	</a>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;"><?php echo e($ch->name); ?></h5>
	                                	</div>
		                            </div>
	                        	</a>
	                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
	                            <?php endif; ?>
	                            <?php if(count($child) < 1): ?>
	                            <a href="<?php echo e(route('add.profile')); ?>">
		                            <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="select_avataer_iner">
		                             		<img src="<?php echo e(asset('frontend/assets/images/plusp_1.png')); ?>">
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;"><?php echo app('translator')->getFromJson('frontend.add_profile'); ?></h5>
	                                	</div>
		                            </div>
	                        	</a>
	                        	<?php endif; ?>
	                        </div>
                    	</div>
                	</div>
                </div>
            </div>
           	<div class="col-md-2 padd_0">
           	</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$(document).ready(function(){
$( "#footer" ).addClass( "fixed-footer" );  
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/frontend/profile/profiles.blade.php ENDPATH**/ ?>