<div id="video"></div>
<script type="text/javascript">
var id = '<?php echo e($id); ?>';
var player = jwplayer("video");
var type = '<?php echo e($type); ?>';
var show_id = '<?php echo e($show_id); ?>';
player.setup({
    file: '<?php echo e(videoUrl($video)); ?>',
    'width': '100%',
    'height': '100%',
    'primary': 'html5',
    'autostart': '<?php echo e($auto ?? "true"); ?>',
});

player.on('time', function(e) {
    Cookies.set('duration', player.getDuration());
    Cookies.set('paused_at', Math.floor(e.position));
    Cookies.set('id',id);
    Cookies.set('type',type);
    Cookies.set('show_id',show_id);
});

player.on('pause', function(e) {
    var paused_at = Cookies.get('paused_at');
    var duration = Cookies.get('duration');
   	resumeWatching(id, parseInt(paused_at), parseInt(duration), type, show_id);
});
player.on('ready', function() {
   var paused_at = '<?php echo e($paused_at); ?>';
	if(parseInt(paused_at) > 0) {
        player.seek(parseInt(paused_at));          
    }
   /*var cookieData = Cookies.get('resumevideodata');
    if(cookieData) {
        var resumeAt = cookieData.split(':')[0],
            videoDur = cookieData.split(':')[1];
        if(parseInt(resumeAt) < parseInt(videoDur)) {
            player.seek(parseInt(resumeAt));          
            logMessage('Resuming at ' + resumeAt); //for demo purposes            
        }
        else if(cookieData && !(parseInt(resumeAt) < parseInt(videoDur))) {
            logMessage('Video ended last time! Will skip resume behavior'); //for demo purposes            
        }        
    }
    else {
        //logMessage('No video resume cookie detected. Refresh page.');
    }*/
});

function resumeWatching(id, paused_at, duration, type, show_id){
	if(type != 'trailer_movie' &&  type != 'trailer_show'){
		if(type == 'movie'){
			data = {"_token": "<?php echo e(csrf_token()); ?>", 'id' : id, 'paused_at': paused_at, 'duration' :  duration, 'type':type};
		}else if(type == 'show'){
			data = {"_token": "<?php echo e(csrf_token()); ?>", 'id' : show_id, 'paused_at': paused_at, 'duration' :  duration, 'episode_id':id, 'type':type};
		}
		$.ajax({
	    	type: 'POST',
	    	dataType: 'json',
	    	url: "<?php echo e(url('resume')); ?>",
	    	data: data,
	     	success: function(result) {
	          //alert("Status Updated Successfully!");
	      	},
	      	error: function() {
	          //alert('error');
	      	}
	  	});
	}
}

function updateUserLog(id, paused_at, duration, type, show_id){
    if(type != 'trailer_movie' &&  type != 'trailer_show'){
        if(type == 'movie'){
            data = {"_token": "<?php echo e(csrf_token()); ?>", 'id' : id, 'paused_at': paused_at, 'duration' :  duration, 'type':type};
        }else if(type == 'show'){
            data = {"_token": "<?php echo e(csrf_token()); ?>", 'id' : show_id, 'paused_at': paused_at, 'duration' :  duration, 'episode_id':id, 'type':type};
        }
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: "<?php echo e(url('userlog')); ?>",
            data: data,
            success: function(result) {
              //alert("Status Updated Successfully!");
            },
            error: function() {
              //alert('error');
            }
        });
    }
}
</script><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/components/player.blade.php ENDPATH**/ ?>