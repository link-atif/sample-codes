<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
    <META Http-Equiv="Pragma" Content="no-cache">
    <META Http-Equiv="Expires" Content="0">
    <title><?php echo e(websiteTitle()); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" />
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('assets/css/flexslider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/scrolling-nav.css')); ?>" rel="stylesheet">
    <?php
    if(app()->getLocale() == "en"){ ?>
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/responsive_login.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet">
    <?php
     }
    else{ ?>
        <link href="<?php echo e(asset('ar/assets/css/style.css')); ?>" rel="stylesheet"> 
        <link href="<?php echo e(asset('ar/assets/css/responsive_login.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('ar/assets/css/responsive.css')); ?>" rel="stylesheet">
   <?php } ?>  
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/headline.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/ionicons.min.css')); ?>" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.1.0/css/flag-icon.min.css" rel="stylesheet">
    <!-- Important Owl stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.css')); ?>">
    <!-- Default Theme -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.css')); ?>">
    <script src="<?php echo e(asset('assets/dist/jquery.min.js')); ?>"></script>
    <!-- <script src='https://www.google.com/recaptcha/api.js'></script> -->
    <script src='https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js'></script>
    <style>
      .captcha-box { border-radius: 5px; border: 2px solid; padding: 0.5rem 2rem;  max-width: 400px; margin: 20px 0; }
      #canvas {
        width: 250px;
        height: 80px;
      }
    </style>
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar">
    <div class="se-pre-con"></div>
    <?php
    if(app()->getLocale() == "en"){
        $langText = "عربى";
        $lang = "ar";
        $lang_link = '';
        $text_align = 'right';
    }
    else{
        $langText = "ENGLISH";
        $lang = "en";
        $lang_link = 'ar/';
        $text_align = 'left';
    }
  ?>
    <!--top bar start-->

    <header class="header fixed-top">
        <!--top bar end-->
        <div class="top-bar w-100">
            <div class="container" style="width: 100%; padding-top: 1rem;">
                <div class="row">
                    <div class="col-6">
                        <a class="navbar-brand page-scroll logo no-margin" href="index.html">
                            <img src="<?php echo e(asset('images/Tasali-Logo.png')); ?>" class="img-fluid" alt="">
                        </a>
                    </div>
                    <!--top left col end-->
                    <div class="col-6 text-<?php echo e($text_align); ?> ">
                        <ul class="list-inline top-socials list-unstyled">
                            <li class="list-inline-item">
                                <a href="<?php echo e(route('lang', [$lang])); ?>"><?php echo e($langText); ?></a>
                            </li>
                            <li class="list-inline-item ">
                                <a class="nav-link cd-signin" id="head_sign" href="https://tasali.media/login"><i
                                        class="ion-ios-contact"></i></a>
                            </li>
                            <li class="list-inline-item login">
                                <a class="cd-signin btn-lg" href="https://tasali.media/login"><?php echo app('translator')->getFromJson('frontend.log_in'); ?></a>
                            </li>
                        </ul>
                    </div>
                    <!--top social col end-->
                </div>
                <!--row-->
            </div>
            <!--container-->
        </div>
        <!-- End of Container -->
        <nav class="navbar navbar-toggleable-md navbar-inverse bg-inverse  header-transparent">
            <div class="container" style="width: 100%;">
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                    data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarNav">
                    <ul class="navbar-nav " style="margin:0 auto">
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>index.html"><?php echo app('translator')->getFromJson('frontend.home'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>about.html"><?php echo app('translator')->getFromJson('frontend.m_about'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>terms.html"><?php echo app('translator')->getFromJson('frontend.terms_of_use'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>privacy.html"><?php echo app('translator')->getFromJson('frontend.privacy_cookie_policy'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>faq.html"><?php echo app('translator')->getFromJson('frontend.faqs'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>contact.html"><?php echo app('translator')->getFromJson('frontend.contact_us'); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!--slider start-->

    <section id="home" class="slider-banner">
      <div class="main-slider">
        <div class=" bg-no-overlay">
          <h1><?php echo app('translator')->getFromJson('frontend.create_new_account'); ?></h1>
        </div>
      </div>
    </section>
    <!-- content Section -->
    <section id="scroll_top"></section>
    <!-- Abotu Section -->
    <section class="about-section all-space bg-parallax" data-jarallax='{"speed": 0.2}'>
      <div class="container">
        <div class="row" style="display: block; margin: 0 auto;">
          <div class="col-lg-9 col-md-9 col-sm-12 scrollReveal sr-bottom sr-ease-in-out-quad sr-delay-1" style="display: block; margin: 0 auto;">
            <div class="register_center">
              <div class="steps_counter">
                <ul>
                  <li class="active"><span><?php echo app('translator')->getFromJson('frontend.step1'); ?> -</span> <p><?php echo app('translator')->getFromJson('frontend.create_your_account'); ?></p></li>
                  <li><span><?php echo app('translator')->getFromJson('frontend.step2'); ?> -</span> <p><?php echo app('translator')->getFromJson('frontend.choose_payment'); ?></p></li>
                  <li><span><?php echo app('translator')->getFromJson('frontend.step3'); ?> -</span> <p><?php echo app('translator')->getFromJson('frontend.subscription'); ?> <strong> <?php if(\Session::get('is_left') == 1): ?><?php echo e(\Session::get('code')); ?> <?php endif; ?> <?php echo e(\Session::get('amount')); ?> <?php if(\Session::get('is_left') == 0): ?><?php echo e(\Session::get('code')); ?> <?php endif; ?> / <?php echo app('translator')->getFromJson('frontend.month'); ?></strong></p></li>
                </ul>
              </div>
              <div class="steps_form step_form_1">
                <?php echo $__env->make('frontend.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-sm-12 alert alert-danger white-text" id="validation_error" style="display: none;"></div>
                <form action="<?php echo e(url('/register')); ?>" id="frm" method="post" name="frm">
                  <?php echo e(csrf_field()); ?>                                
                  <div class="row">
                    <div class="col-md-6">
                      <label><?php echo app('translator')->getFromJson('frontend.name'); ?></label>
                        <input type="text" class="form-control" name="name" autocomplete="off" placeholder="<?php echo app('translator')->getFromJson('frontend.name'); ?>" value="<?php echo e(old('name')); ?>" required>
                    </div>
                    <div class="col-md-6">
                      <label><?php echo app('translator')->getFromJson('frontend.email'); ?></label>
                        <input type="email" class="form-control" name="email" autocomplete="off" placeholder="<?php echo app('translator')->getFromJson('frontend.email'); ?>" value="<?php echo e(old('email')); ?>" required>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <label><?php echo app('translator')->getFromJson('frontend.country'); ?></label>
                      <select name="country" id="country" onchange="getCities()" class="form-control" autocomplete="off" required>
                        <option value="">Select Country*</option>
                         <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option data-code="<?php echo $country->code; ?>" value="<?php echo e($country->name); ?>"><?php echo e($country->name); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <label id="city_label"><?php echo app('translator')->getFromJson('frontend.city'); ?></label>
                      <select name="city" id="city" class="form-control" autocomplete="off" required>
                        <option value=""><?php echo app('translator')->getFromJson('frontend.city'); ?>*</option>
                      </select>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <label><?php echo app('translator')->getFromJson('frontend.password'); ?></label>
                      <input type="password" class="form-control" name="password" autocomplete="off" placeholder="<?php echo app('translator')->getFromJson('frontend.password'); ?>" required>
                    </div>
                    <div class="col-md-6">
                      <label><?php echo app('translator')->getFromJson('frontend.confirm_password'); ?></label>
                      <input type="password" class="form-control" name="password_confirmation" autocomplete="off" placeholder="<?php echo app('translator')->getFromJson('frontend.confirm_password'); ?>" required>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                      <input type="hidden" name="captcha_validation" id="captcha_validation" value="">
                      <div class="captcha-box">
                        <canvas id="canvas"></canvas><span id="refresh" href="javascript:;" style="color: black; font-size: 20px; cursor: pointer;"><i class="fa fa-refresh" aria-hidden="true"></i></span>
                        <input name="code" placeholder="<?php echo app('translator')->getFromJson('frontend.type_code'); ?>" class="form-control" autocomplete="off" required>
                        <a id="valid" href="javascript:;" class="btn btn-sm btn-danger mt-1">Validate</a> 
                      </div>
                    </div>
                    <div class="col-md-3"></div>
                  </div>
                  <button class="reg_conti g-recaptcha" type="button" id="register" style="cursor: pointer;"><?php echo app('translator')->getFromJson('frontend.register_continue'); ?></button>
                      <p class="section_or"></p>
                  <a href="<?php echo e(route('loginFacebook')); ?>" class="fb_signup"><?php echo app('translator')->getFromJson('frontend.facebook_signup'); ?></a>
                </form>
                <div><p style="text-align: justify; color: black; font-weight: bold; font-size: 0.79rem;">Join our first month offer of £3.00, €3.00, $4.00, 5.00 CAD, or 5.00 AUD. After the first month, Tasali streaming service will automatically update your membership to a fixed monthly subscription of £7.00 per month, €7.00 per month, $10.00 per month, 12.00 CAD per month, or 12.00 AUD per month. You can cancel anytime.</p></div>
              </div>
            </div>
          </div>
          <div class="col-lg-2 col-md-2 col-sm-12"></div>
        </div>
      </div>
    </section>
    <section class="content-section">
        <div class="row no-margin">
            <div class="col-md-12 no-padding">
                <hr>
            </div>
        </div>
    </section>
    <div id="play_video" class="modal">
      <div class="modal-content" style="height:70vh;padding:2px;">
      </div>
    </div>
    <section id="footer">
      <div class="footer-bottom">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12">
              <div class="footer-widget-social">
                <ul>
                  <li>
                    <a data-tooltip="facebook" href="https://www.facebook.com/Tasali-114646016899548">
                      <img src="<?php echo e(asset('images/facebook.png')); ?>" alt="" class="img-fluid">
                    </a>
                  </li>
                  <li>
                    <a data-tooltip="inestagram" href="https://www.instagram.com/mediatasali/">
                      <img src="<?php echo e(asset('images/inesta.png')); ?>" alt="" class="img-fluid">
                    </a>
                  </li>
                  <li>
                    <a data-tooltip="youtube" href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                      <img src="<?php echo e(asset('images/youtube.png')); ?>" alt="" class="img-fluid">
                    </a>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 text-center">
                <p><?php echo app('translator')->getFromJson('frontend.copyrights'); ?></p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <a href="javascript:;" class="scrollTop back-to-top" id="back-to-top">
        <i class="fa fa-arrow-up"></i>
    </a>

  
    <script src="<?php echo e(asset('assets/dist/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/jquery.flexslider-min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/scrollreveal.min.js')); ?>"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
    <script src="<?php echo e(asset('assets/dist/jarallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/jarallax-video.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scrolling-nav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jqBootstrapValidation.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
      $("#country").val("<?php echo e(old('country')); ?>");
      if($("#country").val() !="")
          getCities();
     });
    
    function getCities(){
      var code = $("#country > option:selected").attr("data-code");
      if(code){
        $.ajax({
          type:"GET",
          url:"<?php echo e(url('get-cities-list')); ?>?code="+code,
          success:function(res){               
            if(res){
              console.log(res);
              $("#city").empty();
              $("#city_label").empty();
              changeTitle(code, res);
              $("#city").val("<?php echo e(old('city')); ?>");
            }else{
               $("#city").empty();
            }
          }
        });
      }else{
        $("#city").empty();
      }
    }

    function changeTitle(code, res){
      if(code == "US"){
        $("#city_label").append("State");
        $("#city").append($('<option>', {value: "", text: "Select State*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      }else if(code == "GB"){
        $("#city_label").append("Countries");
        $("#city").append($('<option>', {value: "", text: "Select Country*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      }else if(code == "EU"){
        $("#city_label").append("Counties");
        $("#city").append($('<option>', {value: "", text: "Select County*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      }else if(code == "CA" || code == "AU"){
        $("#city_label").append("Region");
        $("#city").append($('<option>', {value: "", text: "Select Region*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      }else{
        $("#city_label").append("City");
        $("#city").append($('<option>', {value: "", text: "Select City*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      } 
    }  
    </script>

    <script src="<?php echo e(asset('assets/js/jquery-captcha-lgh.js')); ?>"></script>
    <script>
      // step-1
      const captcha = new Captcha($('#canvas'),{
        length: 4
      });
      // api
      //captcha.refresh();
      //captcha.getCode();
      //captcha.valid("");

      $('#valid').on('click', function() {
        const ans = captcha.valid($('input[name="code"]').val());
        if(ans =="" || ans == false){
          $("#validation_error").show();
          $("#validation_error").html('<p>Captcha code is not Valid</p>');
            $('html, body').animate({
                scrollTop: $("#scroll_top").offset().top
            }, 1000);
        }
        if(ans == true){
          $("#validation_error").hide();
          $("#captcha_validation").val(ans);
        }
        //captcha.refresh();
      });
      $('#refresh').on('click', function() {
        captcha.refresh();
      });
    </script>
    <script type="text/javascript">
      $("#register").click(function(){
        var captcha_validation = $("#captcha_validation").val();
        if(captcha_validation !="" && captcha_validation == "true"){
          $("#frm").submit();
        }
      });
    </script>
    <script type="text/javascript">
        var language = localStorage.getItem("language");            
        if(language == 'ar'){
            localStorage.setItem("language", "");
            window.location = '<?php echo e(route("lang", "ar")); ?>';
        }            
        if(language == 'en'){
            localStorage.setItem("language", "");
            window.location = '<?php echo e(route("lang", "en")); ?>';
        }
    </script>
</body>
</html><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/auth/register.blade.php ENDPATH**/ ?>