<div class="row">
    <form class="" action="<?php echo e(route('Backend::home.filter')); ?>" method="get">
        <div class="col-lg-3">
            <input class="form-control form-control-inline input-medium default-date-picker" type="text" name="from_date" placeholder="From Date" value="<?php echo e((Request::input('from_date'))?? ''); ?>" />
        </div>
        <div class="col-lg-3">
            <input class="form-control form-control-inline input-medium default-date-picker" type="text" name="to_date" placeholder="To Date" value="<?php echo e((Request::input('to_date'))?? ''); ?>" />
        </div>
        <div class="col-lg-2">
            <button type="submit" class="btn btn-primary btn-block pull-right">Filter & Search</button>
        </div>

        <div class="col-lg-2">
            <button type="button" onclick="resetSearch()" class="btn btn-primary btn-block pull-right">Reset</button>
        </div>
    </form>
    <div class="col-lg-2">
        <a href="<?php echo e(route('Backend::print.pdf')); ?>" class="btn btn-primary btn-block pull-right">Export PDF</a>
    </div>
</div>
<br>
<?php /**PATH C:\xampp\htdocs\tasali\resources\views/backend/partials/filter_form.blade.php ENDPATH**/ ?>