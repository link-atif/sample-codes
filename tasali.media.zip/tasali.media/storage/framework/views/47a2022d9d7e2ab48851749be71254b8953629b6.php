<?php $__env->startSection('content'); ?>

<?php echo $__env->make('frontend.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="profile_tabs_section" style="margin-top: 150px;">
    <div class="container">
        <div class="col-md-12 padd_0">
            <div class="profile_right_info_sec">
                <div class="profile_tabs_right_2">
                    <?php if(count($errors) == 1): ?>
                        <div class="alert alert-danger alert-block fade in">
                            <button data-dismiss="alert" class="close close-sm" type="button">
                                <i class="fa fa-times"></i>
                            </button>
                            <h4>
                                <i class="fa fa-ok-sign"></i>
                                Error!
                            </h4>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><?php echo e($error); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('update.profile')); ?>" id="edit_profile" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" value="<?php echo e($field); ?>" name="field">
                        <input type="hidden" value="<?php echo e($user->id); ?>" name="user_id">
                        <?php if($field == "email"): ?>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label><?php echo app('translator')->getFromJson('frontend.current_email'); ?>:</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="email" class="form-control" name="current_email" value="<?php echo e($user->email); ?>" readonly>
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label><?php echo app('translator')->getFromJson('frontend.email'); ?>:</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label><?php echo app('translator')->getFromJson('frontend.password'); ?>:</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" name="current_password" class="form-control" required>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($field == "name"): ?>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label><?php echo app('translator')->getFromJson('frontend.name'); ?>:</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($field == "password"): ?>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label><?php echo app('translator')->getFromJson('frontend.current_password'); ?>:</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" class="form-control" name="current_password" required>
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label><?php echo app('translator')->getFromJson('frontend.password'); ?>:</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label><?php echo app('translator')->getFromJson('frontend.confirm_password'); ?>:</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" name="password_confirmation" class="form-control" required>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="info_edit_col info_edit_col_2">
                            <div class="col-md-5"></div>
                            <div class="col-md-5">
                                <div class="submit_buttons">
                                    <a href="<?php echo e(route('profile.setting', $user->id)); ?>">Discard</a>
                                    <a href="javascript:{}" onclick="document.getElementById('edit_profile').submit();" class="save_reverse">Save</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/profile/edit_user.blade.php ENDPATH**/ ?>