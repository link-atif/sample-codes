<?php $__env->startSection('content'); ?>

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Create new Country
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('Backend::countries.index')); ?>">Countries</a></li>
            <li class="active"> Create Country </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Create Country
                </header>
                <div class="panel-body">
                    <?php echo $__env->make('backend.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="<?php echo e(route('Backend::countries.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Name</label>
                                <div class="col-lg-5">
                                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control">
                                </div>
                            </div>
                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Code</label>
                                <div class="col-lg-5">
                                    <input type="text" name="code" value="<?php echo e(old('code')); ?>" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Currency Code</label>
                                <div class="col-lg-5">
                                    <input type="text" name="curriency_code" value="<?php echo e(old('curriency_code')); ?>" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">First Month Amount</label>
                                <div class="col-lg-5">
                                    <input type="text" name="amount" value="<?php echo e(old('amount')); ?>" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Ongoing Amount</label>
                                <div class="col-lg-5">
                                    <input type="text" name="ongoing_amount" value="<?php echo e(old('ongoing_amount')); ?>" class="form-control">
                                </div>
                            </div>

                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/countries/create.blade.php ENDPATH**/ ?>