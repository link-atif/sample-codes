<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="Home">
      <meta name="author" content="Pioneer">
      <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
      <META Http-Equiv="Pragma" Content="no-cache">
      <META Http-Equiv="Expires" Content="0">
      <!--<link rel="shortcut icon" href="assets/images/favicon.ico">-->
      <title><?php echo e(websiteTitle()); ?></title>
      <!-- Applying Css-->
      <link href="<?php echo e(asset('frontend/assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(asset('frontend/assets/fonts/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" />
      <link href="<?php echo e(asset('frontend/assets/css/style.css')); ?>" rel="stylesheet" />
      <link href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>" rel="stylesheet">
      <link href="<?php echo e(asset('frontend/assets/css/owl.carousel.css')); ?>" rel="stylesheet">
      <!--fonts-->
      <!-- Compiled and minified CSS -->
      <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css"> -->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--css file end-->
      
      <script src='https://www.google.com/recaptcha/api.js'></script>
      <script src='https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js'></script>
      <style type="text/css">
        .bg{
          background-color: #ee6e73 !important;
        }
      </style>
   </head>
   <?php
      if(app()->getLocale() != "en"){
        $language = "arabic_set";
      }
      else{
        $language = "";
      }
    ?>
  <body class="<?php echo e($language); ?>">
    
    <!--<div class="loader" id="myElem">
        <img class="loader_img_logo" src="<?php echo e(asset('frontend/assets/images/logo.png')); ?>" alt="Logo">
        <div class="clearfix"></div>
        <h1>Loading...</h1>
    </div>-->
    <?php if(Session::get('loader')!="null" && Session::get('loader') == 1 && request()->segment(1) == "home"): ?>
      <div class="preload" id="myElem"><img src="<?php echo e(asset('frontend/assets/images/preloader.gif')); ?>"></div>
      <!-- <div class="preload" id="myElem"><h1 data-content="TASALI">TASALI</h1></div> -->
    <?php endif; ?>

    <!-- preloader after logout -->

    <!-- <?php if(Session::get('home_loader')!="null" && Session::get('home_loader') == 1): ?> -->
    <!-- <div class="preload" id="myElem"><img src="<?php echo e(asset('frontend/assets/images/preloader.gif')); ?>"></div> -->
      <!-- <div class="preload" id="myElem"><h1 data-content="TASALI">TASALI</h1></div> -->
   <!-- <?php 
        Session::put('home_loader', 2);
      ?>
    <?php endif; ?> -->
    <!-- end preloader after logout -->
    <div class="content content-bt-space">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
    <!--footer-->
    <?php echo $__env->make('frontend.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!--Scripts-->

    <!-- *** ST:Production only *** -->
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script> -->
    <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.1/js/materialize.min.js"></script> -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/js/swiper.jquery.min.js"></script> -->
    <!-- *** ED:Production only *** -->
    <script src="<?php echo e(asset('backend/js/dropzone.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/materialize.js')); ?>"></script>
    <!-- Compiled and minified JavaScript -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script> -->
    <script src="<?php echo e(asset('frontend/assets/js/owl.carousel.js')); ?>"></script>    
    <script src="<?php echo e(asset('frontend/assets/jwplayer-8.2.3/jwplayer.flash.swf')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/jwplayer-8.2.3/jwplayer.js')); ?>"></script>
    <script>
      jwplayer.key="<?php echo e(env('JW_KEY_8')); ?>";
    </script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/assets/js/app.js')); ?>"></script>
    <!--Errors-->
   <!-- <?php if(count($errors) > 0): ?>
    <script>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            Materialize.toast('<?php echo e($error); ?>', 4000,'red darken-4')
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
    <?php endif; ?> -->
    <script>
        $(document).ready(function() {
            var owl = $("#owl-demo14");
            owl.owlCarousel({
                itemsCustom: [
                    [0, 1],
                    [450, 1],
                    [600, 1],
                    [700, 1],
                    [1000, 1],
                    [1200, 1],
                    [1400, 1],
                    [1600, 1]
                ],
                autoPlay: true,
                stopOnHover:true,
                navigation: true,
                rtl : true
            });
            owl.trigger('owl.stop');
            setTimeout(function(){ 
              owl.trigger('owl.play', 4000); 
            }, 8000);
        });
    </script>
       <?php
        if(\Auth::check()){
        $genresId = "";
        if(isset($genres)){
          foreach($genres as $genre){
              $genresId .= "#".$genre->slug.",";
          }
          $genreId = trim($genresId, ', ');
      ?>
       <script>
        $(document).ready(function() {
          var genresId = '<?php echo e($genreId); ?>';
            var owl = $("#trending, #recent, #cast, #shows, #continueWatching, "+genresId);
            owl.owlCarousel({
                itemsCustom: [
                    [0, 3],
                    [450, 3],
                    [600, 3],
                    [700, 3],
                    [1000, 4],
                    [1200, 6],
                    [1400, 6],
                    [1600, 6]
                ],
                navigation: true,
                stopOnHover: true,
                autoPlay: 4000,
                rtl: true,
            });
        });
    </script>
  <?php } }?>
       <script>
         $(".play1").click(function(){
           $(".play1").addClass("hide");
             
             $(".stop1").removeClass("hide");
         
         });
         
         $(".stop1").click(function(){
           $(".stop1").addClass("hide");
            
            $(".play1").removeClass("hide");
         
         });
      </script>
    
    <script>
        /* Website Loader */
        jQuery(window).load(function () {
            $(".preload").fadeOut();
        });
    </script>
    
    <script>
        jQuery("#myElem").show().delay(3e3).queue(function (e) {
            $(this).hide();
            e()
        });
    </script>
    <script>
      $(document).ready(function() {
        $(document).on('click','.addToList', function(){
          var id = $(this).attr('data-id');
          var genres = $(this).attr('data-genres');
          var type = $(this).attr('data-type');
          var header = $(this).attr('data-header');
          $.ajax({
              type: 'POST',
              dataType: 'json',
              url: '<?php echo e(route("addToList")); ?>',
              data: {"_token": "<?php echo e(csrf_token()); ?>",'id' : id, 'type' : type },
              success: function(result) {
                  if(header == "yes"){
                    $("#add-slider-"+id).remove();
                    $("#item-slider-"+id).append('<a class="watch_buttons removeList" href="javascript:" data-type="'+type+'" data-id="'+id+'" data-header="yes" id="remove-slider-'+id+'"><i class="material-icons">check</i><?php echo app('translator')->getFromJson("frontend.remove_from_my_list"); ?></a>');
                  }else{
                    $("#add-"+genres+"-"+id).remove();
                    $("#item-"+genres+"-"+id).append('<a class="btn_overlay removeList" href="javascript:" data-type="'+type+'" data-id="'+id+'" data-header="no" data-genres="'+genres+'" id="remove-'+genres+'-'+id+'"><i class="material-icons">check</i><?php echo app('translator')->getFromJson("frontend.remove_from_my_list"); ?></a>');
                  }
              },
              error: function() {
                  alert('error');
              }
          });
        });

      $(document).on('click','.removeList', function(){
          var id = $(this).attr('data-id');
          var type = $(this).attr('data-type'); 
          var header = $(this).attr('data-header'); 
          var genres = $(this).attr('data-genres');

          var route =  "<?php echo e(\Route::current()->getName()); ?>";    
          $.ajax({
              type: 'POST',
              dataType: 'json',
              url: '<?php echo e(route("removeFromList")); ?>',
              data: {"_token": "<?php echo e(csrf_token()); ?>",'id' : id, 'type' : type },
              success: function(result) {
                  if(header == "yes"){
                    $("#remove-slider-"+id).remove();
                    $("#item-slider-"+id).append('<a class="watch_buttons addToList" href="javascript:" data-type="'+type+'" data-id="'+id+'" data-header="yes" id="add-slider-'+id+'"><i class="material-icons">add</i><?php echo app('translator')->getFromJson("frontend.add_to_my_list"); ?></a>');
                  }else{
                    $("#remove-"+genres+"-"+id).remove();
                    $("#item-"+genres+"-"+id).append('<a class="btn_overlay addToList" href="javascript:" data-type="'+type+'" data-id="'+id+'" data-header="no" data-genres="'+genres+'" id="add-'+genres+'-'+id+'"><i class="material-icons">add</i> <?php echo app('translator')->getFromJson("frontend.add_to_my_list"); ?></a>');
                    if(route == "getMyList"){
                      $("#remove-item-"+id).remove();
                    }
                  }
              },
              error: function() {
                  alert('error');
              }
          });
      });
    	
	$(document).on('click','.removeWatching', function(){
      var owl = $("#continueWatching");
      var id = $(this).attr('data-id');
      var type = $(this).attr('data-type');
      var key = $(this).attr('data-key');
      $.ajax({
          type: 'POST',
          dataType: 'json',
          url: '<?php echo e(route("removeWatching")); ?>',
          data: {"_token": "<?php echo e(csrf_token()); ?>",'id' : id, 'type' : type },
          success: function(result) {
            $("#removeItem_"+key).remove();	      },
          error: function() {
              alert('error');
          }
      });
    });


    });
    </script>
    <script type="text/javascript">
      $("[data-toggle=popover]").popover({
        html: true, 
        content: function() {
          return $('#popover-content').html();
        }
      });
    </script>
    <script type="text/javascript">
      function myFunction(elementId){
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val($("#"+elementId).val()).select();
        document.execCommand("copy");
        $temp.remove();
    }
    </script>

    <script type="text/javascript">
      window.setInterval(function(){
        var user_id = '<?php echo e(\Auth::user()->id); ?>';
        var session_id = '<?php echo e(Session::get("session_id")); ?>';
        var role = '<?php echo e(\Auth::user()->role_id); ?>';
        if(role !=2){
          $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo e(route("check.session")); ?>',
            data: {"_token": "<?php echo e(csrf_token()); ?>",'user_id' : user_id, 'session_id' : session_id },
            success: function(result) {
              if(result.type == 'success'){
                //M.toast({html: 'Your Device Limit Has Been Exceeded!', outDuration : 400, classes: 'bg', completeCallback: function(){
                  alert("Device Limit Exceeded!");
                  window.location.href = '<?php echo e(route("logout")); ?>';
                //}})
              }
            },
            error: function() {
                alert('error');
            }
          });
        }
      }, 60000);
    </script>
    <!--Page custom scripts-->
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/frontend.blade.php ENDPATH**/ ?>