    
    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!--tabs-->
    <div class="profile_tabs_section">
        <div class="container">
            <div class="col-md-12 padd_0">
                <div class="profile_right_info_sec">
                    <div class="profile_tabs_right_2">
                        <form action="<?php echo e(route('store.profile')); ?>" id="store_payment" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>Name :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="text" class="form-control" name="name" placeholder="Name">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>Email :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="email" class="form-control" name="email" placeholder="Email">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>Password</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" class="form-control" name="password" placeholder="Password">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>Confirm Password :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password">
                                </div>
                            </div>
                            
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-5"></div>
                                <div class="col-md-5">
                                    <div class="submit_buttons">
                                        <a href="<?php echo e(route('all.profiles')); ?>">Discard</a>
                                        <a href="javascript:{}" onclick="document.getElementById('store_payment').submit();" class="save_reverse">Save</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/profile/add_profile.blade.php ENDPATH**/ ?>