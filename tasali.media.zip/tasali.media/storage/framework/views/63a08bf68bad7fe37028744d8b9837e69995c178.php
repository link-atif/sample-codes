<?php $__env->startSection('content'); ?>

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Config
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
            <li class="active"> Edit Config </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Edit Config
                </header>
                <div class="panel-body">
                    <?php echo $__env->make('backend.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form class="cmxform form-horizontal tasi-form" enctype="multipart/form-data" 
                        action="<?php echo e(route('Backend::config.update', $row->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('post')); ?>

                        <?php $input = "amount" ;
                        ?>
                        <div class="form-group ">
                            <label for="<?php echo e($input); ?>"
                                class="control-label col-lg-2 <?php echo e($errors->has($input) ? ' text-danger' : ''); ?>"><?php echo e(__('backend.'.$input)); ?>

                                <span class="text-danger">*</span></label>
                            <div class="col-lg-10">
                                <input value="<?php echo e(@$row->$input); ?>"
                                    class=" form-control <?php echo e($errors->has($input) ? ' is-invalid' : ''); ?>"
                                    id="<?php echo e($input); ?>" name="<?php echo e($input); ?>" type="number" min="0" required />
                                <?php $__currentLoopData = $errors->get($input); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class='help-inline text-danger'>* <?php echo e($message); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <?php $input = "trial" ;
                        ?>
                        <div class="form-group ">
                            <label for="<?php echo e($input); ?>"
                                class="control-label col-lg-2 <?php echo e($errors->has($input) ? ' text-danger' : ''); ?>"><?php echo e(__('backend.'.$input)); ?>

                                <span class="text-danger">*</span></label>
                            <div class="col-lg-10">
                                <input value="<?php echo e(@$row->$input); ?>"
                                    class=" form-control <?php echo e($errors->has($input) ? ' is-invalid' : ''); ?>"
                                    id="<?php echo e($input); ?>" name="<?php echo e($input); ?>" type="number" min="0" max="1" required />
                                <?php $__currentLoopData = $errors->get($input); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class='help-inline text-danger'>* <?php echo e($message); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <?php $input = "trial_amount" ;
                        ?>
                        <div class="form-group ">
                            <label for="<?php echo e($input); ?>"
                                class="control-label col-lg-2 <?php echo e($errors->has($input) ? ' text-danger' : ''); ?>"><?php echo e(__('backend.'.$input)); ?>

                                <span class="text-danger">*</span></label>
                            <div class="col-lg-10">
                                <input value="<?php echo e(@$row->$input); ?>"
                                    class=" form-control <?php echo e($errors->has($input) ? ' is-invalid' : ''); ?>"
                                    id="<?php echo e($input); ?>" name="<?php echo e($input); ?>" type="number" min="0" required />
                                <?php $__currentLoopData = $errors->get($input); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class='help-inline text-danger'>* <?php echo e($message); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <?php $input = "subscription_duration" ;
                        ?>
                        <div class="form-group ">
                            <label for="<?php echo e($input); ?>"
                                class="control-label col-lg-2 <?php echo e($errors->has($input) ? ' text-danger' : ''); ?>"><?php echo e(__('backend.'.$input)); ?>

                                <span class="text-danger">*</span></label>
                            <div class="col-lg-10">
                                <input value="<?php echo e(@$row->$input); ?>"
                                    class=" form-control <?php echo e($errors->has($input) ? ' is-invalid' : ''); ?>"
                                    id="<?php echo e($input); ?>" name="<?php echo e($input); ?>" type="number" min="0" required />
                                <?php $__currentLoopData = $errors->get($input); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class='help-inline text-danger'>* <?php echo e($message); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <?php $input = "landing_image" ;
                        ?>
                        <div class="form-group ">
                            <label for="<?php echo e($input); ?>" class="control-label col-lg-2 <?php echo e($errors->has($input) ? ' text-danger' : ''); ?>"><?php echo e(__('backend.'.$input)); ?>

                                <span class="text-danger">*</span>
                            </label>
                            <div class="col-lg-10">
                                <div class="image_style">
                                    Choose a Image
                                    <input type="file" id="<?php echo e($input); ?>" name="<?php echo e($input); ?>" class="hide_file" onchange="encodeImageFileAsURL('<?php echo e($input); ?>','image_preview','old_image');">
                                    <?php $__currentLoopData = $errors->get($input); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class='help-inline text-danger'>* <?php echo e($message); ?></span> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12" style="padding-top: 5px;" id="image_preview"></div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12" id="old_image" style="padding-top: 5px;">
                                        <?php if(!empty($row->image)): ?>
                                        <img width="100px" height="100px" src="<?php echo e(thumb($row->image)); ?>">                                    
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php $input = "login_image" ;
                        ?>
                        <div class="form-group ">
                            <label for="<?php echo e($input); ?>" class="control-label col-lg-2 <?php echo e($errors->has($input) ? ' text-danger' : ''); ?>"><?php echo e(__('backend.'.$input)); ?>

                                <span class="text-danger">*</span>
                            </label>
                            <div class="col-lg-10">
                                <div class="image_style">
                                    Choose a Image
                                    <input type="file" id="<?php echo e($input); ?>" name="<?php echo e($input); ?>" class="hide_file" onchange="encodeImageFileAsURL('<?php echo e($input); ?>','poster_preview','old_photo');">
                                    <?php $__currentLoopData = $errors->get($input); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class='help-inline text-danger'>* <?php echo e($message); ?></span> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12" style="padding-top: 5px;" id="poster_preview"></div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12" id="old_photo" style="padding-top: 5px;">
                                        <?php if(!empty($row->photo)): ?>
                                        <img width="100px" height="100px" src="<?php echo e(thumb($row->photo)); ?>">                                    
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                            <div class="col-lg-offset-2 col-lg-10">
                                <button class="btn btn-success" type="submit">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/config/edit.blade.php ENDPATH**/ ?>