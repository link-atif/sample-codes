<?php $__env->startSection('content'); ?>
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 24px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
<div class="page-head">
    <h3 class="m-b-less">
        All Countries
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
            <li class="active">All Countries</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            <?php echo $__env->make('backend.countries.filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <section class="panel">
                <header class="panel-heading head-border">
                    All Countries <?php echo isset($count) ? "<span class='label label-success'>{$count}</span>" : null; ?>

                </header>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Code</th>
                                <th>Currency</th>
                                <th>Amount</th>
                                <!-- <th>Ongoing Amount</th> -->
                                <!-- <th>First Plan Name</th>
                                <th>Ongoing Plan Name</th> -->
                                <th>Actions</th>
                                <th>Status</th>
                                <th>Symbol in Left</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($c->name); ?></td>
                                <td><?php echo e($c->code); ?></td>
                                <td><?php echo e($c->curriency_code); ?></td>
                                <td><?php echo e($c->amount); ?></td>
                                <!-- <td><?php echo e($c->ongoing_amount); ?></td> -->
                              <!--   <td><?php echo e($c->first_plan_id); ?></td>
                                <td><?php echo e($c->ongoing_plan_id); ?></td> -->
                                <td>
                                  <a href="<?php echo e(route('Backend::countries.edit', $c->id)); ?>" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                                  <form action="<?php echo e(route('Backend::countries.destroy', $c->id)); ?>" method="post" style="display: inline;">
                                      <?php echo e(method_field('delete')); ?>

                                      <?php echo e(csrf_field()); ?>

                                      <button class="btn btn-danger btn-xs del-confirm" data-msg="<?php echo app('translator')->getFromJson('backend.confirm_delete'); ?>">
                                          <i class="fa fa-trash-o "></i>
                                      </button>
                                  </form>
                                </td>
                                <td>
                                    <label class="switch">
                                        <input type="checkbox" onclick="updateStatus('<?php echo e($c->id); ?>','status')" id="status<?php echo e($c->id); ?>" <?php echo e(($c->status == 1) ? 'checked="checked"' : ''); ?>>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                                <td><input type="checkbox" name="is_left" onclick="updateStatus('<?php echo e($c->id); ?>','is_left')" id="is_left<?php echo e($c->id); ?>" <?php echo e(($c->is_left == 1) ? 'checked="checked"' : ''); ?>></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>
            <div class="pagination">
              <?php echo e($countries->appends(Request::except('page'))->links()); ?>

            </div>      
        </div>
    </div>
</div>
<script type="text/javascript">
    function updateStatus(id, type){
      var status = 0;
      if($("#"+type+id).prop('checked')==true){ 
        status = 1;
      }
      $.ajax({
          type: 'POST',
          dataType: 'json',
          url: "<?php echo e(route('Backend::countries.status')); ?>",
          data: {'id' : id, 'status': status, 'type' : type },
          success: function(result) {
              //alert("Status Updated Successfully!");
          },
          error: function() {
              alert('error');
          }
      });
      
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/backend/countries/index.blade.php ENDPATH**/ ?>