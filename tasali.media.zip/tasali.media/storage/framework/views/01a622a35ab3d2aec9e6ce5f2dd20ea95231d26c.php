<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
    <META Http-Equiv="Pragma" Content="no-cache">
    <META Http-Equiv="Expires" Content="0">
    <title><?php echo e(websiteTitle()); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" />
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('assets/css/flexslider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/scrolling-nav.css')); ?>" rel="stylesheet">
    <?php
    if(app()->getLocale() == "en"){ ?>
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/responsive_login.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet">
    <?php
     }
    else{ ?>
        <link href="<?php echo e(asset('ar/assets/css/style.css')); ?>" rel="stylesheet"> 
        <link href="<?php echo e(asset('ar/assets/css/responsive_login.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('ar/assets/css/responsive.css')); ?>" rel="stylesheet">
   <?php } ?>    
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/headline.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/ionicons.min.css')); ?>" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.1.0/css/flag-icon.min.css" rel="stylesheet">
    <!-- Important Owl stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.css')); ?>">
    <!-- Default Theme -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.css')); ?>">
    <script src="<?php echo e(asset('assets/dist/jquery.min.js')); ?>"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js'></script>
</head>

<!-- The #page-top ID is part of the scrolling feature - the data-spy and data-target are part of the built-in Bootstrap scrollspy function -->
<?php
    if(app()->getLocale() == "en"){
        $langText = "عربى";
        $lang = "ar";
        $lang_link = '';
        $text_align = 'right';
    }
    else{
        $langText = "ENGLISH";
        $lang = "en";
        $lang_link = 'ar/';
        $text_align = 'left';
    }
?>
<body id="page-top" data-spy="scroll" data-target=".navbar">
    <div class="se-pre-con"></div>
    <!--top bar start-->
    <header class="header fixed-top">
    
        <!--top bar end-->
        <div class="top-bar w-100">
            <div class="container" style="width: 100%; padding-top: 1rem;">
                <div class="row">
                    <div class="col-6">
                        <a class="navbar-brand page-scroll logo no-margin" href="index.html">
                            <img src="<?php echo e(asset('images/Tasali-Logo.png')); ?>" class="img-fluid" alt="">
                        </a>
                    </div>
                    <!--top left col end-->
                    <div class="col-6 text-<?php echo e($text_align); ?> ">
                        <ul class="list-inline top-socials list-unstyled">
                            <li class="list-inline-item ">
                                <a class="nav-link cd-signin" id="head_sign" href="https://tasali.media/login"><i
                                        class="ion-ios-contact"></i></a>
                            </li>
                            <li class="list-inline-item login">
                                <a class="cd-signin btn-lg" href="https://tasali.media/login"><?php echo app('translator')->getFromJson('frontend.log_in'); ?></a>
                            </li>
                            <li class="list-inline-item">
                                <a href="<?php echo e(route('lang', [$lang])); ?>"><?php echo e($langText); ?></a>
                            </li>
                        </ul>
                    </div>
                    <!--top social col end-->
                </div>
                <!--row-->
            </div>
            <!--container-->
        </div>
        <!-- End of Container -->
        <nav class="navbar navbar-toggleable-md navbar-inverse bg-inverse  header-transparent">

            <div class="container" style="width: 100%;">
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                    data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarNav">
                    <ul class="navbar-nav " style="margin:0 auto">
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>index.html"><?php echo app('translator')->getFromJson('frontend.home'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>about.html"><?php echo app('translator')->getFromJson('frontend.m_about'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>terms.html"><?php echo app('translator')->getFromJson('frontend.terms_of_use'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>privacy.html"><?php echo app('translator')->getFromJson('frontend.privacy_cookie_policy'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>faq.html"><?php echo app('translator')->getFromJson('frontend.faqs'); ?></a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="<?php echo e($lang_link); ?>contact.html"><?php echo app('translator')->getFromJson('frontend.contact_us'); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <section id="home" class="slider-banner">
        <div class="main-slider">
            <div class="bg-no-overlay sign-in-heading">
                <h1><?php echo app('translator')->getFromJson('frontend.login'); ?></h1>
            </div>
        </div>
    </section>
    <section class="about-section all-space bg-parallax" data-jarallax='{"speed": 0.2}'>
        <div class="container">
            <div class="row step_center">
                <div class="scrollReveal sr-bottom sr-ease-in-out-quad sr-delay-1">
                    <div class="register_section">
                        <div class="register_center">
                            <div class="steps_form step_form_1" style="padding-top: 50px; padding-bottom: 50px;">
                                <?php echo $__env->make('frontend.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                                <?php if(Session::get('user_id')!="null" && Session::get('user_id') > 0): ?> 
                                    <?php echo $__env->make('frontend.components.devices', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                                <form action="<?php echo e(url('/login')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <label><?php echo app('translator')->getFromJson('frontend.email'); ?></label>
                                    <input type="email" name="email" autocomplete="off" class="form-control" placeholder="<?php echo app('translator')->getFromJson('frontend.email'); ?>">
                                    <label><?php echo app('translator')->getFromJson('frontend.password'); ?></label>
                                    <input type="password" name="password" autocomplete="off" class="form-control" placeholder="<?php echo app('translator')->getFromJson('frontend.password'); ?>">
                                    
                                    <div class="pull-left">
                                        <input type="checkbox" name="remember">
                                        <label><?php echo app('translator')->getFromJson('frontend.rememberme'); ?></label>
                                    </div>
                                    
                                    <div class="pull-right" style="color: #555;">
                                        <a href="<?php echo e(url('/password/reset')); ?>"><strong><?php echo app('translator')->getFromJson('frontend.forgot_password'); ?></strong></a>
                                    </div>
                                    <div class="col-md-6 col-sm-12 clearfix"><button type="submit" class="reg_conti"><?php echo app('translator')->getFromJson('frontend.login'); ?></button></div>
                                    <div class="section_or col-md-6 col-sm-12"><?php echo app('translator')->getFromJson('frontend.or'); ?></div>
                                    <div class="col-md-6 col-sm-12"><a href="https://tasali.media/login/facebook" class="fb_signup"><?php echo app('translator')->getFromJson('frontend.facebook_sign'); ?></a></div>
                                    <div class="pull-right col-md-6 col-sm-12" style="color: #555; text-align: right; padding-right: 0; margin-top: 10px; padding-bottom: 10px;">
                                       <?php echo app('translator')->getFromJson('frontend.signup_to_tasali', ['link' => url('register')]); ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12"></div>
            </div>
        </div>
    </section>
    <section class="content-section">
        <div class="row no-margin">
            <div class="col-md-12 no-padding">
                <hr>
            </div>
        </div>
    </section>
    <div id="play_video" class="modal">
        <div class="modal-content" style="height:70vh;padding:2px;">
        </div>
    </div>
    <section id="footer">
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="footer-widget-social">
                            <ul>
                                <li>
                                    <a data-tooltip="facebook" href="https://www.facebook.com/Tasali-114646016899548">
                                        <img src="<?php echo e(asset('images/facebook.png')); ?>" alt="" class="img-fluid">
                                    </a>
                                </li>
                                <li>
                                    <a data-tooltip="inestagram" href="https://www.instagram.com/mediatasali/">
                                        <img src="<?php echo e(asset('images/inesta.png')); ?>" alt="" class="img-fluid">
                                    </a>
                                </li>
                                <li>
                                    <a data-tooltip="youtube"
                                        href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                                        <img src="<?php echo e(asset('images/youtube.png')); ?>" alt="" class="img-fluid">
                                        </i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 text-center">
                        <p><?php echo app('translator')->getFromJson('frontend.copyrights'); ?></p></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <a href="javascript:;" class="scrollTop back-to-top" id="back-to-top">
        <i class="fa fa-arrow-up"></i>
    </a>

    <script src="<?php echo e(asset('assets/dist/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/jquery.flexslider-min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/scrollreveal.min.js')); ?>"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
    <script src="<?php echo e(asset('assets/dist/jarallax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/dist/jarallax-video.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scrolling-nav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jqBootstrapValidation.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

    <script type="text/javascript">
        var language = localStorage.getItem("language");            
        if(language == 'ar'){
            localStorage.setItem("language", "");
            window.location = '<?php echo e(route("lang", "ar")); ?>';
        }            
        if(language == 'en'){
            localStorage.setItem("language", "");
            window.location = '<?php echo e(route("lang", "en")); ?>';
        }
    </script>
</body>
</html>
<?php /**PATH D:\xampp7\htdocs\tasali\resources\views/auth/login.blade.php ENDPATH**/ ?>