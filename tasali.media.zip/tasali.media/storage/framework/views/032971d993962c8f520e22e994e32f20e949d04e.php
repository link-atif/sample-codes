<?php $__env->startSection('content'); ?>

    <!-- page head start-->
    <div class="page-head">
        <h3 class="m-b-less">
            Update <?php echo e($episode->title); ?>

        </h3>
        <!--<span class="sub-title">Welcome to Static Table</span>-->
        <div class="state-information">
            <ol class="breadcrumb m-b-less bg-less">
                <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('Backend::episodes.index')); ?>">Episodes</a></li>
                <li class="active"> Update <?php echo e($episode->title); ?> </li>
            </ol>
        </div>
    </div>
    <!-- page head end-->

    <!--body wrapper start-->
    <div class="wrapper">

        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Update <?php echo e($episode->title); ?>

                    </header>
                    <div class="panel-body">
                        <?php echo $__env->make('backend.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form">
                            <form class="cmxform form-horizontal tasi-form"
                                  action="<?php echo e(route('Backend::episodes.update', $episode->id)); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('put')); ?>

                                <div class="form-group ">
                                    <label for="name" class="control-label col-lg-2">Title</label>
                                    <div class="col-lg-5">
                                        <input type="text" name="title" value="<?php echo e($episode->translate('en')->title); ?>"
                                               class="form-control">
                                    </div>
                                </div>

                                <div class="form-group ">
                                    <label for="name" class="control-label col-lg-2">Arabic Title</label>
                                    <div class="col-lg-5">
                                        <input type="text" name="ar_title"
                                               value="<?php echo e($episode->translate('ar')->title); ?>" class="form-control"
                                               placeholder="العنوان بالعربى">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Show</label>
                                    <div class="col-lg-5">
                                        <select class="form-control" name="show_id">
                                            <?php $__currentLoopData = $shows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($show->id); ?>" <?php echo e($episode->show_id == $show->id ? 'selected' : null); ?>>
                                                    <?php echo e($show->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="image_id" class="control-label col-lg-2">Image</label>
                                    <div class="col-lg-5">
                                        <div class="image_style" style="padding: 25px 164px">
                                            Choose a image
                                            <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','old_image');">
                                        </div>
                                        <small class="text-danger"><?php echo app('translator')->getFromJson('backend.image_change_warning'); ?></small><br><br><br>
                                        <div id="image_preview"></div>
                                        <div id="old_image">
                                        <?php if(!empty($episode->image)): ?>
                                            <img width="100px" height="100px" src="<?php echo e(thumb($episode->image)); ?>">
                                        <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Season</label>
                                    <div class="col-lg-5">
                                        <input type="number" name="season" value="<?php echo e($episode->season); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Movie Duration (seconds)</label>
                                    <div class="col-lg-5">
                                        <input type="number" name="length" value="<?php echo e($episode->length or old('length')); ?>"
                                               placeholder="120" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Meta Tags</label>
                                    <div class="col-lg-5">
                                        <input type="text" name="meta_tags" value="<?php echo e($episode->meta_tags); ?>" placeholder="Meta Tags"  class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Meta Description</label>
                                    <div class="col-lg-5">
                                        <textarea name="meta_description" rows="8" class="form-control"><?php echo e($episode->meta_description); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-success" type="submit">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </div>
    <!--body wrapper end-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/episodes/edit.blade.php ENDPATH**/ ?>