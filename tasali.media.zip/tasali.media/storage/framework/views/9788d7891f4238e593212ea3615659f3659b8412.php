<div class="header_main">
   <div class="container">
       <div class="col-md-6 padd_0">
           <div class="logo">
            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('frontend/assets/images/logo.png')); ?>" alt="tasali"></a>
           </div>
       </div>
       <div class="col-md-6 padd_0">
            <?php if(\Auth::check()): ?>
                <a href="<?php echo e(route('logout')); ?>" class="signin_btn"><?php echo app('translator')->getFromJson('frontend.logout'); ?></a>
            <?php else: ?>
                <a href="<?php echo e(url('/login')); ?>" class="signin_btn"><?php echo app('translator')->getFromJson('frontend.sign'); ?></a>
            <?php endif; ?>
       </div>
   </div>
</div><?php /**PATH C:\xampp\htdocs\tasali\resources\views/frontend/components/slim_header.blade.php ENDPATH**/ ?>