<!DOCTYPE html>
 <?php
      if(app()->getLocale() == "en"){ 
  ?>
      <html dir="ltr" lang="en">
  <?php
   }else{ ?>
      <html dir="rtl" lang="ar">
 <?php } ?>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
  <META Http-Equiv="Pragma" Content="no-cache">
  <META Http-Equiv="Expires" Content="0">
  <title><?php echo e(websiteTitle()); ?></title>
  <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="<?php echo e(asset('assets/dist/jquery.min.js')); ?>"></script>
  <!-- Theme CSS -->
<?php
        if(app()->getLocale() == "en"){ 
    ?>
            <link href="<?php echo e(asset('frontend/assets/css/loginStyle.css')); ?>" rel="stylesheet">
    <?php
     }else{ ?>
        <link href="<?php echo e(asset('frontend/assets/css/ar_loginStyle.css')); ?>" rel="stylesheet">
   <?php } ?> 
  <style>
      .captcha-box { border-radius: 5px; border: 2px solid; padding: 0.5rem 2rem;  max-width: 400px; margin: 20px 0; }
      #canvas {
        width: 250px;
        height: 80px;
      }
    </style>
    
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-166297346-1"></script>
      <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'UA-166297346-1');
      </script>

    <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '349865283089919');
      fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=349865283089919&ev=PageView&noscript=1"
    /></noscript>
</head>
<body>
  <?php
    if(app()->getLocale() == "en"){
      $langText = "AR";
      $lang = "ar";
      $lang_link = '';
      $text_align = 'right';
      $selectedLang = "EN";
    }else{
      $langText = "EN";
      $selectedLang = "AR";
      $lang = "en";
      $lang_link = 'ar/';
      $text_align = 'left';
    }
    ?>
  <header class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <a class="navbar-brand page-scroll logo no-margin" href="index.html">
            <img src="<?php echo e(asset('frontend/assets/images/logo.png')); ?>" class="img-fluid" alt="">
          </a>
        </div>
        <div class="col-md-6 text-right">
          <ul class="top-links list-unstyled">
             <li class="pull-right">
                <div class="navbar-nav">
                  <div class="nav-item dropdown">
                      <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><?php echo e($selectedLang); ?></a>
                      <div class="dropdown-menu">
                          <a href="<?php echo e(route('lang', [$lang])); ?>"><?php echo e($langText); ?></a>
                      </div>
                  </div>
                </div>
              </li>
              <li class="pull-right login">
                  <a class="cd-signin btn-lg" href="https://tasali.media/logout"><?php echo app('translator')->getFromJson('frontend.logout'); ?></a>
              </li>
          </ul>
                    
        </div>
      </div>
    </div>
  </header>
  <div class="main mt-100">
    <div class="container">
      <div class="row text-center tabs">
        <div class="col-md-3 tab"><?php echo app('translator')->getFromJson('frontend.create_new_account'); ?></div>
        <div class="col-md-3 tab active"><?php echo app('translator')->getFromJson('frontend.your_plan'); ?></div>
        <div class="col-md-3 tab"><?php echo app('translator')->getFromJson('frontend.choose_payment'); ?></div>
        <div class="col-md-3 tab"><?php echo app('translator')->getFromJson('frontend.subscription'); ?></div>
      </div>
      <div class="form-container">

	<div class="right-arrow block_en none_ar" onclick="register();"><img src="<?php echo e(asset('frontend/assets/images/RgtArrow.png')); ?>" class="tic" alt=""></div>

  <div class="left-arrow block_ar none_en" onclick="register();"><img src="<?php echo e(asset('frontend/assets/images/LftArrow.png')); ?>" class="tic" alt=""></i></div>

        <h5><img src="<?php echo e(asset('frontend/assets/images/Good.png')); ?>" class="tic" alt=""> <?php echo app('translator')->getFromJson('frontend.trial_text'); ?></h5>
          <form>
            <div class="row plans py-5 justify-content-center">                                 
              <div class="col-md-3 ">
                  <!-- <a href="#">
                      <h5>Voucher</h5>
                      <div>Have a voucher?</div>
                      <div>Redeem it here.</div>
                      <div><i class="fa fa-times"></i>No channels available</div>
                  </a> -->
              </div>
              <div class="col-sm-4 col-md-4 col-lg-3 plan">                 
                  <a href="#">
                      <!-- <img src="<?php echo e(asset('images/visa.png')); ?>"> -->
                      <h5><?php if($plans->is_left == 1): ?><?php echo e($plans->curriency_code); ?> <?php endif; ?> <?php echo e($plans->amount); ?> <?php if($plans->is_left == 0): ?><?php echo e($plans->curriency_code); ?> <?php endif; ?>  <?php echo app('translator')->getFromJson('frontend.month'); ?></h5>
                      <div><?php echo app('translator')->getFromJson('frontend.free_trial'); ?></div>
                  </a>
              </div>
              <div class="col-md-3">
                  <!-- <a href="#">
                      <img src="img/visa.png">
                      <h5>6 $ Mothly</h5>
                      <div>14 days free trial</div>
                      <div><i class="fa fa-times" aria-hidden="true"></i>No channels available</div>
                  </a> -->
              </div>                  
            </div>
          </form>
            <h5><img src="<?php echo e(asset('frontend/assets/images/Good.png')); ?>" class="tic" alt=""> <?php echo app('translator')->getFromJson('frontend.trial_ends'); ?></h5>
            <h5><img src="<?php echo e(asset('frontend/assets/images/Good.png')); ?>" class="tic" alt=""> <?php echo app('translator')->getFromJson('frontend.cancel_any_time'); ?></h5>
            <div class="form-footer">
                <div class="row my-5">
                  <div class="col-md-6">
                    <?php echo app('translator')->getFromJson('frontend.terms_conditions_text'); ?> <a href="<?php echo e($lang_link); ?>terms.html"><?php echo app('translator')->getFromJson('frontend.terms_conditions'); ?></a>
                  </div>
                  <div class="col-md-1">&nbsp;</div>
                  <div class="col-md-5">
                    <div class="pull-left"><?php echo app('translator')->getFromJson('frontend.already_account'); ?> <a href="https://tasali.media/login"><?php echo app('translator')->getFromJson('frontend.login_text'); ?></a></div>
                    <div class="pull-right"><a href="<?php echo e($lang_link); ?>contact.html"><?php echo app('translator')->getFromJson('frontend.need_help'); ?></a></div>
                  </div>
                </div>
            </div>
        </div>   
    </div>
  </div>
  <section id="footer">
    <div class="footer-bottom">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-12">
              <div class="footer-widget-social">
                  <ul>
                      <li>
                          <a data-tooltip="facebook" href="https://www.facebook.com/Tasali-114646016899548">
                              <img src="<?php echo e(asset('images/facebook.png')); ?>" alt="" class="img-fluid">
                          </a>
                      </li>
                      <li>
                          <a data-tooltip="inestagram" href="https://www.instagram.com/mediatasali/">
                              <img src="<?php echo e(asset('images/inesta.png')); ?>" alt="" class="img-fluid">
                          </a>
                      </li>
                      <li>
                          <a data-tooltip="youtube"
                              href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                              <img src="<?php echo e(asset('images/youtube.png')); ?>" alt="" class="img-fluid">
                              </i>
                          </a>
                      </li>
                  </ul>
              </div>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-12 text-center">
              <p><?php echo app('translator')->getFromJson('frontend.copyrights'); ?></p></p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script type="text/javascript">
      //$("#register").click(function(){
      function register(){
        window.location.href = '<?php echo e(route("registerStep3")); ?>';
      }
      //});
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\tasali\resources\views/auth/register/step_2.blade.php ENDPATH**/ ?>