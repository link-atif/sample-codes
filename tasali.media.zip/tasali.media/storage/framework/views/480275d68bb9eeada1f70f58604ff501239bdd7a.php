<div class="row">
    <form class="" action="<?php echo e(route('Backend::users.filter')); ?>" method="get">
        <div class="col-lg-2">
            <select class="form-control select2" name="role">
                <option value="all">All Privileges</option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e(Request::input('role') == $role->id ? 'selected' : null); ?>>
                        <?php echo e($role->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-lg-2 pull-right">
            <button type="submit" class="btn btn-block btn-primary pull-right">Filter & Search</button>
        </div>
        <div class="col-lg-3 pull-right">
            <input type="text" name="keyword" value="<?php echo e((Request::input('keyword'))?? ""); ?>" placeholder="search..."
                    class="form-control">
        </div>
    </form>
</div>
<br>
<?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/users/filter_form.blade.php ENDPATH**/ ?>