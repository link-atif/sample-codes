<?php $__env->startSection('content'); ?>
<!-- page head start-->
<div class="page-head">
    <h3><?php echo e($page_title); ?></h3>
</div>

<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-12 col-xl-12">
            <div class="trending-column">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Users</h3></div>
                        <section class="panel">
                            <div class="table-responsive">
                                <table class="table table-striped" id="users-table">
                                    <thead>
                                        <tr>
                                            <th>User Name</th>
                                            <th>Email</th>
                                            <th>Privilege</th>
                                            <th>City</th>
                                            <th>Country</th>
                                            <th>Logs</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $au): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($au->name); ?></td>
                                            <td><?php echo e($au->email); ?></td>
                                            <td><?php echo e($au->role->label); ?></td>
                                            <td><?php echo e($au->city); ?></td>
                                            <td><?php echo e($au->country); ?></td>
                                            <td><a href="<?php echo e(route('Backend::logs', $au->id)); ?>" class="btn btn-primary btn-small">User Logs</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--body wrapper end-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
<script>
  $(document).ready(function() {
    $('#users-table').DataTable();
} );
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/backend/all_users.blade.php ENDPATH**/ ?>