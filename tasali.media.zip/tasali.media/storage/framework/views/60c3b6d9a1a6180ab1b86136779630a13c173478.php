<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
	<br><br><br><br><br>

	<h5 class="header white-text">Movies</h5>
	<?php echo $__env->make('frontend.components.grid-items', array('items'=>$movies), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="front-pagination"><?php echo e($movies->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/movies.blade.php ENDPATH**/ ?>