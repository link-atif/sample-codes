<?php $__env->startSection('content'); ?>

<!-- page head start-->
<div class="page-head">
    <h3><?php echo e($page_title); ?></h3>
</div>

<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-12 col-xl-12">
            <div class="trending-column">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Top Watching Titles </h3></div>
                        <div class="col-md-6 col-xl-6">
                            <section class="panel">
                                <header class="panel-heading head-border" style="font-weight: bold;">Movies: </header>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Views</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $trendingMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($tm->title); ?></td>
                                                <td><?php echo e($tm->views); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </section>
                        </div>
                        <div class="col-md-6 col-xl-6">
                            <section class="panel">
                                <header class="panel-heading head-border" style="font-weight: bold;">Shows:</header>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Views</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $trendingShows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($ts->title); ?></td>
                                                <td><?php echo e($ts->views); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--body wrapper end-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<script>
  $(document).ready(function() {
    $('#table').DataTable();
} );
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/backend/top_watching_titles.blade.php ENDPATH**/ ?>