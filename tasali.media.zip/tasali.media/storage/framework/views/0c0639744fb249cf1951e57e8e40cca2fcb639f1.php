<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Tasali Report</title>
      <style type="text/css" media="all">
        body{font-family: DejaVu Sans, sans-serif;}
        body h1{font-family: DejaVu Sans, sans-serif;}
        body h2{font-family: DejaVu Sans, sans-serif;}
        body h3{font-family: DejaVu Sans, sans-serif;}
        body h4{font-family: DejaVu Sans, sans-serif;}
        body h5{font-family: DejaVu Sans, sans-serif;}
        body h6{font-family: DejaVu Sans, sans-serif;}
        body p{font-family: DejaVu Sans, sans-serif;}
        body a{font-family: DejaVu Sans, sans-serif;}
        body span{font-family: DejaVu Sans, sans-serif;}
        body td{font-family: DejaVu Sans, sans-serif;}
        body tr{font-family: DejaVu Sans, sans-serif;}
        body th{font-family: DejaVu Sans, sans-serif;}
        body div{font-family:DejaVu Sans, sans-serif;}
        body footer{font-family: DejaVu Sans, sans-serif;}

.clearfix:after {
  content: "";
  display: table;
  clear: both;
}

a {
  color: #0087C3;
  text-decoration: none;
}

body {
  position: relative;
  width: 16cm;  
  margin: 0 auto; 
  color: #555555;
  background: #FFFFFF; 
  font-size: 14px; 
  font-family: SourceSansPro;
}

header {
  padding: 10px 0;
  margin-bottom: 20px;
  border-bottom: 1px solid #dee2e6;
}

#logo {
  float: left;
  margin: 0px 10px 0 0;
}

#logo img {
  height: 70px;
}

#company {
  float: left;
  text-align: left;
}


#details {
  margin-bottom: 50px;
}

#client {
  float: left;
}

#client .to {
  color: #777777;
}

h2.name {
  font-size: 16px;
  font-weight: 600;
  margin: 0;
  text-transform: capitalize;
}

#invoice {
  float: right;
  text-align: right;
}

#invoice h1 {
  color: #495057;
  font-size: 24px;
  line-height: 1em;
  font-weight: normal;
  margin: 0  0 10px 0;
}

#invoice .date2 {
  font-size: 1.1em;
  color: #723e0d;
  font-weight: bold;
}

table {
  width: 100%;
  border-collapse: collapse;
  border-spacing: 0;
  margin-bottom: 20px;
}

table tbody td {
  padding: 8px;
  border-bottom: 1px solid #dee2e6;
    text-align: left !important;
}

table th {
  white-space: nowrap;        
    color: #723e0d;
    padding: 6px;
    background: #fefefe;
    text-align: center;
    font-weight: bold;
    border-bottom: 1px solid #dee2e6;
    text-align: left;
}

table tbody{padding-bottom: 20px;}

table tbody tr:nth-child(even) {background: #fff;}
table tbody tr:nth-child(odd) {background: #f7f4f6}


table td {
  text-align: right;
}

table td h3{
  color: #57B223;
  font-size: 1.2em;
  font-weight: normal;
  margin: 0 0 0.2em 0;
}

table .no {
  color: #FFFFFF;
  font-size: 1.6em;
  background: #57B223;
}

table .desc {
  text-align: left;
}

table .unit {
  background: #DDDDDD;
}

table .qty {
}

table .total {
  background: #57B223;
  color: #FFFFFF;
}

table td.unit,
table td.qty,
table td.total {
  font-size: 1.2em;
}

table tbody tr:last-child td {
  border: none;
}

table tfoot td {
  padding: 12px 20px;
  background: #FFFFFF;
  border-bottom: none;
  font-size: 14px;
  white-space: nowrap;
  border-top: 1px solid #AAAAAA;
  font-weight: bold;
  color: #495057;
}

table tfoot tr:first-child td {
  border-top: none; 
}

table tfoot tr:last-child td {
  /* color: #57B223; */
  /* font-size: 1.4em; */
  /* border-top: 1px solid #57B223; */
}

table tfoot tr td:first-child {
  border: none;
}

#thanks{
  font-size: 2em;
  margin-bottom: 50px;
}

#notices{
  /* padding-left: 6px; */
  /* border-left: 6px solid #0087C3; */
}

#notices .notice {margin: 6px 0 0 0;}

footer {
  color: #777777;
  width: 100%;
  bottom: 0;
  padding: 8px 0;
  text-align: center;
}

#notices div{ font-size: 14px;}


footer .info_foot{text-align: center;color: #723e0d;border-top: solid 1px #723e0d;border-bottom: solid 1px #723e0d;font-size: 14px;font-weight: 600;padding: 8px 0px;margin: 70px 0 0 0;}
footer .info_foot a{ text-align: center; color: #723e0d;  font-size: 14px; font-weight: 600;}

footer p{font-size: 14px;line-height: 22px;margin: 7px 0 5px 0;color: #495057;}
footer p a{color: #495057;}

      </style>
  </head>
  <body>
    <header class="clearfix">
    </header>
    <div id="details" class="clearfix">
        <div id="client">
          	<div class="to">Date: <?php echo e($date); ?></div>
          	<div class="to">Today's Visitors: <?php echo e($total_visitors); ?></div>
         	<div class="to">Today's Uploaded Files: <?php echo e($videos); ?></div>
         	<div class="to">Total Uploaded Files:  <?php echo e($allVideos); ?></div>
        </div>
      </div>
    <main>
    	<h3>Data on Site:</h3>
      <table border="0" cellspacing="0" cellpadding="0">
        <thead>
          <tr>
            <th>#</th>
            <th>Daily</th>
            <th>Weekly</th>
            <th>Monthly</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Users</td>
            <td><?php echo e($today_users); ?></td>
            <td><?php echo e($weekly_users); ?></td>
            <td><?php echo e($monthly_users); ?></td>
            <td><?php echo e($users); ?></td>
          </tr>
          <tr>
            <td>Movies</td>
            <td><?php echo e($today_movies); ?></td>
            <td><?php echo e($weekly_movies); ?></td>
            <td><?php echo e($monthly_movies); ?></td>
            <td><?php echo e($movies); ?></td>
          </tr>
          <tr>
            <td>Shows</td>
            <td><?php echo e($today_shows); ?></td>
            <td><?php echo e($weekly_shows); ?></td>
            <td><?php echo e($monthly_shows); ?></td>
            <td><?php echo e($shows); ?></td>
          </tr>
          <tr>
            <td>Episodes</td>
            <td><?php echo e($today_episodes); ?></td>
            <td><?php echo e($weekly_episodes); ?></td>
            <td><?php echo e($monthly_episodes); ?></td>
            <td><?php echo e($episodes); ?></td>
          </tr>
          <tr>
            <td>Casts</td>
            <td><?php echo e($today_casts); ?></td>
            <td><?php echo e($weekly_casts); ?></td>
            <td><?php echo e($monthly_casts); ?></td>
            <td><?php echo e($casts); ?></td>
          </tr>
           <tr>
            <td>Genres</td>
            <td><?php echo e($today_genres); ?></td>
            <td><?php echo e($weekly_genres); ?></td>
            <td><?php echo e($monthly_genres); ?></td>
            <td><?php echo e($genres); ?></td>
          </tr>
        </tbody>
      </table>

      <h3>Top Watching Titles:</h3>
      <table border="0" cellspacing="0" cellpadding="0">
        <thead>
          <tr>
            <th colspan="2">Movies:</th>
          </tr>
          <tr>
            <th>Title</th>
            <th>Views</th>
          </tr>
        </thead>
        <tbody>
          	<?php $__currentLoopData = $trendingMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        <tr>
		            <td><?php echo e(removeSpecialChar($tm->title)); ?></td>
		            <td><?php echo e($tm->views); ?></td>
		        </tr>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <table border="0" cellspacing="0" cellpadding="0">
        <thead>
    	<tr>
        <th colspan="2">Shows:</th>
      	</tr>
          <tr>
            <th>Title</th>
            <th>Views</th>
          </tr>
        </thead>
        <tbody>
          	<?php $__currentLoopData = $trendingShows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <tr>
	            <td><?php echo e(removeSpecialChar($ts->title)); ?></td>
	            <td><?php echo e($ts->views); ?></td>
	        </tr>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <h3>Site Visitors & Revenue:</h3>
      <table border="0" cellspacing="0" cellpadding="0">
        <thead>
          <tr>
            <th>Country</th>
            <th>Total Users</th>
            <th>Revenue</th>
          </tr>
        </thead>
        <tbody>
          	<?php $__currentLoopData = $site_visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        <tr>
	            <td><?php echo e($sv->country); ?></td>
	            <td><?php echo e($sv->total); ?></td>
	            <td><?php echo e($sv->amount); ?> <?php echo e(currency_code($sv->country)); ?></td>
	        </tr>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </main>
  </body>
</html><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/report.blade.php ENDPATH**/ ?>