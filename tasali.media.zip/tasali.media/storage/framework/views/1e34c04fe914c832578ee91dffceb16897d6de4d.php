<?php $__env->startSection('content'); ?>

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Update <?php echo e($page->title); ?>

    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('Backend::pages.index')); ?>">Pages</a></li>
            <li class="active"> Update <?php echo e($page->title); ?> </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Update <?php echo e($page->title); ?>

                </header>
                <div class="panel-body">
                    <?php echo $__env->make('backend.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="<?php echo e(route('Backend::pages.update', $page->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('put')); ?>

                            <div class="form-group ">
                                <label for="title" class="control-label col-lg-2">Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="title" value="<?php echo e($page->translate('en')->title ?? ''); ?>" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Arabic Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="ar_title" value="<?php echo e($page->translate('ar')->title ?? ''); ?>" class="form-control" placeholder="الأسم بالعربى">
                                </div>
                            </div>

                            
                            <div class="form-group ">
                                <label for="content" class="control-label col-lg-2">Content</label>
                                <div class="col-lg-5">
                                    <textarea class="summernote form-control" name="content">
                                        <?php echo e($page->translate('en')->content ?? ''); ?>

                                    </textarea>
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="content" class="control-label col-lg-2">Arabic Content</label>
                                <div class="col-lg-5">
                                    <textarea class="summernote form-control" name="ar_content">
                                        <?php echo e($page->translate('ar')->content ?? ''); ?>

                                    </textarea>
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Image</label>
                                <div class="col-lg-5">
                                    <div class="image_style" style="padding: 25px 180px;">
                                        Choose a image
                                        <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','old_image');"/>
                                    </div>
                                    <div id="image_preview"></div>
                                    <div id="old_image">
                                    <?php if($page->image != null): ?>
                                        <img src="<?php echo e(asset(thumb($page->image))); ?>" width="100px" height="100px" style="margin-top: 10px;" />
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group ">
                                    <label for="active" class="control-label col-lg-2">Active</label>
                                    <div class="col-lg-5">
                                        <input type="checkbox" name="is_active" value="1" id="active"
                                        <?php echo e((isset($page->is_active)&& $page->is_active) ? 'checked' : null); ?>/> 
                                    </div>
                                </div>

                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!--summernote-->
    <script src="<?php echo e(asset('backend/js/summernote/dist/summernote.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.summernote').summernote({
                height: 200,
                minHeight: null,
                maxHeight: null,
                focus: true,
                toolbar: [
                    ['style', ['style']],
                    ['fontStyle', ['bold', 'italic', 'underline', 'clear']],
                    ['fontName', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['table', ['table']],
                    ['insert', ['video', 'media', 'link', 'hr', 'picture']],
                    ['font', ['strikethrough', 'superscript', 'subscript']],
                    ['misc', ['redo', 'undo', 'codeview']],
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/pages/edit.blade.php ENDPATH**/ ?>