<section id="footer">
  <div class="footer-bottom footer-sticky">
    <div class="container fcontainer">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12">
          <div class="footer-widget-social">
            <ul>
              <li>
                <a data-tooltip="facebook" href="https://www.facebook.com/Tasali-114646016899548">
                  <img src="<?php echo e(asset('images/facebook.png')); ?>" alt="" class="img-fluid">
                </a>
              </li>
              <li>
                <a data-tooltip="inestagram" href="https://www.instagram.com/mediatasali/">
                  <img src="<?php echo e(asset('images/inesta.png')); ?>" alt="" class="img-fluid">
                </a>
              </li>
              <li>
                <a data-tooltip="youtube" href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                  <img src="<?php echo e(asset('images/youtube.png')); ?>" alt="" class="img-fluid">
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 text-center">
  <div class="copyright">            
<p style="color: #DDB86C;"><?php echo app('translator')->getFromJson('frontend.copyrights'); ?></p></div>
        </div>
      </div>
    </div>
  </div>
</section>
<div id="play_video" class="modal">
  <div class="modal-content" style="height:70vh;padding:2px; background-image: linear-gradient(to top, rgba(199,144,54,1) 10%, rgba(0,0,13,1) 65%);">
  </div>
</div><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/components/footer.blade.php ENDPATH**/ ?>