<?php $__env->startSection('content'); ?>
    <!-- page head start-->
    <div class="page-head">
        <h3 class="m-b-less">
            Update <?php echo e($movie->title); ?>

        </h3>
        <!--<span class="sub-title">Welcome to Static Table</span>-->
        <div class="state-information">
            <ol class="breadcrumb m-b-less bg-less">
                <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('Backend::movies.index')); ?>">Movies</a></li>
                <li class="active"> Update <?php echo e($movie->title); ?> </li>
            </ol>
        </div>
    </div>
    <!-- page head end-->

    <!--body wrapper start-->
    <div class="wrapper">

        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Update <?php echo e($movie->title); ?>

                    </header>
                    <div class="panel-body">
                        <?php echo $__env->make('backend.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form">
                            <form class="cmxform form-horizontal tasi-form"
                                  action="<?php echo e(route('Backend::movies.update', $movie->id)); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('put')); ?>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Title</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="title" value="<?php echo e($movie->translate('en')->title); ?>"
                                                       class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Genre</label>
                                            <div class="col-lg-9">
                                                <select class="form-control js-example-basic-multiple" name="genres[]" multiple>
                                                    <?php
                                                        $genres_id = old('genres') ?? ($movie->genres->pluck('id')->toArray() ?? []);
                                                    ?>
                                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($genre->id); ?>" <?php echo e((in_array($genre->id, $genres_id))?"selected":""); ?>>
                                                            <?php echo e($genre->title); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Arabic Title</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="ar_title" value="<?php echo e($movie->translate('ar')->title); ?>"
                                                       class="form-control" placeholder="العنوان بالعربى">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Cast</label>
                                            <div class="col-lg-9">
                                                <select class="form-control js-example-basic-multiple" name="casts[]" multiple>
                                                    <?php
                                                        $casts_id = old('casts') ?? ($movie->casts->pluck('id')->toArray() ?? []);
                                                    ?>
                                                    <?php $__currentLoopData = $casts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cast->id); ?>" <?php echo e((in_array($cast->id,$casts_id))?"selected":""); ?>>
                                                            <?php echo e($cast->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">IMDB Url</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="imdb_url" value="<?php echo e($movie->imdb_url); ?>"
                                                       placeholder="" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Production Year</label>
                                            <div class="col-lg-9">
                                                <input type="number" name="production" value="<?php echo e($movie->production); ?>"
                                                       placeholder="2016" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Movie Duration (seconds)</label>
                                            <div class="col-lg-9">
                                                <input type="number" min="0" name="length" value="<?php echo e($movie->length); ?>"
                                                       placeholder="120" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label class="control-label col-lg-3">Publish Date</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control form-control-inline input-medium default-date-picker" value="<?php echo e($movie->publish_date); ?>" name="publish_date"/>
                                                <span class="help-block">Select date</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Age</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="age" value="<?php echo e($movie->age); ?>" placeholder="18+"
                                                       class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Publish Country</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="publish_country"
                                                       value="<?php echo e($movie->translate('en')->publish_country); ?>"
                                                       placeholder="egypt" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Arabic Publish Country</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="ar_publish_country"
                                                       value="<?php echo e($movie->translate('ar')->publish_country); ?>" placeholder="مصر"
                                                       class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Description</label>
                                            <div class="col-lg-9">
                                                <textarea name="desc" rows="8"
                                                          class="form-control"><?php echo e($movie->translate('en')->desc); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Arabic Description</label>
                                            <div class="col-lg-9">
                                                <textarea name="ar_desc" rows="8" class="form-control"><?php echo e($movie->translate('ar')->desc); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="poster" class="control-label col-lg-3">Poster</label>
                                            <div class="col-lg-9">
                                                <div class="image_style">
                                                    Choose a image
                                                    <input type="file" name="poster" id="poster" class="hide_file" onchange="encodeImageFileAsURL('poster','poster_preview','old_poster');">
                                                </div>
                                                <small class="text-danger"><?php echo app('translator')->getFromJson('backend.image_change_warning'); ?></small><br><br><br>
                                                <div id="poster_preview"></div>
                                                <div id="old_poster">
                                                <?php if($movie->poster !=""): ?>
                                                    <img width="100px" height="100px" src="<?php echo e(thumb($movie->poster)); ?>">
                                                <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="poster" class="control-label col-lg-3">Wide Image</label>
                                            <div class="col-lg-9">
                                                <div class="image_style">
                                                    Choose a image
                                                    <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','old_image');">
                                                </div>
                                                <small class="text-danger"><?php echo app('translator')->getFromJson('backend.image_change_warning'); ?></small><br><br><br>
                                                <div id="image_preview"></div>
                                                <div id="old_image">
                                                <?php if($movie->poster !=""): ?>
                                                    <img width="200px" height="100px" src="<?php echo e(thumb($movie->image)); ?>">
                                                <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Movie File</label>
                                            <div class="col-lg-9">
                                                <select class="form-control select2" name="video_id">                                            
                                                    <option value="">Select Video</option>
                                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($v->id); ?>" <?php echo e((isset($movie->video->id) && $movie->video->id == $v->id)?"selected":""); ?>>
                                                            <?php echo e($v->original_title); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Meta Tags</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="meta_tags" value="<?php echo e($movie->meta_tags); ?>" placeholder="Meta Tags"  class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Meta Description</label>
                                            <div class="col-lg-9">
                                                <textarea name="meta_description" rows="8" class="form-control"><?php echo e($movie->meta_description); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-success" type="submit">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </div>
    <!--body wrapper end-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/backend/movies/edit.blade.php ENDPATH**/ ?>