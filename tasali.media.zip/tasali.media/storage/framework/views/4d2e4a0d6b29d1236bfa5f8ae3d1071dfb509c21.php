<?php $__env->startSection('content'); ?>
	<?php
		if(app()->getLocale() == "en"){
		    $cw_title = "Continue Watching";
		    $t_title = "Trending";
		}
		else{
		    $cw_title = 'تابع المشاهدة';
		    $t_title = 'الشائع';
		}
	?>
	<?php echo $__env->make('frontend.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 	<?php echo $__env->make('frontend.components.header-swiper', ['slider' => $slider], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bg_gradient_strip"></div>
	 
	<?php if(!empty($continue_watching)): ?>
	<?php echo $__env->make('frontend.components.continue-watching', ['generalSwiperId' => 'continueWatching', 'generalSwiperName' => $cw_title, 'gsItems' => $continue_watching], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
	<?php echo $__env->make('frontend.components.general-swiper', ['generalSwiperId' => 'trending', 'generalSwiperName' => $t_title, 'gsItems' => $trending], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 	
	<?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo $__env->make('frontend.components.general-swiper', ['generalSwiperId' => $genre->slug, 'generalSwiperName' => $genre->title, 'gsItems' => $genre->movies], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo $__env->make('frontend.components.general-swiper', ['generalSwiperId' => $genre->slug, 'generalSwiperName' => $genre->title, 'gsItems' => $genre->shows], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/frontend/home.blade.php ENDPATH**/ ?>