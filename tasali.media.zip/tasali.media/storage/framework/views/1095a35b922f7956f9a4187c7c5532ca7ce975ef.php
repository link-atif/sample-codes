<header class="header header_fixed" data-aos="fade-down" data-aos-duration="1200">
    <!--navigation-->
    <div class="nav-main">
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-default" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	                       	<span class="sr-only">Toggle navigation</span>
	                        <span class="icon-bar"></span>
	                        <span class="icon-bar"></span>
	                        <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand logo" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('frontend/assets/images/logo.png')); ?>" alt="Logo"></a>
                    </div>
                    
                     
                    
                    <div class="header_toggle_left dropdown">
                        <a href="#" class="toogle_bars dropdown-toggle" data-toggle="dropdown">
                        	<i class="fas fa-bars"></i>
                        </a>
                        <div class="dropdown-menu mega_drop_down_menu">
                            <?php 
                            	$i = 1;
                            	$j = 1; 
                            ?>
                           
                            <?php $__currentLoopData = $genres->chunk(7); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="col-md-3">
                                <h4><?php if($j==1): ?> <?php echo app('translator')->getFromJson('frontend.genres'); ?> <?php else: ?> <?php echo e(" "); ?> <?php endif; ?></h4>
                                <?php $__currentLoopData = $genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                	<li><a href="<?php echo e(route('genre', $g->slug)); ?>"><?php echo e($g->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                           	<?php  $j++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <div class="nav_right">
                        
                        <li>
                            <div class="search_header">
                                <form id="search" method="get" action="<?php echo e(route('search')); ?>">
                                <i class="fas fa-search">
                                    <a href="javascript:{}" onclick="document.getElementById('search').submit();"
                                        style="font-size:26px"></a>
                                </i>
                                <input type="text" class="form-control" placeholder="<?php echo app('translator')->getFromJson('frontend.search'); ?>" name="keyword">
                                </form>
                            </div>
                        </li>
                        
                        <li>
                            <?php
                                if(app()->getLocale() == "en"){
                                    $langText = "AR";
                                    $lang = "ar";
                                }
                                else{
                                    $langText = "EN";
                                    $lang = "en";
                                }

                                if(app()->getLocale() == "en"){
                                    $selectedLang = "EN";
                                }
                                else{
                                    $selectedLang = "AR";
                                }
                            ?>
                            <a href="<?php echo e(route('kidSection')); ?>"><?php if($is_kid == 0): ?> <?php echo app('translator')->getFromJson('frontend.kids'); ?> <?php else: ?> <?php echo app('translator')->getFromJson('frontend.main'); ?> <?php endif; ?></a>
                        </li>
                        <li class="dropdown notification_bar">
                              <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                              <i class="far fa-bell"></i>
                              <!--<span class="caret"></span>--></a>
                               <ul class="dropdown-menu notification-menu">
                                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php ( $nUrl = isset($n['season']) ? 'shows/' . $n['slug'] :'movies/' . $n['slug'] ) ?>
                                 <li><a href="<?php if(isset($n['season'])): ?> <?php echo e(route('single.show',$n['slug'])); ?> <?php else: ?> <?php echo e(route('single.movie',$n['slug'])); ?> <?php endif; ?>">

                                    <div class="card">
                                        <div class="card-horizontal">
                                            <div class="col-md-4 col-lg-4 col-sm-12">
                                                <?php if(!empty($n['poster'])): ?>
                                                <img src="<?php echo e(thumb((object)$n['poster'])); ?>" alt="<?php echo e($n['title']); ?>">
                                                <?php else: ?>
                                                <img src="<?php echo e(asset('frontend/assets/images/tasali-logo.png')); ?>" alt="<?php echo e($n['title']); ?>">
                                                <?php endif; ?>
                                            </div>
                                            <div class="card-body col-md-8 col-lg-8 col-sm-12">
                                                <h3 class="card-title"><?php echo e($n['title']); ?></h3>
                                                <p class="card-text"><?php echo e(time_elapsed_string($n['created_at'])); ?></p>
                                            </div>
                                        </div>
                                    </div>

                                </a></li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                        </li>
                        
                        
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <span class="user_icon">
                                    <?php if(!is_null(Auth::user()->avatar)): ?> 
                                        <img src="<?php echo e(asset('frontend/assets/images/avatar/'.Auth::user()->avatar.'.jpg')); ?>" alt="Logo">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('frontend/assets/images/avater.jpg')); ?>" alt="Logo">
                                    <?php endif; ?>
                                </span>
                                <span class="user_name_control">
                                <?php if(Auth::user()->name): ?>
                                    <?php echo e(Auth::user()->name); ?>

                                <?php else: ?>
                                    User Account
                                <?php endif; ?>
                                </span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo e(route('getMyList')); ?>"><?php echo app('translator')->getFromJson('frontend.my_list'); ?></a></li>
                                <?php if(Auth::user()->parent_id > 0): ?>
                                <li><a href="<?php echo e(route('profile.setting', Auth::user()->id)); ?>"><?php echo app('translator')->getFromJson('frontend.settings'); ?></a></li>
                                <?php endif; ?>
                                <?php if(Auth::user()->parent_id == 0): ?>
                                <li><a href="<?php echo e(route('profile')); ?>"><?php echo app('translator')->getFromJson('frontend.settings'); ?></a></li>
                                <?php endif; ?>
                                <?php if(Auth::user()->role_id == 2): ?>
                                <li><a href="<?php echo e(route('Backend::home')); ?>"><?php echo app('translator')->getFromJson('frontend.admin_panel'); ?></a></li>
                                <?php endif; ?>
                                <?php if(Auth::user()->parent_id == 0): ?>
                                <li><a href="<?php echo e(route('all.profiles')); ?>"><?php echo app('translator')->getFromJson('frontend.manage_profiles'); ?></a></li>
                                <?php endif; ?>
                                <li><a href="<?php echo e(route('logout')); ?>"><?php echo app('translator')->getFromJson('frontend.logout'); ?></a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <?php echo e($selectedLang); ?>

                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo e(route('lang', [$lang])); ?>"><?php echo e($langText); ?></a></li>
                            </ul>
                        </li>
                    </div>
                      
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-left nav-links custom_nav">
                        	<!-- <?php $__currentLoopData = $forMenue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        	<li><a href="<?php echo e(route('genre', $m->slug)); ?>"><?php echo e($m->title); ?></a></li>                                           
                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
<!--navigation-->
</header>       
<!--header--><?php /**PATH C:\xampp\htdocs\tasali\resources\views/frontend/components/navbar.blade.php ENDPATH**/ ?>