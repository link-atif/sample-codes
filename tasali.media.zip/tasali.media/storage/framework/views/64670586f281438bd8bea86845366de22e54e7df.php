<style type="text/css">
    .register_bg_page{
        float: left;
        margin: 0px;
        padding: 0px;
        width: 100%;
        /*background: url('<?php echo e(thumb(Session::get('image'))); ?>') 0px 0px no-repeat;*/
        background-size: 100% 100%;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="register_bg_page">
    <div class="header_main">
        <div class="container">
            <div class="col-md-6 padd_0">
                <div class="logo">
                    <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('frontend/assets/images/logo.png')); ?>" alt="tasali"></a>
                </div>
            </div>
            <div class="col-md-6 padd_0">
            </div>
        </div>
    </div>
    <div class="register_section">
        <h2><?php echo app('translator')->getFromJson('frontend.reset_password'); ?></h2>
        <div class="register_center">
            <div class="steps_form step_form_1" style="padding-top: 50px;">
                <?php echo $__env->make('frontend.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('password.email')); ?>" method="post"><?php echo e(csrf_field()); ?>

                    <label><?php echo app('translator')->getFromJson('frontend.email'); ?></label>
                    <input type="email" name="email" class="form-control" placeholder="Email">
                    <button type="submit" class="reg_conti"><?php echo app('translator')->getFromJson('frontend.reset_link'); ?></button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>