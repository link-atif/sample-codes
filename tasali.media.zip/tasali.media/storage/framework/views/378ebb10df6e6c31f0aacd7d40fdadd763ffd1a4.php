<style type="text/css">
  .landing_page_bg{
    float: left;
    margin: 0px;
    padding: 0px;
    width: 100%;
    background: url('<?php echo e(thumb($image)); ?>') 0px 0px no-repeat;
    height: 100vh;
    background-size: 100% 100%;
  }
    
    
    .footer_main{position: absolute; padding: 25px 0 20px 0px !important; bottom: 0;}
    .privacy_section{margin: 20px 0 0 0px !important;}
    
</style>
<?php $__env->startSection('content'); ?>
    <div class="landing_page_bg">
           <!--header-->
           <?php echo $__env->make('frontend.components.slim_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           <!--header-->
           <div class="landing_banner_text">
               <div class="container">
                   <h2><?php echo app('translator')->getFromJson('frontend.landing_heading'); ?><br><?php echo app('translator')->getFromJson('frontend.landing_heading2'); ?></h2>
                   <p><?php echo app('translator')->getFromJson('frontend.landing_slug'); ?></p>
                   <a class="lanfing_signup" href="<?php echo e(url('/register')); ?>"><?php echo app('translator')->getFromJson('frontend.signup'); ?></a>
               </div>
           </div>
       </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/landing.blade.php ENDPATH**/ ?>