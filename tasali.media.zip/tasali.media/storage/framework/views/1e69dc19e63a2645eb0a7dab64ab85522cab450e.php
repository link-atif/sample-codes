<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h3 class="m-b-less">
        All Logs
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
            <li class="active">All Logs</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Country Name</th>
                                <th>Watch Title</th>
                                <th>Type</th>
                                <th>Watch Time</th>
                                <th>Percent</th>
                                <th>Close Time</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($logs)): ?>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($l->movie_id !="" || $l->episode_id !=""): ?>
                            <tr>
                                <td><?php echo e($l->country); ?></td>
                                <td><?php echo e($l->movie_id ?  getMovieById($l->movie_id) : getShowById($l->episode_id)); ?></td>
                                <td><?php echo e($l->movie_id ?  "Movie" : "Show"); ?></td>
                                <td><?php echo e(gmdate("H:i:s", $l->paused_at)); ?></td>
                                <td><?php echo e($l->percent); ?> %</td>
                                <td><?php echo e(Carbon\Carbon::parse($l->created_at)->format('H:i a')); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($l->created_at)->format('F d Y')); ?></td>
                            </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Country Name</th>
                                <th>Ip Address</th>
                                <th>Login Time</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($logs)): ?>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($l->movie_id =="" || $l->episode_id ==""): ?>
                            <tr>
                                <td><?php echo e($l->country); ?></td>
                                <td><?php echo e($l->ip); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($l->created_at)->format('H:i a')); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($l->created_at)->format('F d Y')); ?></td>
                            </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/backend/users/logs.blade.php ENDPATH**/ ?>