<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
	<br><br>
	<?php if(!$movie->isEmpty() || !$series->isEmpty()): ?>
		<h3 class="header white-text"><?php echo app('translator')->getFromJson('frontend.my_list'); ?> </h3>
		<?php if(!$movie->isEmpty()): ?>
			<h4 class="white-text"><?php echo app('translator')->getFromJson('frontend.movies'); ?></h4>
			<?php echo $__env->make('frontend.components.grid-items', array('items'=>$movie), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>
		<?php if(!$series->isEmpty()): ?>
			<h4 class="white-text"><?php echo app('translator')->getFromJson('frontend.series'); ?></h4>
			<?php echo $__env->make('frontend.components.grid-items', array('items'=>$series), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>
	<?php else: ?> 
		<div class="card-panel red darken-4 white-text center-align">
			<h4><?php echo app('translator')->getFromJson('frontend.nothing_in_list'); ?></h4>
		</div>
	<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/user-list.blade.php ENDPATH**/ ?>