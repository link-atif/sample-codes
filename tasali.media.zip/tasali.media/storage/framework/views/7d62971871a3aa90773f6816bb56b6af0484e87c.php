<?php $__env->startSection('content'); ?>
<style type="text/css">
    .dashboard-data:hover{
        opacity: 0.5;
    }
</style>

<!-- page head start-->
<div class="page-head">
    <h3><?php echo e($page_title); ?></h3>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row">
        <a href="<?php echo e(route('Backend::topWatching')); ?>">
            <div class="col-md-4 col-xl-4">
                <div class="dashboard-data blue-background">
                    <div class="counts-padding">
                        <div class="widget-content-left">
                            <h1 class="text-center text-size"><i class="fa fa-video-camera"></i></h1>
                            <h2 class="text-center">Top Watching Titles </h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
       <a href="<?php echo e(route('Backend::allFiles')); ?>">
            <div class="col-md-4 col-xl-4">
                <div class="dashboard-data orange-background">
                    <div class="counts-padding">
                        <div class="widget-content-left">
                            <h1 class="text-center text-size"><i class="fa fa-file"></i></h1>
                            <h2 class="text-center">All Files </h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        <a href="<?php echo e(route('Backend::allUsers')); ?>">
            <div class="col-md-4 col-xl-4">
                <div class="dashboard-data red-background">
                    <div class="counts-padding">
                        <div class="widget-content-left">
                            <h1 class="text-center text-size"><i class="fa fa-users"></i></h1>
                            <h2 class="text-center">All Users</h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="row" style="margin-top: 10px;">
        <a href="<?php echo e(route('Backend::uploadedToday')); ?>">
            <div class="col-md-4 col-xl-4">
                <div class="dashboard-data green-background">
                    <div class="counts-padding">
                        <div class="widget-content-left">
                            <h1 class="text-center text-size"><i class="fa fa-cloud-upload"></i></h1>
                            <h2 class="text-center">Uploaded Today </h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>
<!--body wrapper end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/backend/statistics.blade.php ENDPATH**/ ?>