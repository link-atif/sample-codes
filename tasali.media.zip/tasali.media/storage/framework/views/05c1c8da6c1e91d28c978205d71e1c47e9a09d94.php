<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.components.header-movie' , ['data' => $movie, 'type' => 'movie'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="bg_gradient_strip"></div>
<div class="tabs_section_outer">
  <div class="container padd_0">
  	<ul class="nav nav-tabs">
    	<li class="active"><a data-toggle="tab" href="#tab1"><?php echo app('translator')->getFromJson('frontend.about'); ?></a></li>
    	<li><a data-toggle="tab" href="#tab2"><?php echo app('translator')->getFromJson('frontend.related_movies'); ?></a></li>
  	</ul>
    <div class="tab-content">
    	<div id="tab1" class="tab-pane fade in active">
      		<p><?php echo e($movie->desc); ?></p>
        	<div class="tabs_cast">
            	<h4><?php echo app('translator')->getFromJson('frontend.cast'); ?></h4>
            	<div class="row padd_cus">
            		<?php $__currentLoopData = $movie->casts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            		<div class="col-xs-4 col-md-2 padd_0">
                      <div class="cast_col">
                          <a href="<?php echo e(route('related',$m->id)); ?>">
                            <img src="<?php echo e(thumb($m->poster, 'thumb')); ?>" alt="">
                            <h6><?php echo e($m->name); ?></h6>
                          </a>
                      </div>
                  </div>
                 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            	</div>
        	</div>
    	</div>
    	<div id="tab2" class="tab-pane fade">
    		<div class="tabs_cast">
          	<!-- <h4><?php echo app('translator')->getFromJson('frontend.related_movies'); ?></h4> -->
        	<div class="row padd_cus">
        		<?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<div class="col-xs-4 col-md-2 padd_0" id='<?php echo e($r->id); ?>'>
                <div class="cast_col">
                  <a href="<?php echo e(route('single.movie',$r->slug)); ?>">
                    <img src="<?php echo e(thumb($r->poster, 'thumb')); ?>" alt="">
                  </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        	</div>
      	</div>
    	</div>
  	</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/frontend/single-movie.blade.php ENDPATH**/ ?>