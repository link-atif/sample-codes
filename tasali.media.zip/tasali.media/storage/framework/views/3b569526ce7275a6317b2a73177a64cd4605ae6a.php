<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.components.header-movie', 
	['data' => $show, 'type' => 'show', 'firstId' => isset($show->episodes->first()->id) ?? $show->episodes->first()->id]
, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="bg_gradient_strip"></div>
<div class="tabs_section_outer">
    <div class="container padd_0">
	  	<ul class="nav nav-tabs">
	    	<li class="active"><a data-toggle="tab" href="#tab1"><?php echo app('translator')->getFromJson('frontend.episodes'); ?></a></li>
	    	<li><a data-toggle="tab" href="#tab2"><?php echo app('translator')->getFromJson('frontend.about_the_show'); ?></a></li>
	  	</ul>
	    <div class="tab-content">
        	<div id="tab1" class="tab-pane fade in active">
          		<?php if(!empty($show->episodes)): ?>
					<?php echo $__env->make('frontend.components.videos-list', ['episodes' => $show->episodes, 'paused_episodes' => $paused_episodes], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
        	</div>
        	<div id="tab2" class="tab-pane fade">
          		<p><?php echo e($show->desc); ?></p>
          		<p><?php echo app('translator')->getFromJson('frontend.publish_date'); ?>: <?php echo e(Carbon\Carbon::parse($show->publish_date)->format('d F Y')); ?></p>
          		<p><?php echo app('translator')->getFromJson('frontend.production_country'); ?>: <?php echo e($show->publish_country); ?></p>
            	<div class="tabs_cast">
                	<h4><?php echo app('translator')->getFromJson('frontend.cast'); ?></h4>
                	<div class="row padd_cus">
                		<?php $__currentLoopData = $show->casts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<div class="col-xs-4 col-md-2 padd_0">
	                        <div class="cast_col">
	                            <a href="<?php echo e(route('related',$m->id)); ?>">
		                            <img src="<?php echo e(thumb($m->poster, 'thumb')); ?>" alt="">
		                            <h6><?php echo e($m->name); ?></h6>
	                            </a>
	                        </div>
	                    </div>
	                   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                	</div>
            	</div>
        	</div>
	    </div>
   	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/frontend/single-show.blade.php ENDPATH**/ ?>