<style type="text/css">
  .landing_page_bg{
    float: left;
    margin: 0px;
    padding: 0px;
    width: 100%;
    height: 100vh;
    background: url('<?php echo e(asset('frontend/assets/images/black.jpeg')); ?>') 0px 0px no-repeat;
    background-size: 100% 100%;
  }
</style>

<?php $__env->startSection('content'); ?>
    <div class="landing_page_bg">
           <!--header-->
           <?php echo $__env->make('frontend.components.slim_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           <!--header-->
           <div class="landing_banner_text">
               <div class="container">
                   <h2><?php echo e($page->title); ?></h2>
                   <?php 
                    $out = strlen($page->content) > 330 ? substr($page->content,0,330)."..." : $page->content;
                   ?>
                    <p style="font-size:16px;" class="less"><?php echo $out;; ?></p>
                    <p style="font-size:16px; display: none;" class="full"><?php echo $page->content;; ?></p>
                    <a class="lanfing_signup less" href="javascript:;" onclick="readMore();" style="float: right;"><?php echo app('translator')->getFromJson('frontend.read_more'); ?></a>
                    <a class="lanfing_signup full" href="javascript:;" onclick="readLess();" style="display: none; float: right;"><?php echo app('translator')->getFromJson('frontend.read_less'); ?></a>
               </div>
           </div>
       </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
  function readMore(){
    $(".less").hide();
    $(".full").show();
  }

  function readLess(){
    $(".full").hide();
    $(".less").show();
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/single-page.blade.php ENDPATH**/ ?>