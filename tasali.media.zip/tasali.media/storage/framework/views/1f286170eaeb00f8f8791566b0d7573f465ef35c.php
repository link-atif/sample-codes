<?php $__env->startSection('content'); ?>

<!-- page head start-->
<div class="page-head">
    <h3><?php echo e($page_title); ?></h3>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-12 col-xl-12">
            <div class="trending-column">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Top Watching Titles </h3></div>
                        <div class="col-md-6 col-xl-6">
                            <section class="panel">
                                <header class="panel-heading head-border" style="font-weight: bold;">Movies: </header>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Views</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $trendingMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($tm->title); ?></td>
                                                <td><?php echo e($tm->views); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </section>
                        </div>
                        <div class="col-md-6 col-xl-6">
                            <section class="panel">
                                <header class="panel-heading head-border" style="font-weight: bold;">Shows:</header>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Views</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $trendingShows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($ts->title); ?></td>
                                                <td><?php echo e($ts->views); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-8 col-xl-8">
            <div class="revenue-column" style="background-color: #bed4de;">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Site Visits </h3></div>
                        <div id="regions_div" style="width: 710px; height: 300px;"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <section class="panel">
                <div><h3 style="color: black; text-align: center;">Site Revenue </h3></div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Country</th>
                                <th>Total users</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $site_visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php if($sv->country !=""): ?><img src="https://flagcdn.com/<?php echo e(strtolower(country_code($sv->country))); ?>.svg" width="30"> <?php endif; ?></td>
                                <td><?php echo e($sv->country); ?></td>
                                <td><?php echo e($sv->total); ?></td>
                                <td><?php echo e($sv->amount); ?> <?php echo e(currency_code($sv->country)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>

    <div class="row" style="margin-top: 5px;">
        <div class="col-md-12 col-xl-12">
            <div class="trending-column">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Uploaded Today</h3></div>
                        <section class="panel">
                            <div class="table-responsive">
                                <table class="table table-striped" id="uploaded-today">
                                    <thead>
                                       <tr>
                                            <th>Title</th>
                                            <th>Size</th>
                                            <th>Time</th>
                                            <th>Date</th>
                                            <th>Year</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($video->original_title); ?></td>
                                            <td><?php echo e(convertToReadableSize($video->size)); ?></td>
                                            <td><?php echo e(Carbon\Carbon::parse($video->created_at)->format('h:i a')); ?></td>
                                            <td><?php echo e(Carbon\Carbon::parse($video->created_at)->format('F d')); ?></td>
                                            <td><?php echo e(Carbon\Carbon::parse($video->created_at)->format('Y')); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row" style="margin-top: 5px;">
        <div class="col-md-12 col-xl-12">
            <div class="trending-column">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">All Files</h3></div>
                        <section class="panel">
                            <div class="table-responsive">
                                <table class="table table-striped" id="table">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Category</th>
                                            <th>Size</th>
                                            <th>Time</th>
                                            <th>Date</th>
                                            <th>Year</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $allVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $av): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($av->original_title); ?></td>
                                            <td><?php echo e(video_type($av->parent_type)); ?></td>
                                            <td><?php echo e(convertToReadableSize($av->size)); ?></td>
                                            <td><?php echo e(Carbon\Carbon::parse($av->created_at)->format('h:i a')); ?></td>
                                            <td><?php echo e(Carbon\Carbon::parse($av->created_at)->format('F d')); ?></td>
                                            <td><?php echo e(Carbon\Carbon::parse($av->created_at)->format('Y')); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row" style="margin-top: 5px;">
        <div class="col-md-12 col-xl-12">
            <div class="trending-column">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Users</h3></div>
                        <section class="panel">
                            <div class="table-responsive">
                                <table class="table table-striped" id="users-table">
                                    <thead>
                                        <tr>
                                            <th>User Name</th>
                                            <th>Email</th>
                                            <th>Privilege</th>
                                            <th>Logs</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $au): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($au->name); ?></td>
                                            <td><?php echo e($au->email); ?></td>
                                            <td><?php echo e($au->role->label); ?></td>
                                            <td><a href="<?php echo e(route('Backend::logs', $au->id)); ?>" class="btn btn-primary btn-small">User Logs</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--body wrapper end-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"><script type="text/javascript">
    google.charts.load('current', {
        'packages':['geochart'],
        // Note: you will need to get a mapsApiKey for your project.
        // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
        'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
      });
      google.charts.setOnLoadCallback(drawRegionsMap);

      function drawRegionsMap() {
        var data = google.visualization.arrayToDataTable([<?php echo $usersData ?>]);

        var options = {
            colorAxis: {colors: ['green', 'green']},
            legend: 'none',
            backgroundColor: '#bed4de',
            datalessRegionColor: '#ffffff'
        };

        var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

        chart.draw(data, options);
      }
</script>
<script type="text/javascript">
    function resetSearch(){
        window.location = "<?php echo e(route('Backend::home')); ?>";
    }
</script>
<script>
  $(document).ready(function() {
    $('#table, #uploaded-today, #users-table').DataTable();
} );
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/statistics.blade.php ENDPATH**/ ?>