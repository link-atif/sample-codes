<?php $__env->startSection('content'); ?>
<div class="register_bg">
    <!--header-->
    <?php echo $__env->make('frontend.components.slim_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--header-->
    <div class="register_section">
        <h2>Create New Account</h2>
        <div class="register_center">
            <div class="steps_counter">
                <ul>
                    <li class="active"><span><?php echo app('translator')->getFromJson('frontend.step1'); ?></span> <p><?php echo app('translator')->getFromJson('frontend.create_your_account'); ?></p></li>
                    <li class="active"><span><?php echo app('translator')->getFromJson('frontend.step2'); ?></span> <p><?php echo app('translator')->getFromJson('frontend.choose_payment'); ?></p></li>
                    <li class="active"><span><?php echo app('translator')->getFromJson('frontend.step3'); ?></span> <p><?php echo app('translator')->getFromJson('frontend.price'); ?> <strong><?php if(\Session::get('is_left') == 1): ?><?php echo e(\Session::get('code')); ?> <?php endif; ?> <?php echo e(\Session::get('amount')); ?> <?php if(\Session::get('is_left') == 0): ?><?php echo e(\Session::get('code')); ?> <?php endif; ?> / <?php echo app('translator')->getFromJson('frontend.month'); ?></strong></p></li>
                </ul>
            </div>
            <div class="steps_form step_form_1">
                <?php echo $__env->make('frontend.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('')); ?>" id="frm" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="card_number" value="<?php echo e(\Session::get('card_number')); ?>">
                    <input type="hidden" name="name_on_card" value="<?php echo e(\Session::get('name_on_card')); ?>">
                    <input type="hidden" name="expiration_month" value="<?php echo e(\Session::get('expiration_month')); ?>">
                    <input type="hidden" name ="expiration_year" value="<?php echo e(\Session::get('expiration_year')); ?>">
                    <input type="hidden" name="card_code" value="<?php echo e(\Session::get('card_code')); ?>">
                    <label>OTP</label>
                    <input type="text" class="form-control" name="otp" placeholder="OTP">
                    <a href="javascript:{}" class="reg_conti btn" id="register">Verify</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $("#register").click(function(){
        $("#frm").submit();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/auth/register/step_3.blade.php ENDPATH**/ ?>