<div class="banner_main banner_main_2">
  <div class="slider_scrapped">
    <div class="banner_2_sec">
      <img src="<?php echo e(thumb($data->image)); ?>" alt="">
      <div class="banner_main_outer_content">
        <div class="container padd_0">
          <div class="col-md-7 padd_0">
            <div class="slider_bg_tranparent">
              <div class="rating_movie">
                <span class="rating_cont"><i class="fas fa-star"></i><?php echo e($data->rating_avg); ?></span>
                <p>.</p>
            	  <span class="rating_cont">
                  <span class="imdb">IMDb</span><?php echo e($data->imdb->rate ?? null); ?>

            	  </span>
              </div>
              <h2><?php echo e($data->title); ?></h2>
              <?php if(app()->getLocale() == "en"): ?>
              <h6><?php echo e($data->production); ?> |
                <?php $__currentLoopData = $data->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      				   <?php echo e($genre->title); ?> |
      			    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      			    <?php echo e($data->length); ?> min | <?php echo e($data->age); ?>

              </h6>
              <?php else: ?>
                <h6>
                  <?php $__currentLoopData = $data->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php echo e($genre->title); ?> |
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($data->age); ?> | <span dir="rtl"> <?php echo e("min ". $data->length); ?> </span> | <?php echo e($data->production); ?>

                </h6>
              <?php endif; ?>
              <p><?php echo e($data->desc); ?></p>
              <div class="play_button" id="item-slider-<?php echo e($data->id); ?>">
            	  <?php if($type !='show'): ?>
                <a href="#play_video" data-url="<?php echo e(route('video', [$type, isset($firstId) ? $firstId : $data->id])); ?>" data-src="<?php echo e(asset('images/logo.png')); ?>" class="watch_buttons active modal-trigger">
              	<i class="material-icons">play_arrow</i> <?php echo app('translator')->getFromJson('frontend.play'); ?>
            	  </a>
                <?php endif; ?>
            	  <a href="#play_video" data-url="<?php echo e(route('video', ['trailer_'.$type, $data->id])); ?>" data-src="<?php echo e(asset('images/logo.png')); ?>" class="watch_buttons modal-trigger">
                <i class="material-icons">play_arrow</i> <?php echo app('translator')->getFromJson('frontend.watch_trailer'); ?>
            	  </a>
              	<?php 
    							$favoriteMovies = \Auth::user()->followingMovies->pluck('id')->toArray();
    							$favoriteShows = \Auth::user()->followingSeries->pluck('id')->toArray();
    							$favorites = array_merge($favoriteMovies, $favoriteShows);
    						?>
    						<?php if(in_array($data->id, $favorites)): ?>
    							<a class="watch_buttons removeList" href="javascript:" data-type="<?php echo e($data->season ? 'show' : 'movie'); ?>" data-id="<?php echo e($data->id); ?>" data-header="yes" id="remove-slider-<?php echo e($data->id); ?>">
                    <i class="material-icons">check</i> <?php echo app('translator')->getFromJson('frontend.remove_from_my_list'); ?>
                  </a>
    						<?php else: ?>
    							<a class="watch_buttons addToList" href="javascript:" data-type="<?php echo e($data->season ? 'show' : 'movie'); ?>" data-id="<?php echo e($data->id); ?>" data-header="yes" id="add-slider-<?php echo e($data->id); ?>">
                    <i class="material-icons">add</i> <?php echo app('translator')->getFromJson('frontend.add_to_my_list'); ?>
                  </a>
    						<?php endif; ?>
                <a class="watch_buttons share" id="popoverId" data-placement="bottom" data-toggle="popover" data-container="body" data-html="true" href="javascript:"><?php echo app('translator')->getFromJson('frontend.share'); ?></a>
                <div id="popover-content" class="hide">
                  <div class="popover-header">
                  <button type="button" class="close" id="popoverClose" data-dismiss="popover" aria-hidden="true">&times;</button>
                  </div>
                  <div class="row">
                    <div class="col-xs-12">
                      <input type="text" class="col-xs-12" name="shareUrl" id="shareUrl" value="<?php echo e(url()->full()); ?>" readonly="readonly">
                    </div>
                    <div class="col-xs-12">
                      <a href="javascript:" onclick="myFunction('shareUrl')" data-toggle="tooltip" data-placement="right"><?php echo app('translator')->getFromJson('frontend.copy_link'); ?></a>
                    </div>
                    <div class="row">
                      <div class="col-xs-8">
                      </div>
                      <div class="col-xs-2">
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->full()); ?>" class="pull-right" target="_blank"><img src="<?php echo e(asset('frontend/assets/images/soial_1.png')); ?>" alt=""></a>
                      </div>
                      <div class="col-xs-2">
                        <a href="https://wa.me/?text=<?php echo e(url()->full()); ?>" target="_blank"><img src="<?php echo e(asset('frontend/assets/images/wht.png')); ?>" alt=""></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\tasali\resources\views/frontend/components/header-movie.blade.php ENDPATH**/ ?>