<?php $__env->startSection('content'); ?>
<div class="page-head">
    <h3 class="m-b-less">
        All Privileges
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
            <li class="active">All Privileges</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            <?php echo $__env->make('backend.roles.filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('backend.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <section class="panel">
                <header class="panel-heading head-border">
                    All Privileges <?php echo isset($count) ? "<span class='label label-success'>{$count}</span>" : null; ?>

                </header>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($role->label); ?></td>
                                <td>
                                    <ul class="list-unstyled list-inline">
                                        <li>
                                            <a href="<?php echo e(route('Backend::roles.edit', $role->id)); ?>" class="btn btn-primary btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <form action="<?php echo e(route('Backend::roles.destroy', $role->id)); ?>" method="post">
                                                <?php echo e(method_field('delete')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button class="btn btn-danger btn-xs del-confirm" data-msg="<?php echo app('translator')->getFromJson('backend.confirm_delete'); ?>">
                                                    <i class="fa fa-trash-o "></i>
                                                </button>
                                            </form>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </section>
            <?php echo e($roles->appends(Request::except('page'))->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/backend/roles/index.blade.php ENDPATH**/ ?>