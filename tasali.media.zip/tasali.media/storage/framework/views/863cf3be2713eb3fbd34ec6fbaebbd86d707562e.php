<?php if(count($errors) > 0): ?>
<div class="alert alert-danger alert-block fade in">
    <button data-dismiss="alert" class="close close-sm" type="button">
        <i class="fa fa-times"></i>
    </button>
    <h4>
        <i class="fa fa-ok-sign"></i>
        Error!
    </h4>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php if(Session::has('msg')): ?>
    <div class="alert <?php echo e(Session::get('msg-type') == 'error' ? 'alert-danger' : 'alert-success'); ?>">
        <button data-dismiss="alert" class="close close-sm" type="button">
            <i class="fa fa-times"></i>
        </button>
        <h4>
            <i class="fa fa-ok-sign"></i>
            <?php echo e(ucFirst(Session::get('msg-type'))); ?>!
        </h4>
        <?php echo e(Session::get('msg')); ?>

    </div>
<?php endif; ?>

<?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/backend/partials/error.blade.php ENDPATH**/ ?>