<?php $__env->startSection('content'); ?>
<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Edit Role: <?php echo e($role->label); ?>

    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="<?php echo e(route('Backend::home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('Backend::roles.index')); ?>">roles</a></li>
            <li class="active">Edit Role: <?php echo e($role->label); ?></li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Edit Role <?php echo e($role->label); ?>

                </header>
                <div class="panel-body">
                    <?php echo $__env->make('backend.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form">
                        <form method="post" action="<?php echo e(route('Backend::roles.update', $role->id)); ?>" class="cmxform form-horizontal tasi-form">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('put')); ?>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="label" value="<?php echo e($role->label); ?>" class="form-control">
                                </div>
                            </div>
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Permissions</label>
                                <div class="col-lg-5">
                                    <table class="table">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($value['label']); ?></td>
                                                <?php $__currentLoopData = $value['permissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="text-center">
                                                        <?php if(!empty($permission['id'])): ?>
                                                            <div class="icheck checkbox-inline">
                                                                <label><?php echo e($permission['name']); ?></label>
                                                                <input type="checkbox" name="permissions[]" value="<?php echo e($permission['id']); ?>"
                                                                <?php echo e((in_array($permission['id'], $role_perms)) ? 'checked' : null); ?>

                                                                >
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tasali\resources\views/backend/roles/edit.blade.php ENDPATH**/ ?>