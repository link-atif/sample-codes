<?php $__env->startSection('content'); ?>
<?php echo $__env->make('frontend.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
	<br><br><br><br><br>
	<?php if(!$movies->isEmpty() || !$shows->isEmpty()): ?>
		<h3 class="header white-text">Search results </h3>
		<?php if(!$movies->isEmpty()): ?>
			<h5 class="white-text">Movies</h5>
			<?php echo $__env->make('frontend.components.grid-items', array('items'=>$movies), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>
		<?php if(!$shows->isEmpty()): ?>
			<h5 class="white-text">Shows</h5>
			<?php echo $__env->make('frontend.components.grid-items', array('items'=>$shows), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php endif; ?>
	<?php else: ?> 
		<div class="card-panel red darken-4 white-text center-align">
			<h4 style="color:#DDB86C; font-weight: bold; font-size: 24px;">Nothing found</h4>
		</div>
	<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp7.2\htdocs\tasali\resources\views/frontend/results.blade.php ENDPATH**/ ?>