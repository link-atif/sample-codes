<!DOCTYPE html>
@php
        if(app()->getLocale() == "en"){ 
    @endphp
        <html dir="ltr" lang="en">
    @php
     }else{ @endphp
        <html dir="rtl" lang="ar">
   @php } @endphp

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
  <META Http-Equiv="Pragma" Content="no-cache">
  <META Http-Equiv="Expires" Content="0">
  <title>{{ websiteTitle() }}</title>
  <link rel="shortcut icon" href="{{ asset('images/favicon.png') }}" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="{{ asset('assets/dist/jquery.min.js') }}"></script>
  <!-- Theme CSS -->
  <link href="{{ asset('frontend/assets/css/loginStyle.css') }}" rel="stylesheet">

   @php
        if(app()->getLocale() == "en"){ 
    @endphp
            <link href="{{ asset('frontend/assets/css/loginStyle.css') }}" rel="stylesheet">
    @php
     }else{ @endphp
        <link href="{{ asset('frontend/assets/css/ar_loginStyle.css') }}" rel="stylesheet">
   @php } @endphp 
    
  <style>
      .captcha-box { border-radius: 5px; border: 2px solid; padding: 0.5rem 2rem;  max-width: 400px; margin: 20px 0; }
      #canvas {
        width: 250px;
        height: 80px;
      }
    </style>

    <!-- Global site tag (gtag.js) - Google Analytics -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-166297346-1"></script>
      <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'UA-166297346-1');
      </script>
   
   <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '349865283089919');
      fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=349865283089919&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Facebook Pixel Code -->
</head>
<body>
  @php
    if(app()->getLocale() == "en"){
      $langText = "AR";
      $lang = "ar";
      $lang_link = '';
      $text_align = 'right';
      $selectedLang = "EN";
    }else{
      $langText = "EN";
      $selectedLang = "AR";
      $lang = "en";
      $lang_link = 'ar/';
      $text_align = 'left';
    }
    @endphp
  <header class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <a class="navbar-brand page-scroll logo no-margin" href="index.html">
            <img src="{{ asset('frontend/assets/images/logo.png') }}" class="img-fluid" alt="">
          </a>
        </div>
        <div class="col-md-6 text-right">
          <ul class="top-links list-unstyled">
             <li class="pull-right">
                <div class="navbar-nav">
                  <div class="nav-item dropdown">
                      <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">{{ $selectedLang }}</a>
                      <div class="dropdown-menu">
                          <a href="{{ route('lang', [$lang]) }}">{{ $langText }}</a>
                      </div>
                  </div>
                </div>
              </li>
              <li class="pull-right login">
                  <a class="cd-signin btn-lg" href="https://tasali.media/login">@lang('frontend.log_in')</a>
              </li>
          </ul>
                    
        </div>
      </div>
    </div>
  </header>
  <div class="main mt-100">
    <div class="container">
      <div class="row text-center tabs">
        <div class="col-md-3 tab active">@lang('frontend.create_new_account')</div>
        <div class="col-md-3 tab">@lang('frontend.your_plan')</div>
        <div class="col-md-3 tab">@lang('frontend.choose_payment')</div>
        <div class="col-md-3 tab">@lang('frontend.subscription')</div>
      </div>
      <div class="form-container">

        <div class="right-arrow block_en none_ar" onclick="register();"><img src="{{ asset('frontend/assets/images/RgtArrow.png') }}" class="tic" alt=""></div>

  <div class="left-arrow block_ar none_en" onclick="register();"><img src="{{ asset('frontend/assets/images/LftArrow.png') }}" class="tic" alt=""></i></div>

        <h5> <img src="{{ asset('frontend/assets/images/Good.png') }}" class="tic mr-1" alt="">@lang('frontend.register_page.header_text_1')</h5>
        @include('frontend.components.errors')
        <form action="{{ url('/register') }}" id="frm" method="post" name="frm">
          {{ csrf_field() }}
          <input type="hidden" name="device_token" id="device_token" value="">   
          <div class="row">                 
            <div class="col-md-5">          
              <div class="form-group">
                  <label for="name">@lang('frontend.name')</label>
                  <input type="text" tabindex="1" class="form-control" name="name" autocomplete="off" placeholder="@lang('frontend.name')" value="{{ old('name') }}" required>
              </div>
              <div class="form-group">
                  <label for="country">@lang('frontend.country')</label>
                 <select name="country" tabindex="3" id="country" onchange="getCities()" class="form-control" autocomplete="off" required>
                    <option value="">@lang('frontend.select_country')*</option>
                      @foreach($countries as $country)
                      @if(app()->getLocale() == "en")
                      <option data-code="{!! $country->code !!}" value="{{ $country->name }}">{{ $country->name }}</option>
                      @endif
                      @if(app()->getLocale() == "ar")
                      <option data-code="{!! $country->code !!}" value="{{ $country->name }}">{{ $country->name_ar }}</option>
                      @endif
                      @endforeach
                </select>
              </div>
              <div class="form-group">
                  <label for="password">@lang('frontend.password')</label>
                  <input type="password" tabindex="5" class="form-control" name="password" autocomplete="off" placeholder="@lang('frontend.password')" required>
              </div>          
            </div>
            <div class="col-md-2">&nbsp;</div>
            <div class="col-md-5">
              <div class="form-group">
                  <label for="email">@lang('frontend.email')</label>
                  <input type="email" tabindex="2" class="form-control" name="email" autocomplete="off" placeholder="@lang('frontend.email')" value="{{ old('email') }}" required>
              </div>
              <div class="form-group">              
                 <label for="city" id="city_label">@lang('frontend.city')</label>
                <select name="city" tabindex="4" id="city" class="form-control" autocomplete="off" required>
                     <option value="">@lang('frontend.city')*</option>
                </select>
              </div>
              <div class="form-group">              
                  <label for="password">@lang('frontend.confirm_password')</label>
                  <input type="password" tabindex="6" class="form-control" name="password_confirmation" autocomplete="off" placeholder="@lang('frontend.confirm_password')" required>
              </div>
            </div>          
          </div>
        </form>
        <div class="form-footer">
          <div class="row my-5">
            <div class="col-md-6">
              @lang('frontend.terms_conditions_text') <a href="{{ $lang_link }}terms.html">@lang('frontend.terms_conditions')</a>
            </div>
            <div class="col-md-1">&nbsp;</div>
            <div class="col-md-5">
              <div class="pull-left">@lang('frontend.already_account') <a href="https://tasali.media/login">@lang('frontend.login_text')</a></div>
              <div class="pull-right"><a href="{{ $lang_link }}contact.html">@lang('frontend.need_help')</a></div>
            </div>
          </div>
        </div>
      </div>      
    </div>
  </div>
  <section id="footer">
    <div class="footer-bottom">
      <div class="container">
          <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12">
                  <div class="footer-widget-social">
                      <ul>
                          <li>
                              <a data-tooltip="facebook" href="https://www.facebook.com/Tasali-114646016899548">
                                  <img src="{{ asset('images/facebook.png') }}" alt="" class="img-fluid">
                              </a>
                          </li>
                          <li>
                              <a data-tooltip="inestagram" href="https://www.instagram.com/mediatasali/">
                                  <img src="{{ asset('images/inesta.png') }}" alt="" class="img-fluid">
                              </a>
                          </li>
                          <li>
                              <a data-tooltip="youtube"
                                  href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                                  <img src="{{ asset('images/youtube.png') }}" alt="" class="img-fluid">
                                  </i>
                              </a>
                          </li>
                      </ul>
                  </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 text-center">
                  <p>@lang('frontend.copyrights')</p></p>
              </div>
          </div>
      </div>
    </div>
  </section>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://unpkg.com/@popperjs/core@2"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $("#country").val("{{ old('country') }}");
      if($("#country").val() !="")
          getCities();
     });
    
    function getCities(){
      var code = $("#country > option:selected").attr("data-code");
      if(code){
        $.ajax({
          type:"GET",
          url:"{{url('get-cities-list')}}?code="+code,
          success:function(res){               
            if(res){
              console.log(res);
              $("#city").empty();
              $("#city_label").empty();
              changeTitle(code, res);
              $("#city").val("{{ old('city') }}");
            }else{
               $("#city").empty();
            }
          }
        });
      }else{
        $("#city").empty();
      }
    }

    function changeTitle(code, res){
      if(code == "US"){
        var state_label = "{{ __('frontend.state') }}";
        var select_state = "{{ __('frontend.select_state') }}";
        $("#city_label").append(state_label);
        $("#city").append($('<option>', {value: "", text: select_state+"*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      }else if(code == "GB"){
        var countries = "{{ __('frontend.countries') }}";
        var select_country = "{{ __('frontend.select_country') }}";
        $("#city_label").append(countries);
        $("#city").append($('<option>', {value: "", text: select_country+"*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      }else if(code == "EU"){
        var counties = "{{ __('frontend.counties') }}";
        var select_counties = "{{ __('frontend.select_counties') }}";
        $("#city_label").append(counties);
        $("#city").append($('<option>', {value: "", text: select_counties+"*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      }else if(code == "CA" || code == "AU"){
        var region = "{{ __('frontend.region') }}";
        var select_region = "{{ __('frontend.select_region') }}";
        $("#city_label").append(region);
        $("#city").append($('<option>', {value: "", text: select_region+"*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      }else{
        var city_label = "{{ __('frontend.city') }}";
        var select_city = "{{ __('frontend.select_city') }}";
        $("#city_label").append(city_label);
        $("#city").append($('<option>', {value: "", text: select_city+"*" }));
          $.each(res, function(i,v){
            $("#city").append($('<option>', {value: v.asciiname, text: v.asciiname }));
        });
      } 
    }  
    </script>
    <script src="{{ asset('assets/js/jquery-captcha-lgh.js') }}"></script>
    <script>
      // step-1
      const captcha = new Captcha($('#canvas'),{
        length: 4
      });
      // api
      //captcha.refresh();
      //captcha.getCode();
      //captcha.valid("");

      $('#valid').on('click', function() {
        const ans = captcha.valid($('input[name="code"]').val());
        if(ans =="" || ans == false){
          $("#validation_error").show();
          $("#validation_error").html('<p>Captcha code is not Valid</p>');
            $('html, body').animate({
                scrollTop: $("#scroll_top").offset().top
            }, 1000);
        }
        if(ans == true){
          $("#validation_error").hide();
          $("#captcha_validation").val(ans);
        }
        //captcha.refresh();
      });
      $('#refresh').on('click', function() {
        captcha.refresh();
      });
    </script>
    <script type="text/javascript">
      function register(){
      //$("#register").click(function(){
        //var captcha_validation = $("#captcha_validation").val();
        //if(captcha_validation !="" && captcha_validation == "true"){
          $("#frm").submit();
        //}
      //});
    }
    </script>
    <script type="text/javascript">
        var device_token = localStorage.getItem("device_token");
        if(device_token !=null){
            $("#device_token").val(device_token);
        }else{
            var device_token = '{{ generateToken() }}';
            localStorage.setItem("device_token", device_token);
            $("#device_token").val(device_token);
        }

        var language = localStorage.getItem("language");            
        if(language == 'ar'){
            localStorage.setItem("language", "");
            window.location = '{{ route("lang", "ar") }}';
        }            
        if(language == 'en'){
            localStorage.setItem("language", "");
            window.location = '{{ route("lang", "en") }}';
        }
    </script>
</body>
</html>