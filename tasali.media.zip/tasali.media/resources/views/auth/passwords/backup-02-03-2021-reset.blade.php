@extends('frontend.frontend')
<style type="text/css">
    .register_bg_page{
        float: left;
        margin: 0px;
        padding: 0px;
        width: 100%;
        /*background: url('{{ thumb(Session::get('image')) }}') 0px 0px no-repeat;*/
        background-size: 100% 100%;
    }
</style>
@section('content')
<div class="register_bg_page">
    <div class="header_main">
        <div class="container">
            <div class="col-md-6 padd_0">
                <div class="logo">
                    <a href="{{ route('home') }}"><img src="{{ asset('frontend/assets/images/logo.png') }}" alt="tasali"></a>
                </div>
            </div>
            <div class="col-md-6 padd_0">
            </div>
        </div>
    </div>
    <div class="register_section">
        <h2>@lang('frontend.reset_password')</h2>
        <div class="register_center">
            <div class="steps_form step_form_1" style="padding-top: 50px;">
                @include('frontend.components.errors')
                @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif
                <form action="{{ route('password.request') }}" method="post">{{ csrf_field() }}
                    <input type="hidden" name="token" value="{{ $token }}">
                    <label>@lang('frontend.email')</label>
                    <input type="email" name="email" class="form-control" placeholder="Email" value="{{ $email }}" required autofocus>
                    <label>@lang('frontend.password')</label>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password">
                    <label>@lang('frontend.password_confirmation')</label>
                    <input type="password" name="password_confirmation" id="password-confirm" class="form-control" placeholder="@lang('frontend.password_confirmation')">

                    <button type="submit" class="reg_conti">@lang('frontend.reset_password')</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection