<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
  <META Http-Equiv="Pragma" Content="no-cache">
  <META Http-Equiv="Expires" Content="0">
  <title>{{ websiteTitle() }}</title>
  <link rel="shortcut icon" href="{{ asset('images/favicon.png') }}" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
  <!-- Theme CSS -->
  <link href="{{ asset('frontend/assets/css/loginStyle.css') }}" rel="stylesheet">
  <script src="{{ asset('assets/dist/jquery.min.js') }}"></script>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <a class="navbar-brand page-scroll logo no-margin" href="{{ route('login') }}">
                        <img src="{{ asset('frontend/assets/images/logo.png') }}" class="img-fluid" alt="">
                    </a>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                </div>
            </div>
        </div>
    </header>
    <section class="all-space" style="min-height: calc(100vh - 162px);">
        <div class="container">
            <div class="row">
                <div class="register_center mx-auto">
                    <div class="steps_form step_form_1" style="padding-top: 50px;">
                        @include('frontend.components.errors')
                        @if (session('status'))
                            <div class="alert alert-success">
                                {{ session('status') }}
                            </div>
                        @endif
                        <form action="{{ route('password.email') }}" method="post">{{ csrf_field() }}
                            <label>@lang('frontend.email')</label>
                            <input type="email" name="email" class="form-control" placeholder="Email">
                            <button type="submit" class="reg_conti">@lang('frontend.reset_link')</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="footer">
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="footer-widget-social">
                            <ul>
                                <li>
                                    <a data-tooltip="facebook" href="https://www.facebook.com/Tasali-114646016899548">
                                        <img src="{{ asset('images/facebook.png') }}" alt="" class="img-fluid">
                                    </a>
                             </li>
                                <li>
                                    <a data-tooltip="inestagram" href="https://www.instagram.com/mediatasali/">
                                        <img src="{{ asset('images/inesta.png') }}" alt="" class="img-fluid">
                                    </a>
                                </li>
                                <li>
                                    <a data-tooltip="youtube"
                                        href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                                        <img src="{{ asset('images/youtube.png') }}" alt="" class="img-fluid">
                                        </i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 text-center">
                        <p>@lang('frontend.copyrights')</p></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
</body>
</html>