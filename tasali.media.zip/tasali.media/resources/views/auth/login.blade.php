<!DOCTYPE html>
@php
        if(app()->getLocale() == "en"){ 
    @endphp
        <html dir="ltr" lang="en">
    @php
     }else{ @endphp
        <html dir="rtl" lang="ar">
   @php } @endphp


<head>
    <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
  <META Http-Equiv="Pragma" Content="no-cache">
  <META Http-Equiv="Expires" Content="0">
  <title>{{ websiteTitle() }}</title>
  <link rel="shortcut icon" href="{{ asset('images/favicon.png') }}" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <!-- Theme CSS -->
    @php
        if(app()->getLocale() == "en"){ 
    @endphp
            <link href="{{ asset('frontend/assets/css/loginStyle.css') }}" rel="stylesheet">
    @php
     }else{ @endphp
        <link href="{{ asset('frontend/assets/css/ar_loginStyle.css') }}" rel="stylesheet">
   @php } @endphp  

    <!-- Global site tag (gtag.js) - Google Analytics -->
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-166297346-1"></script>
      <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'UA-166297346-1');
      </script>
   
   <script>
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '349865283089919');
      fbq('track', 'PageView');
    </script>
    <noscript><img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=349865283089919&ev=PageView&noscript=1"
    /></noscript>
    <!-- End Facebook Pixel Code -->

</head>
<body>
    @php
    if(app()->getLocale() == "en"){
      $langText = "AR";
      $lang = "ar";
      $lang_link = '';
      $text_align = 'right';
      $selectedLang = "EN";
    }else{
      $langText = "EN";
      $selectedLang = "AR";
      $lang = "en";
      $lang_link = 'ar/';
      $text_align = 'left';
    }
    @endphp
    <header class="header">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <a class="navbar-brand page-scroll logo no-margin" href="index.html">
                        <img src="{{ asset('frontend/assets/images/logo.png') }}" class="img-fluid" alt="">
                    </a>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                    <ul class="top-links list-unstyled">
                        <li class="pull-right">
                            <div class="navbar-nav">
                                <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">{{ $selectedLang }}</a>
                                    <div class="dropdown-menu">
                                        <a href="{{ route('lang', [$lang]) }}">{{ $langText }}</a>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <section class="all-space">
        <div class="container">
            <div class="row">
                <div class="steps_form step_form_1" style="padding-top: 50px; padding-bottom: 50px;">
                    @include('frontend.components.errors') 
                    @if(Session::get('user_id')!="null" && Session::get('user_id') > 0) 
                        @include('frontend.components.devices')
                    @endif
                    <form action="{{ url('/login') }}" method="post">
                        {{ csrf_field() }}
                    <input type="hidden" name="device_token" id="device_token" value="">
                    <label>@lang('frontend.email')</label>
                    <input type="email" name="email" autocomplete="off" class="form-control" placeholder="@lang('frontend.email')">
                    <label>@lang('frontend.password')</label>
                    <input type="password" name="password" autocomplete="off" class="form-control" placeholder="@lang('frontend.password')">

                    <input type="checkbox" name="remember" id="remember-me" class="block_en none_ar" style="width: 20px; text-align:left;">
                    <label for="remember-me" class="block_en none_ar" style="padding: 7px 0px 0px 7px; width: 50% !important">@lang('frontend.rememberme')</label>

                    <input type="checkbox" name="remember" id="remember-me" class="block_ar none_en" style="width: 20px; text-align:left; float: right; margin-left: 10px">
                    <label for="remember-me" class="block_ar none_en" style="padding: 7px 0px 0px 7px; width: 50% !important; float: right; ">@lang('frontend.rememberme')</label>

                    <br class="clearfix">
                    <div class="pull-right block_en none_ar" style="color: #555;"> <a href="https://tasali.media/password/reset" style="color: #DDB86C;"><strong>@lang('frontend.forgot_password')</strong></a> </div>
                    <div class="col-md-6 col-sm-12 clearfix text-left block_en none_ar">
                        <button type="submit" class="reg_conti">@lang('frontend.login')</button>
                    </div>
                    <!-- <div class="section_or col-md-6 col-sm-12">OR</div>
                    <div class="col-md-6 col-sm-12"><a href="https://tasali.media/login/facebook" class="fb_signup">Sign in with Facebook</a></div> -->
                    <div class="pull-right col-md-6 col-sm-12 signUp-link block_en none_ar" style="color: #cbcbcd; text-align: right; padding-right: 0; margin-top: 10px; padding-bottom: 10px;"> @lang('frontend.signup_to_tasali', ['link' => url('register')])</div>


                    <div class="text-left block_ar none_en" style="color: #555;"> <a href="https://tasali.media/password/reset" style="color: #DDB86C;"><strong>@lang('frontend.forgot_password')</strong></a> </div>
                    <div class="col-sm-12 clearfix text-right block_ar none_en">
                        <button type="submit" class="reg_conti">@lang('frontend.login')</button>
                    </div>
                    <!-- <div class="section_or col-md-6 col-sm-12">OR</div>
                    <div class="col-md-6 col-sm-12"><a href="https://tasali.media/login/facebook" class="fb_signup">Sign in with Facebook</a></div> -->
                    <div class="text-left col-sm-12 signUp-link block_ar none_en" style="color: #cbcbcd; padding-right: 0; margin-top: 10px; padding-bottom: 10px;"> @lang('frontend.signup_to_tasali', ['link' => url('register')])</div>
                </form>
            </div>
            </div>
        </div>
    </section>

    <section id="footer">
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="footer-widget-social">
                            <ul>
                                <li>
                                    <a data-tooltip="facebook" href="https://www.facebook.com/Tasali-114646016899548">
                                        <img src="{{ asset('images/facebook.png') }}" alt="" class="img-fluid">
                                    </a>
                             </li>
                                <li>
                                    <a data-tooltip="inestagram" href="https://www.instagram.com/mediatasali/">
                                        <img src="{{ asset('images/inesta.png') }}" alt="" class="img-fluid">
                                    </a>
                                </li>
                                <li>
                                    <a data-tooltip="youtube"
                                        href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                                        <img src="{{ asset('images/youtube.png') }}" alt="" class="img-fluid">
                                        </i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 text-center">
                        <p>@lang('frontend.copyrights')</p></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<script type="text/javascript">
        var device_token = localStorage.getItem("device_token");
        if(device_token !=null){
            $("#device_token").val(device_token);
        }else{
            var device_token = '{{ generateToken() }}';
            localStorage.setItem("device_token", device_token);
            $("#device_token").val(device_token);
        }

        var language = localStorage.getItem("language");            
        if(language == 'ar'){
            localStorage.setItem("language", "");
            window.location = '{{ route("lang", "ar") }}';
        }            
        if(language == 'en'){
            localStorage.setItem("language", "");
            window.location = '{{ route("lang", "en") }}';
        }
    </script>
</body>
</html>
