@extends('frontend.frontend')
@section('content')
<div class="register_bg">
    <!--header-->
    @include('frontend.components.slim_header')
    <!--header-->
    <div class="register_section">
        <h2>Create New Account</h2>
        <div class="register_center">
            <div class="steps_counter">
                <ul>
                    <li class="active"><span>@lang('frontend.step1')</span> <p>@lang('frontend.create_your_account')</p></li>
                    <li class="active"><span>@lang('frontend.step2')</span> <p>@lang('frontend.choose_payment')</p></li>
                    <li><span>@lang('frontend.step3')</span> <p>@lang('frontend.price') <strong>@if(\Session::get('is_left') == 1){{ \Session::get('code') }} @endif {{ \Session::get('amount') }} @if(\Session::get('is_left') == 0){{ \Session::get('code') }} @endif / @lang('frontend.month')</strong></p></li>
                </ul>
            </div>
            <div class="steps_form step_form_1">
                @include('frontend.components.errors')
                <label>@lang('frontend.payment_description')</label>
                    <div class="row">
                        <!-- <div class="col-md-12">
                            <div class="paypal_group">
                                <a href="javascript:" id="paypal"><img src="{{ asset('frontend/assets/images/paypal.png') }}" alt="">@lang('frontend.paypal')</a>
                            </div>        
                        </div> -->
		<div class="col-md-12">
                   <div class="paypal_group">
                       <form  method="post" action="{{ route('stripe') }}">
                                    {{ csrf_field() }}
                                    <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                        data-key="{{ env('STRIPE_KEY') }}"
                                        data-amount="0"
                                        data-locale="auto"
                    data-email="{{ \Auth::user()->email }}"
                                        data-label="Pay with Stripe"
                    data-panel-label="Start your free trial"
                    data-address="true"
                                        data-currency="{{ \Session::get('code') }}">
                                    </script>
                                </form>
			</div>		
		</div>
                        <!-- <div class="col-md-6">
                             <div class="paypal_group stripe_group">
                                <a href="javascript:" id="stripe"><img src="{{ asset('frontend/assets/images/stripe.png') }}" height="40px;" width="50px;" alt="">@lang('frontend.stripe')</a>
                            </div> 
                        </div> -->
                    </div>
                <!-- <form action="{{ url('register/paypalPayment') }}" method="post" id="paypalForm">
                    {{ csrf_field() }}
                    <input type="hidden" name="amount" value="{{ \Session::get('amount') }}">
                    <input type="hidden" name="currency" value="{{ \Session::get('code') }}">
                </form> -->
                <!-- <form action="{{ route('payment') }}" id="frm" method="post">
                    {{ csrf_field() }}
                    <p class="section_or">@lang('frontend.or')</p>
                    <label>@lang('frontend.card_number')</label>
                    <input type="text" class="form-control" name="card_number" placeholder="Card Number ">
                    <label>@lang('frontend.name_on_card')</label>
                    <input type="text" class="form-control" name="name_on_card" placeholder="Name On Card">
                    <div class="row">
                        <div class="col-md-3">
                            <label>@lang('frontend.expiration_month')</label>
                            <input type="text" class="form-control" name="expiration_month" placeholder="@lang('frontend.expiration_month_placeholder')">
                        </div>
                        <div class="col-md-3">
                            <label>@lang('frontend.expiration_year')</label>
                            <input type="text" class="form-control" name="expiration_year" required placeholder="@lang('frontend.expiration_year_placeholder')">
                        </div>
                        <div class="col-md-2">&nbsp;</div>
                        <div class="col-md-4">
                            <label>@lang('frontend.card_code')</label>
                            <input type="text" class="form-control" placeholder="@lang('frontend.cvv')" name="card_code">
                        </div>
                    </div>
                    <input type="hidden" name="payment_type" value="paylane" id="payment_type">
                    <a href="javascript:{}" class="reg_conti btn" id="register">@lang('frontend.start_membership')</a>
                </form> -->
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script type="text/javascript">
    $("#register").click(function(){
        $("#frm").submit();
    });

    $("#paypal").click(function(){
        $("#paypalForm").submit();
    });

    $("#stripe").click(function(){
        $(".stripe_group").css('background-color','#DDB86C');
        var url =  $("#stripe").data('url');
        $("#payment_type").val("stripe");
        $("#frm").attr('action', url);
    });
</script>
@endsection

<!DOCTYPE html>
<html lang="">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
  <META Http-Equiv="Pragma" Content="no-cache">
  <META Http-Equiv="Expires" Content="0">
  <title>{{ websiteTitle() }}</title>
  <link rel="shortcut icon" href="{{ asset('images/favicon.png') }}" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="{{ asset('assets/dist/jquery.min.js') }}"></script>
  <!-- Theme CSS -->
  <link href="{{ asset('frontend/assets/css/loginStyle.css') }}" rel="stylesheet"> 
  <style>
      .captcha-box { border-radius: 5px; border: 2px solid; padding: 0.5rem 2rem;  max-width: 400px; margin: 20px 0; }
      #canvas {
        width: 250px;
        height: 80px;
      }
    </style>
</head>
<body>
  @php
    if(app()->getLocale() == "en"){
      $langText = "AR";
      $lang = "ar";
      $lang_link = '';
      $text_align = 'right';
      $selectedLang = "EN";
    }else{
      $langText = "EN";
      $selectedLang = "AR";
      $lang = "en";
      $lang_link = 'ar/';
      $text_align = 'left';
    }
    @endphp
  <header class="header">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <a class="navbar-brand page-scroll logo no-margin" href="index.html">
            <img src="{{ asset('frontend/assets/images/logo.png') }}" class="img-fluid" alt="">
          </a>
        </div>
        <div class="col-md-6 text-right">
          <ul class="top-links list-unstyled">
             <li class="pull-right">
                <div class="navbar-nav">
                  <div class="nav-item dropdown">
                      <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">{{ $selectedLang }}</a>
                      <div class="dropdown-menu">
                          <a href="{{ route('lang', [$lang]) }}">{{ $langText }}</a>
                      </div>
                  </div>
                </div>
              </li>
              <li class="pull-right login">
                  <a class="cd-signin btn-lg" href="https://tasali.media/logout">@lang('frontend.logout')</a>
              </li>
          </ul>
                    
        </div>
      </div>
    </div>
  </header>
  <div class="main mt-100">
    <div class="container">
      <div class="row text-center tabs">
        <div class="col-md-3 tab active">@lang('frontend.create_new_account')</div>
        <div class="col-md-3 tab">@lang('frontend.your_plan')</div>
        <div class="col-md-3 tab">@lang('frontend.choose_payment')</div>
        <div class="col-md-3 tab">@lang('frontend.subscription')</div>
      </div>
      <div class="form-container">
        <div class="right-arrow" id="register"><i class="fa fa-angle-right"></i></div>
        <div class="left-arrow"><i class="fa fa-angle-left"></i></div>
        <h5><i class="fa fa-check" aria-hidden="true"></i> @lang('frontend.trial_text')</h5>
          <form>
            <div class="row plans py-5 justify-content-center">                                 
              <div class="col-md-3 plan">                 
                  <a href="#">
                      <img src="img/visa.png">
                      <h5>@if(\Session::get('is_left') == 1){{ \Session::get('code') }} @endif {{ \Session::get('amount') }} @if(\Session::get('is_left') == 0){{ \Session::get('code') }} @endif  @lang('frontend.month')</h5>
                      <div>@lang('frontend.free_trial')</div>
                      <div><i class="fa fa-check" aria-hidden="true"></i>@lang('frontend.channels_available')</div>
                  </a>
              </div>
              <div class="col-md-3 plan mx-5">
                  <a href="#">
                      <h5>Voucher</h5>
                      <div>Have a voucher?</div>
                      <div>Redeem it here.</div>
                      <div><i class="fa fa-times"></i>No channels available</div>
                  </a>
              </div>
              <div class="col-md-3 plan">
                  <a href="#">
                      <img src="img/visa.png">
                      <h5>6 $ Mothly</h5>
                      <div>14 days free trial</div>
                      <div><i class="fa fa-times" aria-hidden="true"></i>No channels available</div>
                  </a>
              </div>                  
            </div>
          </form>
            <h5><i class="fa fa-check" aria-hidden="true"></i> @lang('frontend.trial_ends')</h5>
            <h5><i class="fa fa-check" aria-hidden="true"></i> @lang('frontend.cancel_any_time')</h5>
            <div class="form-footer">
                <div class="row my-5">
                  <div class="col-md-6">
                    @lang('frontend.terms_conditions_text') <a href="{{ $lang_link }}terms.html">@lang('frontend.terms_conditions')</a>
                  </div>
                  <div class="col-md-1">&nbsp;</div>
                  <div class="col-md-5">
                    <div class="pull-left">@lang('frontend.already_account') <a href="https://tasali.media/login">@lang('frontend.login_text')</a></div>
                    <div class="pull-right"><a href="{{ $lang_link }}contact.html">@lang('frontend.need_help')</a></div>
                  </div>
                </div>
            </div>
        </div>   
    </div>
  </div>
  <section id="footer">
    <div class="footer-bottom">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-12">
            <div class="footer-widget-social">
              <ul>
                <li>
                  <a data-tooltip="facebook" href="https://www.facebook.com/Tasali-114646016899548">
                    <img src="images/facebook.png" alt="" class="img-fluid">
                  </a>
                </li>
                <li>
                  <a data-tooltip="inestagram" href="https://www.instagram.com/mediatasali/">
                    <img src="images/inesta.png" alt="" class="img-fluid">
                  </a>
                </li>
                <li>
                  <a data-tooltip="youtube" href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                    <img src="images/youtube.png" alt="" class="img-fluid">
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-6 col-md-6 col-sm-12 text-center">
            <p>@lang('frontend.copyrights')</p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://unpkg.com/@popperjs/core@2"></script>
    <script type="text/javascript">
      $("#register").click(function(){
        window.location.href = '{{ route("registerStep3") }}';
      });
    </script>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
    <META Http-Equiv="Pragma" Content="no-cache">
    <META Http-Equiv="Expires" Content="0">
    <title>{{ websiteTitle() }}</title>
    <link rel="shortcut icon" href="{{ asset('images/favicon.png') }}" />
    <!-- Bootstrap Core CSS -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="{{ asset('assets/css/flexslider.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/scrolling-nav.css') }}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/dc_payment_icons.css') }}" />
    @php
    if(app()->getLocale() == "en"){ @endphp
        <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet">
        <link href="{{ asset('assets/css/responsive_login.css') }}" rel="stylesheet">
        <link href="{{ asset('assets/css/responsive.css') }}" rel="stylesheet">
    @php
     }
    else{ @endphp
        <link href="{{ asset('ar/assets/css/style.css') }}" rel="stylesheet"> 
        <link href="{{ asset('ar/assets/css/responsive_login.css') }}" rel="stylesheet">
        <link href="{{ asset('ar/assets/css/responsive.css') }}" rel="stylesheet">
   @php } @endphp  
    <link href="{{ asset('assets/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/headline.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/ionicons.min.css') }}" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.1.0/css/flag-icon.min.css" rel="stylesheet">
    <!-- Important Owl stylesheet -->
    <link rel="stylesheet" href="{{ asset('assets/css/owl.carousel.css') }}">
    <!-- Default Theme -->
    <link rel="stylesheet" href="{{ asset('assets/css/owl.theme.css') }}">
    <script src="{{ asset('assets/dist/jquery.min.js') }}"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js'></script>
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar">
    <div class="se-pre-con"></div>
    @php
    if(app()->getLocale() == "en"){
        $langText = "Ø¹Ø±Ø¨Ù‰";
        $lang = "ar";
        $lang_link = '';
        $text_align = 'right';
    }
    else{
        $langText = "ENGLISH";
        $lang = "en";
        $lang_link = 'ar/';
        $text_align = 'left';
    }
  @endphp
    <!--top bar start-->
    <header class="header fixed-top">
        <!--top bar end-->
        <div class="top-bar w-100">
            <div class="container" style="width: 100%; padding-top: 1rem;">
                <div class="row">
                    <div class="col-6">
                        <a class="navbar-brand page-scroll logo no-margin" href="index.html">
                            <img src="{{ asset('images/Tasali-Logo.png') }}" class="img-fluid" alt="">
                        </a>
                    </div>
                    <!--top left col end-->
                    <div class="col-6 text-{{ $text_align }} ">
                        <ul class="list-inline top-socials list-unstyled">
                            <li class="list-inline-item">
                                <a href="{{ route('lang', [$lang]) }}">{{ $langText }}</a>
                            </li>
                            <li class="list-inline-item ">
                                <a class="nav-link cd-signin" id="head_sign" href="{{ route('logout') }}"><i
                                        class="ion-ios-contact"></i></a>
                            </li>
                            <li class="list-inline-item login">
                                <a class="cd-signin btn-lg" href="{{ route('logout') }}">@lang('frontend.logout')</a>
                            </li>
                        </ul>
                    </div>
                    <!--top social col end-->
                </div>
                <!--row-->
            </div>
            <!--container-->
        </div>
        <!-- End of Container -->
        <nav class="navbar navbar-toggleable-md navbar-inverse bg-inverse  header-transparent">
            <div class="container" style="width: 100%;">
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                    data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarNav">
                    <ul class="navbar-nav " style="margin:0 auto">
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="{{ $lang_link }}index.html">@lang('frontend.home')</a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="{{ $lang_link }}about.html">@lang('frontend.m_about')</a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="{{ $lang_link }}terms.html">@lang('frontend.terms_of_use')</a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="{{ $lang_link }}privacy.html">@lang('frontend.privacy_cookie_policy')</a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="{{ $lang_link }}faq.html">@lang('frontend.faqs')</a>
                        </li>
                        <li class="nav-item ">
                            <a class="page-scroll nav-link" href="{{ $lang_link }}contact.html">@lang('frontend.contact_us')</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!--slider start-->
    <section id="home" class="slider-banner">
        <div class="main-slider">
            <div class=" bg-no-overlay">
                <h1>@lang('frontend.payment')</h1>
            </div>
            <!--slides overlay end-->
            <!-- cd-user-modal -->
            <!--pop end-->
        </div>
    </section>
    <!-- content Section -->
    <!-- Abotu Section -->
    <section class="about-section all-space bg-parallax" data-jarallax='{"speed": 0.2}'>
        <div class="container">
            <div class="row step_center" style="display: block; margin: 0 auto;">
                <div class="col-lg-9 col-md-9 col-sm-12 scrollReveal sr-bottom sr-ease-in-out-quad" style=" margin: 0 auto;">
                    <div class="register_section">
                        <div class="register_center">
                            <div class="steps_counter">
                                <ul>
                                  <li class="active"><span>@lang('frontend.step1') .</span> <p>@lang('frontend.create_your_account')</p></li>
                                  <li class="active"><span>@lang('frontend.step2') .</span> <p>@lang('frontend.choose_payment')</p></li>
                                  <li><span>@lang('frontend.step3') .</span> <p>@lang('frontend.subscription') <strong> @if(\Session::get('is_left') == 1){{ \Session::get('code') }} @endif {{ \Session::get('amount') }} @if(\Session::get('is_left') == 0){{ \Session::get('code') }} @endif / @lang('frontend.month')</strong></p></li>
                                </ul>
                            </div>
                            <div class="steps_form step_form_1">
                                <p><br><h5 style="color: #555;">@lang('frontend.payment_description')</h5></p>
                                <p>
                                    <span class="dc_payment_icons_glossy_50 dc_visa_glossy" title="Visa"></span>
                                    <span class="dc_payment_icons_glossy_50 dc_mastercard_glossy" title="Mastercard"></span>
                                    <span class="dc_payment_icons_glossy_50 dc_americanexpress_glossy" title="American Express"></span>
                                    <span class="dc_payment_icons_glossy_50 dc_discover_glossy" title="Discover"></span>
                                    <span class="dc_payment_icons_glossy_50 dc_maestro_glossy" title="Maestro"></span>
                                    <span class="dc_payment_icons_glossy_50 dc_cirrus_glossy" title="Cirrus"></span>
                                    <span class="dc_payment_icons_glossy_50 dc_visaelectron_glossy" title="Visa Electron"></span>
                                </p>
                                <div class="row">        
                        <div class="col-md-12">
                            <h5 style="color: #555;">@lang('frontend.secure_payment')</h5>
                            <p></p>
                            <div class="paypal_group">
                                <p style="text-align: center; margin: revert;"><img src="{{ asset('images/lock.png') }}"></p>
                                <form  method="post" action="{{ route('stripe') }}">
                                    {{ csrf_field() }}
                                    <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                        data-key="{{ env('STRIPE_KEY') }}"
                                        data-amount="0"
                                        data-locale="auto"
                    data-email="{{ \Auth::user()->email }}"
                                        data-label="Pay with Stripe"
                    data-panel-label="Start your free trial"
                    data-address="true"
                                        data-currency="{{ \Session::get('code') }}">
                                    </script>
                                </form>
                            </div>
                        </div>                
                    </div>
                </div>
            </div>
        </div>
    </div>

                

            </div>



        </div>

    </section>

    <section class="content-section">

        <div class="row no-margin">

            <div class="col-md-12 no-padding">
                <hr>
            </div>

        </div>

    </section>




    <div id="play_video" class="modal">
        <div class="modal-content" style="height:70vh;padding:2px;">
        </div>
    </div>
  <section id="footer">
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="footer-widget-social">
                            <ul>
                                <li>
                                    <a data-tooltip="facebook" href="https://www.facebook.com/Tasali-114646016899548">
                                        <img src="images/facebook.png" alt="" class="img-fluid">
                                    </a>
                                </li>
                                <li>
                                    <a data-tooltip="inestagram" href="https://www.instagram.com/mediatasali/">
                                        <img src="images/inesta.png" alt="" class="img-fluid">
                                    </a>
                                </li>
                                <li>
                                    <a data-tooltip="youtube" href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                                        <img src="images/youtube.png" alt="" class="img-fluid">
                                        </i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 text-center">
                        <p>@lang('frontend.copyrights')</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <a href="javascript:;" class="scrollTop back-to-top" id="back-to-top">

        <i class="fa fa-arrow-up"></i>

    </a>
 <script src="{{ asset('assets/dist/tether.min.js') }}"></script>
    <script src="{{ asset('assets/dist/jquery.flexslider-min.js') }}"></script>
    <script src="{{ asset('assets/dist/scrollreveal.min.js') }}"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
    <script src="{{ asset('assets/dist/jarallax.min.js') }}"></script>
    <script src="{{ asset('assets/dist/jarallax-video.min.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('assets/js/jquery.easing.min.js') }}"></script>
    <script src="{{ asset('assets/js/scrolling-nav.js') }}"></script>
    <script src="{{ asset('assets/js/main.js') }}"></script>
    <script src="{{ asset('assets/js/jqBootstrapValidation.js') }}"></script>
    <script src="{{ asset('assets/js/owl.carousel.js') }}"></script>
    <script src="{{ asset('assets/js/custom.js') }}"></script>

</body>
</html>