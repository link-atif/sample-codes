@extends('frontend.frontend')
@section('content')
<div class="register_bg">
    <!--header-->
    @include('frontend.components.slim_header')
    <!--header-->
    <div class="register_section">
        <h2>Create New Account</h2>
        <div class="register_center">
            <div class="steps_counter">
                <ul>
                    <li class="active"><span>@lang('frontend.step1')</span> <p>@lang('frontend.create_your_account')</p></li>
                    <li class="active"><span>@lang('frontend.step2')</span> <p>@lang('frontend.choose_payment')</p></li>
                    <li class="active"><span>@lang('frontend.step3')</span> <p>@lang('frontend.price') <strong>@if(\Session::get('is_left') == 1){{ \Session::get('code') }} @endif {{ \Session::get('amount') }} @if(\Session::get('is_left') == 0){{ \Session::get('code') }} @endif / @lang('frontend.month')</strong></p></li>
                </ul>
            </div>
            <div class="steps_form step_form_1">
                @include('frontend.components.errors')
                <form action="{{ route('') }}" id="frm" method="post">
                    {{ csrf_field() }}
                    <input type="hidden" name="card_number" value="{{ \Session::get('card_number') }}">
                    <input type="hidden" name="name_on_card" value="{{ \Session::get('name_on_card') }}">
                    <input type="hidden" name="expiration_month" value="{{ \Session::get('expiration_month') }}">
                    <input type="hidden" name ="expiration_year" value="{{ \Session::get('expiration_year') }}">
                    <input type="hidden" name="card_code" value="{{ \Session::get('card_code') }}">
                    <label>OTP</label>
                    <input type="text" class="form-control" name="otp" placeholder="OTP">
                    <a href="javascript:{}" class="reg_conti btn" id="register">Verify</a>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
<script type="text/javascript">
    $("#register").click(function(){
        $("#frm").submit();
    });
</script>
@endsection