@extends('frontend.register')

@section('content')
    <div class="register-landing">
        <div class="container landing-content">
            @include('frontend.components.slim_header')
            <div class="row landing-container">
                <div class="col s4 step active">
                    <p class="primary-dark-text-color">@lang('frontend.step1')</p>
                    <h1 class="secondary-dark-text-color">@lang('frontend.create_your_account')</h1>
                </div>
                <div class="col s4 step active">
                    <p class="primary-dark-text-color">@lang('frontend.step2')</p>
                    <h1 class="secondary-dark-text-color">@lang('frontend.choose_payment')</h1>
                </div>
                <div class="col s4 step active">
                    <p class="primary-dark-text-color">@lang('frontend.step3')</p>
                    <h1 class="secondary-dark-text-color">@lang('frontend.setup_payment')</h1>
                </div>
            </div>
            <!-- register content -->
            <div class="row register-content">
                <div class="col s4 offset-s4">
                    <p>@lang('frontend.pay_description')</p>
                    <form action="{{ url('/register') }}" method="post" class="register-form">
                        <div class="row">
                            {{ csrf_field() }}
                            <div class="col s12">
                                <label for="email">@lang('frontend.card_number')</label>
                                <input type="text" class="validate">
                            </div>
                            <div class="col s12">
                                <label for="email">@lang('frontend.exp_date')</label>
                                <input type="text" class="validate" placeholder="@lang('frontend.exp_date_placeholder')">
                            </div>
                            <div class="col s12">
                                <label for="email">@lang('frontend.security_code')</label>
                                <input type="text" class="validate" placeholder="@lang('frontend.cvv')">
                            </div>
                            <div class="actions col s12">
                                <p>@lang('frontend.register_disclaimer')</p>
                                <p>
                                    <input type="checkbox" class="filled-in main-color" id="agree" />
                                    <label for="agree">@lang('frontend.agree')</label>
                                </p>
                                <button type="submit" class="btn waves-effect waves-light main-color">@lang('frontend.start_membership')</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!--// register content -->
        </div>
    </div>
@endsection
