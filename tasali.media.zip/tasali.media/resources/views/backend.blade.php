<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Admin Dashboard</title>

    <!--easy pie chart-->
    <link rel="stylesheet" href="{{ asset('backend/js/jquery-easy-pie-chart/jquery.easy-pie-chart.css') }}">

    <!--vector maps -->
    <link rel="stylesheet" href="{{ asset('backend/js/vector-map/jquery-jvectormap-1.1.1.css') }}">

    <!--right slidebar-->
    <link rel="stylesheet" href="{{ asset('backend/css/slidebars.css') }}">

    <!--switchery-->
    <link rel="stylesheet" href="{{ asset('backend/js/switchery/switchery.min.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/js/toastr-master/toastr.css') }}">
    <!--jquery-ui-->
    <link rel="stylesheet" href="{{ asset('backend/js/jquery-ui/jquery-ui-1.10.1.custom.min.css') }}">

    <!--iCheck-->
    <link rel="stylesheet" href="{{ asset('backend/js/icheck/skins/all.css') }}">

    <link rel="stylesheet" href="{{ asset('backend/css/owl.carousel.css') }}">

    <!--bootstrap-fileinput-master-->
    <link rel="stylesheet" href="{{ asset('backend/js/bootstrap-fileinput-master/css/fileinput.css') }}">

    <!--Select2-->
    <link rel="stylesheet" href="{{ asset('backend/css/select2.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/select2-bootstrap.css') }}">

    <!--dropzone-->
    <link rel="stylesheet" href="{{ asset('backend/css/dropzone.css') }}">

    <!--bootstrap picker-->
    <link rel="stylesheet" href="{{ asset('backend/js/bootstrap-datepicker/css/datepicker.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/js/bootstrap-timepicker/compiled/timepicker.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/js/bootstrap-colorpicker/css/colorpicker.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/js/bootstrap-daterangepicker/daterangepicker-bs3.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/js/bootstrap-datetimepicker/css/datetimepicker.css') }}">

    <!--  summernote -->
    <link rel="stylesheet" href="{{ asset('backend/js/summernote/dist/summernote.css') }}">

    <!--bootstrap-fileinput-master-->
    <link rel="stylesheet" href="{{ asset('backend/js/bootstrap-fileinput-master/css/fileinput.css') }}" />

    <!--common style-->
    <link rel="stylesheet" href="{{ asset('backend/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('backend/css/style-responsive.css') }}">

    <!--iCheck-->
    <link rel="stylesheet" href="{{ asset('backend/js/icheck/skins/all.css') }}">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="{{ asset('backend/js/html5shiv.js') }}"></script>
    <script src="{{ asset('backend/js/respond.min.js') }}"></script>
    <![endif]-->
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

</head>

<body class="sticky-header">

    <section>
        <!-- sidebar left start-->
        <div class="sidebar-left">
            <!--responsive view logo start-->
            <div class="logo dark-logo-bg visible-xs-* visible-sm-*">
                <a href="{{ route('Backend::home') }}">
                    <img src="{{ asset('backend/img/logo-icon.png') }}" alt="">
                    <!--<i class="fa fa-maxcdn"></i>-->
                    
                </a>
            </div>
            <!--responsive view logo end-->

            <div class="sidebar-left-info">
                <!-- visible small devices start-->
                <div class=" search-field">  </div>
                <!-- visible small devices end-->

                <!--sidebar nav start-->
                <ul class="nav nav-pills nav-stacked side-navigation">
                    <li {{ Route::currentRouteName('Backend::home') ? 'class="active"' : '' }}>
                        <a href="{{ route('Backend::home') }}"><i class="fa fa-home"></i> <span>Dashboard</span></a>
                    </li>
                    <li {{ Route::currentRouteName('Backend::statistics') ? 'class="active"' : '' }}>
                        <a href="{{ route('Backend::statistics') }}"><i class="fa fa-bar-chart"></i> <span>Statistics</span></a>
                    </li>
                    <li>
                        <h3 class="navigation-title">Users</h3>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'users' ? ' active' : '' }}">
                        <a href="{{ route('Backend::users.index') }}"><i class="fa fa-users"></i>  <span>Users</span></a>
                        <ul class="child-list">
                            <li {{ route::currentRouteName('Backend::users.create') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::users.create') }}">New User</a>
                            </li>
                            <li {{ route::currentRouteName('Backend::users.index') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::users.index') }}">All Users</a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'roles' ? ' active' : '' }}">
                        <a href="{{ route('Backend::roles.index') }}"><i class="fa fa-gavel"></i>  <span>Privileges</span></a>
                        <ul class="child-list">
                            <li {{ route::currentRouteName('Backend::roles.create') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::roles.create') }}">New Privilege</a>
                            </li>
                            <li {{ route::currentRouteName('Backend::roles.index') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::roles.index') }}">All Privileges</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <h3 class="navigation-title">Config</h3>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'shows' ? 'active' : '' }}">
                        <a href=""><i class="fa fa-desktop"></i>  <span>Config</span></a>
                        <ul class="child-list">
                            <li {{ Request::is('admin/config') ? ' class="active"' : '' }}>
                                <a href="{{ URL::to('/') }}/admin/config">General</a></li>
                        </ul>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'countries' ? ' active' : '' }}">
                        <a href=""><i class="fa fa-user"></i>  <span>Countries</span></a>
                        <ul class="child-list">
                            <li {{ Request::is('admin/countries/create') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::countries.create') }}"> New Country</a>
                            </li>
                            <li {{ Request::is('admin/countries') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::countries.index') }}"> All Countries</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <h3 class="navigation-title">shows</h3>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'shows' ? 'active' : '' }}">
                        <a href=""><i class="fa fa-desktop"></i>  <span>Shows</span></a>
                        <ul class="child-list">
                            <li {{ Request::is('admin/shows/create') ? ' class="active"' : '' }}>
                                <a href="{{ URL::to('/') }}/admin/shows/create">New Show</a></li>
                            <li {{ Request::is('admin/shows') ? ' class="active"' : '' }}>
                                <a href="{{ URL::to('admin/shows') }}">All Shows</a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'episodes' ? 'active' : '' }}">
                        <a href=""><i class="fa fa-play"></i>  <span>Episodes</span></a>
                        <ul class="child-list">
                            <li {{ Request::is('admin/episodes/create') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::episodes.create') }}">New Episode</a></li>
                            <li {{ Request::is('admin/episodes') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::episodes.index') }}">All Episodes</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <h3 class="navigation-title">Movies</h3>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'movies' ? ' active' : '' }}">
                        <a href=""><i class="fa fa-video-camera"></i>  <span>Movies</span></a>
                        <ul class="child-list">
                            <li {{ Request::is('admin/movies/create') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::movies.create') }}"> New Movie</a>
                            </li>
                            <li {{ Request::is('admin/movies') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::movies.index') }}"> All Movies</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <h3 class="navigation-title">Genres & Casts</h3>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'genres' ? ' active' : '' }}">
                        <a href=""><i class="fa fa-bars"></i>  <span>Genres</span></a>
                        <ul class="child-list">
                            <li {{ Request::is('admin/genres/create') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::genres.create') }}"> New Genre</a>
                            </li>
                            <li {{ Request::is('admin/genres') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::genres.index') }}"> All Genres</a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'casts' ? ' active' : '' }}">
                        <a href=""><i class="fa fa-user"></i>  <span>Casts</span></a>
                        <ul class="child-list">
                            <li {{ Request::is('admin/casts/create') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::casts.create') }}"> New Cast</a>
                            </li>
                            <li {{ Request::is('admin/casts') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::casts.index') }}"> All Casts</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <h3 class="navigation-title">Pages</h3>
                    </li>
                    <li class="menu-list {{ Request::segment(2) == 'casts' ? ' active' : '' }}">
                        <a href=""><i class="fa fa-user"></i>  <span>Pages</span></a>
                        <ul class="child-list">
                            <li {{ Request::is('admin/pages/create') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::pages.create') }}"> New Page</a>
                            </li>
                            <li {{ Request::is('admin/pages') ? ' class="active"' : '' }}>
                                <a href="{{ route('Backend::pages.index') }}"> All Pages</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <h3 class="navigation-title">Videos</h3>
                    </li>
                    <li class="{{ Request::segment(2) == 'videos' ? ' active' : '' }}">
                        <a href="{{ route('Backend::videos.index') }}"><i class="fa fa-file-movie-o"></i>  <span>videos</span></a>
                    </li>
                </ul>
                <!--sidebar nav end-->
            </div>
        </div>
        <!-- sidebar left end-->

        <!-- body content start-->
        <div class="body-content">
            <!-- header section start-->
            <div class="header-section">

                <!--logo and logo icon start-->
                <div class="logo dark-logo-bg hidden-xs hidden-sm">
                    <a href="{{ route('Backend::home') }}" target="_blank">
                        <span class="brand-name">New Tasali Platform</span>
                    </a>
                </div>

                <div class="icon-logo dark-logo-bg hidden-xs hidden-sm">
                    <a href="{{ route('Backend::home') }}" target="_blank">
                        <img src="{{ URL::to('/backend/img/logo-icon.png') }}" alt="">
                        <!--<i class="fa fa-maxcdn"></i>-->
                    </a>
                </div>
                <!--logo and logo icon end-->

                <!--toggle button start-->
                <a class="toggle-btn"><i class="fa fa-outdent"></i></a>
                <!--toggle button end-->
                <div class="notification-wrap">
                    <!--right notification start-->
                    <div class="right-notification">
                        <ul class="notification-menu">
                            <li>
                                <a href="javascript:;" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                    @if(!is_null (Auth::user()->avatar))
                                    <img src="{{ asset('frontend/assets/images/avatar/'.Auth::user()->avatar.'.jpg')}}" alt="{{Auth::user()->name}}">
                                    @else
                                        <img src="{{ asset('frontend/assets/images/avatar.jpg') }}" alt="Logo">
                                    @endif
                                    {{ Auth::user()->name }}
                                    <span class=" fa fa-angle-down"></span>
                                </a>
                                <ul class="dropdown-menu dropdown-usermenu purple pull-right">
                                    <li><a href="{{ URL::to('/users/'.Auth::user()->id.'/edit') }}">  Profile</a></li>
                                    <li><a href="{{ URL::to('/logout') }}"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="right-notification" style="margin-right: 10px;">
                        <ul class="notification-menu">
                            <li>
                                <a href="{{ route('Backend::maintenance') }}" class="btn btn-default">
                                    Maintenance
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="right-notification" style="margin-right: 10px;">
                        <ul class="notification-menu">
                            <li>
                                <a href="{{ route('home') }}" class="btn btn-default">
                                    Visit Website
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!--right notification end-->
                </div>

            </div>
            <!-- header section end-->
            @yield('content')

        </div>
        <!-- body content end-->
    </section>

    <!-- Placed js at the end of the document so the pages load faster -->
    <script src="{{ asset('backend/js/jquery-1.10.2.min.js') }}"></script>

    <!--jquery-ui-->
    <script src="{{ asset('backend/js/jquery-ui/jquery-ui-1.10.1.custom.min.js') }}"></script>

    <script src="{{ asset('backend/js/jquery-migrate.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('backend/js/modernizr.min.js') }}"></script>

    <!--Nice Scroll-->
    <script src="{{ asset('backend/js/jquery.nicescroll.js') }}"></script>

    <!--right slidebar-->
    <script src="{{ asset('backend/js/slidebars.min.js') }}"></script>

    <!--switchery-->
    <script src="{{ asset('backend/js/switchery/switchery.min.js') }}"></script>
    <script src="{{ asset('backend/js/switchery/switchery-init.js') }}"></script>

    <!--Sparkline Chart-->
    <script src="{{ asset('backend/js/sparkline/jquery.sparkline.js') }}"></script>
    <script src="{{ asset('backend/js/sparkline/sparkline-init.js') }}"></script>

    <!--vectormap-->
    <script src="{{ asset('backend/js/vector-map/jquery-jvectormap-1.2.2.min.js') }}"></script>
    <script src="{{ asset('backend/js/vector-map/jquery-jvectormap-world-mill-en.js') }}"></script>
    <script src="{{ asset('backend/js/dashboard-vmap-init.js') }}"></script>

    <!--Icheck-->
    <script src="{{ asset('backend/js/icheck/skins/icheck.min.js') }}"></script>
    <script src="{{ asset('backend/js/todo-init.js') }}"></script>

    <!--jquery countTo-->
    <script src="{{ asset('backend/js/jquery-countTo/jquery.countTo.js') }}"></script>

    <!--owl carousel-->
    <script src="{{ asset('backend/js/owl.carousel.js') }}"></script>

    <!-- validate -->
    <script src="{{ asset('backend/js/jquery.validate.min.js') }}"></script>

    <!--bootstrap-fileinput-master-->
    <script src="{{ asset('backend/js/bootstrap-fileinput-master/js/fileinput.js') }}"></script>
    <script src="{{ asset('backend/js/file-input-init.js') }}"></script>

    <!--select2-->
    <script src="{{ asset('backend/js/select2.js') }}"></script>
    <script src="{{ asset('backend/js/select2-init.js') }}"></script>

    <!--dropzone-->
    <script src="{{ asset('backend/js/dropzone.js') }}"></script>

    <!--bootstrap picker-->
    <script src="{{ asset('backend/js/bootstrap-datepicker/js/bootstrap-datepicker.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap-daterangepicker/moment.min.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap-daterangepicker/daterangepicker.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap-colorpicker/js/bootstrap-colorpicker.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap-timepicker/js/bootstrap-timepicker.js') }}"></script>
    <script src="{{ asset('backend/js/picker-init.js') }}"></script>
    <!--Icheck-->
    <script src="{{ asset('backend/js/icheck/skins/icheck.min.js') }}"></script>
    <!--icheck init-->
    <script src="{{ asset('backend/js/icheck-init.js') }}"></script>

    <!--summernote-->
    <script src="{{ asset('backend/js/summernote/dist/summernote.min.js') }}"></script>
    <script src="{{ asset('backend/js/toastr-master/toastr.js') }}"></script>
    <script src="{{ asset('backend/js/toastr-init.js') }}"></script>
    <!-- resumable -->
    <script src="{{ asset('backend/js/resumable.js') }}"></script>
    <script src="{{ asset('backend/js/resumable-init.js') }}"></script>

    <!-- The jQuery UI widget factory, can be omitted if jQuery UI is already included -->
    {{--  <script src="js/vendor/jquery.ui.widget.js"></script>  --}}
    <!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
     {{-- <script src="{{ asset('backend/js/jQuery-File-Upload-9.21.0/js/jquery.iframe-transport.js') }}"></script>  --}}
    <!-- The basic File Upload plugin -->
     {{-- <script src="{{ asset('backend/js/jQuery-File-Upload-9.21.0/js/jquery.fileupload.js') }}"></script>  --}}
     {{-- <script src="{{ asset('backend/js/jQuery-File-Upload-9.21.0/js/init.js') }}"></script>  --}}

    <script src="{{ asset('backend/js/toastr-init.js') }}"></script>
    <!--common scripts for all pages-->
    <script src="{{ asset('backend/js/scripts.js') }}"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.js-example-basic-multiple').select2();
        });
    </script>
    <script type="text/javascript">    
        function encodeImageFileAsURL(image,id,old_image) {
            var filesSelected = document.getElementById(image).files;
            if (filesSelected.length > 0) {
                var fileToLoad = filesSelected[0];
                var fileReader = new FileReader();
                fileReader.onload = function(fileLoadedEvent) {
                    var srcData = fileLoadedEvent.target.result; // <--- data: base64
                    var newImage = document.createElement('img');
                    newImage.src = srcData;
                    document.getElementById(id).innerHTML = newImage.outerHTML;
                }
                fileReader.readAsDataURL(fileToLoad);
                if(old_image !=""){
                    document.getElementById(old_image).style.display = 'none';
                }
            }
        }
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
            var navListItems = $('div.setup-panel div a'),
                allWells = $('.setup-content'),
                allNextBtn = $('.nextBtn');
                allWells.hide();
                navListItems.click(function (e) {
                    e.preventDefault();
                    var $target = $($(this).attr('href')),
                    $item = $(this);

                    if (!$item.hasClass('disabled')) {
                        navListItems.removeClass('btn-success').addClass('btn-default');
                        $item.addClass('btn-success');
                        allWells.hide();
                        $target.show();
                        $target.find('input:eq(0)').focus();
                    }
                });

                allNextBtn.click(function () {
                    var curStep = $(this).closest(".setup-content"),
                    curStepBtn = curStep.attr("id"),
                    nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
                    curInputs = curStep.find("input[type='text'],input[type='url']"),
                    isValid = true;

                    $(".form-group").removeClass("has-error");
                    for (var i = 0; i < curInputs.length; i++) {
                        if (!curInputs[i].validity.valid) {
                            isValid = false;
                            $(curInputs[i]).closest(".form-group").addClass("has-error");
                        }
                    }

                    if (isValid) nextStepWizard.removeAttr('disabled').trigger('click');
                });

                $('div.setup-panel div a.btn-success').trigger('click');
        });
    </script>
    @yield('script')
</body>
</html>
