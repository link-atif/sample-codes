@extends('frontend.frontend')

@section('content')
@include('frontend.components.navbar')
<div class="container">
	<br><br><br><br><br>

	<h5 class="header white-text">Movies</h5>
	@include('frontend.components.grid-items', array('items'=>$movies))
	<div class="front-pagination">{{ $movies->links() }}</div>
</div>
@endsection