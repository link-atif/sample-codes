@extends('frontend.frontend')
@section('content')
@include('frontend.components.navbar')

	<div class="profile_tabs_section" style="color:#fff">
        @if (Session::has('flash_message'))
		    <div class="alert alert-success alert-block fade in">
		        <button data-dismiss="alert" class="close close-sm" type="button">
		            <i class="fa fa-times"></i>
		        </button>
		        <p>{{ Session::get('flash_message') }}</p>
		    </div>
		@endif
        <div class="container">
            <div class="col-md-2 padd_0">
            </div>
            <div class="col-md-8 padd_0">
                <div class="tab-content">
                	<div class="profile_right_info_sec who_is_watching">
                    	<div class="tab-pane fade in active">
	                        <div class="info_edit_col">
                                <a href="{{ route('profile') }}">
	                                <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="profile_avatar_inner">
		                             		@if($user->avatar =="")
		                             		<img src="{{ asset('frontend/assets/images/p_1.jpg') }}">
	                                		@endif
	                                		@if($user->avatar !="")
	                                		<img src="{{ asset('frontend/assets/images/avatar/'.$user->avatar.'.jpg') }}" height="105px">
	                                		@endif
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">{{ $user->name }}</h5>
	                                	</div>
		                            </div>
		                        </a>
	                            @if(!empty($child))
	                            @foreach($child as $ch)
	                            <a href="#">
		                            <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="select_avataer_iner">
		                             		@if($ch->avatar =="")
		                             		<img src="{{ asset('frontend/assets/images/p_1.jpg') }}">
	                                		@endif
	                                		@if($ch->avatar !="")
	                                		<img src="{{ asset('frontend/assets/images/avatar/'.$ch->avatar.'.jpg') }}" height="105px">
	                                		@endif
	                                	</div>
	                                	<a href="{{ route('profile.setting', $ch->id) }}">
		                                	<div class="edit-profile">
			                                    <i class="fas fa-edit"></i>
			                                </div>
		                                </a>
		                                <a href="{{ route('remove.profile', $ch->id) }}" onclick="confirm('Are You Sure to Remove this Profile.')">
			                                <div class="delete-profile">
			                                    <i class="fas fa-trash"></i>
			                                </div>
		                            	</a>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">{{ $ch->name }}</h5>
	                                	</div>
		                            </div>
	                        	</a>
	                            @endforeach	
	                            @endif
	                            @if(count($child) < 1)
	                            <a href="{{ route('add.profile') }}">
		                            <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="select_avataer_iner">
		                             		<img src="{{ asset('frontend/assets/images/plusp_1.png') }}">
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">@lang('frontend.add_profile')</h5>
	                                	</div>
		                            </div>
	                        	</a>
	                        	@endif
	                        </div>
                    	</div>
                	</div>
                </div>
            </div>
           	<div class="col-md-2 padd_0">
           	</div>
        </div>
    </div>
@endsection