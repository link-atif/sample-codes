    @extends('frontend.frontend')
    @section('content')
    @include('frontend.components.navbar')
    
    <!--tabs-->
    <div class="profile_tabs_section">
        <div class="container">
            <div class="col-md-12 padd_0">
                <div class="profile_right_info_sec">
                    <div class="profile_tabs_right_2">
                        @include('frontend.components.errors')
                        <form action="{{ route('store.profile') }}" id="store_payment" method="post">
                            {{ csrf_field() }}
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.name') :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="text" class="form-control" name="name" placeholder="@lang('frontend.name')" value="{{ old('name') }}">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.email') :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="email" class="form-control" name="email" placeholder="@lang('frontend.email')" value="{{ old('email') }}">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.password')</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" class="form-control" name="password" placeholder="@lang('frontend.password')">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.confirm_password') :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" class="form-control" name="password_confirmation" placeholder="@lang('frontend.confirm_password')">
                                </div>
                            </div>
                            
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-5"></div>
                                <div class="col-md-5">
                                    <div class="submit_buttons">
                                        <a href="{{ route('all.profiles') }}">Discard</a>
                                        <a href="javascript:{}" onclick="document.getElementById('store_payment').submit();" class="save_reverse">Save</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
@endsection