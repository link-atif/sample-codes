@extends('frontend.frontend')
<style>
@media only screen 
	and (width: 1024px) 
	and (height: 1366px)
	and (-webkit-min-device-pixel-ratio: 1) {
		.selectd_tick i {margin-top: 30px !important;}
	}
</style>

@section('content')
@include('frontend.components.navbar')

	<div class="profile_tabs_section" style="margin-top: 50px; color:#fff">
        @if (Session::has('flash_message'))
		    <div class="alert alert-success alert-block fade in">
		        <button data-dismiss="alert" class="close close-sm" type="button">
		            <i class="fa fa-times"></i>
		        </button>
		        <p>{{ Session::get('flash_message') }}</p>
		    </div>
		@endif
        <div class="container">
            <div class="col-md-4 fix_padd_mob">
                <div class="profile_left_nav">
                    <ul>
                        <li class="active"><a href="#tab1" id="showTab1" data-toggle="tab">@lang('frontend.my_info')</a></li>
                        <li><a href="#tab2" id="showTab2" data-toggle="tab">@lang('frontend.my_plan_details')</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-8 padd_0">
                <div class="tab-content">
                	<div class="profile_right_info_sec">
                    	<div id="tab1" class="tab-pane fade in active">
	                        <div class="info_edit_col">
	                            <div class="col-md-3">
	                                <label>@lang('frontend.name') :</label>
	                            </div>
	                            <div class="col-md-6">
	                                <input type="text" class="form-control" value="{{ $user->name }}" readonly>
	                            </div>
	                            <div class="col-md-3">
	                                <a href="{{ route('editProfile', 'name') }}" class="edit_info_button">@lang('frontend.edit')</a>
	                            </div>
	                        </div>
	                        
	                        <div class="info_edit_col">
	                            <div class="col-md-3">
	                                <label>@lang('frontend.email') :</label>
	                            </div>
	                            <div class="col-md-6">
	                                <input type="text" class="form-control" value="{{ $user->email }}" readonly>
	                            </div>
	                            <div class="col-md-3">
	                                <a href="{{ route('editProfile' , 'email') }}" class="edit_info_button">@lang('frontend.edit')</a>
	                            </div>
	                        </div>
	                        <div class="info_edit_col">
	                            <div class="col-md-3">
	                                <label>@lang('frontend.password') :</label>
	                            </div>
	                            <div class="col-md-6">
	                                <input type="password" class="form-control" value="Test Account" readonly>
	                            </div>
	                            <div class="col-md-3">
	                                <a href="{{ route('editProfile', 'password') }}" class="edit_info_button">@lang('frontend.edit')</a>
	                            </div>
	                        </div>
	                        <div class="info_edit_col">
	                            @for($i=1; $i <= 4; $i++)
                                <div class="col-md-2 col-sm-2 col-xs-3 select-avatar @if(!is_null(Auth::user()->avatar) && Auth::user()->avatar == $i) selected @endif" data-image_id="{{ $i }}">
                                <div class="select_avataer_iner">
	                             	<img src="{{ asset('frontend/assets/images/avatar/'.$i.'.jpg') }}">
                                <div class="selectd_tick">
                                    <i class="far fa-check-circle"></i>
                                </div>
                                </div>
	                            </div>	
							    @endfor
	                        </div>
	                        @if(!empty($devices))
	                        <div class="info_edit_col">
	                            <div class="col-md-3">
	                                <label>@lang('frontend.devices') :</label>
	                            </div>
	                            <div class="col-md-9">
	                            </div>
	                        </div>
	                        @foreach($devices as $d)
	                        <div class="info_edit_col">
	                            <div class="col-md-3">
	                                <label>Platform : {{ $d->platform }}</label>
	                            </div>
	                            <div class="col-md-3">
	                            	<label>Platform version : {{ $d->platform_version }}</label>
	                            </div>
	                            <div class="col-md-3">
	                            	<label>Browser : {{ $d->browser }}</label>
	                            </div>
	                            <div class="col-md-3">
	                                 <form action="{{ route('delete_device', $d->id) }}" id="delete_device-{{ $d->id }}" method="post">
										{{ method_field('delete') }}
										{{ csrf_field() }}
										<a href="javascript:{}" onclick="document.getElementById('delete_device-'+'{{ $d->id }}').submit();return confirm('Are you sure?')" 
										data-msg="@lang('backend.confirm_delete')" class="mylinks">@lang('frontend.delete')</a>
									</form>
	                            </div>
	                        </div>
	                        @endforeach
	                        @endif
                    	</div>

                    	<div id="tab2" class="tab-pane fade second_right_tab" style="min-heigh:1000px">
		                    <p>@lang('frontend.setting_price') {{ $currency }} {{ $amount ?? null}}/@lang('frontend.month')</p>
                        	<p>@lang('frontend.subscription_end_date') : <span>{{ $user->premium_end_date ? \Carbon\Carbon::parse($user->premium_end_date)->toDateString() : null }}</span></p>
                        	@if(isset($cards))
								@foreach($cards as $card)
									<div class="row">
										<div class="col-sm-2"><strong>Card {{ $loop->index+1 }}:</strong></div>
										<div class="col-sm-1">
											@if($card->type != "")
												<img src="{{ asset('frontend/assets/images/'.$card->type.'.png') }}">
											@else
												<img style="width: 50px;" src="{{ asset('frontend/assets/images/Visa.png') }}">
											@endif
										</div>
										<div class="col-sm-4">{{ $card->card_number }}</div>
										@if($card->is_primary == 1)
											<div class="col-sm-2">
												<a href="{{ route('primary_payment', $card->id) }}" class="mylinks">@lang('frontend.primary_card')</a>
											</div>
										@else
											<div class="col-sm-2">
												<a href="{{ route('primary_payment', $card->id) }}" class="mylinks">@lang('frontend.make_primary')</a>
											</div>
										@endif
										@if($loop->count != 1 && $card->is_primary != 1)
										<div class="col-sm-1">
											<form action="{{ route('delete_payment', $card->id) }}" id="delete_payment-{{ $card->id }}" method="post">
												{{ method_field('delete') }}
												{{ csrf_field() }}
												<a href="javascript:{}" onclick="document.getElementById('delete_payment-'+'{{ $card->id }}').submit();return confirm('Are you sure?')" 
												data-msg="@lang('backend.confirm_delete')" class="mylinks">@lang('frontend.delete')</a>
											</form>
										</div>
										@endif
									</div>
								@endforeach
							@endif
							<div class="row" style="margin-top: 15px;">
								<div class="col-md-12">
	                        		<a href="{{ route('add_payment') }}" class="add_card" style="margin-right:10px;">@lang('frontend.add_new_card')</a>&nbsp; &nbsp;
		                		@if(isset($subscription))
									 <a href="{{ route('cancel_subscription', $subscription->id) }}" onclick="return confirm('Are you sure?');" class="add_card">@lang('frontend.cancel_subscription')</a>
								@endif
								</div>
							</div>
	                	</div>
                	</div>
                </div>
            </div>
        </div>
    </div>

    <form method="post" action="{{ route('updateProfile') }}" name="frm" id="frm">{{ csrf_field() }}
  		<input type="hidden" value="image_id" name="field">
  		<input type="hidden" name="image_id" id="image_id" value="">
    </form>
@endsection

@section('script')
<script type="text/javascript">
	$(document).ready(function() {
		$(document).on('click','#showTab1', function(){
			$("#tab1").show();
			$("#tab2").hide();
			$(".profile_right_info_sec").height($("#tab1").height()+"px");
		});
		$(document).on('click','#showTab2', function(){
			$("#tab2").show();
			$("#tab1").hide();
			$(".profile_right_info_sec").height($(window).height()-400+"px");
		});
	});
	$(document).on('click','.select-avatar', function(){
		var image_id = $(this).attr("data-image_id");
		$("#image_id").val(image_id);
		$("#frm").submit();
	});
</script>
@endsection