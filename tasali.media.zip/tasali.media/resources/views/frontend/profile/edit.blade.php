@extends('frontend.frontend')

@section('content')

@include('frontend.components.navbar')

<div class="profile_tabs_section" style="margin-top: 150px;">
    <div class="container">
        <div class="col-md-12 padd_0">
            <div class="profile_right_info_sec">
                <div class="profile_tabs_right_2">
                    @if (count($errors) == 1)
                        <div class="alert alert-danger alert-block fade in">
                            <button data-dismiss="alert" class="close close-sm" type="button">
                                <i class="fa fa-times"></i>
                            </button>
                            <h4>
                                <i class="fa fa-ok-sign"></i>
                                Error!
                            </h4>
                            @foreach ($errors->all() as $error)
                                <p>{{ $error }}</p>
                            @endforeach
                        </div>
                    @endif
                    <form action="{{ route('updateProfile') }}" id="edit_profile" method="post">
                        {{ csrf_field() }}
                        <input type="hidden" value="{{ $field }}" name="field">
                        @if($field == "email")
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.current_email'):</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="email" class="form-control" name="current_email" value="{{ $user->email }}" readonly>
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.email'):</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="email" name="email" class="form-control" value="{{ old('email') }}" required>
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.password'):</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" name="current_password" class="form-control" required>
                                </div>
                            </div>
                        @endif
                        @if($field == "name")
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.name'):</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="text" class="form-control" name="name" value="{{ $user->name }}" required>
                                </div>
                            </div>
                        @endif
                        @if($field == "password")
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.current_password'):</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" class="form-control" name="current_password" required>
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.password'):</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>@lang('frontend.confirm_password'):</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="password" name="password_confirmation" class="form-control" required>
                                </div>
                            </div>
                        @endif
                        <div class="info_edit_col info_edit_col_2">
                            <div class="col-md-5"></div>
                            <div class="col-md-5">
                                <div class="submit_buttons">
                                    <a href="{{ route('profile') }}">Discard</a>
                                    <a href="javascript:{}" onclick="document.getElementById('edit_profile').submit();" class="save_reverse">Save</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection