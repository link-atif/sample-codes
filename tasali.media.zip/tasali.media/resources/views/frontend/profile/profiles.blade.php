@extends('frontend.frontend')
<style>

@media only screen and (min-width: 769px) and (max-width: 1024px){
.profile_tabs_section{
	margin-top: 100px;
	margin-bottom: 100px;

	}
}

@media only screen and (min-width: 769px){
.profile_tabs_section{
	margin-top: 100px;
	}
}

@media only screen and (min-width:768px){
.profile_tabs_section{
	margin-top: 100px;
	}
}

@media only screen and (min-width:600px) and (max-width:768px){
.who_is_watching {
    	margin-bottom: 120px;
	}
}

@media only screen and (min-width:425px) and (max-width:767px){
.profile_tabs_section{margin: 140px 0 100px;}

}

@media only screen and (min-width:380px) and (max-width:424px){
.profile_tabs_section{margin: 70px 0 70px;}

}

@media only screen and (min-width: 351px) and (max-width: 375px){
.profile_tabs_section {
    margin: 55px 0 54px;
}
}


@media only screen and (max-width: 350px){
.profile_tabs_section {
    margin: 100px 0;
}

}

</style>
@section('content')
@include('frontend.components.navbar')

	<div class="profile_tabs_section" style="color:#fff">
        @if (Session::has('flash_message'))
	    <div class="alert alert-success alert-block fade in">
	        <button data-dismiss="alert" class="close close-sm" type="button">
	            <i class="fa fa-times"></i>
	        </button>
	        <p>{{ Session::get('flash_message') }}</p>
	    </div>
		@endif
        <div class="container">
            <div class="col-md-2 padd_0">
            </div>
            <div class="col-md-8 padd_0">
                <div class="tab-content">
                	<div class="profile_right_info_sec who_is_watching">
                    	<div class="tab-pane fade in active">
	                        <div class="info_edit_col">
                                <a href="{{ route('profile') }}">
	                                <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="profile_avatar_inner">
		                             		@if($user->avatar =="")
		                             		<img src="{{ asset('frontend/assets/images/avater.jpg') }}">
	                                		@endif
	                                		@if($user->avatar !="")
	                                		<img src="{{ asset('frontend/assets/images/avatar/'.$user->avatar.'.jpg') }}" height="auto">
	                                		@endif
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">{{ $user->name }}</h5>
	                                	</div>
		                            </div>
		                        </a>
	                            @if(!empty($child))
	                            @foreach($child as $ch)
	                            <a href="#">
		                            <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="select_avataer_iner">
		                             		@if($ch->avatar =="")
		                             		<img src="{{ asset('frontend/assets/images/avater.jpg') }}">
	                                		@endif
	                                		@if($ch->avatar !="")
	                                		<img src="{{ asset('frontend/assets/images/avatar/'.$ch->avatar.'.jpg') }}" height="105px">
	                                		@endif
	                                	</div>
	                                	<a href="{{ route('profile.setting', $ch->id) }}">
		                                	<div class="edit-profile">
			                                    <i class="fas fa-edit"></i>
			                                </div>
		                                </a>
		                                <a href="{{ route('remove.profile', $ch->id) }}" onclick="confirm('Are You Sure to Remove this Profile.')">
			                                <div class="delete-profile">
			                                    <i class="fas fa-trash"></i>
			                                </div>
		                            	</a>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">{{ $ch->name }}</h5>
	                                	</div>
		                            </div>
	                        	</a>
	                            @endforeach	
	                            @endif
	                            @if(count($child) < 1)
	                            <a href="{{ route('add.profile') }}">
		                            <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="select_avataer_iner">
		                             		<img src="{{ asset('frontend/assets/images/plusp_1.png') }}">
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">@lang('frontend.add_profile')</h5>
	                                	</div>
		                            </div>
	                        	</a>
	                        	@endif
	                        </div>
                    	</div>
                	</div>
                </div>
            </div>
           	<div class="col-md-2 padd_0">
           	</div>
        </div>
    </div>
@endsection
@section('script')
<script>
$(document).ready(function(){
$( "#footer" ).addClass( "fixed-footer" );  
});
</script>
@endsection