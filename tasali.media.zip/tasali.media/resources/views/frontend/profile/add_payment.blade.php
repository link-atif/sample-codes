    @extends('frontend.frontend')
    @section('content')
    @include('frontend.components.navbar')
    
    <!--tabs-->
    <div class="profile_tabs_section" style="margin-top: 150px;">
        <div class="container">
            <div class="col-md-12 padd_0">
                <div class="profile_right_info_sec">
                    <div class="profile_tabs_right_2">
                        @include('frontend.components.errors')
                        <form action="{{ route('store_payment') }}" id="store_payment" method="post">
                            {{ csrf_field() }}
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>Card Number :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="number" class="form-control" name="card_number" placeholder="Card Number">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>Name On Card :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="text" class="form-control" name="name_on_card" placeholder="Name On Card">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>Expiration Month :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="number" class="form-control" name="expiration_month" placeholder="MM">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>Expiration Year :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="number" class="form-control" name="expiration_year" placeholder="YYYY">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-2">
                                    <label>Security Code :</label>
                                </div>
                                <div class="col-md-5">
                                    <input type="number" class="form-control" name="card_code" placeholder="CVV">
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-5">
                                    <label>
                                    <input type="checkbox" class="form-control" id="filled-in-box" name="is_primary" value="1">
                                        <span>Make Primary</span>
                                    </label>
                                </div>
                            </div>
                            <div class="info_edit_col info_edit_col_2">
                                <div class="col-md-5"></div>
                                <div class="col-md-5">
                                    <div class="submit_buttons">
                                        <a href="{{ route('profile') }}">Discard</a>
                                        <a href="javascript:{}" onclick="document.getElementById('store_payment').submit();" class="save_reverse">Save</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
@endsection