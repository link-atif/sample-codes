@extends('frontend.frontend')
@section('content')
@include('frontend.components.navbar')

	<div class="profile_tabs_section" style="margin-top: 50px; color:#fff">
        @if (Session::has('flash_message'))
		    <div class="alert alert-success alert-block fade in">
		        <button data-dismiss="alert" class="close close-sm" type="button">
		            <i class="fa fa-times"></i>
		        </button>
		        <p>{{ Session::get('flash_message') }}</p>
		    </div>
		@endif
        <div class="container">
            <div class="col-md-4 fix_padd_mob">
                <div class="profile_left_nav">
                    <ul>
                        <li class="active"><a href="#tab1" id="showTab1" data-toggle="tab">@lang('frontend.my_info')</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-8 padd_0">
                <div class="tab-content">
                	<div class="profile_right_info_sec">
                    	<div id="tab1" class="tab-pane fade in active">
	                        <div class="info_edit_col">
	                            <div class="col-md-3">
	                                <label>@lang('frontend.name') :</label>
	                            </div>
	                            <div class="col-md-6">
	                                <input type="text" class="form-control" value="{{ $user->name }}" readonly>
	                            </div>
	                            <div class="col-md-3">
	                                <a href="{{ url('user/edit/name/'.$user->id) }}" class="edit_info_button">@lang('frontend.edit')</a>
	                            </div>
	                        </div>
	                        
	                        <div class="info_edit_col">
	                            <div class="col-md-3">
	                                <label>@lang('frontend.email') :</label>
	                            </div>
	                            <div class="col-md-6">
	                                <input type="text" class="form-control" value="{{ $user->email }}" readonly>
	                            </div>
	                            <div class="col-md-3">
	                                <a href="{{ url('user/edit/email/'.$user->id) }}" class="edit_info_button">@lang('frontend.edit')</a>
	                            </div>
	                        </div>
	                        <div class="info_edit_col">
	                            <div class="col-md-3">
	                                <label>@lang('frontend.password') :</label>
	                            </div>
	                            <div class="col-md-6">
	                                <input type="password" class="form-control" value="Test Account" readonly>
	                            </div>
	                            <div class="col-md-3">
	                                <a href="{{ url('user/edit/password/'.$user->id) }}" class="edit_info_button">@lang('frontend.edit')</a>
	                            </div>
	                        </div>
	                        <div class="info_edit_col">
	                            @for($i=1; $i <= 4; $i++)
                                <div class="col-md-2 col-sm-2 col-xs-3 select-avatar @if(!is_null($user->avatar) && $user->avatar == $i) selected @endif" data-image_id="{{ $i }}">
                                <div class="select_avataer_iner">
	                             	<img src="{{ asset('frontend/assets/images/avatar/'.$i.'.jpg') }}">
                                <div class="selectd_tick">
                                    <i class="far fa-check-circle"></i>
                                </div>
                                </div>
	                            </div>	
							    @endfor
	                        </div>
	                	</div>
                	</div>
                </div>
            </div>
        </div>
    </div>
    <form method="post" action="{{ route('update.profile') }}" name="frm" id="frm">{{ csrf_field() }}
  		<input type="hidden" value="image_id" name="field">
  		<input type="hidden" name="image_id" id="image_id" value="">
  		<input type="hidden" name="user_id" value="{{ $user->id }}">
    </form>
@endsection
@section('script')
<script type="text/javascript">
	$(document).on('click','.select-avatar', function(){
		var image_id = $(this).attr("data-image_id");
		$("#image_id").val(image_id);
		$("#frm").submit();
	});
</script>
@endsection