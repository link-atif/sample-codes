@extends('frontend.frontend')
<style type="text/css">
  .landing_page_bg{
    float: left;
    margin: 0px;
    padding: 0px;
    width: 100%;
    height: 100vh;
    background: url('{{ asset('frontend/assets/images/black.jpeg') }}') 0px 0px no-repeat;
    background-size: 100% 100%;
  }
</style>

@section('content')
    <div class="landing_page_bg">
           <!--header-->
           @include('frontend.components.slim_header')
           <!--header-->
           <div class="landing_banner_text">
               <div class="container">
                   <h2>{{ $page->title }}</h2>
                   @php 
                    $out = strlen($page->content) > 300 ? substr($page->content,0,330)."..." : $page->content;
                   @endphp
                    <p style="font-size:16px;" class="less">{!! $out; !!}</p>
                    <p style="font-size:16px; display: none;" class="full">{!! $page->content; !!}</p>
                    <a class="lanfing_signup less" href="javascript:;" onclick="readMore();" style="float: right;">@lang('frontend.read_more')</a>
                    <a class="lanfing_signup full" href="javascript:;" onclick="readLess();" style="display: none; float: right;">@lang('frontend.read_less')</a>
               </div>
           </div>
       </div>
@endsection
@section('script')
<script type="text/javascript">
  function readMore(){
    $(".less").hide();
    $(".full").show();
  }

  function readLess(){
    $(".full").hide();
    $(".less").show();
  }
</script>
@endsection