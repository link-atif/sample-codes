@extends('frontend.frontend')
<style type="text/css">
  .landing_page_bg{
    float: left;
    margin: 0px;
    padding: 0px;
    width: 100%;
    background: url('{{ thumb($image) }}') 0px 0px no-repeat;
    height: 100vh;
    background-size: 100% 100%;
  }
    
    
    .footer_main{position: absolute; padding: 25px 0 20px 0px !important; bottom: 0;}
    .privacy_section{margin: 20px 0 0 0px !important;}
    
</style>
@section('content')
    <div class="landing_page_bg">
           <!--header-->
           @include('frontend.components.slim_header')
           <!--header-->
           <div class="landing_banner_text">
               <div class="container">
                   <h2>@lang('frontend.landing_heading')<br>@lang('frontend.landing_heading2')</h2>
                   <p>@lang('frontend.landing_slug')</p>
                   <a class="lanfing_signup" href="{{ url('/register') }}">@lang('frontend.signup')</a>
               </div>
           </div>
       </div>
@endsection
