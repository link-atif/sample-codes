@extends('frontend.frontend')
@section('content')
	<div class="profile_tabs_section" style="color:#fff">
        @if (Session::has('flash_message'))
		    <div class="alert alert-success alert-block fade in">
		        <button data-dismiss="alert" class="close close-sm" type="button">
		            <i class="fa fa-times"></i>
		        </button>
		        <p>{{ Session::get('flash_message') }}</p>
		    </div>
		@endif
        <div class="container">
            <div class="col-md-2 padd_0">
            </div>
            <div class="col-md-8 padd_0">
                <div class="tab-content">
                	<div class="profile_right_info_sec who_is_watching" style="min-height: 200px;">
                    	<div class="tab-pane fade in active">
	                        <h2 style="color: #ffffff; text-align: center;">Who's Watching?</h2>
	                        <div class="info_edit_col">
                                <a href="{{ route('home') }}">
	                                <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="select_avataer_iner">
	                                		@if($user->avatar =="")
		                             		<img src="{{ asset('frontend/assets/images/p_1.jpg') }}">
	                                		@endif
	                                		@if($user->avatar !="")
	                                		<img src="{{ asset('frontend/assets/images/avatar/'.$user->avatar.'.jpg') }}" height="105px">
	                                		@endif
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">{{ $user->name }}</h5>
	                                	</div>
		                            </div>
		                        </a>
		                        <a href="{{ route('kidSection') }}">
	                                <div class="col-md-2 col-sm-2 col-xs-3">
	                                	<div class="select_avataer_iner">
		                             		<img src="{{ asset('frontend/assets/images/kids.jpg') }}">
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">Kids</h5>
	                                	</div>
		                            </div>
		                        </a>
	                        </div>
                    	</div>
                	</div>
                </div>
            </div>
           	<div class="col-md-2 padd_0">
           	</div>
        </div>
    </div>
@endsection