<!DOCTYPE html>
<html>
    <head>
        <title>{{ $title }}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="//fonts.googleapis.com/icon?family=Material+Icons">
        <link rel="stylesheet" href="{{ asset('frontend/assets/css/app.css') }}">
    </head>
    <body class="register">
        @yield('content')
        <script src="{{ asset('frontend/assets/js/app.js') }}"></script>
    </body>
</html>
