@extends('frontend.frontend')

@section('content')
@include('frontend.components.navbar')
<div class="container">
	<br><br><br><br><br>

	@if(count($moviesSlug) > 0)
		<h3 style="color: white;">{{ $genreSlug->title }}</h3>
		@include('frontend.components.grid-items', array('items'=>$moviesSlug))
	@endif
	@if(count($showsSlug) > 0)
		<h3 style="color: white;">{{ $genreSlug->title }}</h3>
		@include('frontend.components.grid-items', array('items'=>$showsSlug))
	@endif
</div>
@endsection