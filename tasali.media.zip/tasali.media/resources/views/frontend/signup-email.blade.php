<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.welcome-main{
			background: url('{{ $message->embed(asset("images/background.jpg")) }}');
			background-size: cover;
			background-repeat: no-repeat;
			margin: 0px auto;
		}

		.logo{
			width: 290px;
			height: auto;
			margin-top: 320px;
			margin-bottom: 68px;
		}

		.welcome-text{
			line-height: 55px;
			color: #fffffe;
		}

		.welcome-text h1{
			font-size: 45px;
			font-family: ProximaNova Semibold;
			margin-bottom: 40px;
			color: #e8ce80;
		}

		.welcome-text h5{
			font-size: 30px;
			font-family: ProximaNova Regular;
			margin-bottom: 40px;
		}

		.welcome-text p{
			font-size: 30px;
			font-family: ProximaNova Regular;
		}


		.login .button{
			padding: 5px 32px;
			background-image: linear-gradient(to right, rgba(199,144,54,1), rgba(252,244,162,1));
			font-size: 40px;
			color: #1a1714;
			font-family: ProximaNova Semibold;
			text-decoration: none;
			border-radius: 5px;
		}

		.btn-bottom-text h1{
			font-size: 68px;
			color: #e8ce80;
		}

		.footer-logo{
			width: 174px;
			height: auto;
		}

		.f-text{
			line-height: 100px;
			color: #e7ca7c;
			font-family: ProximaNova Semibold;
		}
	</style>
</head>
<body>
	<div class="welcome-main" style="width: 100%;">
		<table style="width: 840px; margin: 0px auto" cellspacing="0" cellpadding="0" border="0">
			<tr style="text-align: center;">
				<td style="width: 100%;"><img src="{{ $message->embed(asset('images/logo.png')) }}" class="logo"></td>
			</tr>
			<tr class="welcome-text" style="width: 100%; text-align: left;">
				<td>
					<tr>
						<td><h1 style="color: #e8ce80;">Hi <span id="name"> {{ $name }},</span></h1></td>
					</tr>
					<tr>
						<td><h5 style="color: #d6d5d5; font-size: 30px;">Welcome to Tasali! </h5></td>
					</tr>
					<tr>
						<td>
							<tr>
								<td>
									<p style="color: #d6d5d5; font-size: 30px;">Enjoy unlimited Arabic content from around the Middle East and North Africa. At Tasali, we want our customers to always be satisfied, and that is why you are welcome to have a two week free trial to make sure that Tasali is right for you! Even after the trial period ends, if you change your mind, you can cancel anytime and there are no hidden fees. We believe that we should deliver on our promises, and so when we say “unlimited access” we really mean it! There are no films or shows that you will need to pay extra to view. As soon as you sign up, you will have access to every single film and show that we are proud to offer. We also want you to take Tasali with you wherever you go, so each subscription will be available on two devices. Payment will be taken automatically each month, once your two week trial period is complete. Depending on where you live, payment will be taken in your local currency as follows.</p>
									<p style="color: #d6d5d5; font-size: 30px; text-align: center;">Monthly subscriptions:<br> 
									The United Kingdom: £7.00 <br>
									The United States: $10.00 <br>
									European Union:  7.00 EURO <br>
									Canada: 12.00 CAD <br>
									Australia: 12.00 AUD <br>
									</p>
								</td>
							</tr>
							<tr>
								<td>
									<p style="color: #d6d5d5; font-size: 30px;">We hope you enjoy our service and we look forward to seeing you soon! </p>
								</td>
							</tr>
						</td>
					</tr>
				</td>
			</tr>
			<tr>
        		<td style="font-size: 1px; height: 80px; line-height: 60px; mso-line-height-rule: exactly;" valign="top" align="left">&nbsp;</td>
      		</tr>
			<tr class="welcome-text">
				<td>
					<tr style="width: 100%;">
						<td><h1 style="color: #e8ce80;text-align: right;" dir="rtl" lang="ar">مرحبا <span id="name"> {{ $name }}،</span></h1></td>
					</tr>
					<tr style="width: 100%;">
						<td><h5 style="color: #d6d5d5;text-align: right; font-size: 30px;" dir="rtl" lang="ar">مرحبا بكم في تسالي!</h5></td>
					</tr>
					<tr style="width: 100%;">
						<td><p style="color: #d6d5d5;text-align: right; font-size: 30px;" dir="rtl" lang="ar">استمتع بمحتوى عربي غير محدود من جميع أنحاء الشرق الأوسط وشمال إفريقيا.
 في تسالي ، نريد أن يشعر عملاؤنا بالرضا دائمًا ، ولهذا السبب نرحب بك للحصول على نسخة تجريبية مجانية لمدة أسبوعين للتأكد من أن تسالي تناسبك! حتى بعد انتهاء الفترة التجريبية ، إذا غيرت رأيك ، يمكنك الإلغاء في أي وقت ولا توجد رسوم خفية. نعتقد أنه يجب علينا الوفاء بوعودنا ، ولذا عندما نقول "الوصول غير المحدود" فإننا نعني ذلك حقًا! لا توجد أفلام أو عروض تحتاج إلى دفع رسوم إضافية لمشاهدتها. بمجرد التسجيل بتسالي ، ستتمكن من الوصول إلى كل محتوي نحن فخورون بتقديمه. نريدك أيضًا أن تأخذ تسالي معك أينما ذهبت ، لذلك سيكون كل اشتراك متاحًا للوصول على جهازين. و سيتم تحصيل الدفعة تلقائيًا كل شهر ، بمجرد اكتمال الفترة التجريبية التي تبلغ مدتها أسبوعين. اعتمادًا على المكان الذي تعيش فيه ، سيتم تحصيل المدفوعات بعملتك المحلية على النحو التالي.</p>
<p style="color: #d6d5d5; text-align: center; font-size: 30px;" dir="rtl" lang="ar">
	الاشتراكات الشهرية:
<br>المملكة المتحدة: ٧ جنيهات إسترلينية.
<br>الولايات المتحدة: ١٠ دولارات امريكية.
<br>الاتحاد الأوروبي: ٧ يورو. 
<br>كندا: ١٢ دولار كندي.
<br>

</p>
</td>
					</tr>
					
					<tr style="width: 100%;">
						<td><p style="color: #d6d5d5;text-align: right; font-size: 30px;" dir="rtl" lang="ar">نأمل أن تستمتع بخدماتنا ونتطلع إلى رؤيتك قريبًا!</p></td>
					</tr>
				</td>
			</tr>
			<tr class="btn-bottom-text" style="width: 100%;text-align: center;">
				<td><h1 dir="rtl" lang="ar">تسالي .. بيتك في بلدك الثاني</h1></td>
			</tr>
			<tr class="w-footer" style="width: 100%">
				<td style="width: 50%; float: left; text-align: left;">
					<img src="{{ $message->embed(asset('images/logo.png')) }}" class="footer-logo">
				</td>
				<td class="f-text" style="width: 50%; float: left; text-align: right;">All rights reserved &#169; <span>Tasali Media 2021</span></td>
			</tr>
			<tr>
        		<td style="font-size: 1px; height: 80px; line-height: 60px; mso-line-height-rule: exactly;" valign="top" align="left">&nbsp;</td>
      		</tr>
		</table>
	</div>
</body>
</html>