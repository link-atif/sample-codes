@extends('frontend.frontend')

@section('content')
@include('frontend.components.navbar')
@include('frontend.components.header-movie', 
	['data' => $show, 'type' => 'show', 'firstId' => isset($show->episodes->first()->id) ?? $show->episodes->first()->id]
)

<div class="bg_gradient_strip"></div>
<div class="tabs_section_outer">
    <div class="container padd_0">
	  	<ul class="nav nav-tabs">
	    	<li class="active"><a data-toggle="tab" href="#tab1">@lang('frontend.episodes')</a></li>
	    	<li><a data-toggle="tab" href="#tab2">@lang('frontend.about_the_show')</a></li>
	  	</ul>
	    <div class="tab-content">
        	<div id="tab1" class="tab-pane fade in active">
          		@if(!empty($show->episodes))
					@include('frontend.components.videos-list', ['episodes' => $show->episodes, 'paused_episodes' => $paused_episodes])
				@endif
        	</div>
        	<div id="tab2" class="tab-pane fade">
          		<p>{{ $show->desc }}</p>
          		<p>@lang('frontend.publish_date'): {{ Carbon\Carbon::parse($show->publish_date)->format('d F Y') }}</p>
          		<p>@lang('frontend.production_country'): {{ $show->publish_country }}</p>
            	<div class="tabs_cast">
                	<h4>@lang('frontend.cast')</h4>
                	<div class="row padd_cus">
                		@foreach($show->casts as $m)
                		<div class="col-xs-4 col-md-2 padd_0">
	                        <div class="cast_col">
	                            <a href="{{ route('related',$m->id) }}">
		                            <img src="{{ thumb($m->poster, 'thumb') }}" alt="">
		                            <h6>{{ $m->name }}</h6>
	                            </a>
	                        </div>
	                    </div>
	                   	@endforeach
                	</div>
            	</div>
        	</div>
	    </div>
   	</div>
</div>

@endsection
