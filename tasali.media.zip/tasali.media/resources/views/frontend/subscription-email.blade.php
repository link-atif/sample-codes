<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.welcome-main{
			background: url('{{ $message->embed(asset("images/background.jpg")) }}');
			background-size: cover;
			background-repeat: no-repeat;
			margin: 0px auto;
		}

		.logo{
			width: 290px;
			height: auto;
			margin-top: 320px;
			margin-bottom: 68px;
		}

		.welcome-text{
			line-height: 55px;
			color: #fffffe;
		}

		.welcome-text h1{
			font-size: 45px;
			font-family: ProximaNova Semibold;
			margin-bottom: 40px;
			color: #e8ce80;
		}

		.welcome-text h5{
			font-size: 30px;
			font-family: ProximaNova Regular;
			margin-bottom: 40px;
		}

		.welcome-text p{
			font-size: 30px;
			font-family: ProximaNova Regular;
		}

		.start-watch .button{
			padding: 42px 52px;
			background-image: linear-gradient(to right, rgba(199,144,54,1), rgba(252,244,162,1));
			font-size: 40px;
			color: #1a1714;
			font-family: ProximaNova Semibold;
			text-decoration: none;
			border-radius: 5px;
		}

		.btn-bottom-text h1{
			font-size: 68px;
			color: #e8ce80;
		}

		.footer-logo{
			width: 174px;
			height: auto;
		}

		.f-text{
			line-height: 100px;
			color: #e7ca7c;
			font-family: ProximaNova Semibold;
		}
	</style>
</head>
<body>
	<div class="welcome-main" style="width: 100%;">
		<table style="width: 840px; margin: 0px auto" cellspacing="0" cellpadding="0" border="0">
			<tr style="text-align: center;">
				<td style="width: 100%;"><img src="{{ $message->embed(asset('images/logo.png')) }}" class="logo"></td>
			</tr>
			<tr class="welcome-text" style="width: 100%; text-align: left; padding-left: 20px;">
				<td>
					<tr>
						<td><h1 style="color: #e8ce80;">Hi <span id="name">"{{ $name }}",</span></h1></td>
					</tr>
					<tr>
						<td><h5 style="color: #fffffe;">Welcome to Tasali!</h5></td>
					</tr>
					<tr>
						<td><p style="color: #fffffe;">Your subscription has been successfully completed. Your next payment ({{ $next_date }}) will be taken by direct debit one month from today and every month thereafter. To make things easier for you, once our launch offer has expired your monthly subscription price will change automatically to the amount stated on our website, based on your local currency.  All you have to do is sit back, relax, and enjoy the many films and Arabic content we offer. We hope you enjoy our service and look forward to seeing you soon! </p></td>
					</tr>
				</td>
			</tr>
			<tr>
        		<td style="font-size: 1px; height: 80px; line-height: 60px; mso-line-height-rule: exactly;" valign="top" align="left">&nbsp;</td>
      		</tr>
			<tr class="welcome-text" style="padding-right: 20px;">
				<td>
					<tr style="width: 100%;">
						<td><h1 style="color: #e8ce80;text-align: right;" dir="rtl" lang="ar">مرحبا <span id="name">"{{ $name }}"،</span></h1></td>
					</tr>
					<tr style="width: 100%;">
						<td><h5 style="color: #fffffe;text-align: right;" dir="rtl" lang="ar">اهلا بكم في تسالي</h5></td>
					</tr>		
					<tr style="width: 100%;">
						<td><p style="color: #fffffe;text-align: right;" dir="rtl" lang="ar">تم الانتهاء من اشتراكك بنجاح. سيتم أخذ دفعتك التالية ({{ $next_date }}) عن طريق الخصم المباشر بعد شهر واحد من اليوم. لتسهيل الأمور عليك ، بمجرد انتهاء عرض الانطلاق الخاص بنا ، سيتغير سعر اشتراكك الشهري تلقائيًا إلى المبلغ المذكور على موقعنا الإلكتروني، بناءً على عملتك المحلية.  كل ما عليك فعله هو الجلوس والاسترخاء والاستمتاع بالعديد من الأفلام والمحتوى العربي الذي نقدمه.  نأمل أن تستمتع بخدمتنا ونتطلع إلى رؤيتك قريبًا!</p></td>
					</tr>
				</td>
			</tr>
			<tr>
        		<td style="font-size: 1px; height: 135px; line-height: 118px; mso-line-height-rule: exactly;" valign="top" align="left">&nbsp;</td>
      		</tr>
			<tr class="start-watch" style="width: 100%;text-align: center;">
				<td><a href="https://tasali.media/login" class="button"><img src="{{ $message->embed(asset('images/play-botton.png')) }}" style=" margin-top: -7px"> Start Watching</a></td>
			</tr>
			<tr>
        		<td style="font-size: 1px; height: 135px; line-height: 118px; mso-line-height-rule: exactly;" valign="top" align="left">&nbsp;</td>
      		</tr>
			<tr class="btn-bottom-text" style="width: 100%;text-align: center;">
				<td><h1 dir="rtl" lang="ar">تسالي .. بيتك في بلدك الثان</h1></td>
			</tr>
			<tr class="w-footer" style="width: 100%">
				<td style="width: 50%; float: left; text-align: left; padding-left: 20px;">
					<img src="{{ $message->embed(asset('images/logo.png')) }}" class="footer-logo">
				</td>
				<td class="f-text" style="width: 50%; float: left; text-align: right; padding-right: 20px;">All rights reserved &#169; <span>Tasali Media 2021</span></td>
			</tr>	
			<tr>
        		<td style="font-size: 1px; height: 80px; line-height: 60px; mso-line-height-rule: exactly;" valign="top" align="left">&nbsp;</td>
      		</tr>
		</table>
	</div>
</body>
</html>