<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="Home">
      <meta name="author" content="Pioneer">
      <!--<link rel="shortcut icon" href="assets/images/favicon.ico">-->
      <title>{{ websiteTitle() }}</title>
      <!-- Applying Css-->
      <link href="{{ asset('frontend/assets/css/bootstrap.min.css') }}" rel="stylesheet">
      <link href="{{ asset('frontend/assets/fonts/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css" />
      <link href="{{ asset('frontend/assets/css/style.css') }}" rel="stylesheet" />
      <link href="{{ asset('frontend/assets/css/responsive.css') }}" rel="stylesheet">
      <link href="{{ asset('frontend/assets/css/owl.carousel.css') }}" rel="stylesheet">
      <!--fonts-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--css file end-->
      
   </head>
<body>
    <div class="content">
        @yield('content')
    </div>
    
    <!--footer-->
    @include('frontend.components.footer')


    <!--Scripts-->

    <!-- *** ST:Production only *** -->
    <!-- <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script> -->
    <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.1/js/materialize.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/3.4.2/js/swiper.jquery.min.js"></script> -->
    <!-- *** ED:Production only *** -->
    <script src="{{ asset('frontend/assets/js/jquery.min.js') }}"></script>
    <script src="{{ asset('frontend/assets/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('frontend/assets/js/materialize.js') }}"></script>
    <script src="{{ asset('frontend/assets/js/owl.carousel.js') }}"></script>    
    <script src="{{ asset('frontend/assets/jwplayer-8.2.3/jwplayer.flash.swf') }}"></script>
    <script src="{{ asset('frontend/assets/jwplayer-8.2.3/jwplayer.js') }}"></script>
    <script>
      jwplayer.key="{{ env('JW_KEY_8') }}";
    </script>
    <script type="text/javascript" src="{{ asset('frontend/assets/js/app.js') }}"></script>
    <!--Errors-->
    @if (count($errors) > 0)
    <script>
        @foreach ($errors->all() as $error)
            Materialize.toast('{{ $error }}', 4000,'red darken-4')
        @endforeach
    </script>
    @endif
    <script>
        $(document).ready(function() {
            var owl = $("#owl-demo14");
            owl.owlCarousel({
                itemsCustom: [
                    [0, 1],
                    [450, 1],
                    [600, 1],
                    [700, 1],
                    [1000, 1],
                    [1200, 1],
                    [1400, 1],
                    [1600, 1]
                ],
                navigation: true,
                autoPlay: false,
                rtl: true
            });
        });
    </script>
       <?php
        if(\Auth::check()){
        $genresId = "";
        if(isset($genres)){
          foreach($genres as $genre){
              $genresId .= "#".$genre->slug.",";
          }
          $genreId = trim($genresId, ', ');
      ?>
       <script>
        $(document).ready(function() {
          var genresId = '{{ $genreId }}';
            var owl = $("#trending, #recent, #cast, #shows, "+genresId);
            owl.owlCarousel({
                itemsCustom: [
                    [0, 1],
                    [450, 1],
                    [600, 3],
                    [700, 3],
                    [1000, 4],
                    [1200, 6],
                    [1400, 6],
                    [1600, 6]
                ],
                navigation: true,
                autoPlay: 4000,
                rtl: true
            });
        });
    </script>
  <?php } }?>
       <script>
         $(".play1").click(function(){
           $(".play1").addClass("hide");
             
             $(".stop1").removeClass("hide");
         
         });
         
         $(".stop1").click(function(){
           $(".stop1").addClass("hide");
            
            $(".play1").removeClass("hide");
         
         });
      </script>
    <!--Page custom scripts-->
    @yield('script')
</body>

</html>