@extends('frontend.frontend')
<style>
	@media only screen and (min-width: 1025px){
.profile_tabs_section{
	margin-top: 100px;
	}
}

@media only screen and (min-width: 769px) and (max-width: 1024px){
.profile_tabs_section{
	margin-top: 100px;
	margin-bottom: 100px;

	}
}

@media only screen and (min-width:768px){
.profile_tabs_section{
	margin-top: 100px;
	}
}

@media only screen and (min-width:600px) and (max-width:768px){
.who_is_watching {
    	margin-bottom: 120px;
	}
}

@media only screen and (min-width:425px) and (max-width:767px){
.profile_tabs_section{margin: 140px 0 100px;}

}

@media only screen and (min-width:380px) and (max-width:424px){
.profile_tabs_section{margin: 100px 0 100px;}

}


@media only screen and (min-width: 374px) and (max-width: 375px){
.profile_tabs_section {
    margin: 55px 0 54px;
}
.pro_tab_sec{
    margin: 83px 0 83px;
}
}

@media only screen and (max-width: 320px){
.profile_tabs_section {
    margin: 100px 0 100px;
}
}
</style>
@section('content')

	<div class="profile_tabs_section pro_tab_sec" style="color:#fff">
        @if (Session::has('flash_message'))
		    <div class="alert alert-success alert-block fade in">
		        <button data-dismiss="alert" class="close close-sm" type="button">
		            <i class="fa fa-times"></i>
		        </button>
		        <p>{{ Session::get('flash_message') }}</p>
		    </div>
		@endif
        <div class="container">
            <div class="col-md-2 padd_0">
            </div>
            <div class="col-md-8 padd-top-40 padd_0">
                                	<div class="profile_right_info_sec who_is_watching" style="min-height: 200px;">
                    	<div class="tab-pane fade in active">
	                        <h2 style="color: #ffffff; text-align: center;">@lang('frontend.who_is_watching')</h2>
	                        <div class="info_edit_col infoedit_col">

				<div class="col-md-2 col-sm-2 col-xs-3 ">
                                <a href="{{ route('home') }}">
	                                
	                                	<div class="select_avataer_iner">
	                                		@if($user->avatar =="")
		                             		<img src="{{ asset('frontend/assets/images/avater.jpg') }}">
	                                		@endif
	                                		@if($user->avatar !="")
	                                		<img src="{{ asset('frontend/assets/images/avatar/'.$user->avatar.'.jpg') }}">
	                                		@endif
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">{{ $user->name }}</h5>
	                                	</div>
		                           
		                        </a>
					 </div>
					
					<div class="col-md-2 col-sm-2 col-xs-3">
		                        <a href="{{ route('kidSection') }}">
	                                
	                                	<div class="select_avataer_iner">
		                             		<img src="{{ asset('frontend/assets/images/kids.jpg') }}">
	                                	</div>
	                                	<div>
	                                		<h5 style="color: #FFFFFF; text-align: center;">@lang('frontend.kids')</h5>
	                                	</div>
		                           
		                        </a>
					 </div>
	                        </div>
                    	</div>
                	</div>
                           </div>
           	<div class="col-md-2 padd_0">
           	</div>
        </div>
    </div>
@endsection
@section('script')
<script>
$(document).ready(function(){
$( "#footer" ).addClass( "fixed-footer" );  
});
</script>
@endsection