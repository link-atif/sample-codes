<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.welcome-main{
			background: url('{{ $message->embed(asset("images/background.jpg")) }}');
			background-size: cover;
			background-repeat: no-repeat;
			margin: 0px auto;
		}

		.logo{
			width: 290px;
			height: auto;
			margin-top: 320px;
			margin-bottom: 68px;
		}

		.welcome-text{
			line-height: 55px;
			color: #ffffff;
		}

		.welcome-text h1{
			font-size: 15px;
			font-family: ProximaNova Semibold;
			margin-bottom: 40px;
			color: #e8ce80;
		}

		.welcome-text h5{
			font-size: 15px;
			font-family: ProximaNova Regular;
			margin-bottom: 40px;
		}

		.welcome-text p{
			font-size: 15px;
			font-family: ProximaNova Regular;
		}


		.login .button{
			padding: 5px 32px;
			background-image: linear-gradient(to right, rgba(199,144,54,1), rgba(252,244,162,1));
			font-size: 40px;
			color: #1a1714;
			font-family: ProximaNova Semibold;
			text-decoration: none;
			border-radius: 5px;
		}

		.btn-bottom-text h1{
			font-size: 68px;
			color: #e8ce80;
		}

		.footer-logo{
			width: 174px;
			height: auto;
		}

		.f-text{
			line-height: 100px;
			color: #e7ca7c;
			font-family: ProximaNova Semibold;
		}
	</style>
</head>
<body>

	<div class="welcome-main" style="width: 100%;">
		<table style="width: 840px; margin: 0px auto;" cellspacing="0" cellpadding="0" border="0">
			<tr class="welcome-text">
				<td>
					<tr>
						<td style="width: 100%;">
							<p style="color: #d6d5d5;text-align: right; font-size: 15px; margin-top: 320px;" dir="rtl" lang="ar">نشكركم على اهتمامكم الأخير بتسالي. لم يسعنا إلا أن نلاحظ أنكم لم تكملوا عملية الاشتراك ، وأردنا الاتصال بكم لمعرفة ما إذا كان بإمكاننا تقديم أي مساعدة في عملية على الاشتراك. يمكنك إكمال اشتراكك باتباع هذا الرابط (https://tasali.media/register).
							</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">نود أيضًا إعلامكم بأننا لن نتقاضى أي دفعة مالية حتى تكتمل الفترة التجريبية المجانية التي تبلغ أسبوعين.
يمكنكم الإلغاء في أي وقت قبل الأسبوعين ، ولن يتم تحصيل أي رسوم منكم. </p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">من أجل ضمان أعلى درجات الأمان لعملائنا ، فنحن لا نحتفظ بأي تفاصيل خاصة ببطاقة الائتمان أو البنوك في قاعدة بياناتنا.</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">نتمنى أن نراكم مرة أخرى قريبًا ، ونتطلع إلى الترحيب بكم في تسالي!</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">أطيب التحيات،</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">فريق تسالي</p>
						</td>
					</tr>
				</td>
			</tr>
			<tr class="welcome-text" style="width: 100%; text-align: left;">
				<td>
					<tr>
						<td style="width: 100%;">
							<p style="color: #d6d5d5; font-size: 15px;">Thank you for your recent interest in Tasali. We couldn’t help but notice that you did not complete the sign-up process, and we wanted to get in touch to see if we can be of any assistance in helping you to subscribe. You can complete your subscription by following this link (https://tasali.media/register). </p>
							<p style="color: #d6d5d5; font-size: 15px;">We would also like to inform you that we will not be taking any payment until your two-week free trial period is completed. You can cancel any time before the two weeks, and you will not be charged. In order to ensure the highest degree of security for our customers, we do not hold any credit card or banking details in our database. </p>
							<p style="color: #d6d5d5; font-size: 15px;">We hope to see you again soon, and we look forward to welcoming you to Tasali! </p>
							<p style="color: #d6d5d5; font-size: 15px;">Kindest regards,</p>
							<p style="color: #d6d5d5; font-size: 15px;">The Tasali Team </p>
							<p style="color: #d6d5d5; font-size: 15px;">Your opinion matters to us, please take a moment to complete the following survey about your recent experience with Tasali.</p>
						</td>
					</tr>
				</td>
			</tr>
			<tr class="welcome-text">
				<td>
					<tr>
						<td style="width: 100%;">
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">رأيك يهمنا ، برجاء إكمال الاستبيان التالي حول تجربتك الأخيرة مع تسالي</p>
						</td>
					</tr>
				</td>
			</tr>
		</table>
		<table style="table-layout: fixed; width: 840px; margin: 0px auto;" cellspacing="0" cellpadding="0" border="0">
			<tr class="welcome-text">
				<td>
					<tr style="width: 100%">
						<td style="width: 50%">
							<p style="color: #d6d5d5; font-size: 15px;">What is the reason you didn’t subscribe (Kindly select only one)</p>
							<p style="color: #d6d5d5; font-size: 15px;">- Our content didn’t suit you <br>
																		- Our price is high<br> 
																		- You changed your mind<br> 
																		- You didn’t find what you're looking for
							</p>
							<p style="color: #d6d5d5; font-size: 15px;">Kindly Rate our website</p>
							<p style="color: #d6d5d5; font-size: 15px;">1   2   3   4   5 </p>
							<p style="color: #d6d5d5; font-size: 15px;">Kindly Rate our website content</p>
							<p style="color: #d6d5d5; font-size: 15px;">1    2    3    4    5 </p> 
							<p style="color: #d6d5d5; font-size: 15px;">Have you heard about us before</p>
							<p style="color: #d6d5d5; font-size: 15px;">Yes   No <br>
																		If yes<br>  
																		- Facebook<br> 
																		-Instagram<br> 
																		-Google <br>
																		-Referral
							</p>
							<p style="color: #d6d5d5; font-size: 15px;">Will you come back later?</p>
							<p style="color: #d6d5d5; font-size: 15px;">
								- Yes, if I find the content that I like <br>
								- Yes, later <br>
								- No, I don’t like your content<br> 
								- No, I changed my mind <br>
								- No, your price is high 

							</p>
						</td>
						<td style="width: 50%">
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">ما سبب عدم اشتراكك (يرجى اختيار واحد فقط)</p>
							<p style="color: #d6d5d5; text-align: right; font-size: 15px;" dir="rtl" lang="ar">- المحتوى الخاص بنا لا يناسبك
								<br>- سعرنا مرتفع
								<br>- لقد غيرت تفكيرك
								<br>- لم تجد ما تبحث عنه
							</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">يرجى تقييم موقعنا على شبكة الإنترنت</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">1 2 3 4 5</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">يرجى تقييم محتوى موقعنا</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">1 2 3 4 5</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">هل سمعت عنا من قبل</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">نعم / لا
<br>اذا نعم
<br>- موقع التواصل الاجتماعي الفيسبوك
<br>-انستغرام
<br>-جوجل
<br>- ترشيح من شخص</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">هل ستعود لاحقا؟</p>
							<p style="color: #d6d5d5;text-align: right; font-size: 15px;" dir="rtl" lang="ar">- نعم ، إذا وجدت المحتوى الذي يعجبني
<br>- نعم لاحقا
<br>- لا ، أنا لا أحب المحتوى الخاص بك
<br>- لا ، لقد غيرت رأيي
 <br>- لا ، سعرك مرتفع</p>
						</td>

					</tr>
				</td>
			</tr>
			<tr>
        		<td style="font-size: 1px; height: 80px; line-height: 60px; mso-line-height-rule: exactly;" valign="top" align="left">&nbsp;</td>
      		</tr>
			<tr class="w-footer" style="width: 100%">
				<td style="width: 50%;">
					<img src="{{ $message->embed(asset('images/logo.png')) }}" class="footer-logo">
				</td>
				<td class="f-text" style="width: 50%; text-align: right;">All rights reserved &#169; <span>Tasali Media 2021</span></td>
			</tr>
			<tr>
        		<td style="font-size: 1px; height: 80px; line-height: 60px; mso-line-height-rule: exactly;" valign="top" align="left">&nbsp;</td>
      		</tr>
		</table>
	</div>
</body>
</html>