@extends('frontend.frontend')

@section('content')
@include('frontend.components.navbar')
<div class="container">
	<br><br><br><br><br>
	@php $kid = request()->session()->get('kid'); @endphp
	<h5 class="header white-text">@lang('frontend.movies')</h5>
	<div class="row">
	@if(count($movies) > 0)
		@foreach ($movies as $item)
			@if($kid == $item->is_kid)
			<div class="col-xs-4 col-md-2" style="margin-top: 10px; margin-bottom: 7px;">
		        <div class="item">
		          	<div class="movie_col_inner">
				        <a href="{{ route('single.movie',$item->slug) }}">
				            <img src="{{ thumb($item->poster, 'thumb') }}" alt="{{ $item->title }}">
				            <div class="overlay_bg"></div>
				            <div class="movie_col_overlay" id="item-cast-{{ $item->id }}">
				                <a href="{{ route('single.movie',$item->slug) }}" class="btn_overlay active">
				                  <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
				                    <path d="M7.38906 5.85312L0.379025 1.01861C0.304816 0.967609 0.208609 0.962291 0.129323 1.00363C0.0497954 1.04544 0 1.12763 0 1.21755V10.8866C0 10.9765 0.0497954 11.0589 0.129323 11.1007C0.164615 11.1191 0.203291 11.1283 0.241725 11.1283C0.289829 11.1283 0.33769 11.1138 0.379025 11.0855L7.38906 6.251C7.45457 6.2058 7.49348 6.13159 7.49348 6.05206C7.49348 5.97253 7.45432 5.89832 7.38906 5.85312Z" fill="white"/>
				                  </svg> 
				                  <span>@lang('frontend.watch')</span>
				                </a>
				                @php 
									$favoriteMovies = \Auth::user()->followingMovies->pluck('id')->toArray();
									$favoriteShows = \Auth::user()->followingSeries->pluck('id')->toArray();
									$favorites = array_merge($favoriteMovies, $favoriteShows);
								@endphp
								@if(in_array($item->id, $favorites))
									<a class="btn_overlay removeList" href="javascript:" data-type="movie" data-genres="cast" data-id="{{ $item->id }}" data-header="no" id="remove-cast-{{ $item->id }}">
		                  				<i class="fas fa-check"></i> @lang('frontend.remove_from_my_list')
		                			</a>
								@else
									<a class="btn_overlay addToList" href="javascript:" data-type="movie" data-genres="cast" data-id="{{ $item->id }}" data-header="no" id="add-cast-{{ $item->id }}">
		                  				<i class="fas fa-plus"></i> @lang('frontend.add_to_my_list')
		                			</a>
								@endif
				            </div>
				      	</a>
				    </div>
				</div>
	    	</div>
	    	@endif
		@endforeach
	@endif
	</div>	
</div>
@endsection