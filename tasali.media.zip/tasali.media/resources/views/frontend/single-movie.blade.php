@extends('frontend.frontend')

@section('content')
@include('frontend.components.navbar')
@include('frontend.components.header-movie' , ['data' => $movie, 'type' => 'movie'])

<div class="bg_gradient_strip"></div>
<div class="tabs_section_outer">
  <div class="container padd_0">
  	<ul class="nav nav-tabs">
    	<li class="active"><a data-toggle="tab" href="#tab1">@lang('frontend.about')</a></li>
    	<li><a data-toggle="tab" href="#tab2">@lang('frontend.related_movies')</a></li>
  	</ul>
    <div class="tab-content">
    	<div id="tab1" class="tab-pane fade in active">
      		<p>{{ $movie->desc }}</p>
        	<div class="tabs_cast">
            	<h4>@lang('frontend.cast')</h4>
            	<div class="row padd_cus">
            		@foreach($movie->casts as $m)
            		<div class="col-xs-4 col-md-2 padd_0">
                      <div class="cast_col">
                          <a href="{{ route('related',$m->id) }}">
                            <img src="{{ thumb($m->poster, 'thumb') }}" alt="">
                            <h6>{{ $m->name }}</h6>
                          </a>
                      </div>
                  </div>
                 	@endforeach
            	</div>
        	</div>
    	</div>
    	<div id="tab2" class="tab-pane fade">
    		<div class="tabs_cast">
          	<!-- <h4>@lang('frontend.related_movies')</h4> -->
        	<div class="row padd_cus">
        		@foreach($related as $r)
        		<div class="col-xs-4 col-md-2 padd_0" id='{{ $r->id }}'>
                <div class="cast_col">
                  <a href="{{ route('single.movie',$r->slug) }}">
                    <img src="{{ thumb($r->poster, 'thumb') }}" alt="">
                  </a>
                </div>
            </div>
            @endforeach
        	</div>
      	</div>
    	</div>
  	</div>
	</div>
</div>
@endsection