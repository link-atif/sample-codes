@extends('frontend.frontend')

@section('content')
@include('frontend.components.navbar')
<div class="container">
	<br><br><br><br><br>

	<h5 class="header white-text">Shows</h5>
	@include('frontend.components.grid-items', array('items'=>$shows))
	<div class="front-pagination">{{ $shows->links() }}</div>
</div>
@endsection