@extends('frontend.frontend')
@section('content')
	@php
		if(app()->getLocale() == "en"){
		    $cw_title = "Continue Watching";
		    $t_title = "Trending";
		}
		else{
		    $cw_title = 'تابع المشاهدة';
		    $t_title = 'الشائع';
		}
	@endphp
	@include('frontend.components.navbar')
 	@include('frontend.components.header-swiper', ['slider' => $slider])
	<div class="bg_gradient_strip"></div>
	 {{-- @include('frontend.components.general-swiper', ['generalSwiperId' => 'recent', 'generalSwiperName' => 'Recently added', 'gsItems' => $recently]) --}}
	@if(!empty($continue_watching))
	@include('frontend.components.continue-watching', ['generalSwiperId' => 'continueWatching', 'generalSwiperName' => $cw_title, 'gsItems' => $continue_watching])
	@endif
	@include('frontend.components.general-swiper', ['generalSwiperId' => 'trending', 'generalSwiperName' => $t_title, 'gsItems' => $trending])
 	{{-- @include('frontend.components.general-swiper', ['generalSwiperId' => 'coming', 'generalSwiperName' => 'Coming soon', 'gsItems' => $coming]) --}}
	@foreach($genres as $genre)
		@include('frontend.components.general-swiper', ['generalSwiperId' => $genre->slug, 'generalSwiperName' => $genre->title, 'gsItems' => $genre->movies])
	@endforeach
	@foreach($genres as $genre)
		@include('frontend.components.general-swiper', ['generalSwiperId' => $genre->slug, 'generalSwiperName' => $genre->title, 'gsItems' => $genre->shows])
	@endforeach
@endsection

