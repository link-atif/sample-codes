@extends('frontend.frontend')

@section('content')
@include('frontend.components.navbar')

<div class="container">
	<br><br>
	@if (!$movie->isEmpty() || !$series->isEmpty())
		<h3 class="header white-text">@lang('frontend.my_list') {{-- for: {{ $title }} --}}</h3>
		@if (!$movie->isEmpty())
			<h4 class="white-text">@lang('frontend.movies')</h4>
			@include('frontend.components.grid-items', array('items'=>$movie))
		@endif
		@if (!$series->isEmpty())
			<h4 class="white-text">@lang('frontend.series')</h4>
			@include('frontend.components.grid-items', array('items'=>$series))
		@endif
	@else 
		<div class="card-panel red darken-4 white-text center-align">
			<h4>@lang('frontend.nothing_in_list')</h4>
		</div>
	@endif

</div>

@endsection