@extends('frontend.frontend')
<style>
	@media only screen and (min-width: 1025px){
.profile_tabs_section{
	margin-top: 100px;
	}
}

@media only screen and (min-width: 769px) and (max-width: 1024px){
.profile_tabs_section{
	margin-top: 100px;
	margin-bottom: 100px;

	}
}

@media only screen and (min-width:768px){
.profile_tabs_section{
	margin-top: 100px;
	}
}

@media only screen and (min-width:600px) and (max-width:768px){
.who_is_watching {
    	margin-bottom: 120px;
	}
}

@media only screen and (min-width:425px) and (max-width:767px){
.profile_tabs_section{margin: 140px 0 100px;}

}

@media only screen and (min-width:380px) and (max-width:424px){
.profile_tabs_section{margin: 100px 0 100px;}

}


@media only screen and (min-width: 374px) and (max-width: 375px){
.profile_tabs_section {
    margin: 55px 0 54px;
}
.pro_tab_sec{
    margin: 83px 0 83px;
}
}

@media only screen and (max-width: 320px){
.profile_tabs_section {
    margin: 100px 0 100px;
}
}
</style>
@section('content')

	<div class="profile_tabs_section pro_tab_sec" style="color:#fff">
        @if (Session::has('flash_message'))
		    <div class="alert alert-success alert-block fade in">
		        <button data-dismiss="alert" class="close close-sm" type="button">
		            <i class="fa fa-times"></i>
		        </button>
		        <p>{{ Session::get('flash_message') }}</p>
		    </div>
		@endif
        <div class="container">
            <div class="col-md-2 padd_0">
            </div>
            <div class="col-md-8 padd-top-40 padd_0">
                <div class="tab-content">
                	<div class="profile_right_info_sec who_is_watching" style="min-height: 200px;">
                    	<div class="tab-pane fade in active">
	                        <h2 style="color: #ffffff; text-align: center;">DEVICES</h2>
	                        @foreach($devices as $d)
	                        <div class="info_edit_col">
	                            <div class="col-md-3">
	                                <label>Platform : {{ $d->platform }}</label>
	                            </div>
	                            <div class="col-md-3">
	                            	<label>Platform version : {{ $d->platform_version }}</label>
	                            </div>
	                            <div class="col-md-3">
	                            	<label>Browser : {{ $d->browser }}</label>
	                            </div>
	                            <div class="col-md-3">
	                                 <form action="{{ route('delete_device', $d->id) }}" id="delete_device-{{ $d->id }}" method="post">
										{{ method_field('delete') }}
										{{ csrf_field() }}
										<a href="javascript:{}" onclick="document.getElementById('delete_device-'+'{{ $d->id }}').submit();return confirm('Are you sure?')" 
										data-msg="@lang('backend.confirm_delete')" class="mylinks">Delete</a>
									</form>
	                            </div>
	                        </div>
	                        @endforeach
                    	</div>
                	</div>
                </div>
            </div>
           	<div class="col-md-2 padd_0">
           	</div>
        </div>
    </div>
@endsection
@section('script')
<script>
$(document).ready(function(){
$( "#footer" ).addClass( "fixed-footer" );  
});
</script>
@endsection