@extends('frontend.frontend')
<style type="text/css">
	#footer {
		position: unset;
		bottom: 0;
		width: 100%;
	}
</style>
@section('content')
@include('frontend.components.navbar')

<div class="container">
	<br><br><br><br><br>
	@if (!$movies->isEmpty() || !$shows->isEmpty())
		<h3 class="header white-text">@lang('frontend.search_results') {{-- for: {{ $title }} --}}</h3>
		@if (!$movies->isEmpty())
			<h5 class="white-text">@lang('frontend.movies')</h5>
			@include('frontend.components.grid-items', array('items'=>$movies))
		@endif
		@if (!$shows->isEmpty())
			<h5 class="white-text">@lang('frontend.series')</h5>
			@include('frontend.components.grid-items', array('items'=>$shows))
		@endif
	@else 
		<div class="card-panel red darken-4 white-text center-align">
			<h4 style="color:#DDB86C; font-weight: bold; font-size: 30px; margin-top: 70px;">@lang('frontend.nothing_found')</h4>
		</div>
	@endif

</div>

@endsection