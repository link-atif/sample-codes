<div class="banner_main banner_main_2">
  <div class="slider_scrapped">
    <div class="banner_2_sec">
      <img src="{{ thumb($data->image) }}" alt="">
      <div class="banner_main_outer_content">
        <div class="container padd_0">
          <div class="col-md-7 padd_0">
            <div class="slider_bg_tranparent">
              <div class="rating_movie">
                <span class="rating_cont"><i class="fas fa-star"></i>{{ $data->rating_avg }}</span>
                <p>.</p>
            	  <span class="rating_cont">
                  <span class="imdb">IMDb</span>{{ $data->imdb->rate ?? null}}
            	  </span>
              </div>
              <h2>{{ $data->title }}</h2>
              @if(app()->getLocale() == "en")
              <h6>{{ $data->production }} |
                @foreach ($data->genres as $genre)
      				   {{ $genre->title }} |
      			    @endforeach
      			    {{ $data->length }} min | {{ $data->age }}
              </h6>
              @else
                <h6>
                  @foreach ($data->genres as $genre)
                   {{ $genre->title }} |
                  @endforeach
                  {{ $data->age }} | <span dir="rtl"> {{ "min ". $data->length }} </span> | {{ $data->production }}
                </h6>
              @endif
              <p>{{ $data->desc }}</p>
              <div class="play_button" id="item-slider-{{ $data->id }}">
            	  @if($type !='show')
                <a href="#play_video" data-url="{{ route('video', [$type, isset($firstId) ? $firstId : $data->id]) }}" data-src="{{ asset('images/logo.png') }}" class="watch_buttons active modal-trigger">
              	<i class="material-icons">play_arrow</i> @lang('frontend.play')
            	  </a>
                @endif
            	  <a href="#play_video" data-url="{{ route('video', ['trailer_'.$type, $data->id]) }}" data-src="{{ asset('images/logo.png') }}" class="watch_buttons modal-trigger">
                <i class="material-icons">play_arrow</i> @lang('frontend.watch_trailer')
            	  </a>
              	@php 
    							$favoriteMovies = \Auth::user()->followingMovies->pluck('id')->toArray();
    							$favoriteShows = \Auth::user()->followingSeries->pluck('id')->toArray();
    							$favorites = array_merge($favoriteMovies, $favoriteShows);
    						@endphp
    						@if(in_array($data->id, $favorites))
    							<a class="watch_buttons removeList" href="javascript:" data-type="{{ $data->season ? 'show' : 'movie' }}" data-id="{{ $data->id }}" data-header="yes" id="remove-slider-{{ $data->id }}">
                    <i class="material-icons">check</i> @lang('frontend.remove_from_my_list')
                  </a>
    						@else
    							<a class="watch_buttons addToList" href="javascript:" data-type="{{ $data->season ? 'show' : 'movie' }}" data-id="{{ $data->id }}" data-header="yes" id="add-slider-{{ $data->id }}">
                    <i class="material-icons">add</i> @lang('frontend.add_to_my_list')
                  </a>
    						@endif
                <a class="watch_buttons share" id="popoverId" data-placement="bottom" data-toggle="popover" data-container="body" data-html="true" href="javascript:">@lang('frontend.share')</a>
                <div id="popover-content" class="hide">
                  <div class="popover-header">
                  <button type="button" class="close" id="popoverClose" data-dismiss="popover" aria-hidden="true">&times;</button>
                  </div>
                  <div class="row">
                    <div class="col-xs-12">
                      <input type="text" class="col-xs-12" name="shareUrl" id="shareUrl" value="{{ url()->full() }}" readonly="readonly">
                    </div>
                    <div class="col-xs-12">
                      <a href="javascript:" onclick="myFunction('shareUrl')" data-toggle="tooltip" data-placement="right">@lang('frontend.copy_link')</a>
                    </div>
                    <div class="row">
                      <div class="col-xs-8">
                      </div>
                      <div class="col-xs-2">
                        <a href="https://www.facebook.com/sharer/sharer.php?u={{ url()->full() }}" class="pull-right" target="_blank"><img src="{{ asset('frontend/assets/images/soial_1.png') }}" alt=""></a>
                      </div>
                      <div class="col-xs-2">
                        <a href="https://wa.me/?text={{ url()->full() }}" target="_blank"><img src="{{ asset('frontend/assets/images/wht.png') }}" alt=""></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>