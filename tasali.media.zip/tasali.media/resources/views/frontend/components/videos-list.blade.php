<div class="videos-list">
	{{--  <div class="row">
			<div class="input-field col s12 m2">
			@foreach ($episodes as $episode)
				@php ($seasons[]=$episode->season)
			@endforeach
			<select class="episode-select  primary-color-text secondary-color">
				@foreach (array_unique($seasons) as $season)
					<option value="season-{{ $season }}" {{ $season =='1'? 'selected':'' }}>Season {{ $season }}</option>
				@endforeach
			</select>
			<label></label>
		</div>
	</div>
	--}}
	<div class="row">
		@foreach ($episodes as $episode)
			<div class="single-video col-sm-6 col-md-3 season-item season-{{ $episode->season }}">
				<a href="#play_video" class="image episode-play modal-trigger" data-url="{{ route('video', ['show', $episode->id]) }}" style="background-image: url({{ thumb($episode->image) }})">
					<div class="arrow-cont">
						<div class="arrow">
							<i class="material-icons">play_arrow</i>
						</div>
					</div>
					@if(isset($paused_episodes[$episode->id]))
					<div class="progress">
		                <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="{{ $paused_episodes[$episode->id]['percent'] }}"
		                aria-valuemin="0" aria-valuemax="100" style="width:{{ $paused_episodes[$episode->id]['percent'] }}%">
		                  {{ $paused_episodes[$episode->id]['percent'] }}%
		                </div>
		            </div>
					@endif
					{{-- <div class="seconds white-text right">04:00</div> --}}
				</a>
				<div class="title white-text center-align">{{ $episode->title }}</div>
			</div>
		@endforeach
	</div>
</div>