@if (Session::has('msg'))
    <div class="col sm-12 white-text alert {{ Session::get('msg-type') == 'error' ? 'alert-danger' : 'alert-success' }}">
        {{ Session::get('msg') }}
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    </div>
@endif

@if (count($errors) > 0)
<div class="col sm-12 alert alert-danger white-text">
    @foreach ($errors->all() as $error)
        <p>{{ $error }}</p>
    @endforeach
</div>
@endif
