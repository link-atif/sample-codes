<div class="row" style="margin-bottom: 40px" >
@php $kid = request()->session()->get('kid'); @endphp
@foreach ($items as $item)
@php ($gsUrl = $item->season ? 'shows/':'movies/' . $item->slug ) @endphp
	@if($kid == $item->is_kid && $item->status == 1)
	<div class="col-xs-4 col-md-2" style="margin-top: 10px; margin-bottom: 7px;" id="remove-item-{{ $item->id }}">
        <div class="item">
          	<div class="movie_col_inner">
		        <!-- <a href="@if($item->season) {{ route('single.show',$item->slug) }} @else {{ route('single.movie',$item->slug) }} @endif"> -->
		            <img src="{{ thumb($item->poster, 'thumb') }}" alt="{{ $item->title }}" >
		            <div class="overlay_bg"></div>
		            <div class="movie_col_overlay" id="item-genres-{{ $item->id }}">
		                <a href="@if($item->season) {{ route('single.show',$item->slug) }} @else {{ route('single.movie',$item->slug) }} @endif" class="btn_overlay active">
		                  <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
		                    <path d="M7.38906 5.85312L0.379025 1.01861C0.304816 0.967609 0.208609 0.962291 0.129323 1.00363C0.0497954 1.04544 0 1.12763 0 1.21755V10.8866C0 10.9765 0.0497954 11.0589 0.129323 11.1007C0.164615 11.1191 0.203291 11.1283 0.241725 11.1283C0.289829 11.1283 0.33769 11.1138 0.379025 11.0855L7.38906 6.251C7.45457 6.2058 7.49348 6.13159 7.49348 6.05206C7.49348 5.97253 7.45432 5.89832 7.38906 5.85312Z" fill="white"/>
		                  </svg> 
		                  <span>@lang('frontend.watch')</span>
		                </a>
		                @php 
							$favoriteMovies = \Auth::user()->followingMovies->pluck('id')->toArray();
							$favoriteShows = \Auth::user()->followingSeries->pluck('id')->toArray();
							$favorites = array_merge($favoriteMovies, $favoriteShows);
						@endphp
						@if(in_array($item->id, $favorites))
							<a class="btn_overlay removeList" href="javascript:" data-type="{{ $item->season ? 'show' : 'movie' }}" data-genres="genres" data-id="{{ $item->id }}" data-header="no" id="remove-genres-{{ $item->id }}">
                  				<i class="fas fa-check"></i> <span>@lang('frontend.remove_from_my_list')</span>
                			</a>
						@else
							<a class="btn_overlay addToList" href="javascript:" data-type="{{ $item->season ? 'show' : 'movie' }}" data-genres="genres" data-id="{{ $item->id }}" data-header="no" id="add-genres-{{ $item->id }}">
                  				<i class="fas fa-plus"></i> <span>@lang('frontend.add_to_my_list')</span>
                			</a>
						@endif
		            </div>
		      	<!-- </a> -->
		    </div>
		<div style="clear: both"></div>
		</div>
    </div>
    @endif
@endforeach
</div>