<div class="header_main">
   <div class="container">
       <div class="col-md-6 padd_0">
           <div class="logo">
            <a href="{{ url('/') }}"><img src="{{ asset('frontend/assets/images/logo.png') }}" alt="tasali"></a>
           </div>
       </div>
       <div class="col-md-6 padd_0">
            @if(\Auth::check())
                <a href="{{ route('logout') }}" class="signin_btn">@lang('frontend.logout')</a>
            @else
                <a href="{{ url('/login') }}" class="signin_btn">@lang('frontend.sign')</a>
            @endif
       </div>
   </div>
</div>