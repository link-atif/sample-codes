<div class="banner_main">
    <div id="demo">
        <div id="owl-demo14" class="owl-carousel">
          @foreach ($slider as $slide)
          <div class="item">
              <img src="{{ thumb($slide->image) }}" alt="">
                <!--<div class="overlay_gradient_fix"></div>-->
                <div class="banner_main_outer_content">
                    <div class="container padd_0">
                        <div class="col-md-7 padd_0">
                        <div class="slider_bg_tranparent">
                        <div class="rating_movie">
                          <span class="rating_cont"><i class="fas fa-star"></i>{{ $slide->rating_avg }}</span>
                          <p>.</p>
                            <span class="rating_cont">
                                <span class="imdb">IMDb</span>{{ $slide->imdb->rate ?? null}}
                            </span>
                        </div>
                        <h2>{{ $slide->title }}</h2>
                        @if(app()->getLocale() == "en")
                        <h6>{{ $slide->production }} |
                          @foreach ($slide->genres as $genre)
                           {{ $genre->title }} |
                          @endforeach
                          {{ $slide->length }} min | {{ $slide->age }}
                        </h6>
                        @else
                          <h6>
                            @foreach ($slide->genres as $genre)
                             {{ $genre->title }} |
                            @endforeach
                            {{ $slide->age }} | <span dir="rtl"> {{ "min ". $slide->length }} </span> | {{ $slide->production }} 

                          </h6>
                        @endif
                        <p>{{ $slide->desc }}</p>
                      <div class="play_button" id="item-slider-{{ $slide->id }}">
                        <a href="{{ $slide->season ? 'shows':'movies' }}/{{ $slide->slug }}" class="watch_buttons active">
                          <i class="material-icons">play_arrow</i> @lang('frontend.play')
                        </a>
                        <a href="#play_video" data-url="{{ route('video', ['trailer_'.($slide->season ? 'show' : 'movie'), $slide->id]) }}" data-src="{{ asset('images/logo.png') }}" class="watch_buttons modal-trigger">
                            <i class="material-icons">play_arrow</i> @lang('frontend.watch_trailer')
                        </a>
                        @php 
                          $favoriteMovies = \Auth::user()->followingMovies->pluck('id')->toArray();
                          $favoriteShows = \Auth::user()->followingSeries->pluck('id')->toArray();
                          $favorites = array_merge($favoriteMovies, $favoriteShows);
                        @endphp
                        @if(in_array($slide->id, $favorites))
                          <a class="watch_buttons removeList" href="javascript:" data-type="{{ $slide->season ? 'show' : 'movie' }}" data-id="{{ $slide->id }}" data-header="yes" id="remove-slider-{{ $slide->id }}">
                            <i class="material-icons">check</i> @lang('frontend.remove_from_my_list')
                          </a>
                        @else
                          <a class="watch_buttons addToList" href="javascript:" data-type="{{ $slide->season ? 'show' : 'movie' }}" data-id="{{ $slide->id }}" data-header="yes" id="add-slider-{{ $slide->id }}">
                            <i class="material-icons">add</i> @lang('frontend.add_to_my_list')
                          </a>
                        @endif
                      </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
          @endforeach
        </div>
    </div>
</div>
<!--banner-->