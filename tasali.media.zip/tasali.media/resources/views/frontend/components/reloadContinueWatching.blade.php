@php $kid = request()->session()->get('kid'); @endphp
@foreach ($gsItems as $key => $gsItem)
  @php ( $gsUrl = $gsItem['series_id'] ? 'shows/' .$gsItem['episodes']['show']['slug'] : 'movies/' . $gsItem['movies']['slug'] );
      ( $type = $gsItem['series_id'] ? 'episode' : 'movie' );
      ( $id = $gsItem['series_id'] ? $gsItem['episode_id'] : $gsItem['movie_id'] ); 
      ( $isKid = $gsItem['series_id'] ? $gsItem['episodes']['show']['is_kid'] : $gsItem['movies']['is_kid'] );
      ( $production = $gsItem['series_id'] ? $gsItem['episodes']['show']['production'] : $gsItem['movies']['production'] );
      ( $poster_id = $gsItem['series_id'] ? $gsItem['episodes']['show']['poster_id'] : $gsItem['movies']['poster_id'] );
      $poster = App\Image::where('id',$poster_id)->first();
      ( $title = $gsItem['series_id'] ? $gsItem['episodes']['show']['slug'] : $gsItem['movies']['slug'] );
  @endphp
  @if($kid == $isKid)
  <div class="item" id="removeItem_{{ $key }}">
    <div class="movie_col_inner">
      <a href="#!">
      <img src="{{ thumb($poster) }}" alt="{{ $title }}">
      <div class="overlay_bg"></div>
      <div class="movie_col_overlay">
        <div class="progress">
          <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="{{ $gsItem['percent'] }}"
          aria-valuemin="0" aria-valuemax="100" style="width:{{ $gsItem['percent'] }}%">
            {{ $gsItem['percent'] }}%
          </div>
        </div>
        <div class="play_button_overlay">
          <a href="{{ $production ? $gsUrl : '#!'}}" class="btn_overlay active">
            <svg width="8" height="12" viewBox="0 0 8 12" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M7.38906 5.85312L0.379025 1.01861C0.304816 0.967609 0.208609 0.962291 0.129323 1.00363C0.0497954 1.04544 0 1.12763 0 1.21755V10.8866C0 10.9765 0.0497954 11.0589 0.129323 11.1007C0.164615 11.1191 0.203291 11.1283 0.241725 11.1283C0.289829 11.1283 0.33769 11.1138 0.379025 11.0855L7.38906 6.251C7.45457 6.2058 7.49348 6.13159 7.49348 6.05206C7.49348 5.97253 7.45432 5.89832 7.38906 5.85312Z" fill="white"/>
            </svg> 
            <span>@lang('frontend.watch')</span>
          </a>
          <a class="btn_overlay removeWatching" href="javascript:" data-type="{{ $type }}" data-id="{{ $id }}" data-key="{{ $key }}">
            <span>@lang('frontend.remove')</span>
          </a>
        </div>
      </div>
    </a>
    </div>
  </div>
  @endif
  @endforeach