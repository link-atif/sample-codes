<div class="footer_main">
   <div class="container">
       <div class="row">
           <div class="col-md-3 col-sm-6 col-xs-12">
               <div class="footer_col">
                   <h4>@lang('frontend.company')</h4>
                    @if($pages)
                        <div class="col s3">
                            <ul>
                                @foreach($pages as $key=>$value)
                                    @if($key=='about')<li><a href="{{route('page.show',$key)}}">{{ __($value) }}</a></li>@endif
                                    @if($key=='contact')<li><a href="{{route('page.show',$key)}}">{{ __($value) }}</a></li>@endif
                                @endforeach 
                            </ul>
                        </div>
                    @endif
               </div>
           </div>
           
           <div class="col-md-3 col-sm-6 col-xs-12">
               <div class="footer_col">
                   <h4>@lang('frontend.legal')</h4>
                   <ul>
                    @foreach($pages as $key=>$value)
                        @if($key=='terms')<li><a href="{{route('page.show',$key)}}">{{ __($value) }}</a></li>@endif
                        @if($key=='privacy')<li><a href="{{route('page.show',$key)}}">{{ __($value) }}</a></li>@endif
                    @endforeach
                   </ul>
               </div>
           </div>
           
           <div class="col-md-3 col-sm-6 col-xs-12">
               <div class="footer_col">
                   <h4>@lang('frontend.help')</h4>
                   <ul>
                    @foreach($pages as $key=>$value)
                        @if($key=='faqs')<li><a href="{{route('page.show',$key)}}">{{ __($value) }}</a></li>@endif
                    @endforeach
                   </ul>
               </div>
           </div>
           
           <div class="col-md-3 col-sm-6 col-xs-12">
               <div class="footer_col">
                   <h4>@lang('frontend.services')</h4>
                   <ul>
                       <li><a href="{{ route('movie') }}">@lang('frontend.movies')</a></li>
                       <li><a href="{{ route('show') }}">@lang('frontend.series')</a></li>
                   </ul>
               </div>
           </div>
           
           <div class="clearfix"></div>
           
           <div class="privacy_section">
               <div class="col-md-6">
                   <div class="social_footer">
                       
                       <a href="https://www.facebook.com/Tasali-114646016899548">
                        <img src="{{ asset('frontend/assets/images/soial_1.png') }}" alt="">
                       </a>
                       
                       <!-- <a href="https://twitter.com/MediaTasali">
                        <img src="{{ asset('frontend/assets/images/soial_2.png') }}" alt="">
                       </a> -->
                       
                       <a href="https://www.instagram.com/mediatasali/">
                        <img src="{{ asset('frontend/assets/images/soial_3.png') }}" alt="">
                       </a>
                       
                       <!-- <a href="https://www.linkedin.com/company/tasalimedia">
                        <img src="{{ asset('frontend/assets/images/soial_4.png') }}" alt="">
                       </a> -->
                       
                       <a href="https://www.youtube.com/channel/UCYfHHYJjFeJteFjrXLENkkg">
                        <img src="{{ asset('frontend/assets/images/soial_5.png') }}" alt="">
                       </a>
                       
                   </div>
               </div>
               
               <div class="col-md-6">
                   <p>© 2020 @lang('frontend.copyrights')</p>
               </div>
               
           </div>
           
       </div>
   </div>
</div>

<div id="play_video" class="modal">
  <div class="modal-content" style="height:70vh;padding:2px;">
  </div>
</div>