<header class="header header_fixed" data-aos="fade-down" data-aos-duration="1200">
    <!--navigation-->
    <div class="nav-main">
        <div class="container">
            <div class="row">
                <nav class="navbar navbar-default" role="navigation">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
	                       	<span class="sr-only">Toggle navigation</span>
	                        <span class="icon-bar"></span>
	                        <span class="icon-bar"></span>
	                        <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand logo" href="{{ route('home') }}"><img src="{{ asset('frontend/assets/images/logo.png') }}" alt="Logo"></a>
                    </div>
                    
                     
                    
                    <div class="header_toggle_left dropdown">
                        <a href="#" class="toogle_bars dropdown-toggle" data-toggle="dropdown">
                        	<i class="fas fa-bars"></i>
                        </a>
                        <div class="dropdown-menu mega_drop_down_menu">
                            @php 
                            	$i = 1;
                            	$j = 1; 
                            @endphp
                           {{-- @foreach($shows->chunk(7) as $show)
                            <ul class="col-md-3">
                                <h4>@if($i==1) {{ "Shows" }} @else{{ "-" }} @endif</h4>
                                @foreach($show as $s)
                                	<li><a href="{{ route('single.show', $s->slug) }}">{{ $s->title }}</a></li>
                            	@endforeach
                            	@php $i++; @endphp
                            </ul>
                            @endforeach --}}
                            @foreach($genres->chunk(7) as $genre)
                            <ul class="col-md-3">
                                <h4>@if($j==1) @lang('frontend.genres') @else {{ " " }} @endif</h4>
                                @foreach($genre as $g)
                                	<li><a href="{{ route('genre', $g->slug) }}">{{ $g->title }}</a></li>
                                @endforeach
                            </ul>
                           	@php  $j++; @endphp
                            @endforeach
                        </div>
                    </div>

                    <div class="nav_right">
                        
                        <li>
                            <div class="search_header">
                                <form id="search" method="get" action="{{ route('search') }}">
                                <i class="fas fa-search">
                                    <a href="javascript:{}" onclick="document.getElementById('search').submit();"
                                        style="font-size:26px"></a>
                                </i>
                                <input type="text" class="form-control" placeholder="@lang('frontend.search')" name="keyword">
                                </form>
                            </div>
                        </li>
                        
                        <li>
                            @php
                                if(app()->getLocale() == "en"){
                                    $langText = "AR";
                                    $lang = "ar";
                                }
                                else{
                                    $langText = "EN";
                                    $lang = "en";
                                }

                                if(app()->getLocale() == "en"){
                                    $selectedLang = "EN";
                                }
                                else{
                                    $selectedLang = "AR";
                                }
                            @endphp
                            <a href="{{ route('kidSection') }}">@if($is_kid == 0) @lang('frontend.kids') @else @lang('frontend.main') @endif</a>
                        </li>
                        <li class="dropdown notification_bar">
                              <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                              <i class="far fa-bell"></i>
                              <!--<span class="caret"></span>--></a>
                               <ul class="dropdown-menu notification-menu">
                                @foreach($notifications as $n)
                                @php ( $nUrl = isset($n['season']) ? 'shows/' . $n['slug'] :'movies/' . $n['slug'] ) @endphp
                                 <li><a href="@if(isset($n['season'])) {{ route('single.show',$n['slug']) }} @else {{ route('single.movie',$n['slug']) }} @endif">

                                    <div class="card">
                                        <div class="card-horizontal">
                                            <div class="col-md-4 col-lg-4 col-sm-12">
                                                @if(!empty($n['poster']))
                                                <img src="{{ thumb((object)$n['poster']) }}" alt="{{ $n['title'] }}">
                                                @else
                                                <img src="{{ asset('frontend/assets/images/tasali-logo.png') }}" alt="{{ $n['title'] }}">
                                                @endif
                                            </div>
                                            <div class="card-body col-md-8 col-lg-8 col-sm-12">
                                                <h3 class="card-title">{{ $n['title'] }}</h3>
                                                <p class="card-text">{{ time_elapsed_string($n['created_at']) }}</p>
                                            </div>
                                        </div>
                                    </div>

                                </a></li>
                                 @endforeach
                              </ul>
                        </li>
                        
                        
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <span class="user_icon">
                                    @if(!is_null(Auth::user()->avatar)) 
                                        <img src="{{ asset('frontend/assets/images/avatar/'.Auth::user()->avatar.'.jpg') }}" alt="Logo">
                                    @else
                                        <img src="{{ asset('frontend/assets/images/avater.jpg') }}" alt="Logo">
                                    @endif
                                </span>
                                <span class="user_name_control">
                                @if(Auth::user()->name)
                                    {{ Auth::user()->name }}
                                @else
                                    User Account
                                @endif
                                </span>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="{{ route('getMyList') }}">@lang('frontend.my_list')</a></li>
                                @if(Auth::user()->parent_id > 0)
                                <li><a href="{{ route('profile.setting', Auth::user()->id) }}">@lang('frontend.settings')</a></li>
                                @endif
                                @if(Auth::user()->parent_id == 0)
                                <li><a href="{{ route('profile') }}">@lang('frontend.settings')</a></li>
                                @endif
                                @if(Auth::user()->role_id == 2)
                                <li><a href="{{ route('Backend::home') }}">@lang('frontend.admin_panel')</a></li>
                                @endif
                                @if(Auth::user()->parent_id == 0)
                                <li><a href="{{ route('all.profiles') }}">@lang('frontend.manage_profiles')</a></li>
                                @endif
                                <li><a href="{{ route('logout') }}">@lang('frontend.logout')</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                {{ $selectedLang }}
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="{{ route('lang', [$lang]) }}">{{ $langText }}</a></li>
                            </ul>
                        </li>
                    </div>
                      
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-left nav-links custom_nav">
                        	<!-- @foreach($forMenue as $m)
                        	<li><a href="{{ route('genre', $m->slug) }}">{{ $m->title }}</a></li>                                           
                        	@endforeach -->
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
<!--navigation-->
</header>       
<!--header-->