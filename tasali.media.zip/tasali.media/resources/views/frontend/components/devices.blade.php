@php
    $devices = \App\Device::where('user_id', Session::get('user_id'))->get();
    Session::put('user_id', -1);
@endphp
<div class="col sm-12 alert alert-danger white-text">
@foreach($devices as $key=>$d)
<div class="row">
    <div class="col-md-3">
        <label>Device-{{ $key+1 }}</label>
    </div>
    <div class="col-md-3">
         <form action="{{ route('remove.device', $d->id) }}" id="delete_device-{{ $d->id }}" method="post">
            {{ method_field('delete') }}
            {{ csrf_field() }}
            <a href="javascript:{}" onclick="document.getElementById('delete_device-'+'{{ $d->id }}').submit();return confirm('Are you sure?')" 
            data-msg="@lang('backend.confirm_delete')" class="mylinks">Delete</a>
        </form>
    </div>
</div>
@endforeach
</div>
