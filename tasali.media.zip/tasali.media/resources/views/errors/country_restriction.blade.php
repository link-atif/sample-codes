<!DOCTYPE html>
<html>
<head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="Home">
      <meta name="author" content="Pioneer">
      <META Http-Equiv="Cache-Control" Content="no-store, max-age=0, must-revalidate">
      <META Http-Equiv="Pragma" Content="no-cache">
      <META Http-Equiv="Expires" Content="0">
      <!--<link rel="shortcut icon" href="assets/images/favicon.ico">-->
      <title>Country Restriction</title>
      <!-- Applying Css-->
      <link href="{{ asset('frontend/assets/css/bootstrap.min.css') }}" rel="stylesheet">
      <link href="{{ asset('frontend/assets/fonts/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet" type="text/css" />
      <link href="{{ asset('frontend/assets/css/style.css') }}" rel="stylesheet" />
      <link href="{{ asset('frontend/assets/css/responsive.css') }}" rel="stylesheet">
      <link href="{{ asset('frontend/assets/css/owl.carousel.css') }}" rel="stylesheet">
      <!--fonts-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--css file end-->
      
   </head>
  <body>
    
    <div class="preload" id="myElem"><img src="{{ asset('frontend/assets/images/tasali-logo.png') }}"><br>
        <h1>Sorry, Tasali is not<br> available in your country.</h1>
    </div>
    <script src="{{ asset('frontend/assets/js/jquery.min.js') }}"></script>
    <script src="{{ asset('frontend/assets/js/bootstrap.min.js') }}"></script>
</body>

</html>