@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3>{{ $page_title }}</h3>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row">
        @include('backend.partials.filter_form')
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data blue-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-desktop"></i></h1>
                        <h2 class="text-center">Shows: {{ $shows }}</h2>
                        @if($search == 0)
                        <h4 class="text-center"><span class="p_5">Daily: {{ $today_shows }} </span><span class="p_5"> Weekly: {{ $weekly_shows }}</span><span> Monthly: {{ $monthly_shows }}</span></h4>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data orange-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-video-camera"></i></h1>
                        <h2 class="text-center">Movies: {{ $movies }}</h2>
                        @if($search == 0)    
                        <h4 class="text-center"><span class="p_5">Daily: {{ $today_movies }} </span><span class="p_5"> Weekly: {{ $weekly_movies }}</span><span> Monthly: {{ $monthly_movies }}</span></h4>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data red-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-video-camera"></i></h1>
                        <h2 class="text-center">Genres: {{ $genres }}</h2>
                        @if($search == 0)    
                        <h4 class="text-center"><span class="p_5">Daily: {{ $today_genres }} </span><span class="p_5"> Weekly: {{ $weekly_genres }}</span><span> Monthly: {{ $monthly_genres }}</span></h4>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data green-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-play"></i></h1>
                        <h2 class="text-center">Episodes: {{ $episodes }}</h2>
                        @if($search == 0)
                        <h4 class="text-center"><span class="p_5">Daily: {{ $today_episodes }} </span><span class="p_5"> Weekly: {{ $weekly_episodes }}</span><span> Monthly: {{ $monthly_episodes }}</span></h4>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data blue-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-user"></i></h1>
                        <h2 class="text-center">Casts: {{ $casts }}</h2>
                        @if($search == 0)
                        <h4 class="text-center"><span class="p_5">Daily: {{ $today_casts }} </span><span class="p_5"> Weekly: {{ $weekly_casts }}</span><span> Monthly: {{ $monthly_casts }}</span></h4>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data red-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-users"></i></h1>
                        <h2 class="text-center">Users: {{ $users }}</h2>
                        @if($search == 0)
                        <h4 class="text-center"><span class="p_5">Daily: {{ $today_users }} </span><span class="p_5"> Weekly: {{ $weekly_users }}</span><span> Monthly: {{ $monthly_users }}</span></h4>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-4 col-xl-4">
            <div class="dashboard-data red-background">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <h1 class="text-center text-size"><i class="fa fa-users"></i></h1>
                        <h2 class="text-center">Today's Visitors : {{ $total_visitors }}</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-8 col-xl-8">
            <div class="revenue-column" style="background-color: #bed4de;">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Site Visits </h3></div>
                        <div id="regions_div" style="width: 710px; height: 300px;"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-xl-4">
            <section class="panel">
                <div><h3 style="color: black; text-align: center;">Site Revenue </h3></div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Country</th>
                                <th>Total users</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($site_visitors as $sv)
                            <tr>
                                <td>@if($sv->country !="")<img src="https://flagcdn.com/{{ strtolower(country_code($sv->country)) }}.svg" width="30"> @endif</td>
                                <td>{{ $sv->country }}</td>
                                <td>{{ $sv->total }}</td>
                                <td>{{ $sv->amount }} {{ currency_code($sv->country) }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
</div>
<!--body wrapper end-->
@endsection
@section('script')
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css"><script type="text/javascript">
    google.charts.load('current', {
        'packages':['geochart'],
        // Note: you will need to get a mapsApiKey for your project.
        // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
        'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
      });
      google.charts.setOnLoadCallback(drawRegionsMap);

      function drawRegionsMap() {
        var data = google.visualization.arrayToDataTable([<?php echo $usersData ?>]);

        var options = {
            colorAxis: {colors: ['green', 'green']},
            legend: 'none',
            backgroundColor: '#bed4de',
            datalessRegionColor: '#ffffff'
        };

        var chart = new google.visualization.GeoChart(document.getElementById('regions_div'));

        chart.draw(data, options);
      }
</script>
<script type="text/javascript">
    function resetSearch(){
        window.location = "{{ route('Backend::home') }}";
    }
</script>
<script>
  $(document).ready(function() {
    $('#table, #uploaded-today, #users-table').DataTable();
} );
 </script>
@endsection