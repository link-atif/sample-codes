@extends('backend')
@section('content')
<div class="page-head">
    <h3>{{ $page_title }}</h3>
</div>
<div class="wrapper">
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-12 col-xl-12">
            <div class="trending-column">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Uploaded Today</h3></div>
                        <section class="panel">
                            <div class="table-responsive">
                                <table class="table table-striped" id="uploaded-today">
                                    <thead>
                                       <tr>
                                            <th>Title</th>
                                            <th>Size</th>
                                            <th>Time</th>
                                            <th>Date</th>
                                            <th>Year</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($videos as $video)
                                        <tr>
                                            <td>{{ $video->original_title }}</td>
                                            <td>{{ convertToReadableSize($video->size) }}</td>
                                            <td>{{ Carbon\Carbon::parse($video->created_at)->format('h:i a') }}</td>
                                            <td>{{ Carbon\Carbon::parse($video->created_at)->format('F d') }}</td>
                                            <td>{{ Carbon\Carbon::parse($video->created_at)->format('Y') }}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
<script>
  $(document).ready(function() {
    $('#table, #uploaded-today, #users-table').DataTable();
} );
 </script>
@endsection