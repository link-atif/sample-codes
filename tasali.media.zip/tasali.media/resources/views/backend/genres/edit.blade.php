@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Update {{ $genre->title }}
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::genres.index') }}">Genres</a></li>
            <li class="active"> Update {{ $genre->title }} </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Update {{ $genre->title }}
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::genres.update', $genre->id) }}" method="post">
                            {{ csrf_field() }}
                            {{ method_field('put') }}
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="title" value="{{ $genre->translate('en')->title }}" class="form-control" required>
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Arabic Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="ar_title" value="{{ $genre->translate('ar')->title }}" class="form-control" placeholder="العنوان بالعربى" required>
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Meta Tags</label>
                                <div class="col-lg-5">
                                    <input type="text" name="meta_tags" value="{{ $genre->meta_tags }}" class="form-control" placeholder="SEO Tags">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Meta Description</label>
                                <div class="col-lg-5">
                                    <textarea name="meta_description" class="form-control">{{ $genre->meta_description }}</textarea>
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Sort Order</label>
                                <div class="col-lg-5">
                                    <input type="number" name="sort_order" min="0" value="{{ $genre->sort_order }}" class="form-control" placeholder="Sort Order" required>
                                </div>
                            </div>

                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->


@endsection
