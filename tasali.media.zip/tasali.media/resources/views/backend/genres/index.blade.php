@extends('backend')
@section('content')
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 24px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
<div class="page-head">
    <h3 class="m-b-less">
        All genres
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li class="active">All genres</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            @include('backend.genres.filter_form')
            @include('backend.partials.flash')
            <section class="panel">
                <header class="panel-heading head-border">
                    All genres {!! isset($count) ? "<span class='label label-success'>{$count}</span>" : null !!}
                </header>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>title</th>
                                <th>Arabic Title</th>
                                <th>Order</th>
                                <th>Actions</th>
                                <th>Status</th>
                                <th>Display on homepage</th>
                                <th>Show in Menue</th>
                                <th>Is Kid</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($genres as $genre)
                            <tr>
                                <td>{{ $genre->translate('en')->title ?? null }}</td>
                                <td>{{ $genre->translate('ar')->title ?? null }}</td>
                                <td>{{ $genre->sort_order }}</td>
                                <td>
                                    @if(in_array('genres-edit', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                        <a href="{{ route('Backend::genres.edit', $genre->id) }}" class="btn btn-primary btn-xs">
                                            <i class="fa fa-pencil"></i>
                                        </a>
                                    @endif
                                    @if(in_array('genres-delete', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                        <form action="{{ route('Backend::genres.destroy', $genre->id) }}" method="post" style="display: inline;">
                                            {{ method_field('delete') }}
                                            {{ csrf_field() }}
                                            <button class="btn btn-danger btn-xs del-confirm" data-msg="@lang('backend.confirm_delete')">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </form>
                                    @endif
                                </td>
                                <td>
                                    <label class="switch">
                                        <input type="checkbox" onclick="updateStatus('{{$genre->id}}','status')" id="status{{ $genre->id }}" {{ ($genre->status == 1) ? 'checked="checked"' : '' }}>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                                <td><input type="checkbox" name="display_on_homepage" onclick="updateStatus('{{$genre->id}}','display_on_homepage')" id="display_on_homepage{{ $genre->id }}" {{ ($genre->display_on_homepage == 1) ? 'checked="checked"' : '' }}></td>
                                <td><input type="checkbox" name="show_in_menue" onclick="updateStatus('{{$genre->id}}','show_in_menue')" id="show_in_menue{{ $genre->id }}" {{ ($genre->show_in_menue == 1) ? 'checked="checked"' : '' }}></td>
                                <td><input type="checkbox" name="id_kid" onclick="updateStatus('{{$genre->id}}','is_kid')" id="is_kid{{ $genre->id }}" {{ ($genre->is_kid == 1) ? 'checked="checked"' : '' }}></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>
            <div class="pagination">
                {{ $genres->appends(Request::except('page'))->links() }}
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function updateStatus(id, type){
      var status = 0;
      if($("#"+type+id).prop('checked')==true){ 
        status = 1;
      }
      $.ajax({
          type: 'POST',
          dataType: 'json',
          url: "{{ route('Backend::genres.status') }}",
          data: {'id' : id, 'status': status, 'type' : type },
          success: function(result) {
              //alert("Status Updated Successfully!");
          },
          error: function() {
              alert('error');
          }
      });
      
    }
</script>
@stop
