@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Config
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li class="active"> Edit Config </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Edit Config
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <form class="cmxform form-horizontal tasi-form" enctype="multipart/form-data" 
                        action="{{ route('Backend::config.update', $row->id) }}" method="post" name="frm">
                        {{ csrf_field() }}
                        {{ method_field('post') }}
                        @php $input = "amount" ;
                        @endphp
                        <div class="form-group ">
                            <label for="{{$input}}"
                                class="control-label col-lg-2 {{ $errors->has($input) ? ' text-danger' : '' }}">{{ __('backend.'.$input)}}
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-10">
                                <input value="{{@$row->$input}}"
                                    class=" form-control {{ $errors->has($input) ? ' is-invalid' : '' }}"
                                    id="{{$input}}" name="{{$input}}" type="number" min="0" required />
                                @foreach($errors->get($input) as $message)
                                <span class='help-inline text-danger'>* {{ $message }}</span> @endforeach
                            </div>
                        </div>

                        @php $input = "trial" ;
                        @endphp
                        <div class="form-group ">
                            <label for="{{$input}}"
                                class="control-label col-lg-2 {{ $errors->has($input) ? ' text-danger' : '' }}">{{ __('backend.'.$input)}}
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-10">
                                <input value="{{@$row->$input}}"
                                    class=" form-control {{ $errors->has($input) ? ' is-invalid' : '' }}"
                                    id="{{$input}}" name="{{$input}}" type="number" min="0" max="1" required />
                                @foreach($errors->get($input) as $message)
                                <span class='help-inline text-danger'>* {{ $message }}</span> @endforeach
                            </div>
                        </div>

                        @php $input = "trial_amount" ;
                        @endphp
                        <div class="form-group ">
                            <label for="{{$input}}"
                                class="control-label col-lg-2 {{ $errors->has($input) ? ' text-danger' : '' }}">{{ __('backend.'.$input)}}
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-10">
                                <input value="{{@$row->$input}}"
                                    class=" form-control {{ $errors->has($input) ? ' is-invalid' : '' }}"
                                    id="{{$input}}" name="{{$input}}" type="number" min="0" required />
                                @foreach($errors->get($input) as $message)
                                <span class='help-inline text-danger'>* {{ $message }}</span> @endforeach
                            </div>
                        </div>

                        @php $input = "subscription_duration" ;
                        @endphp
                        <div class="form-group ">
                            <label for="{{$input}}"
                                class="control-label col-lg-2 {{ $errors->has($input) ? ' text-danger' : '' }}">{{ __('backend.'.$input)}}
                                <span class="text-danger">*</span></label>
                            <div class="col-lg-10">
                                <input value="{{@$row->$input}}"
                                    class=" form-control {{ $errors->has($input) ? ' is-invalid' : '' }}"
                                    id="{{$input}}" name="{{$input}}" type="number" min="0" required />
                                @foreach($errors->get($input) as $message)
                                <span class='help-inline text-danger'>* {{ $message }}</span> @endforeach
                            </div>
                        </div>
                        <!-- @php $input = "landing_image" ;
                        @endphp
                        <div class="form-group ">
                            <label for="{{$input}}" class="control-label col-lg-2 {{ $errors->has($input) ? ' text-danger' : '' }}">{{ __('backend.'.$input)}}
                                <span class="text-danger">*</span>
                            </label>
                            <div class="col-lg-10">
                                <div class="image_style">
                                    Choose a Image
                                    <input type="file" id="{{ $input }}" name="{{ $input }}" class="hide_file" onchange="encodeImageFileAsURL('{{ $input }}','image_preview','old_image');">
                                    @foreach($errors->get($input) as $message)
                                        <span class='help-inline text-danger'>* {{ $message }}</span> 
                                    @endforeach
                                </div>
                                <div class="row">
                                    <div class="col-lg-12" style="padding-top: 5px;" id="image_preview"></div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12" id="old_image" style="padding-top: 5px;">
                                        @if(!empty($row->image))
                                        <img width="100px" height="100px" src="{{ thumb($row->image) }}">                                    
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>

                        @php $input = "login_image" ;
                        @endphp
                        <div class="form-group ">
                            <label for="{{$input}}" class="control-label col-lg-2 {{ $errors->has($input) ? ' text-danger' : '' }}">{{ __('backend.'.$input)}}
                                <span class="text-danger">*</span>
                            </label>
                            <div class="col-lg-10">
                                <div class="image_style">
                                    Choose a Image
                                    <input type="file" id="{{ $input }}" name="{{ $input }}" class="hide_file" onchange="encodeImageFileAsURL('{{ $input }}','poster_preview','old_photo');">
                                    @foreach($errors->get($input) as $message)
                                        <span class='help-inline text-danger'>* {{ $message }}</span> 
                                    @endforeach
                                </div>
                                <div class="row">
                                    <div class="col-lg-12" style="padding-top: 5px;" id="poster_preview"></div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12" id="old_photo" style="padding-top: 5px;">
                                        @if(!empty($row->photo))
                                        <img width="100px" height="100px" src="{{ thumb($row->photo) }}">                                    
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div> -->

                        <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                            <div class="col-lg-offset-2 col-lg-10">
                                <button class="btn btn-success" type="submit">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </div>
</div>

@endsection