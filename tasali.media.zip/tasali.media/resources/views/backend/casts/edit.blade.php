@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Update {{ $cast->name }}
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::casts.index') }}">Casts</a></li>
            <li class="active"> Update {{ $cast->name }} </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Update {{ $cast->name }}
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::casts.update', $cast->id) }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            {{ method_field('put') }}
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Name</label>
                                <div class="col-lg-5">
                                    <input type="text" name="name" value="{{ $cast->translate('en')->name }}" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Arabic Name</label>
                                <div class="col-lg-5">
                                    <input type="text" name="ar_name" value="{{ $cast->translate('ar')->name }}" class="form-control" placeholder="الأسم بالعربى">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="poster" class="control-label col-lg-2">Image</label>
                                <div class="col-lg-5">
                                    <div class="image_style">
                                        Choose a image
                                        <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','old_image');">
                                    </div>
                                    <br><br><br>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                    <div style="padding-top: 20px;" id="old_image">
                                        @if($cast->image !="")
                                            <img width="200px" height="100px" src="{{ thumb($cast->image) }}">
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="seasons" class="control-label col-lg-2">Meta Tags</label>
                                <div class="col-lg-5">
                                    <input type="text" name="meta_tags" value="{{ $cast->meta_tags }}" placeholder="Meta Tags"  class="form-control">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label for="seasons" class="control-label col-lg-2">Meta Description</label>
                                <div class="col-lg-5">
                                    <textarea name="meta_description" rows="8" class="form-control">{{ $cast->meta_description }}</textarea>
                                </div>
                            </div>

                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->


@endsection
