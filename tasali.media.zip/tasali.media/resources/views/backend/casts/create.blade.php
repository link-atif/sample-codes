@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Create new Cast
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::casts.index') }}">Casts</a></li>
            <li class="active"> Create Cast </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Create Cast
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::casts.store') }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Name</label>
                                <div class="col-lg-5">
                                    <input type="text" name="name" value="{{ old('name') }}" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Arabic Name</label>
                                <div class="col-lg-5">
                                    <input type="text" name="ar_name" value="{{ old('ar_name') }}" class="form-control" placeholder="الأسم بالعربى">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="poster" class="control-label col-lg-2">Image</label>
                                <div class="col-lg-5">
                                    <div class="image_style">
                                        Choose a Image
                                        <input type="file" id="image" name="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','');">
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="seasons" class="control-label col-lg-2">Meta Tags</label>
                                <div class="col-lg-5">
                                    <input type="text" name="meta_tags" value="{{ old('meta_tags') }}" placeholder="Meta Tags"  class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="seasons" class="control-label col-lg-2">Meta Description</label>
                                <div class="col-lg-5">
                                    <textarea name="meta_description" rows="8" class="form-control">{{ old('meta_description') }}</textarea>
                                </div>
                            </div>
                                    
                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->


@endsection
