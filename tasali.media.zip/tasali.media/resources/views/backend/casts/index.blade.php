@extends('backend')
@section('content')
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 24px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
<div class="page-head">
    <h3 class="m-b-less">
        All Casts
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li class="active">All Casts</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            @include('backend.casts.filter_form')
            @include('backend.partials.flash')
            <section class="panel">
                <header class="panel-heading head-border">
                    All Casts {!! isset($count) ? "<span class='label label-success'>{$count}</span>" : null !!}
                </header>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Arabic Name</th>
                                <th>Actions</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($casts as $cast)
                            <tr>
                                <td>{{ $cast->translate('en')->name }}</td>
                                <td>{{ $cast->translate('ar')->name }}</td>
                                <td>
                                    @if(in_array('casts-edit', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                        <a href="{{ route('Backend::casts.edit', $cast->id) }}" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                                    @endif
                                    @if(in_array('casts-delete', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                        <form action="{{ route('Backend::casts.destroy', $cast->id) }}" method="post" style="display: inline;">
                                            {{ method_field('delete') }}
                                            {{ csrf_field() }}
                                            <button class="btn btn-danger btn-xs del-confirm" data-msg="@lang('backend.confirm_delete')">
                                                <i class="fa fa-trash-o "></i>
                                            </button>
                                        </form>
                                    @endif
                                </td>
                                <td>
                                    <label class="switch">
                                        <input type="checkbox" onclick="updateStatus('{{$cast->id}}','status')" id="status{{ $cast->id }}" {{ ($cast->status == 1) ? 'checked="checked"' : '' }}>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>
            <div class="pagination">
                {{ $casts->appends(Request::except('page'))->links() }}
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function updateStatus(id, type){
      var status = 0;
      if($("#"+type+id).prop('checked')==true){ 
        status = 1;
      }
      $.ajax({
          type: 'POST',
          dataType: 'json',
          url: "{{ route('Backend::casts.status') }}",
          data: {'id' : id, 'status': status, 'type' : type },
          success: function(result) {
              //alert("Status Updated Successfully!");
          },
          error: function() {
              alert('error');
          }
      });
      
    }
</script>
@stop
