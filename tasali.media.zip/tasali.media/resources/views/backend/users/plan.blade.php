@extends('backend.master')

@section('content')
<div class="row">
    <div class="col-xs-12">
        @include('backend.partials.error')
        <br>
        <div action="" class="form-inline mb10">
            <div class="form-group">
                <select name="" id="" class="form-control">
                    <option value="">Bulk Actions</option>
                    <option value="">Edit</option>
                    <option value="">Move to Trash</option>
                </select>

                <div class="btn btn-default">Apply</div>
            </div>

            <div class="form-group pull-right" style="margin-left:10px;">
                <form action="{{ route('Backend::usersSearch') }}" method="post">
                    {!! csrf_field() !!}
                    <input type="text" name="email" class="form-control">
                    <button type="submit" class="btn btn-default">search</button>
                </form>
            </div>

            <div class="form-group pull-right">
                <form action="{{ route('Backend::usersPremPlan') }}" method="get">
                    <select class="form-control" name="id">
                        @foreach ($plans as $plan)
                            <option value="{{ $plan->id }}">{{ $plan->translate(app()->getlocale())->title }}</option>
                        @endforeach
                    </select>
                    <button type="submit" class="btn btn-default">Filter</button>
                </form>
            </div>
        </div>
        <div class="panel">
    		<div class="panel-body panel-no-padding">
                <div class="table-vertical">
                  <table class="table table-striped table-bordered m-n">
                    <thead>
                        <tr>
                            <th width="40"><div class="icheck checkbox-inline select-all"><input type="checkbox"></div></th>
                            <th>@lang('backend.title')</th>
                            <th>@lang('backend.email')</th>
                            <th>@lang('backend.role')</th>
                            <th>@lang('backend.plan')</th>
                            <th>@lang('backend.enddate')</th>
                            <th class="text-center" width="240">@lang('backend.actions')</th>
                        </tr>
                    </thead>
                    <tbody>
                      @foreach ($users as $user)
                          <tr>
                            <td data-title="#"><div class="icheck checkbox-inline"><input type="checkbox" name="id[]"></div></td>
                            <td data-title="@lang('backend.title')">
                                <a href="{{ route('Backend::users.edit', $user->id) }}">{{ $user->name }}</a>
                            </td>
                            <td data-title="@lang('backend.email')">{{ $user->email }}</td>
                            <td data-title="@lang('backend.role')">{{ $user->role->name }}</td>
                            <td data-title="@lang('backend.plan')">{{ $user->plan->title }}</td>
                            <td data-title="@lang('backend.enddate')">{{ $user->premium_end }}</td>
                            <td data-title="@lang('backend.actions')" class="text-center">
                                <ul class="list-inline list-unstyled text-center">
                                    <li>
                                        <a href="#" class="btn btn-success btn-sm btn-label">
                                            <span class="fa fa-search"></span> @lang('backend.view')
                                        </a>
                                    </li>
                                    <li>
                                        <a href="{{ route('Backend::users.edit', $user->id) }}" class="btn btn-primary btn-sm btn-label">
                                            <span class="fa fa-pencil"></span> @lang('backend.edit')
                                        </a>
                                    </li>
                                    <li>
                                        <form action="{{ route('Backend::users.destroy', $user->id) }}" method="post">
                                            {{ method_field('delete') }}
                                            {{ csrf_field() }}
                                            <button class="btn btn-danger btn-sm btn-label del-confirm" data-msg="@lang('backend.confirm_delete')">
                                                <span class="fa fa-trash-o"></span> @lang('backend.delete')
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </td>
                          </tr>
                      @endforeach
                    </tbody>
                  </table>
                </div>
    		</div>
        </div>
        <div class="pagination">
            {{ $users->links() }}
        </div>
    </div>
</div>
</div>
@endsection
