@extends('backend')

@section('content')
<div class="page-head">
    <h3 class="m-b-less">
        All Devices
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li class="active">All Devices</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            @include('backend.partials.flash')
            <section class="panel">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>IP</th>
                                <th>Platform</th>
                                <th>Platform Version</th>
                                <th>Browser</th>
                                <th>Browser Version</th>
                                <th>Device</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          @if($devices !="null")
                            @foreach($devices as $d)
                            <tr>
                                <td>{{ $d->ip }}</td>
                                <td>{{ $d->platform }}</td>
                                <td>{{ $d->platform_version }}</td>
                                <td>{{ $d->browser }}</td>
                                <td>{{ $d->browser_version }}</td>
                                <td>{{ $d->device }}</td>
                                <td>
                                    <ul class="list-unstyled list-inline">
                                        <li>
                                            <form action="{{ route('Backend::users.remove', $d->id) }}" method="post">
                                                {{ csrf_field() }}
                                                <button class="btn btn-danger btn-xs del-confirm" data-msg="@lang('backend.confirm_delete')">
                                                    <i class="fa fa-trash-o "></i>
                                                </button>
                                            </form>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            @endforeach
                          @endif
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
</div>
@stop