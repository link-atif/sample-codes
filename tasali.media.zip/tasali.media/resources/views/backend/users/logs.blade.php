@extends('backend')

@section('content')
<div class="page-head">
    <h3 class="m-b-less">
        All Logs
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li class="active">All Logs</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Country Name</th>
                                <th>Watch Title</th>
                                <th>Type</th>
                                <th>Watch Time</th>
                                <th>Percent</th>
                                <th>Close Time</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(!empty($logs))
                            @foreach($logs as $l)
                                @if($l->movie_id !="" || $l->episode_id !="")
                            <tr>
                                <td>{{ $l->country }}</td>
                                <td>{{ $l->movie_id ?  getMovieById($l->movie_id) : getShowById($l->episode_id) }}</td>
                                <td>{{ $l->movie_id ?  "Movie" : "Show" }}</td>
                                <td>{{ gmdate("H:i:s", $l->paused_at) }}</td>
                                <td>{{ $l->percent }} %</td>
                                <td>{{ Carbon\Carbon::parse($l->created_at)->format('H:i a') }}</td>
                                <td>{{ Carbon\Carbon::parse($l->created_at)->format('F d Y') }}</td>
                            </tr>
                                @endif
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Country Name</th>
                                <th>Ip Address</th>
                                <th>Login Time</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(!empty($logs))
                            @foreach($logs as $l)
                                @if($l->movie_id =="" || $l->episode_id =="")
                            <tr>
                                <td>{{ $l->country }}</td>
                                <td>{{ $l->ip }}</td>
                                <td>{{ Carbon\Carbon::parse($l->created_at)->format('H:i a') }}</td>
                                <td>{{ Carbon\Carbon::parse($l->created_at)->format('F d Y') }}</td>
                            </tr>
                                @endif
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </div>
</div>
@stop