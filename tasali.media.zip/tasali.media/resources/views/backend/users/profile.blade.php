@extends('backend.master')

@section('content')
    <div class="row">
        <div class="col-md-12">
            @include('backend.partials.error')
        	<div class="panel panel-default" data-widget='{"draggable": "false"}'>
        		<div class="panel-heading">
        			<h2>@lang('backend.edit_title', ['title' => $title])</h2>
        		</div>
                <form action="{{ route('Backend::profileUpdate') }}" method="post" class="form-horizontal row-border" enctype="multipart/form-data">
                    {{ csrf_field() }}
                    {{ method_field('put') }}
                    <div class="panel-body">
                        <div class="form-group">
        					<label class="col-sm-2 control-label">@lang('backend.email')</label>
        					<div class="col-sm-8">
        						<input type="text" class="form-control" name="email" value="{{ $user->email }}">
        					</div>
        				</div>

                        <div class="form-group">
        					<label class="col-sm-2 control-label">@lang('backend.display_name')</label>
        					<div class="col-sm-8">
        						<input type="text" class="form-control" name="display_name" value="{{ $user->display_name }}">
        					</div>
        				</div>

                        <div class="form-group">
        					<label class="col-sm-2 control-label">@lang('backend.password')</label>
        					<div class="col-sm-8">
        						<input type="password" class="form-control" name="password" autocomplete="off">
                                <i class="text-danger">@lang('backend.password_change_warning')</i>
        					</div>
        				</div>

                        <div class="form-group">
        					<label class="col-sm-2 control-label">@lang('backend.phone')</label>
        					<div class="col-sm-8">
        						<input type="text" class="form-control" name="phone" value="{{ $user->phone }}">
        					</div>
        				</div>

                        <div class="form-group">
        					<label class="col-sm-2 control-label">@lang('backend.thumb')</label>
        					<div class="col-sm-8">
        						<input type="file" class="form-control" name="thumb">
        					</div>
        				</div>

                        <div class="form-group">
        					<label class="col-sm-2 control-label">@lang('backend.gender')</label>
        					<div class="col-sm-8">
                                <div class="icheck radio-inline">
                                    <input type="radio" name="gender" value="male" {{ ($user->gender == 'male') ? 'checked' : '' }}>
                                </div>
                                <div class="icheck radio-inline">
                                    <input type="radio" name="gender" value="female" {{ ($user->gender == 'female') ? 'checked' : '' }}>
                                </div>
        					</div>
        				</div>

                        <div class="form-group">
        					<label class="col-sm-2 control-label">@lang('backend.description')</label>
        					<div class="col-sm-8">
        						<textarea name="desc" class="form-control">{{ $user->desc }}</textarea>
        					</div>
        				</div>

                        <div class="form-group">
        					<label class="col-sm-2 control-label">@lang('backend.ar_description')</label>
        					<div class="col-sm-8">
        						<textarea name="ar_desc" class="form-control">{{ $user->ar_desc }}</textarea>
        					</div>
        				</div>

                        <div class="panel-footer">
            				<div class="row">
            					<div class="col-sm-8 col-sm-offset-2">
            						<button class="btn-primary btn">@lang('backend.update')</button>
            					</div>
            				</div>
            			</div>

            		</div>
                </form>
        	</div>
        </div>
    </div>
@endsection
