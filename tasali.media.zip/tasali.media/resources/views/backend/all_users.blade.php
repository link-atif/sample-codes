@extends('backend')
@section('content')
<!-- page head start-->
<div class="page-head">
    <h3>{{ $page_title }}</h3>
</div>

<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-12 col-xl-12">
            <div class="trending-column">
                <div class="counts-padding">
                    <div class="widget-content-left">
                        <div><h3 style="color: black; text-align: center;">Users</h3></div>
                        <section class="panel">
                            <div class="table-responsive">
                                <table class="table table-striped" id="users-table">
                                    <thead>
                                        <tr>
                                            <th>User Name</th>
                                            <th>Email</th>
                                            <th>Privilege</th>
                                            <th>City</th>
                                            <th>Country</th>
                                            <th>Logs</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($allUsers as $au)
                                        <tr>
                                            <td>{{ $au->name }}</td>
                                            <td>{{ $au->email }}</td>
                                            <td>{{ $au->role->label }}</td>
                                            <td>{{ $au->city }}</td>
                                            <td>{{ $au->country }}</td>
                                            <td><a href="{{ route('Backend::logs', $au->id) }}" class="btn btn-primary btn-small">User Logs</a></td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--body wrapper end-->
@endsection
@section('script')
<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css">
<script>
  $(document).ready(function() {
    $('#users-table').DataTable();
} );
 </script>
@endsection