@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Update {{ $page->title }}
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::pages.index') }}">Pages</a></li>
            <li class="active"> Update {{ $page->title }} </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Update {{ $page->title }}
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::pages.update', $page->id) }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            {{ method_field('put') }}
                            <div class="form-group ">
                                <label for="title" class="control-label col-lg-2">Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="title" value="{{ $page->translate('en')->title ?? '' }}" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Arabic Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="ar_title" value="{{ $page->translate('ar')->title ?? '' }}" class="form-control" placeholder="الأسم بالعربى">
                                </div>
                            </div>

                            
                            <div class="form-group ">
                                <label for="content" class="control-label col-lg-2">Content</label>
                                <div class="col-lg-5">
                                    <textarea class="summernote form-control" name="content">
                                        {{ $page->translate('en')->content ?? '' }}
                                    </textarea>
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="content" class="control-label col-lg-2">Arabic Content</label>
                                <div class="col-lg-5">
                                    <textarea class="summernote form-control" name="ar_content">
                                        {{ $page->translate('ar')->content ?? '' }}
                                    </textarea>
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Image</label>
                                <div class="col-lg-5">
                                    <div class="image_style" style="padding: 25px 180px;">
                                        Choose a image
                                        <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','old_image');"/>
                                    </div>
                                    <div id="image_preview"></div>
                                    <div id="old_image">
                                    @if($page->image != null)
                                        <img src="{{ asset(thumb($page->image)) }}" width="100px" height="100px" style="margin-top: 10px;" />
                                    @endif
                                    </div>
                                </div>
                            </div>

                            <div class="form-group ">
                                    <label for="active" class="control-label col-lg-2">Active</label>
                                    <div class="col-lg-5">
                                        <input type="checkbox" name="is_active" value="1" id="active"
                                        {{ (isset($page->is_active)&& $page->is_active) ? 'checked' : null }}/> 
                                    </div>
                                </div>

                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->


@endsection

@section('script')
    <!--summernote-->
    <script src="{{ asset('backend/js/summernote/dist/summernote.min.js')}}"></script>
    <script>
        $(document).ready(function () {
            $('.summernote').summernote({
                height: 200,
                minHeight: null,
                maxHeight: null,
                focus: true,
                toolbar: [
                    ['style', ['style']],
                    ['fontStyle', ['bold', 'italic', 'underline', 'clear']],
                    ['fontName', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['table', ['table']],
                    ['insert', ['video', 'media', 'link', 'hr', 'picture']],
                    ['font', ['strikethrough', 'superscript', 'subscript']],
                    ['misc', ['redo', 'undo', 'codeview']],
                ]
            });
        });
    </script>
@endsection