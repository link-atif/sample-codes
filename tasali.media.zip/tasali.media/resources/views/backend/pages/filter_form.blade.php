<div class="row">
    <form class="" action="{{ route('Backend::pages.filter') }}" method="get">
        <div class="col-lg-2 pull-right">
            <button type="submit" class="btn btn-block btn-primary pull-right">Filter & Search</button>
        </div>
        <div class="col-lg-3 pull-right">
            <input type="text" name="keyword" value="{{ (Request::input('keyword'))?? "" }}" placeholder="search..."
                    class="form-control">
        </div>
    </form>
</div>
<br>
