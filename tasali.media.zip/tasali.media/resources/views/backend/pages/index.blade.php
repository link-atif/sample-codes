@extends('backend')

@section('content')
<div class="page-head">
    <h3 class="m-b-less">
        All Pages
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li class="active">All Pages</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            @include('backend.pages.filter_form')
            @include('backend.partials.flash')
            <section class="panel">
                <header class="panel-heading head-border">
                    All Pages {!! isset($count) ? "<span class='label label-success'>{$count}</span>" : null !!}
                </header>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Arabic Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($pages as $page)
                            <tr>
                                <td>{{ $page->translate('en')->title ?? '' }}</td>
                                <td>{{ $page->translate('ar')->title ?? '' }}</td>
                                <td>
                                    <table class="table-actions">
                                        <tr>
                                            @if(in_array('pages-edit', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                            <td>
                                                <a href="{{ route('Backend::pages.edit', $page->id) }}" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                                            </td>
                                            @endif
                                            @if(in_array('pages-delete', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                            <td>
                                                <form action="{{ route('Backend::pages.destroy', $page->id) }}" method="post">
                                                    {{ method_field('delete') }}
                                                    {{ csrf_field() }}
                                                    <button class="btn btn-danger btn-xs del-confirm" data-msg="@lang('backend.confirm_delete')">
                                                        <i class="fa fa-trash-o "></i>
                                                    </button>
                                                </form>
                                            </td>
                                            @endif
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>
            <div class="pagination">
                {{ $pages->appends(Request::except('page'))->links() }}
            </div>
        </div>
    </div>
</div>
@stop
