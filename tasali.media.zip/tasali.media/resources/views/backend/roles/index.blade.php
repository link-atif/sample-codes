@extends('backend')

@section('content')
<div class="page-head">
    <h3 class="m-b-less">
        All Privileges
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li class="active">All Privileges</li>
        </ol>
    </div>
</div>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            @include('backend.roles.filter_form')
            @include('backend.partials.flash')
            <section class="panel">
                <header class="panel-heading head-border">
                    All Privileges {!! isset($count) ? "<span class='label label-success'>{$count}</span>" : null !!}
                </header>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($roles as $role)
                            <tr>
                                <td>{{ $role->label }}</td>
                                <td>
                                    <ul class="list-unstyled list-inline">
                                        <li>
                                            <a href="{{ route('Backend::roles.edit', $role->id) }}" class="btn btn-primary btn-xs">
                                                <i class="fa fa-pencil"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <form action="{{ route('Backend::roles.destroy', $role->id) }}" method="post">
                                                {{ method_field('delete') }}
                                                {{ csrf_field() }}
                                                <button class="btn btn-danger btn-xs del-confirm" data-msg="@lang('backend.confirm_delete')">
                                                    <i class="fa fa-trash-o "></i>
                                                </button>
                                            </form>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>
            {{ $roles->appends(Request::except('page'))->links() }}
        </div>
    </div>
</div>
@endsection
