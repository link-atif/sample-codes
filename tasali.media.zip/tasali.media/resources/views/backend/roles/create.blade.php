@extends('backend')

@section('content')
<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Create new Role
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::roles.index') }}">roles</a></li>
            <li class="active"> create Role </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Create Role
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form method="post" action="{{ route('Backend::roles.store') }}" class="cmxform form-horizontal tasi-form">
                            {!! csrf_field() !!}
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="label" value="{{ old('label') }}" class="form-control">
                                </div>
                            </div>
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Permissions</label>
                                <div class="col-lg-5">
                                    <table class="table">
                                        @foreach ($permissions as $value)
                                            <tr>
                                                <td>{{ $value['label'] }}</td>
                                                @foreach ($value['permissions'] as $permission)
                                                    <td class="text-center">
                                                        @if (!empty($permission['id']))
                                                            <div class="icheck checkbox-inline">
                                                                <label>{{ $permission['name'] }}</label>
                                                                <input type="checkbox" name="permissions[]" value="{{ $permission['id'] }}" checked>
                                                            </div>
                                                        @endif
                                                    </td>
                                                @endforeach
                                            </tr>
                                        @endforeach
                                    </table>
                                </div>
                            </div>
                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->
@endsection
