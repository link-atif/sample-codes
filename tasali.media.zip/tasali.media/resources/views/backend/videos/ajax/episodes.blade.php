@if (count($episodes) > 0)
    @foreach ($episodes as $episode)
        <option value="{{ $episode->id }}">
            {{ $episode->translate('en')->title }}
        </option>
    @endforeach
@endif