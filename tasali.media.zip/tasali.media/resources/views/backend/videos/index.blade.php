@extends('backend')

@section('content')
<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Create new video
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::videos.index') }}">Videos</a></li>
            <li class="active"> Create video </li>
        </ol>
    </div>
</div>
<!-- page head end-->
<!--body wrapper start-->
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            @include('backend.partials.error')
            <section class="panel">
                <header class="panel-heading">
                    Create Video
                </header>
                <div class="panel-body">
                    <div class="form-group">
                        <div class="col-md-4">
                            <div class="text-center">
                                <div id="resumable-error" style="display: none">
                                    Resumable not supported
                                </div>
                                <div id="resumable-drop" style="display: none">
                                    <button id="resumable-browse" data-url="{{ route('Backend::videos.store') }}" >Upload</button> or drop here
                                </div>
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            </div>
                        </div>
                        <div class="col-md-8">
                            <ul id="file-upload-list" class="list-unstyled"  style="display: none"></ul>
                        </div>
                    </div>
                </div>
            </section>

            <section class="panel">
                <header class="panel-heading head-border">
                    All Videos
                </header>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($videos as $video)
                            <tr>
                                <td>{{ $video->original_title }}</td>
                                <td>
                                    <table class="table-actions">
                                        <tr>
                                            @if(in_array('videos-edit', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                                <td>
                                                    <a href="{{ route('Backend::videos.edit', $video->id) }}" class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></a>
                                                </td>
                                            @endif
                                            @if(in_array('videos-delete', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                                <td>
                                                    <form action="{{ route('Backend::videos.destroy', $video->id) }}" method="post">
                                                        {{ method_field('delete') }}
                                                        {{ csrf_field() }}
                                                        <button class="btn btn-danger btn-xs del-confirm" data-msg="@lang('backend.confirm_delete')">
                                                            <i class="fa fa-trash-o "></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            @endif
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>
            <div class="pagination">
                {{ $videos->appends(Request::except('page'))->links() }}
            </div>
        </div>
    </div>
</div>
@endsection