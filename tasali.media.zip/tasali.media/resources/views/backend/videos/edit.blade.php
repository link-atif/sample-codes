@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Update
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::videos.index') }}">Videos</a></li>
            <li class="active"> Edit video </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Edit video: {{ $video->original_title }}
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::videos.update', $video->id) }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            {{ method_field('put') }}
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="original_title" value="{{ $video->original_title }}" class="form-control">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="type" class="control-label col-lg-2">Video or Trailer?</label>
                                <div class="col-lg-5">
                                    <select class="form-control" name="type" id="type">
                                        <option value="video" {{ in_array($video->parent_type, ['movie', 'show']) ? 'selected' : '' }}>
                                            Video
                                        </option>
                                        <option value="trailer" {{ !in_array($video->parent_type, ['movie', 'show']) ? 'selected' : '' }}>
                                            Trailer
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="parent_type" class="control-label col-lg-2">Show or Movie</label>
                                <div class="col-lg-5">
                                    <select class="form-control" name="parent_type" id="parent_type" data-url="{{ route('Backend::videos.type') }}">
                                        <option value="none" {{ $video->parent_type == null ? 'selected' : '' }}>
                                            none
                                        </option>
                                        <option value="movie" {{ in_array($video->parent_type, ['movie', 'trailer_movie']) ? 'selected' : '' }}>
                                            Movie
                                        </option>
                                        <option value="show" {{ in_array($video->parent_type, ['show', 'trailer_show']) ? 'selected' : '' }}>
                                            Show
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group selection" id="shows" {!! in_array($video->parent_type, ['show', 'trailer_show']) ? '' : 'style="display:none;"' !!}>
                                <label for="name" class="control-label col-lg-2">shows</label>
                                <div class="col-lg-5">
                                    <select class="form-control" name="show" id="show" data-url="{{ route('Backend::videos.episodes') }}">
                                        <option value="none">none</option>
                                        @foreach ($shows as $show)
                                        <option value="{{ $show->id }}" {{ isset($showId) && $show->id == $showId ? 'selected' : '' }}>
                                                {{ $show->translate('en')->title }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-group selection" id="episodes" {!! in_array($video->parent_type, ['show', 'trailer_show']) ? '' : 'style="display:none;"' !!}>
                                <label for="episode" class="control-label col-lg-2">Episode</label>
                                <div class="col-lg-5">
                                    <select class="form-control" name="episode" id="episode">
                                        <option value="none">none</option>
                                        @if (isset($episodes) && count($episodes) > 0)
                                        @foreach ($episodes as $episode)
                                            <option value="{{ $episode->id }}" {{ $episode->id == $video->parent ? 'selected' : '' }}>
                                                {{ $episode->translate('en')->title }}
                                            </option>
                                        @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>

                            <div class="form-group selection" id="movies" {!! in_array($video->parent_type, ['movie', 'trailer_movie']) ? '' : 'style="display:none;"' !!}>
                                <label for="movie" class="control-label col-lg-2">Movie</label>
                                <div class="col-lg-5">
                                    <select class="form-control select2" name="movie" id="movie">
                                        <option value="none">none</option>
                                        @foreach ($movies as $movie)
                                            <option value="{{ $movie->id }}" 
                                            {{ in_array($video->parent_type, ['movie', 'trailer_movie']) && $video->parent == $movie->id ? 'selected' : '' }}>
                                                {{ $movie->translate('en')->title }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->
@endsection

@section('script')
    <script>
        $(document).ready(function() {
            $('#parent_type').change(function(event) {
                event.preventDefault();
                var type = $(this).val();

                $('.selection').fadeOut('fast');
                $('.selection select').val('none').change();

                if (type == 'movie') {    
                    $('#movies').fadeIn('fast');
                } else if(type == 'show') {
                    $('#shows, #episodes').fadeIn('fast');
                }
            });

            $('#show').change(function(event) {
                event.preventDefault();
                $.ajax({
                    type: 'POST',
                    dataType: 'json',
                    url: $(this).attr('data-url'),
                    data: { id: $(this).val() },
                    success: function(result) {
                        $('#episode').html(result.data);
                    },
                    error: function() {
                        alert('error');
                    }
                });
            });
        });
    </script>
@endsection
