@extends('backend')

@section('content')
<style type="text/css">
    .dashboard-data:hover{
        opacity: 0.5;
    }
</style>

<!-- page head start-->
<div class="page-head">
    <h3>{{ $page_title }}</h3>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">
    <div class="row">
        <a href="{{ route('Backend::topWatching') }}">
            <div class="col-md-4 col-xl-4">
                <div class="dashboard-data blue-background">
                    <div class="counts-padding">
                        <div class="widget-content-left">
                            <h1 class="text-center text-size"><i class="fa fa-video-camera"></i></h1>
                            <h2 class="text-center">Top Watching Titles </h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
       <a href="{{ route('Backend::allFiles') }}">
            <div class="col-md-4 col-xl-4">
                <div class="dashboard-data orange-background">
                    <div class="counts-padding">
                        <div class="widget-content-left">
                            <h1 class="text-center text-size"><i class="fa fa-file"></i></h1>
                            <h2 class="text-center">All Files </h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        <a href="{{ route('Backend::allUsers') }}">
            <div class="col-md-4 col-xl-4">
                <div class="dashboard-data red-background">
                    <div class="counts-padding">
                        <div class="widget-content-left">
                            <h1 class="text-center text-size"><i class="fa fa-users"></i></h1>
                            <h2 class="text-center">All Users</h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    <div class="row" style="margin-top: 10px;">
        <a href="{{ route('Backend::uploadedToday') }}">
            <div class="col-md-4 col-xl-4">
                <div class="dashboard-data green-background">
                    <div class="counts-padding">
                        <div class="widget-content-left">
                            <h1 class="text-center text-size"><i class="fa fa-cloud-upload"></i></h1>
                            <h2 class="text-center">Uploaded Today </h2>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>
<!--body wrapper end-->
@endsection