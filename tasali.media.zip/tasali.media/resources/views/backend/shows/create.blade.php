@extends('backend')
@section('content')
<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Create new show
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::shows.index') }}">Shows</a></li>
            <li class="active"> Create show </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Create show
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::shows.store') }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="name" class="control-label col-lg-3">Title</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="title" value="{{ old('title') }}" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <label for="name" class="control-label col-lg-3">Arabic Title</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="ar_title" value="{{ old('ar_title') }}" class="form-control" placeholder="العنوان بالعربى">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="name" class="control-label col-lg-3">Genre</label>
                                        <div class="col-lg-9">
                                            <select class="form-control js-example-basic-multiple" name="genres[]" multiple>
                                                @foreach ($genres as $genre)
                                                    <option value="{{ $genre->id }}">{{ $genre->title }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="name" class="control-label col-lg-3">Cast</label>
                                        <div class="col-lg-9">
                                            <select class="form-control js-example-basic-multiple" name="casts[]" multiple>
                                                @foreach ($casts as $cast)
                                                    <option value="{{ $cast->id }}">
                                                        {{ $cast->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Seasons #</label>
                                        <div class="col-lg-9">
                                            <input type="number" name="season" min="1" value="{{ empty(old('season')) ? 1 : old('season') }}" class="form-control">
                                        </div>
                                    </div>
                                
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">IMDB Url</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="imdb_url" value="{{ old('imdb_url') }}"
                                                   placeholder="" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Production Year</label>
                                        <div class="col-lg-9">
                                            <input type="number" name="production" value="{{ old('production') }}" placeholder="2016" class="form-control">
                                        </div>
                                    </div>
                                
                                    <div class="col-lg-6">
                                        <label class="control-label col-lg-3">Publish Date</label>
                                        <div class="col-lg-9">
                                            <input class="form-control form-control-inline input-medium default-date-picker" type="text" name="publish_date" />
                                            <span class="help-block">Select date</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Age</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="age" value="{{ old('age') }}" placeholder="18+" class="form-control">
                                        </div>
                                    </div>
                                
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Publish Country</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="publish_country" value="{{ old('publish_country') }}" placeholder="egypt" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Arabic Publish Country</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="ar_publish_country" value="{{ old('ar_publish_country') }}" placeholder="مصر" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Description</label>
                                        <div class="col-lg-9">
                                            <textarea name="desc" rows="8" class="form-control">{{ old('desc') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Arabic Description</label>
                                        <div class="col-lg-9">
                                            <textarea name="ar_desc" rows="8" class="form-control">{{ old('ar_desc') }}</textarea>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <label for="poster" class="control-label col-lg-3">Poster</label>
                                        <div class="col-lg-9">
                                            <div class="image_style">
                                                Choose a image
                                                <input type="file" id="poster" name="poster" class="hide_file" onchange="encodeImageFileAsURL('poster','poster_preview','');">
                                            </div>
                                            <div style="padding-top: 5px;" id="poster_preview"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="poster" class="control-label col-lg-3">Wide Image</label>
                                        <div class="col-lg-9">
                                            <div class="image_style">
                                                Choose a image
                                                <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','');">
                                            </div>
                                            <div style="padding-top: 5px;" id="image_preview"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Meta Tags</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="meta_tags" value="{{ old('meta_tags') }}" placeholder="Meta Tags"  class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Meta Description</label>
                                        <div class="col-lg-9">
                                            <textarea name="meta_description" rows="8" class="form-control">{{ old('meta_description') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->

@endsection