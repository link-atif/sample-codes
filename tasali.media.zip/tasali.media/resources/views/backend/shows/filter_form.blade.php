<div class="row">
    <form class="" action="{{ route('Backend::shows.filter') }}" method="get">
        <div class="col-lg-2">
            <select class="form-control select2" name="genre">
                <option value="all">All Genres</option>
                @foreach ($genres as $genre)
                    <option value="{{ $genre->id }}" {{ Request::input('genre') == $genre->id ? 'selected' : null }}>
                        {{ $genre->translate('en')->title }}
                    </option>
                @endforeach
            </select>
        </div>
        <div class="col-lg-2 pull-right">
            <button type="submit" class="btn btn-primary btn-block pull-right">Filter & Search</button>
        </div>
        <div class="col-lg-3 pull-right">
                <input type="text" name="keyword" value="{{ (Request::input('keyword'))?? "" }}" placeholder="search..."
                       class="form-control">
            </div>
    </form>
</div>
<br>