@extends('backend')

@section('content')
    <!-- page head start-->
    <div class="page-head">
        <h3 class="m-b-less">
            Update {{ $movie->title }}
        </h3>
        <!--<span class="sub-title">Welcome to Static Table</span>-->
        <div class="state-information">
            <ol class="breadcrumb m-b-less bg-less">
                <li><a href="{{ route('Backend::home') }}">Home</a></li>
                <li><a href="{{ route('Backend::movies.index') }}">Movies</a></li>
                <li class="active"> Update {{ $movie->title }} </li>
            </ol>
        </div>
    </div>
    <!-- page head end-->

    <!--body wrapper start-->
    <div class="wrapper">

        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Update {{ $movie->title }}
                    </header>
                    <div class="panel-body">
                        @include('backend.partials.error')
                        <div class="form">
                            <form class="cmxform form-horizontal tasi-form"
                                  action="{{ route('Backend::movies.update', $movie->id) }}" method="post"
                                  enctype="multipart/form-data">
                                {{ csrf_field() }}
                                {{ method_field('put') }}
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Title</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="title" value="{{ $movie->translate('en')->title }}"
                                                       class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Genre</label>
                                            <div class="col-lg-9">
                                                <select class="form-control js-example-basic-multiple" name="genres[]" multiple>
                                                    @php
                                                        $genres_id = old('genres') ?? ($movie->genres->pluck('id')->toArray() ?? []);
                                                    @endphp
                                                    @foreach ($genres as $genre)
                                                        <option value="{{ $genre->id }}" {{(in_array($genre->id, $genres_id))?"selected":""}}>
                                                            {{ $genre->title }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Arabic Title</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="ar_title" value="{{ $movie->translate('ar')->title }}"
                                                       class="form-control" placeholder="العنوان بالعربى">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Cast</label>
                                            <div class="col-lg-9">
                                                <select class="form-control js-example-basic-multiple" name="casts[]" multiple>
                                                    @php
                                                        $casts_id = old('casts') ?? ($movie->casts->pluck('id')->toArray() ?? []);
                                                    @endphp
                                                    @foreach ($casts as $cast)
                                                        <option value="{{ $cast->id }}" {{(in_array($cast->id,$casts_id))?"selected":""}}>
                                                            {{ $cast->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">IMDB Url</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="imdb_url" value="{{ $movie->imdb_url }}"
                                                       placeholder="" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Production Year</label>
                                            <div class="col-lg-9">
                                                <input type="number" name="production" value="{{ $movie->production }}"
                                                       placeholder="2016" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Movie Duration (seconds)</label>
                                            <div class="col-lg-9">
                                                <input type="number" min="0" name="length" value="{{ $movie->length }}"
                                                       placeholder="120" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label class="control-label col-lg-3">Publish Date</label>
                                            <div class="col-lg-9">
                                                <input type="text" class="form-control form-control-inline input-medium default-date-picker" value="{{ $movie->publish_date }}" name="publish_date"/>
                                                <span class="help-block">Select date</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Age</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="age" value="{{ $movie->age }}" placeholder="18+"
                                                       class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Publish Country</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="publish_country"
                                                       value="{{ $movie->translate('en')->publish_country }}"
                                                       placeholder="egypt" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Arabic Publish Country</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="ar_publish_country"
                                                       value="{{ $movie->translate('ar')->publish_country }}" placeholder="مصر"
                                                       class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Description</label>
                                            <div class="col-lg-9">
                                                <textarea name="desc" rows="8"
                                                          class="form-control">{{ $movie->translate('en')->desc }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Arabic Description</label>
                                            <div class="col-lg-9">
                                                <textarea name="ar_desc" rows="8" class="form-control">{{ $movie->translate('ar')->desc }}</textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="poster" class="control-label col-lg-3">Poster</label>
                                            <div class="col-lg-9">
                                                <div class="image_style">
                                                    Choose a image
                                                    <input type="file" name="poster" id="poster" class="hide_file" onchange="encodeImageFileAsURL('poster','poster_preview','old_poster');">
                                                </div>
                                                <small class="text-danger">@lang('backend.image_change_warning')</small><br><br><br>
                                                <div id="poster_preview"></div>
                                                <div id="old_poster">
                                                @if($movie->poster !="")
                                                    <img width="100px" height="100px" src="{{ thumb($movie->poster) }}">
                                                @endif
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="poster" class="control-label col-lg-3">Wide Image</label>
                                            <div class="col-lg-9">
                                                <div class="image_style">
                                                    Choose a image
                                                    <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','old_image');">
                                                </div>
                                                <small class="text-danger">@lang('backend.image_change_warning')</small><br><br><br>
                                                <div id="image_preview"></div>
                                                <div id="old_image">
                                                @if($movie->poster !="")
                                                    <img width="200px" height="100px" src="{{ thumb($movie->image) }}">
                                                @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Movie File</label>
                                            <div class="col-lg-9">
                                                <select class="form-control select2" name="video_id">                                            
                                                    <option value="">Select Video</option>
                                                    @foreach ($videos as $v)
                                                        <option value="{{ $v->id }}" {{ (isset($movie->video->id) && $movie->video->id == $v->id)?"selected":""}}>
                                                            {{ $v->original_title }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Meta Tags</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="meta_tags" value="{{ $movie->meta_tags }}" placeholder="Meta Tags"  class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Meta Description</label>
                                            <div class="col-lg-9">
                                                <textarea name="meta_description" rows="8" class="form-control">{{ $movie->meta_description }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-success" type="submit">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </div>
    <!--body wrapper end-->


@endsection
