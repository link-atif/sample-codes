@extends('backend')

@section('content')
<style type="text/css">
    .stepwizard-step p {
        margin-top: 0px;
        color:#666;
    }
    .stepwizard-row {
        display: table-row;
    }
    .stepwizard {
        display: table;
        width: 100%;
        position: relative;
    }
    .stepwizard-step button[disabled] {
        /*opacity: 1 !important;
        filter: alpha(opacity=100) !important;*/
    }
    .stepwizard .btn.disabled, .stepwizard .btn[disabled], .stepwizard fieldset[disabled] .btn {
        opacity:1 !important;
        color:#bbb;
    }
    .stepwizard-row:before {
        top: 14px;
        bottom: 0;
        position: absolute;
        content:" ";
        width: 100%;
        height: 1px;
        background-color: #ccc;
        z-index: 0;
    }
    .stepwizard-step {
        display: table-cell;
        text-align: center;
        position: relative;
    }
    .btn-circle {
        width: 30px;
        height: 30px;
        text-align: center;
        padding: 6px 0;
        font-size: 12px;
        line-height: 1.428571429;
        border-radius: 15px;
    }
</style>
    <!-- page head start-->
    <div class="page-head">
        <h3 class="m-b-less">
            Create new movie
        </h3>
        <!--<span class="sub-title">Welcome to Static Table</span>-->
        <div class="state-information">
            <ol class="breadcrumb m-b-less bg-less">
                <li><a href="{{ route('Backend::home') }}">Home</a></li>
                <li><a href="{{ route('Backend::movies.index') }}">Movies</a></li>
                <li class="active"> Create movie</li>
            </ol>
        </div>
    </div>
    <!-- Start Tabs  -->
        <div class="container">
    <div class="stepwizard">
        <div class="stepwizard-row setup-panel">
            <div class="stepwizard-step col-xs-3"> 
                <a href="#step-1" type="button" class="btn btn-success btn-circle">1</a>
                <p><small>Shipper</small></p>
            </div>
            <div class="stepwizard-step col-xs-3"> 
                <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
                <p><small>Destination</small></p>
            </div>
            <div class="stepwizard-step col-xs-3"> 
                <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
                <p><small>Schedule</small></p>
            </div>
            <div class="stepwizard-step col-xs-3"> 
                <a href="#step-4" type="button" class="btn btn-default btn-circle" disabled="disabled">4</a>
                <p><small>Cargo</small></p>
            </div>
        </div>
    </div>
    
    <form role="form">
        <div class="panel panel-primary setup-content" id="step-1">
            <div class="panel-heading">
                 <h3 class="panel-title">Shipper</h3>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="control-label">First Name</label>
                    <input maxlength="100" type="text" required="required" class="form-control" placeholder="Enter First Name" />
                </div>
                <div class="form-group">
                    <label class="control-label">Last Name</label>
                    <input maxlength="100" type="text" required="required" class="form-control" placeholder="Enter Last Name" />
                </div>
                <button class="btn btn-primary nextBtn pull-right" type="button">Next</button>
            </div>
        </div>
        
        <div class="panel panel-primary setup-content" id="step-2">
            <div class="panel-heading">
                 <h3 class="panel-title">Destination</h3>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="control-label">Company Name</label>
                    <input maxlength="200" type="text" required="required" class="form-control" placeholder="Enter Company Name" />
                </div>
                <div class="form-group">
                    <label class="control-label">Company Address</label>
                    <input maxlength="200" type="text" required="required" class="form-control" placeholder="Enter Company Address" />
                </div>
                <button class="btn btn-primary nextBtn pull-right" type="button">Next</button>
            </div>
        </div>
        
        <div class="panel panel-primary setup-content" id="step-3">
            <div class="panel-heading">
                 <h3 class="panel-title">Schedule</h3>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="control-label">Company Name</label>
                    <input maxlength="200" type="text" required="required" class="form-control" placeholder="Enter Company Name" />
                </div>
                <div class="form-group">
                    <label class="control-label">Company Address</label>
                    <input maxlength="200" type="text" required="required" class="form-control" placeholder="Enter Company Address" />
                </div>
                <button class="btn btn-primary nextBtn pull-right" type="button">Next</button>
            </div>
        </div>
        
        <div class="panel panel-primary setup-content" id="step-4">
            <div class="panel-heading">
                 <h3 class="panel-title">Cargo</h3>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="control-label">Company Name</label>
                    <input maxlength="200" type="text" required="required" class="form-control" placeholder="Enter Company Name" />
                </div>
                <div class="form-group">
                    <label class="control-label">Company Address</label>
                    <input maxlength="200" type="text" required="required" class="form-control" placeholder="Enter Company Address" />
                </div>
                <button class="btn btn-success pull-right" type="submit">Finish!</button>
            </div>
        </div>
    </form>
</div>

    <!-- End Tabs  -->
    <!-- page head end-->

    <!--body wrapper start-->
    <div class="wrapper">

        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Create movie
                    </header>
                    <div class="panel-body">
                        @include('backend.partials.error')
                        <div class="form">
                            <form class="cmxform form-horizontal tasi-form"
                                  action="{{ route('Backend::movies.store') }}" method="post"
                                  enctype="multipart/form-data">
                                {{ csrf_field() }}
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Title</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="title" value="{{ old('title') }}" class="form-control"
                                                       placeholder="English title">
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Genre</label>
                                            <div class="col-lg-9">
                                                <select class="form-control js-example-basic-multiple" name="genres[]" id="genres" multiple>
                                                    @foreach ($genres as $genre)
                                                    <option value="{{ $genre->id }}" {{ (collect(old('genres'))->contains($genre->id)) ? 'selected':'' }}>
                                                        {{ $genre->title }}
                                                    </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Arabic Title</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="ar_title" value="{{ old('ar_title') }}"
                                                       class="form-control" placeholder="العنوان بالعربى">
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Cast</label>
                                            <div class="col-lg-9">
                                                <select class="form-control js-example-basic-multiple" name="casts[]" multiple>
                                                    @foreach ($casts as $cast)
                                                        <option value="{{ $cast->id }}" {{ (collect(old('casts'))->contains($cast->id)) ? 'selected':'' }}>
                                                            {{ $cast->name }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">IMDB Url</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="imdb_url" value="{{ old('imdb_url') }}"
                                                       placeholder="" class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                
                                            <label for="seasons" class="control-label col-lg-3">Production Year</label>
                                            <div class="col-lg-9">
                                                <input type="number" name="production" value="{{ old('production') }}"
                                                       placeholder="2016" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Movie Duration (seconds)</label>
                                            <div class="col-lg-9">
                                                <input type="number" min="0" name="length" value="{{ old('length') }}"
                                                    placeholder="120" class="form-control">
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-6">
                                            <label class="control-label col-lg-3">Publish Date</label>
                                            <div class="col-lg-9">
                                                <input class="form-control form-control-inline input-medium default-date-picker"
                                                    type="text" name="publish_date" value="{{ old('publish_date') }}"/>
                                                <span class="help-block">Select date</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                
                                            <label for="seasons" class="control-label col-lg-3">Age</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="age" value="{{ old('age') }}" placeholder="18+"
                                                       class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                
                                            <label for="seasons" class="control-label col-lg-3">Publish Country</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="publish_country" value="{{ old('publish_country') }}"
                                                       placeholder="egypt" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Arabic Publish Country</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="ar_publish_country" value="{{ old('ar_publish_country') }}" placeholder="مصر"  class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                        
                                            <label for="seasons" class="control-label col-lg-3">Description</label>
                                            <div class="col-lg-9">
                                                <textarea name="desc" rows="8" class="form-control">{{ old('desc') }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Arabic Description</label>
                                            <div class="col-lg-9">
                                                <textarea name="ar_desc" rows="8"
                                                          class="form-control">{{ old('ar_desc') }}</textarea>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">

                                            <label for="poster" class="control-label col-lg-3">Poster</label>
                                            <div class="col-lg-9">
                                                <div class="image_style">
                                                    Choose a Image
                                                    <input type="file" id="poster" name="poster" class="hide_file" onchange="encodeImageFileAsURL('poster','poster_preview','');">
                                                </div>
                                                <div style="padding-top: 5px;" id="poster_preview"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="poster" class="control-label col-lg-3">Wide Image</label>
                                            <div class="col-lg-9">
                                                <div class="image_style">
                                                    Choose a Image
                                                    <input type="file" id="image" name="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','');">
                                                </div>
                                                <div style="padding-top: 5px;" id="image_preview"></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <label for="name" class="control-label col-lg-3">Movie File</label>
                                            <div class="col-lg-9">
                                                <select class="form-control select2" name="video_id">                                            
                                                    <option value="">Select Video</option>
                                                    @foreach ($videos as $v)
                                                        <option value="{{ $v->id }}">
                                                            {{ $v->original_title }}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Meta Tags</label>
                                            <div class="col-lg-9">
                                                <input type="text" name="meta_tags" value="{{ old('meta_tags') }}" placeholder="Meta Tags"  class="form-control">
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <label for="seasons" class="control-label col-lg-3">Meta Description</label>
                                            <div class="col-lg-9">
                                                <textarea name="meta_description" rows="8" class="form-control">{{ old('meta_description') }}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-success" type="submit">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </div>
    <!--body wrapper end-->


@endsection