<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Manage Episodes : {{ $show_name }}
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::episodes.store') }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <input type="hidden" name="show_id" value="{{ $show_id }}">
                            <input type="hidden" name="show_details" value="yes">
                            <div class="form-group ">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="name" class="control-label col-lg-3">Title</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="title" value="{{ old('title') }}" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="name" class="control-label col-lg-3">Movie File</label>
                                        <div class="col-lg-9">
                                            <select class="form-control select2" name="video_id">                                            
                                                <option value="">Select Video</option>
                                                @foreach ($videos as $v)
                                                    <option value="{{ $v->id }}">
                                                        {{ $v->original_title }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="name" class="control-label col-lg-3">Arabic Title</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="ar_title" value="{{ old('ar_title') }}" class="form-control" placeholder="العنوان بالعربى">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Season</label>
                                        <div class="col-lg-9">
                                            <input type="number" class="form-control" name="season" value="1">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="seasons" class="control-label col-lg-3">Episode Duration (seconds)</label>
                                        <div class="col-lg-9">
                                            <input type="number" name="length" value="{{ old('length') }}" placeholder="120" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="image_id" class="control-label col-lg-3">Image</label>
                                        <div class="col-lg-9">
                                            <div class="image_style" style="padding: 25px 125px">
                                                Choose a image
                                                <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','');">
                                            </div>
                                            <div style="padding-top: 5px;" id="image_preview"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <label for="meta_tags" class="control-label col-lg-3">Meta Tags</label>
                                        <div class="col-lg-9">
                                            <input type="text" name="meta_tags" value="{{ old('meta_tags') }}" placeholder="Meta Tags" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <label for="meta_description" class="control-label col-lg-3">Meta Description</label>
                                        <div class="col-lg-9">
                                            <textarea name="meta_description" class="form-control" rows="6">{{ old('meta_description') }}</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-6">

                                    </div>
                                </div>
                            </div>
                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Add Episode</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->
