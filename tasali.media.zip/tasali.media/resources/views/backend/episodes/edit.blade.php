@extends('backend')

@section('content')

    <!-- page head start-->
    <div class="page-head">
        <h3 class="m-b-less">
            Update {{ $episode->title }}
        </h3>
        <!--<span class="sub-title">Welcome to Static Table</span>-->
        <div class="state-information">
            <ol class="breadcrumb m-b-less bg-less">
                <li><a href="{{ route('Backend::home') }}">Home</a></li>
                <li><a href="{{ route('Backend::episodes.index') }}">Episodes</a></li>
                <li class="active"> Update {{ $episode->title }} </li>
            </ol>
        </div>
    </div>
    <!-- page head end-->

    <!--body wrapper start-->
    <div class="wrapper">

        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Update {{ $episode->title }}
                    </header>
                    <div class="panel-body">
                        @include('backend.partials.error')
                        <div class="form">
                            <form class="cmxform form-horizontal tasi-form"
                                  action="{{ route('Backend::episodes.update', $episode->id) }}" method="post"
                                  enctype="multipart/form-data">
                                {{ csrf_field() }}
                                {{ method_field('put') }}
                                <div class="form-group ">
                                    <label for="name" class="control-label col-lg-2">Title</label>
                                    <div class="col-lg-5">
                                        <input type="text" name="title" value="{{ $episode->translate('en')->title }}"
                                               class="form-control">
                                    </div>
                                </div>

                                <div class="form-group ">
                                    <label for="name" class="control-label col-lg-2">Arabic Title</label>
                                    <div class="col-lg-5">
                                        <input type="text" name="ar_title"
                                               value="{{ $episode->translate('ar')->title }}" class="form-control"
                                               placeholder="العنوان بالعربى">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Show</label>
                                    <div class="col-lg-5">
                                        <select class="form-control" name="show_id">
                                            @foreach ($shows as $show)
                                                <option value="{{ $show->id }}" {{ $episode->show_id == $show->id ? 'selected' : null }}>
                                                    {{ $show->title }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="image_id" class="control-label col-lg-2">Image</label>
                                    <div class="col-lg-5">
                                        <div class="image_style" style="padding: 25px 164px">
                                            Choose a image
                                            <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','old_image');">
                                        </div>
                                        <small class="text-danger">@lang('backend.image_change_warning')</small><br><br><br>
                                        <div id="image_preview"></div>
                                        <div id="old_image">
                                        @if(!empty($episode->image))
                                            <img width="100px" height="100px" src="{{ thumb($episode->image) }}">
                                        @endif
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Season</label>
                                    <div class="col-lg-5">
                                        <input type="number" name="season" value="{{ $episode->season }}">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Movie Duration (seconds)</label>
                                    <div class="col-lg-5">
                                        <input type="number" name="length" value="{{ $episode->length or old('length') }}"
                                               placeholder="120" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Meta Tags</label>
                                    <div class="col-lg-5">
                                        <input type="text" name="meta_tags" value="{{ $episode->meta_tags }}" placeholder="Meta Tags"  class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="seasons" class="control-label col-lg-2">Meta Description</label>
                                    <div class="col-lg-5">
                                        <textarea name="meta_description" rows="8" class="form-control">{{ $episode->meta_description }}</textarea>
                                    </div>
                                </div>

                                <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                    <div class="col-lg-offset-2 col-lg-10">
                                        <button class="btn btn-success" type="submit">Save</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </div>
    <!--body wrapper end-->


@endsection
