@extends('backend')
@section('content')
<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 24px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
<div class="wrapper">
    <div class="row">
        <div class="col-lg-12">
            @include('backend.episodes.add_episode_form')
            <section class="panel">
                <header class="panel-heading head-border">
                    All episodes {!! isset($count) ? "<span class='label label-success'>{$count}</span>" : null !!}
                </header>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>title</th>
                                <th>Show</th>
                                <th>Actions</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($episodes as $episode)
                            <tr>
                                <td>{{ $episode->title }}</td>
                                <td>{{ $episode->show->translate('en')->title }}</td>
                                <td>
                                    <table class="table-actions">
                                        <tr>
                                            @if(in_array('episodes-edit', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                                <td>
                                                    <a href="{{ route('Backend::episodes.edit', $episode->id) }}" class="btn btn-primary btn-xs">
                                                        <i class="fa fa-pencil"></i>
                                                    </a>
                                                </td>
                                            @endif
                                            @if(in_array('episodes-delete', \Auth::user()->role->permissions->pluck('name')->toArray()))
                                                <td>
                                                    <form action="{{ route('Backend::episodes.destroy', $episode->id) }}" method="post">
                                                        {{ method_field('delete') }}
                                                        {{ csrf_field() }}
                                                        <button class="btn btn-danger btn-xs del-confirm" data-msg="@lang('backend.confirm_delete')">
                                                            <i class="fa fa-trash-o "></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            @endif
                                        </tr>
                                    </table>
                                </td>
                                <td>
                                    <label class="switch">
                                        <input type="checkbox" onclick="updateStatus('{{$episode->id}}','status')" id="status{{ $episode->id }}" {{ ($episode->status == 1) ? 'checked="checked"' : '' }}>
                                        <span class="slider round"></span>
                                    </label>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </section>
            <div class="pagination">
                {{ $episodes->appends(Request::except('page'))->links() }}
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function updateStatus(id, type){
      var status = 0;
      if($("#"+type+id).prop('checked')==true){ 
        status = 1;
      }
      $.ajax({
          type: 'POST',
          dataType: 'json',
          url: "{{ route('Backend::episodes.status') }}",
          data: {'id' : id, 'status': status, 'type' : type },
          success: function(result) {
              //alert("Status Updated Successfully!");
          },
          error: function() {
              alert('error');
          }
      });
      
    }
</script>
@stop
