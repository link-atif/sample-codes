<div class="row">
    <form class="" action="{{ route('Backend::episodes.filter') }}" method="get">
        <div class="col-lg-2">
            <select class="form-control select2" name="show">
                <option value="all">All Shows</option>
                @foreach ($shows as $show)
                    <option value="{{ $show->id }}" {{ Request::input('show') == $show->id ? 'selected' : null }}>
                        {{ $show->translate('en')->title }}
                    </option>
                @endforeach
            </select>
        </div>
        <div class="col-lg-2 pull-right">
            <button type="submit" class="btn btn-primary btn-block pull-right">Filter & search</button>
        </div>
        <div class="col-lg-3 pull-right">
            <input type="text" name="keyword" value="{{ (Request::input('keyword'))?? "" }}" placeholder="search..."
                    class="form-control">
        </div>
    </form>
</div>
<br>
