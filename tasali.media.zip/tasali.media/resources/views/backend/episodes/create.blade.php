@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Create new Episode
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::episodes.index') }}">Episodes</a></li>
            <li class="active"> Create episode </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Create episode
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::episodes.store') }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="title" value="{{ old('title') }}" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Arabic Title</label>
                                <div class="col-lg-5">
                                    <input type="text" name="ar_title" value="{{ old('ar_title') }}" class="form-control" placeholder="العنوان بالعربى">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="seasons" class="control-label col-lg-2">Show</label>
                                <div class="col-lg-5">
                                    <select class="form-control" name="show_id">
                                        @foreach ($shows as $show)
                                            <option value="{{ $show->id }}">{{ $show->title }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="image_id" class="control-label col-lg-2">Image</label>
                                <div class="col-lg-5">
                                    <div class="image_style" style="padding: 25px 164px">
                                        Choose a image
                                        <input type="file" name="image" id="image" class="hide_file" onchange="encodeImageFileAsURL('image','image_preview','');">
                                    </div>
                                    <div style="padding-top: 5px;" id="image_preview"></div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="seasons" class="control-label col-lg-2">Season</label>
                                <div class="col-lg-5">
                                    <input type="number" name="season" value="1">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="seasons" class="control-label col-lg-2">Episode Duration (seconds)</label>
                                <div class="col-lg-5">
                                    <input type="number" name="length" value="{{ old('length') }}"
                                           placeholder="120" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="name" class="control-label col-lg-2">Movie File</label>
                                <div class="col-lg-5">
                                    <select class="form-control select2" name="video_id">                                            
                                        <option value="">Select Video</option>
                                        @foreach ($videos as $v)
                                            <option value="{{ $v->id }}">
                                                {{ $v->original_title }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="seasons" class="control-label col-lg-2">Meta Tags</label>
                                <div class="col-lg-5">
                                    <input type="text" name="meta_tags" value="{{ old('meta_tags') }}" placeholder="Meta Tags"  class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="seasons" class="control-label col-lg-2">Meta Description</label>
                                <div class="col-lg-5">
                                    <textarea name="meta_description" rows="8" class="form-control">{{ old('meta_description') }}</textarea>
                                </div>
                            </div>
                                            
                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
<!--body wrapper end-->
@endsection