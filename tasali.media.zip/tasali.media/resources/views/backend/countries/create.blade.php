@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Create new Country
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::countries.index') }}">Countries</a></li>
            <li class="active"> Create Country </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Create Country
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::countries.store') }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Name</label>
                                <div class="col-lg-5">
                                    <input type="text" name="name" value="{{ old('name') }}" class="form-control">
                                </div>
                            </div>
                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Code</label>
                                <div class="col-lg-5">
                                    <input type="text" name="code" value="{{ old('code') }}" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Currency Code</label>
                                <div class="col-lg-5">
                                    <input type="text" name="curriency_code" value="{{ old('curriency_code') }}" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Amount</label>
                                <div class="col-lg-5">
                                    <input type="text" name="amount" value="{{ old('amount') }}" class="form-control">
                                </div>
                            </div>

                           <!--  <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Ongoing Amount</label>
                                <div class="col-lg-5">
                                    <input type="text" name="ongoing_amount" value="{{ old('ongoing_amount') }}" class="form-control">
                                </div>
                            </div> -->

                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->


@endsection
