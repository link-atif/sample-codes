@extends('backend')

@section('content')

<!-- page head start-->
<div class="page-head">
    <h3 class="m-b-less">
        Update {{ $country->name }}
    </h3>
    <!--<span class="sub-title">Welcome to Static Table</span>-->
    <div class="state-information">
        <ol class="breadcrumb m-b-less bg-less">
            <li><a href="{{ route('Backend::home') }}">Home</a></li>
            <li><a href="{{ route('Backend::countries.index') }}">Countries</a></li>
            <li class="active"> Update {{ $country->name }} </li>
        </ol>
    </div>
</div>
<!-- page head end-->

<!--body wrapper start-->
<div class="wrapper">

    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                    Update {{ $country->name }}
                </header>
                <div class="panel-body">
                    @include('backend.partials.error')
                    <div class="form">
                        <form class="cmxform form-horizontal tasi-form" action="{{ route('Backend::countries.update', $country->id) }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            {{ method_field('put') }}
                            <div class="form-group ">
                                <label for="name" class="control-label col-lg-2">Name</label>
                                <div class="col-lg-5">
                                    <input type="text" name="name" value="{{ $country->name }}" class="form-control">
                                </div>
                            </div>
                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Code</label>
                                <div class="col-lg-5">
                                    <input type="text" name="code" value="{{ $country->code }}" class="form-control">
                                </div>
                            </div>
                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Currency Code</label>
                                <div class="col-lg-5">
                                    <input type="text" name="curriency_code" value="{{ $country->curriency_code }}" class="form-control">
                                </div>
                            </div>

                            <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Amount</label>
                                <div class="col-lg-5">
                                    <input type="text" name="amount" value="{{ $country->amount }}" class="form-control">
                                </div>
                            </div>

<!--                             <div class="form-group ">
                                <label for="code" class="control-label col-lg-2">Ongoing Amount</label>
                                <div class="col-lg-5">
                                    <input type="text" name="ongoing_amount" value="{{ $country->ongoing_amount }}" class="form-control">
                                </div>
                            </div> -->
                            <div class="form-group" style="border-bottom: 0;padding-bottom: 0">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button class="btn btn-success" type="submit">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div>
<!--body wrapper end-->


@endsection
