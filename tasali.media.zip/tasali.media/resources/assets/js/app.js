
$(document).ready(function() {
	//Header
	$('.dropdown-button').dropdown({
		constrainWidth: true,
		belowOrigin: true,
	});

	//Header Swiper
	var swiper = new Swiper('.header-swiper', {
        pagination: '.swiper-pagination',
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        paginationClickable: true,
        spaceBetween: 0,
        centeredSlides: true,
        autoplay: 4000,
        autoplayDisableOnInteraction: false,
    });

    //General Swiper
	$('.general-swiper').each(function(index, el) {
		var generalSwiper = $(this).find('.swiper-container');
		var rightArrow = $(this).find('.general-swiper-right');
		var leftArrow =  $(this).find('.general-swiper-left');

		if (/Mobi/.test(navigator.userAgent)) {
			var numberOfSlidesView = 2;
		    // mobile!
		} else {
			var numberOfSlidesView = 7;
		}

		new Swiper(generalSwiper, {
			nextButton: rightArrow,
			prevButton: leftArrow,
			slidesPerView: numberOfSlidesView,
			centeredSlides: false,
			spaceBetween: 20,
		});
	});

	//Tabs
	$('ul.tabs').tabs();

	//Select Eposide
	$('select').material_select();
	$('.season-item').addClass('hide');
	var selectedSeason = 'season-1';
	$('.'+ selectedSeason).removeClass('hide');
	$('.episode-select').on('change','', function(event) {
		event.preventDefault();
		selectedSeason =  $(this).val();
		if (selectedSeason){
			$('.season-item').addClass('hide');

			$('.'+selectedSeason.toString()).removeClass('hide');
		} 
	});

	//Collapsible Grid Items
	$('.grid-items li a').click(function(event) {
		event.preventDefault();
		var thisElment = $(this);
		var newCollapsible = document.createElement("div");

		var appendCollapsible = function(){
			if (!$(thisElment.parent().children()[1]).hasClass('collapsible-view')){
				var movieTitle = thisElment.attr('data-title');
				var movieDesc = thisElment.attr('data-description');
				var movieLargeImg = thisElment.attr('data-largeimg');
				var movieUrl = thisElment.attr('href');
				var movieProduction = thisElment.attr('data-production');
				var movieAge = thisElment.attr('data-age');
				var movieDate = thisElment.attr('data-date');
				var movieCountry = thisElment.attr('data-country');

				$(newCollapsible).attr({
					class: 'collapsible-view card black',
					style: 'background-image: url('+movieLargeImg+')',
				});


				$(newCollapsible).html('\
					<div class="container">\
						<div class="collapsible-close right"><i class="material-icons">close</i></div>\
						<div class="row">\
							<div class="col s12 m8">\
								<div class="card-content">\
									<h4>'+movieTitle+'</h4>\
									<span class="main-text-color">'+movieProduction+', '+movieCountry+', '+movieAge+'+</span>\
									<p>'+movieDesc+'</p>\
								</div>\
								<div class="card-action">\
									<a class="btn btn-outline waves-effect waves-light" href="'+movieUrl+'"><i class="material-icons left">play_arrow</i> Play</a>\
									<a class="btn btn-outline waves-effect waves-light" href="'+movieUrl+'"><i class="material-icons left">play_circle_filled</i> Watch trailer</a>\
									<a class="btn btn-outline waves-effect waves-light" href="'+movieUrl+'"><i class="material-icons left">add</i> Add to my list</a>\
								</div>\
							</div>\
						</div>\
					</div>');
				thisElment.parent().append($(newCollapsible));

				thisElment.addClass('active');
				$('.grid-items li').height('auto');
				thisElment.parent().height(thisElment.parent().height()+$(newCollapsible).height()+15);

				$('html, body').animate({
					scrollTop: thisElment.offset().top-5
				}, 1000);
			}
		}

		if ($('.collapsible-view').length == 0) {
			appendCollapsible();
		} else {
			$('.collapsible-view').remove();
			$('.grid-items li a').removeClass('active');
			appendCollapsible();
		}

		$('.collapsible-close').click(function(event) {
			event.preventDefault();
			$('.collapsible-view').remove();
			$('.grid-items li').height('auto');
			$('.grid-items li a').removeClass('active');
		});

	});

	//SideNav
	$(".button-collapse").sideNav({
		menuWidth: 250, // Default is 300
	});

	$(document).on('click', "#play, .episode-play", function(event) {
		event.preventDefault();
		var url = $(this).attr('data-url');
		$.ajax({
			type: 'GET',
			dataType: 'json',
			url: url,
			success: function(result) {
				$('.header-movie').html(result.template);
			},
			error: function() {
				Materialize.toast('Video not found!', 4000,'red darken-4')
				// M.toast({html: 'there is an error, please try again later.'})
			}
		});
		return false;
	});

	$('.modal').modal({		
		ready: function(modal, trigger) {
			var url = trigger.attr('data-url');
			$.ajax({
				url: url,
				type: 'get',
				dataType: 'json',
				success: function(result) {
					$('#trailer .modal-content').html(result.template);
				},
				error: function() {
					Materialize.toast('404! video not found.', 4000,'red darken-4')
				}
			});
		},
		complete: function() {
			$('#trailer .modal-content').html('');
		}
	});



});
