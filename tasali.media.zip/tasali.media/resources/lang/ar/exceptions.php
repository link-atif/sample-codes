<?php
/**
 * Created by PhpStorm.
 * User: Backend Dev
 * Date: 3/6/2018
 * Time: 11:49 AM
 */
return [
    "query_exceptions"          => [
        "unique_email" => "The email has already been taken."
    ],
    "swift_transport_exception" => "mail authentication required",
    "forget_password"           => [
        "email" => 'We cant find an account with this email. Please make sure you entered the right information.'
    ],
    "login"                     => [
        "jwt_exception" => "Failed to login, please try again.",
        "credentials"   => 'We cant find an account with this credentials. Please make sure you entered the right information.'
    ]
];