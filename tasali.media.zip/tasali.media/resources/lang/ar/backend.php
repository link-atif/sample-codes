<?php

return [
    'success_store'        => 'Stored successfully.',
    'success_update'       => 'updated successfully.',
    'success_delete'       => 'Deleted successfully.',
    'error_store'          => 'Error while storing, try again later.',
    'error_update'         => 'Error while updating, try again later.',
    'error_delete'         => 'Error while deleteing, try again later.',
    'image_change_warning' => 'choosing image will change the old one.',
    'video_change_warning' => 'choosing video will change the old one.',
    'amount' => 'Amount.',
    'trial' => 'Trial.',
    'trial_amount' => 'Trial Amount',
    'subscription_duration' => 'Subscription Duration .',
    'landing_image' => 'Landing Image',
    'login_image' => 'Login Page Image',
    'extend_subscription' => 'Extend Subscription',
    'update_subscription' => 'Subscription has been extended Successfully!',
    'error_subscription' => 'There is no Primary card against this user!',
    'password_warning' => 'Passwords must be at least six characters and match the confirmation.'
];
