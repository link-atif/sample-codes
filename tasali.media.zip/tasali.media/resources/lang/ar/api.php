<?php
/**
 * Created by PhpStorm.
 * User: Backend Dev
 * Date: 3/6/2018
 * Time: 12:38 PM
 */

return [
    "forget_password" => [
        "success" => "تم",
    ],
    "login"           => [

    ],
    "register"        => [

    ],
    "home"            => [
        "trending"         => "الأكثر شيوعا",
        "recently"         => "Recently Added",
        "shows"            => "TV Shows",
        "coming"           => "Coming Soon",
        "continueWatching" => "Continue Watching"
    ],
    "validation"      => [
        "general_error" => "input errors",
        "min_or_equal"  => "The :attribute may not be least than or equal :parameters."
    ],
    "movie"           => "افلام",
    "series"          => "مسلسلات",
    "class_rename"    => [
        "movie" => "movie",
        "show"  => "series",
    ],
    "response_code"   => [
        1100 => "Sorry, this email used as a social account",

        4100 => 'We cant find an account with this email. Please make sure you entered the right information.',
        4101 => 'The email has already been taken.',

        4110 => 'We cant find an account with this credentials. Please make sure you entered the right information.',
        4111 => 'Your account has been expired. Please re-activate you account.',
        4112 => 'Failed to login, please try again.',
        4113 => 'Mail authentication required.',
        4114 => 'Unauthorized user.',

        200 => "success",
        400 => "error",
        404 => "not found"


    ],
    "variables"       => [
        "paused_at" => "paused_at",
        "duration"  => "duration"
    ]
];