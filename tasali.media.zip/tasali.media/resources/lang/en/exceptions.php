<?php
/**
 * Created by PhpStorm.
 * User: Backend Dev
 * Date: 3/6/2018
 * Time: 12:38 PM
 */

return [

    "NotFoundHttpException" => "Sorry, the page you are looking for could not be found.",
];